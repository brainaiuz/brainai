insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_IMPORT', 'SALESMAN', 'ALLOW');
