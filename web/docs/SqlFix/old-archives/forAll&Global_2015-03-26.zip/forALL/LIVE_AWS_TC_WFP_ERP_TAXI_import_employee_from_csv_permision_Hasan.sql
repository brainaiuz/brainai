insert into permission(code,context,"name",parent,modulecode) values
                       ('SHOW_IMPORT_EMPLOYEE','PM','Import Employee from csv', (select id from permission where code = 'PM_EMPLOYEE_REMOVE'),'PM');


insert into permission(code,context,"name",parent,modulecode) values
                       ('SHOW_IMPORT_EMPLOYEE_HRMS','HRMS','Import Employee from csv', (select id from permission where code = 'HRMS_EMPLOYEE_REMOVE'),'HRMS_MODULE');


-- for zero schema
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('SHOW_IMPORT_EMPLOYEE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('SHOW_IMPORT_EMPLOYEE_HRMS', 'ADMIN', 'ALLOW');



-- for all schema
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('SHOW_IMPORT_EMPLOYEE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('SHOW_IMPORT_EMPLOYEE_HRMS', 'ADMIN', 'ALLOW');