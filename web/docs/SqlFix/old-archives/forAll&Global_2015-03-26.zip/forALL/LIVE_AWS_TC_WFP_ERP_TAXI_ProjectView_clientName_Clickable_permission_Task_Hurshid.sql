insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CLIENT_NAME_CLICKABLE', 'PM', 'Client name clickable', '25', 'false', (select id from permission where code='PM_PROJECT_LIST'), 'false', 'TASK_MANAGEMENT');


insert into "0".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CLIENT_NAME_CLICKABLE', 'SALESMAN', 'ALLOW');
