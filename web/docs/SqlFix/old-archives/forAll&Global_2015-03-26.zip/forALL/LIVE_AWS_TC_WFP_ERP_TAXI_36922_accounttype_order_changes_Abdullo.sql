update accounttype set sorder = 1 where code ='BANK';
update accounttype set sorder = 2 where code ='SALES';
update accounttype set sorder = 3 where code ='REVENUE';
update accounttype set sorder = 4 where code ='OTHER_INCOME';
update accounttype set sorder = 5 where code ='COST_OF_SALES';
update accounttype set sorder = 6 where code ='DIRECT_EXPENSES';
update accounttype set sorder = 7 where code ='OVERHEAD';
update accounttype set sorder = 8 where code ='CURRENT_ASSET';
update accounttype set sorder = 9 where code ='FIXED_ASSET';
update accounttype set sorder = 10 where code ='LIABILITY';
update accounttype set sorder = 11 where code ='LONG_TERM_LIABILITY';
update accounttype set sorder = 12 where code ='CURRENT_LIABILITY';
update accounttype set sorder = 13 where code ='EQUITY';
update accounttype set sorder = 14 where code ='DEPRECIATION';
update accounttype set sorder = 15 where code ='PREPAYMENT';

