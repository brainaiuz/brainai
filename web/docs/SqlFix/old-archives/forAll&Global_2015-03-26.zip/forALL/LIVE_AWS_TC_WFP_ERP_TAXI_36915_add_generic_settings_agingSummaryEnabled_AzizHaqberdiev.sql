insert into "anv".genericSettings (key, value) values ('AGING_SUMMARY_ENABLED', 'NO');
--custom SED company uchun enable
update "45990".genericsettings set value = 'YES' where key = 'AGING_SUMMARY_ENABLED';