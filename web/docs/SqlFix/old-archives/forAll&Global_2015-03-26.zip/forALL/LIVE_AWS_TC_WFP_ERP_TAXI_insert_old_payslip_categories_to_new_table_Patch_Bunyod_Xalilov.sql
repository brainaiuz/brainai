
-- faqat bir marta urilsin
insert into "anv".payslip_payments(payment_deduction_id, payslip_id, payment_total) select pd.id, p.id, pd.paymentamount from "anv".paymentdeduction pd
inner join "anv".payslip p on p.id=pd.payslipid where p.deleted is not true;