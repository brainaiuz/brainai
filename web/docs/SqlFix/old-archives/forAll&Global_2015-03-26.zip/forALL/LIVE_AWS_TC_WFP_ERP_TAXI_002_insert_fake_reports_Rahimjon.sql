insert into "anv".reporting(name, description, viewCode, viewName, code, fakeReport, targetLink,folderid,sorder)
select E'Budget Summary',E'Budget Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Budget Summary',true, 'Accounting.html#report|budgetsheetView', f.id,1 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Budget Variance',E'Budget Variance','ACCOUNTING FAKE REPORT','Accounting Fake Report','Budget Variance',true, 'Accounting.html#report|budgetsheetView', f.id,2 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Expenses by Contact',E'Expenses by Contact','ACCOUNTING FAKE REPORT','Accounting Fake Report','Expenses by Contact',true, 'Accounting.html#accounting|reportList', f.id,3 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Income by Contact',E'Income by Contact','ACCOUNTING FAKE REPORT','Accounting Fake Report','Income by Contact',true, 'Accounting.html#accounting|reportList', f.id,4 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Executive Summary',E'Executive Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Executive Summary',true, 'Accounting.html', f.id,5 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Inventory Items Summary',E'Inventory Items Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Inventory Items Summary',true, 'Accounting.html', f.id,6 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Profit and Loss',E'Profit and Loss','ACCOUNTING FAKE REPORT','Accounting Fake Report','Profit and Loss',true, 'Accounting.html#report|newProfitAndLossView', f.id,7 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Sales Tax Report',E'Sales Tax Report','ACCOUNTING FAKE REPORT','Accounting Fake Report','Sales Tax Report',true, 'Accounting.html', f.id,8 from "anv".folders f where f.name='Performance Reports' and f.category_id=1
union
select E'Bank Reconciliation Summary',E'Bank Reconciliation Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Bank Reconciliation Summary',true, 'Accounting.html', f.id,8 from "anv".folders f where f.name='Cash Reports' and f.category_id=1
union
select E'Bank Summary',E'Bank Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Bank Summary',true, 'Accounting.html', f.id,9 from "anv".folders f where f.name='Cash Reports' and f.category_id=1
union
select E'Cash Summary',E'Cash Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Cash Summary',true, 'Accounting.html', f.id,10 from "anv".folders f where f.name='Cash Reports' and f.category_id=1

union
select E'Pay Run by Employee',E'Pay Run by Employee','ACCOUNTING FAKE REPORT','Accounting Fake Report','Pay Run by Employee',true, 'Payroll.html', f.id,11 from "anv".folders f where f.name='Pay Run Reports' and f.category_id=1
union
select E'Pay Run by Pay Item',E'Pay Run by Pay Item','ACCOUNTING FAKE REPORT','Accounting Fake Report','Pay Run by Pay Item',true, 'Payroll.html', f.id,12 from "anv".folders f where f.name='Pay Run Reports' and f.category_id=1
union
select E'Pay Run by Pay Type',E'Pay Run by Pay Type','ACCOUNTING FAKE REPORT','Accounting Fake Report','Pay Run by Pay Type',true, 'Payroll.html', f.id,13 from "anv".folders f where f.name='Pay Run Reports' and f.category_id=1
union
select E'Pay Run Summary',E'Pay Run Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Pay Run Summary',true, 'Payroll.html', f.id,14 from "anv".folders f where f.name='Pay Run Reports' and f.category_id=1

union
select E'Account Summary',E'Account Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Account Summary',true, 'Accounting.html', f.id,15 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'Account Transactions',E'Account Transactions','ACCOUNTING FAKE REPORT','Accounting Fake Report','Account Transactions',true, 'Accounting.html#report|transactionsByPeriod', f.id,16 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'Detailed Account Transactions',E'Detailed Account Transactions','ACCOUNTING FAKE REPORT','Accounting Fake Report','Detailed Account Transactions',true, 'Accounting.html', f.id,17 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'General Ledger',E'General Ledger','ACCOUNTING FAKE REPORT','Accounting Fake Report','General Ledger',true, 'Accounting.html', f.id,18 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'Journal Report',E'Journal Report','ACCOUNTING FAKE REPORT','Accounting Fake Report','Journal Report',true, 'Accounting.html#report|journalReport', f.id,19 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'Supplier Invoice Report',E'Supplier Invoice Report','ACCOUNTING FAKE REPORT','Accounting Fake Report','Supplier Invoice Report',true, 'Accounting.html', f.id,20 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'Tracking Summary',E'Tracking Summary','ACCOUNTING FAKE REPORT','Accounting Fake Report','Tracking Summary',true, 'Accounting.html', f.id,21 from "anv".folders f where f.name='Detail Reports' and f.category_id=1
union
select E'Trial Balance',E'Trial Balance','ACCOUNTING FAKE REPORT','Accounting Fake Report','Trial Balance',true, 'Accounting.html#report|trialBalanceView', f.id,22 from "anv".folders f where f.name='Detail Reports' and f.category_id=1

union
select E'Balance Sheet',E'Balance Sheet','ACCOUNTING FAKE REPORT','Accounting Fake Report','Balance Sheet',true, 'Accounting.html#report|balanceSheet', f.id,23 from "anv".folders f where f.name='Other Reports' and f.category_id=1
union
select E'Aged Receivables',E'Aged Receivables','ACCOUNTING FAKE REPORT','Accounting Fake Report','Aged Receivables',true, 'Accounting.html', f.id,24 from "anv".folders f where f.name='Other Reports' and f.category_id=1
union
select E'Aged Payables',E'Aged Payables','ACCOUNTING FAKE REPORT','Accounting Fake Report','Aged Payables',true, 'Accounting.html', f.id,25 from "anv".folders f where f.name='Other Reports' and f.category_id=1
union
select E'Foreign Currency Gains and Losses',E'Foreign Currency Gains and Losses','ACCOUNTING FAKE REPORT','Accounting Fake Report','Foreign Currency Gains and Losses',true, 'Accounting.html', f.id,26 from "anv".folders f where f.name='Other Reports' and f.category_id=1
union
select E'Depreciation Schedule',E'Depreciation Schedule','ACCOUNTING FAKE REPORT','Accounting Fake Report','Depreciation Schedule',true, 'Accounting.html', f.id,26 from "anv".folders f where f.name='Other Reports' and f.category_id=1
union
select E'Fixed Asset Reconciliation',E'Fixed Asset Reconciliation','ACCOUNTING FAKE REPORT','Accounting Fake Report','Fixed Asset Reconciliation',true, 'Accounting.html', f.id,27 from "anv".folders f where f.name='Other Reports' and f.category_id=1
union
select E'Movements in Equity',E'Movements in Equity','ACCOUNTING FAKE REPORT','Accounting Fake Report','Movements in Equity',true, 'Accounting.html', f.id,28 from "anv".folders f where f.name='Other Reports' and f.category_id=1