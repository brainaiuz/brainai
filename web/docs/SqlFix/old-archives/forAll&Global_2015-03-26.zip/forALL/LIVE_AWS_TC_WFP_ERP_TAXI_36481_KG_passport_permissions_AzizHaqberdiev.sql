DELETE FROM permission WHERE code in ('TC_PASSPORT_LIST_VIEW','TC_PASSPORT_ISSUE','TC_PASSPORT_EDIT','TC_PASSPORT_DELETE');

INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_LIST_VIEW', 'TRAININGCENTER', FALSE, 'Passports List View', 11, (SELECT id FROM permission WHERE code = 'TC_OPERATION_MENU'), FALSE, 'CORE');
INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_ISSUE', 'TRAININGCENTER', FALSE, 'Issue Passports', 1, (SELECT id FROM permission WHERE code = 'TC_PASSPORT_LIST_VIEW'), FALSE, 'CORE');
INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_EDIT', 'TRAININGCENTER', FALSE, 'Edit Passports', 2, (SELECT id FROM permission WHERE code = 'TC_PASSPORT_LIST_VIEW'), FALSE, 'CORE');
INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_DELETE', 'TRAININGCENTER', FALSE, 'Delete Passports', 3, (SELECT id FROM permission WHERE code = 'TC_PASSPORT_LIST_VIEW'), FALSE, 'CORE');