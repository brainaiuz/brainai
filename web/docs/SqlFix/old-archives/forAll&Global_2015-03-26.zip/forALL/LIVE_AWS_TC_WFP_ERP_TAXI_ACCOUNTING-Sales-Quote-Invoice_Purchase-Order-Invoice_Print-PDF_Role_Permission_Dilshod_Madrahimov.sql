
                                                           ------ SALES QUOTE ----------------

--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('ACCOUNTING_SALES_QUOTE_PDF','ACCOUNTING','Sales Quote PDF',6,'false',(select id from permission where code='ACCOUNTING_SALES_QUOTE_LIST'),'false','ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_PDF', 'PM', 'ALLOW');


                                                    -----      SALES INVOICE -----------
--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('ACCOUNTING_SALES_INVOICE_PDF','ACCOUNTING','Sales Invoice PDF',6,'false',(select id from permission where code='ACCOUNTING_SALES_INVOICE_LIST'),'false','ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_PDF', 'PM', 'ALLOW');


                                                            --------  PURCHASE INVOICE ---------------

--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('ACCOUNTING_PURCHASE_INVOICE_PDF','ACCOUNTING','Purchase Invoice PDF',6,'false',(select id from permission where code='ACCOUNTING_PURCHASE_INVOICE_LIST'),'false','ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'PM', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_PDF', 'PM', 'ALLOW');




                                                       --------  PURCHASE ORDER  ------------
--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('ACCOUNTING_PURCHASE_ORDER_PDF','ACCOUNTING','Purchase Order PDF',6,'false',(select id from permission where code='ACCOUNTING_PURCHASE_ORDER_LIST'),'false','ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_PDF', 'PM', 'ALLOW');



                                                             --------  SALES ORDER  ------------
--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('ACCOUNTING_SALES_ORDER_PDF','ACCOUNTING','Sales Order PDF',6,'false',(select id from permission where code='ACCOUNTING_SALES_ORDER_LIST'),'false','ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'PM', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_PDF', 'PM', 'ALLOW');






