INSERT INTO "anv".mymodule (code) select 'MEETING_MINUTES' as code from companySystemSettings where companyId = anv and isShowMeetingMinutes!=false;

INSERT INTO "anv".mymodule (code) select 'BOOKING_ITEMS' as code from companySystemSettings where companyId = anv and isShowBookingItems!=false;

--INSERT INTO "anv".mymodule (code) select 'PERMISSION_MANAGEMENT' as code from companySystemSettings where companyId = anv and isPermissionManagement!=false;

INSERT INTO "anv".mymodule (code) select 'CUSTOM_REFERENCES' as code from companySystemSettings where companyId = anv and isReferenceItems!=false;

INSERT INTO "anv".mymodule (code) select 'MEETING_MINUTES' as code from company where id = anv and massMailEnabled!=false;



--buni tepadagi patchlar urilgandan keyin urish kerak
ALTER TABLE companySystemSettings DROP isShowMeetingMinutes;
ALTER TABLE companySystemSettings DROP isShowBookingItems;
ALTER TABLE companySystemSettings DROP isPermissionManagement;
ALTER TABLE companySystemSettings DROP isReferenceItems;
