-------------------Accounting
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Performance Reports' and category_id=1) where code='SALES_BY_ITEM';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='CRITICAL NUMBERS';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='COUNTRY PL REPORT';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='SALES REVENUE YTD';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='TOP 10 PRODUCTS';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='SIGNED CONTRACTS';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='RECRUITMENT- REPORT PER MANAGER';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='SALES AND STOCK REPORT';
 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Customisation Reports' and category_id=1) where code='SALES GROWTH YTD';

 update  "anv".reporting set folderid=(select distinct id from "anv".folders where name='Other Reports' and category_id=1) where code='CUSTOMER BALANCE DETAILS';


----Project Management
  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='ACTIVE PROJECTS';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='BILLABLE_BY_PROJECT';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='PROJECT OVERDUE';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='PROJECT PROGRESS';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='PROJECTS_SUMMARY';
  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='EMPLOYEE HOURS BY PROJECT';
  update  "anv".reporting set sorder=7, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='PROJECT INVOLVEMENT';
  update  "anv".reporting set sorder=8, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='PROJECT HOURS BY STATUS';
  update  "anv".reporting set sorder=9, folderid=(select distinct id from "anv".folders where name='Project' and category_id=3) where code='MY PROJECT PROGRESS';

  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Task' and category_id=3) where code='TASK PROGRESS';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Task' and category_id=3) where code='OVERDUE TASKS';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Task' and category_id=3) where code='DUE TASKS';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Task' and category_id=3) where code='EMPLOYEE TASK WORKLOAD';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Task' and category_id=3) where code='TASK_SUMMARY';
  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Task' and category_id=3) where code='TASK LIST';

  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Timesheet' and category_id=3) where code='TIMESHEET DASHLET';

  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Other Reports' and category_id=3) where code='APPROVAL_PENDING_HOURS';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Other Reports' and category_id=3) where code='BILLABLE WORKSTREAMS';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Other Reports' and category_id=3) where code='EMPLOYEE WORKLOAD';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Other Reports' and category_id=3) where code='RESOURCE_UTILIZATION';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Other Reports' and category_id=3) where code='PROJECT PROGRESS DASHBOARD';


 ---- CRM
  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='LEADS_BY_STATUS';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='LEADS_BY_INDUSTRY';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='LEADS BY SOURCE';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='CONVERTED LEADS';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='RECENTLY MODIFIED LEADS';
  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='RECENTLY CREATED LEADS';
  update  "anv".reporting set sorder=7, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='TODAYS LEADS';
  update  "anv".reporting set sorder=8, folderid=(select distinct id from "anv".folders where name='Leads' and category_id=2) where code='THIS WEEK CREATED LEADS';


  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES LAST WEEK';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES THIS WEEK';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='MY RECENTLY CREATED OPPORTUNITIES';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='MY RECENTLY MODIFIED OPPORTUNITIES';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES CLOSING NEXT MONTH';
  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES CLOSING THIS MONTH';
  update  "anv".reporting set sorder=7, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY_HISTORY';
  update  "anv".reporting set sorder=8, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY_PRODUCT';
  update  "anv".reporting set sorder=9, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY PIPELINE BY STAGE';
  update  "anv".reporting set sorder=10, folderid=(select distinct id from "anv".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY SALES FUNNEL';

  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='OPEN CASES BY STATUS';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='OPEN CASES BY PRIORITY';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='TODAYS CASES';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='OPEN CASES BY ASSIGNEE';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='OPEN CASE BY PRIORITY';
  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='CASES BY ORIGIN';
  update  "anv".reporting set sorder=7, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='TOP CUSTOMERS BY OPEN CASES';
  update  "anv".reporting set sorder=8, folderid=(select distinct id from "anv".folders where name='Cases' and category_id=2) where code='CASES';


  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Others' and category_id=2) where code='ACCOUNTS_BY_INDUSTRY';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Others' and category_id=2) where code='CALLS AND EVENTS REPORT';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Others' and category_id=2) where code='TEAMS SIGNED CONTRACTS THIS WEEK';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=2) where code='MY RESULTS THIS WEEK';


  -------------------HRMS---
  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT REPORT';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT RECENT CANDIDATES';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENTS CALLS FOR TODAY';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT CALLS FOR TODAY';
  update  "anv".reporting set sorder=5, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT OPEN VACANCIES';
  update  "anv".reporting set sorder=6, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT RECENT PLACEMENTS';
  update  "anv".reporting set sorder=7, folderid=(select distinct id from "anv".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT SHORTLIST';

  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS UNAVAILABLE EMPLOYEES TODAY';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS TODAY';
  update  "anv".reporting set sorder=3, folderid=(select distinct id from "anv".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS THIS WEEK';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS FOR CURRENT AND NEXT WEEK';

  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Appraisals' and category_id=6) where code='YOUR PENDING APPRAISALS';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Appraisals' and category_id=6) where code='COMPLETED APPRAISALS';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Appraisals' and category_id=6) where code='DRAFT APPRAISALS';

  update  "anv".reporting set sorder=1, folderid=(select distinct id from "anv".folders where name='Goals' and category_id=6) where code='PERSONAL GOALS';
  update  "anv".reporting set sorder=2, folderid=(select distinct id from "anv".folders where name='Goals' and category_id=6) where code='COMPANY GOALS';

  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=6) where code='EMPLOYEE REPORT';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=6) where code='COMPANY HOLIDAYS';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=6) where code='COMPANY NEWS';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=6) where code='WAITING FOR YOUR REVIEW';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=6) where code='WAITING FOR APPROVAL';
  update  "anv".reporting set sorder=4, folderid=(select distinct id from "anv".folders where name='Others' and category_id=6) where code='UNAVAILABLE_EMPLOYEES';