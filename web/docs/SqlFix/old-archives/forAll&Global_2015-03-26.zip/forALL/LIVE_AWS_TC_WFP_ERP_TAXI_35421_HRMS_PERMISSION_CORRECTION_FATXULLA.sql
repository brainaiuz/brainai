update permission set name='Recommendations List' where code='HRMS_ALL_EMPLOYEE_BONUS_RECOMMENDATIONS';
update permission set  name='Recommendation Summary' where code='HRMS_ALL_EMPLOYEE_BONUS_RECOMMENDATIONS_SUMMARY';
update permission set  name='Recommendation Status Approve' where code='HRMS_ALL_EMPLOYEE_BONUS_RECOMMENDATIONS_STATUS_APPROVE';
update permission set name='Recommendation Status Reject' where code='HRMS_ALL_EMPLOYEE_BONUS_RECOMMENDATIONS_STATUS_REJECT';
update permission set name='Recommendation Remove' where code='HRMS_ALL_EMPLOYEE_BONUS_RECOMMENDATIONS_REMOVE';
update permission set name='Recommendation Remove' where code='HRMS_ADD_NEW_ALL_EMPLOYEE_BONUS_RECOMMENDATIONS';

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_PUNISHMENTS_PROMOTIONS', 'ADMIN', 'ALLOW') ;
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_PUNISHMENTS_PROMOTIONS', 'DR', 'ALLOW') ;

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_PUNISHMENTS_PROMOTIONS', 'ADMIN', 'ALLOW') ;
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_PUNISHMENTS_PROMOTIONS', 'DR', 'ALLOW') ;
