--Schema update dan keyin urilsin
update "anv".invoicingSettings set isConvertInvoiceBtnShow = true;

update "0".invoicingSettings set isConvertInvoiceBtnShow = true;