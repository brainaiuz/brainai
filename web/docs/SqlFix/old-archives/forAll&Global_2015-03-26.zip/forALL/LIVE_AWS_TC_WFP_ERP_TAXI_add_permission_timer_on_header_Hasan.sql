insert into permission(code,context,name,sorder, ismainmenu,parent, modulecode) values
('TIMER_MAIN_MENU','PM','Timer on header menu', 1, false,(select id from permission where code = 'PM_MAIN_MENU'),'PM');

-- for zero schema
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'ADMIN_LOCATION', 'ALLOW');



-- for all schema
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('TIMER_MAIN_MENU', 'ADMIN_LOCATION', 'ALLOW');