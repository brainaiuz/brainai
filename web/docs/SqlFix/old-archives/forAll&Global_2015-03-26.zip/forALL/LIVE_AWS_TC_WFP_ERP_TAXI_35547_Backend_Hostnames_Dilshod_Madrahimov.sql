
-- scheme updatedan keyin urilsin
update backendmanagement set hostnames=hostname;