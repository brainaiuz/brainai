
insert into "anv".eos_settings(countrycode) values('AE');

insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(20, 'EMPLOYEE_RESIGNATION', 'Less than 1 year', 1, '0<x<1'); 
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(7, 'EMPLOYEE_RESIGNATION', '1 to 3 years', 1, '1<=x<3'); 
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(14, 'EMPLOYEE_RESIGNATION', '3 to 5 years', 1, '3<=x<5'); 
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(21, 'EMPLOYEE_RESIGNATION', 'More than 5 years', 1, 'x>5'); 
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(21, 'CONTRACT_TERMINATION', 'Less than 5 years', 1, 'x<=5'); 
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(30, 'CONTRACT_TERMINATION', 'More than 5 years', 1, 'x>5'); 
