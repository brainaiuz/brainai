
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('PM_BOOKING_EDIT', 'PM', 'Booking edit', '1', 'false', (select id from permission where code='PM_BOOKING_ITEMS'), 'false', 'BOOKING_ITEMS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('PM_ADD_RESERVATION', 'PM', 'Add Reservation', '2', 'false', (select id from permission where code='PM_BOOKING_ITEMS'), 'false', 'BOOKING_ITEMS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('PM_BOOKING_ITEMS_ADD', 'PM', 'Booking items add', '3', 'false', (select id from permission where code='PM_BOOKING_ITEMS'), 'false', 'BOOKING_ITEMS');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_EDIT', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_ADD_RESERVATION', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_ADD_RESERVATION', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_ADD_RESERVATION', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_ITEMS_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_ITEMS_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_ITEMS_ADD', 'HR', 'ALLOW');




insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_EDIT', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_ADD_RESERVATION', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_ADD_RESERVATION', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_ADD_RESERVATION', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_ITEMS_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_ITEMS_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_BOOKING_ITEMS_ADD', 'HR', 'ALLOW');


