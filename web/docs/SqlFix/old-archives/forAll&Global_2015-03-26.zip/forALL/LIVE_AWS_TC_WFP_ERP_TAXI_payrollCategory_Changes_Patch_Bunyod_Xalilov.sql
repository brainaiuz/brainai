

update "anv".category set forAll=true where code='CASH_ADVANCE';

update "anv".category set forAll=true where code='BASIC_SALARY';

update "anv".category set forAll=true where code='BONUS';


