
-- public schema
INSERT INTO permission(code, context, "name", sorder, ismainmenu) VALUES ('PAYROLL_CAN_APPROVE_PAYSLIP', 'PAYROLL', 'Can Approve Payslip', 1, false);


-- for zero schema
insert into "0".rolepermission (permissioncode,  rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode,  rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'ACCOUNTANT', 'ALLOW');


-- for company schema
insert into "anv".rolepermission (permissioncode,  rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode,  rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'ACCOUNTANT', 'ALLOW');



