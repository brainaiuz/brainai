insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'HRMS', 'Certificate list', '8', 'false', (select id from permission where code='HRMS_SECTION_TAB'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'HRMS', 'Issue Certificate', '1', 'false', (select id from permission where code='CETIFICATE_OF_EMPLOYMENT_LIST'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'HRMS', 'Edit Certificate', '2', 'false', (select id from permission where code='CETIFICATE_OF_EMPLOYMENT_LIST'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'HRMS', 'Delete Certificate', '3', 'false', (select id from permission where code='CETIFICATE_OF_EMPLOYMENT_LIST'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'HRMS', 'Customize certificate', '3', 'false', (select id from permission where code='CETIFICATE_OF_EMPLOYMENT_LIST'), 'false', 'HRMS_MODULE');




insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'HR', 'ALLOW');





insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_ADD', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_EDIT', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_DELETE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CETIFICATE_OF_EMPLOYMENT_CUSTOMIZE', 'HR', 'ALLOW');
