-- for zero schema
insert into "0".reference(code, name, issystemreference, sorder, parentid) values('PY_SUBMITTED_TO_MANAGER', 'Submitted', true, 1, (select id from "0".reference where code='PAYRUN_STATUS' limit 1));


-- for all
insert into "anv".reference(code, name, issystemreference, sorder, parentid) values('PY_SUBMITTED_TO_MANAGER', 'Submitted', true, 1, (select id from "anv".reference where code='PAYRUN_STATUS' limit 1));