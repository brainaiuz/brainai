INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_LIST_VIEW', 'TRAININGCENTER', FALSE, 'HSE Passports List View', 10, 588, FALSE, 'CORE');
INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_ISSUE', 'TRAININGCENTER', FALSE, 'Issue Passports', 1, 830, FALSE, 'CORE');
INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_EDIT', 'TRAININGCENTER', FALSE, 'Edit Passports', 2, 830, FALSE, 'CORE');
INSERT INTO permission (code, context, ismainmenu, NAME, sorder, parent, iscore, modulecode)
VALUES ('TC_PASSPORT_DELETE', 'TRAININGCENTER', FALSE, 'Delete Passports', 3, 830, FALSE, 'CORE');

INSERT INTO "31287".reference (code, NAME, isremovable, issystemreference, shared, iscustombutton)
 VALUES ('_PASSPORT_STATUS', 'Passport Status',  FALSE, TRUE, TRUE, FALSE);
INSERT INTO "31287".reference (code, NAME, isremovable, issystemreference, shared, iscustombutton, sorder, parentid)
 VALUES ('ISSUED', 'Passport Status',  FALSE, TRUE, TRUE, FALSE, 1, (SELECT id FROM "31287".reference WHERE code = '_PASSPORT_STATUS'));
INSERT INTO "31287".reference (code, NAME, isremovable, issystemreference, shared, iscustombutton, sorder, parentid)
 VALUES ('ON_HOLD', 'Passport Status',  FALSE, TRUE, TRUE, FALSE, 2, (SELECT id FROM "31287".reference WHERE code = '_PASSPORT_STATUS'));
INSERT INTO "31287".reference (code, NAME, isremovable, issystemreference, shared, iscustombutton, sorder, parentid)
 VALUES ('SPOILED', 'Passport Status',  FALSE, TRUE, TRUE, FALSE, 3, (SELECT id FROM "31287".reference WHERE code = '_PASSPORT_STATUS'));
INSERT INTO "31287".reference (code, NAME, isremovable, issystemreference, shared, iscustombutton, sorder, parentid)
 VALUES ('LOST', 'Passport Status',  FALSE, TRUE, TRUE, FALSE, 4, (SELECT id FROM "31287".reference WHERE code = '_PASSPORT_STATUS'));