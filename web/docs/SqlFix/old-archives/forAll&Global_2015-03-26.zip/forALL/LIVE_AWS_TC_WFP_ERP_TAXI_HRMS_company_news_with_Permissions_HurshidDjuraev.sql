--Enable MS Project Export link. for now, only for schema 1
insert into "1".genericSettings (key, value) values('ENABLE_MSPROJECT_EXPORT', 'YES');

--HRMS hide NEWS tab
update companySystemSettings set shownews='false' where companyid=anv;

--HRMS Company news;
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COMPANY_NEWS', 'HRMS', 'Company news', '7', 'false', (select id from permission where code='HRMS_SECTION_TAB'), 'true', 'HRMS_MODULE');--1302
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COMPANY_NEWS_LIST', 'HRMS', 'Company news list', '1', 'false', (select id from permission where code='HRMS_COMPANY_NEWS'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COMPANY_NEWS_CATEGORIES', 'HRMS', 'Company news categories', '2', 'false', (select id from permission where code='HRMS_COMPANY_NEWS'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COMPANY_NEWS_ADD', 'HRMS', 'Add news', '1', 'false', (select id from permission where code='HRMS_COMPANY_NEWS_LIST'), 'false', 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COMPANY_NEWS_EDIT', 'HRMS', 'Edit news', '2', 'false', (select id from permission where code='HRMS_COMPANY_NEWS_LIST'), 'false', 'HRMS_MODULE');


--HRMS company news role permission
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'MEM', 'DENY');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'MEM', 'DENY');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'MEM', 'DENY');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'MEM', 'DENY');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'MEM', 'DENY');

--HRMS company news role permission for schema 0
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'MEM', 'DENY');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_LIST', 'MEM', 'DENY');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_ADD', 'MEM', 'DENY');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_EDIT', 'MEM', 'DENY');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS_CATEGORIES', 'MEM', 'DENY');


