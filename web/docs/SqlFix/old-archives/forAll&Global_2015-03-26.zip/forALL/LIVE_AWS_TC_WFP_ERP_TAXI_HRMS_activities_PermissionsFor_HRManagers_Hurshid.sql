
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ACTIVITIES_VIEW', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SUMMARY_ACTIVITY', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ADD_NEW_ACTIVITY_EVENT', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ADD_NEW_ACTIVITY_LOG_A_CALL', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_ACTIVITY', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_REMOVE_ACTIVITY', 'HR', 'ALLOW');


insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ACTIVITIES_VIEW', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SUMMARY_ACTIVITY', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ADD_NEW_ACTIVITY_EVENT', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ADD_NEW_ACTIVITY_LOG_A_CALL', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_ACTIVITY', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_REMOVE_ACTIVITY', 'HR', 'ALLOW');

