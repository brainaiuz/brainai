/* It is only for free db*/
update "anv".invoicingSettings set isconvertinvoicebtnshow=true;