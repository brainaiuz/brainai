INSERT INTO pdfreference (code, name) values ('CERTIFICATE_SUMMARY', 'Certificate Summary');
