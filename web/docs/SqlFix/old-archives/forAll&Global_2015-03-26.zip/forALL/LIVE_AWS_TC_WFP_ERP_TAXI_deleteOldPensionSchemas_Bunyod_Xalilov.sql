
DELETE FROM "anv".pensionscheme;

delete from "anv".paymentdeductionsettings;