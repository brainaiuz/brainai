
update "anv".emailtemplate set messagehtml='<p>Dear ${firstname}  ${lastname},</p>
<p>Please be advised that ${name} has submitted a Purchase Order with amount ${totalamount} for your attention on ${startdate}</p>
<p>${hasaccesslink}</p>
<p>Once you approve or Reject the Purchase Order ${name} will receive email notification about its status.</p>
<p>Your Sincerely,</br> ${name} </br><b> ${companyname} </b></p>'  where code='DEFAULT_ORDER_FOR_MANAGER';