--Zero schemaga apply qilinadi
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS','DR','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS','ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS','ACCOUNTANT','ALLOW');

INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS','DR','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS','ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS','ACCOUNTANT','ALLOW');

INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS','DR','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS','ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS','ACCOUNTANT','ALLOW');