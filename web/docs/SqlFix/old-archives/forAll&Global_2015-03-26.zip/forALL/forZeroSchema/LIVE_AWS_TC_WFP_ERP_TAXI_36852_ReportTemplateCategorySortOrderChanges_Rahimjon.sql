update reporttemplatecategory set sorder =1 where name='Project Management';
update reporttemplatecategory set sorder =2 where name='HRMS';
update reporttemplatecategory set sorder =3 where name='CRM';
update reporttemplatecategory set sorder =4 where name='Accounting & Finance';