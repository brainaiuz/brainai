-------------------Accounting
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Performance Reports' and category_id=1) where code='SALES_BY_ITEM';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='CRITICAL NUMBERS';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='COUNTRY PL REPORT';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='SALES REVENUE YTD';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='TOP 10 PRODUCTS';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='SIGNED CONTRACTS';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='RECRUITMENT- REPORT PER MANAGER';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='SALES AND STOCK REPORT';
 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Customisation Reports' and category_id=1) where code='SALES GROWTH YTD';

 update  "0".reporting set folderid=(select distinct id from "0".folders where name='Other Reports' and category_id=1) where code='CUSTOMER BALANCE DETAILS';


----Project Management
  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='ACTIVE PROJECTS';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='BILLABLE_BY_PROJECT';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='PROJECT OVERDUE';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='PROJECT PROGRESS';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='PROJECTS_SUMMARY';
  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='EMPLOYEE HOURS BY PROJECT';
  update  "0".reporting set sorder=7, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='PROJECT INVOLVEMENT';
  update  "0".reporting set sorder=8, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='PROJECT HOURS BY STATUS';
  update  "0".reporting set sorder=9, folderid=(select distinct id from "0".folders where name='Project' and category_id=3) where code='MY PROJECT PROGRESS';

  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Task' and category_id=3) where code='TASK PROGRESS';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Task' and category_id=3) where code='OVERDUE TASKS';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Task' and category_id=3) where code='DUE TASKS';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Task' and category_id=3) where code='EMPLOYEE TASK WORKLOAD';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Task' and category_id=3) where code='TASK_SUMMARY';
  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Task' and category_id=3) where code='TASK LIST';

  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Timesheet' and category_id=3) where code='TIMESHEET DASHLET';

  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Other Reports' and category_id=3) where code='APPROVAL_PENDING_HOURS';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Other Reports' and category_id=3) where code='BILLABLE WORKSTREAMS';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Other Reports' and category_id=3) where code='EMPLOYEE WORKLOAD';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Other Reports' and category_id=3) where code='RESOURCE_UTILIZATION';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Other Reports' and category_id=3) where code='PROJECT PROGRESS DASHBOARD';


 ---- CRM
  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='LEADS_BY_STATUS';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='LEADS_BY_INDUSTRY';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='LEADS BY SOURCE';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='CONVERTED LEADS';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='RECENTLY MODIFIED LEADS';
  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='RECENTLY CREATED LEADS';
  update  "0".reporting set sorder=7, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='TODAYS LEADS';
  update  "0".reporting set sorder=8, folderid=(select distinct id from "0".folders where name='Leads' and category_id=2) where code='THIS WEEK CREATED LEADS';


  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES LAST WEEK';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES THIS WEEK';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='MY RECENTLY CREATED OPPORTUNITIES';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='MY RECENTLY MODIFIED OPPORTUNITIES';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES CLOSING NEXT MONTH';
  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='MY OPPORTUNITIES CLOSING THIS MONTH';
  update  "0".reporting set sorder=7, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY_HISTORY';
  update  "0".reporting set sorder=8, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY_PRODUCT';
  update  "0".reporting set sorder=9, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY PIPELINE BY STAGE';
  update  "0".reporting set sorder=10, folderid=(select distinct id from "0".folders where name='Opportunities' and category_id=2) where code='OPPORTUNITY SALES FUNNEL';

  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='OPEN CASES BY STATUS';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='OPEN CASES BY PRIORITY';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='TODAYS CASES';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='OPEN CASES BY ASSIGNEE';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='OPEN CASE BY PRIORITY';
  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='CASES BY ORIGIN';
  update  "0".reporting set sorder=7, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='TOP CUSTOMERS BY OPEN CASES';
  update  "0".reporting set sorder=8, folderid=(select distinct id from "0".folders where name='Cases' and category_id=2) where code='CASES';


  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Others' and category_id=2) where code='ACCOUNTS_BY_INDUSTRY';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Others' and category_id=2) where code='CALLS AND EVENTS REPORT';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Others' and category_id=2) where code='TEAMS SIGNED CONTRACTS THIS WEEK';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=2) where code='MY RESULTS THIS WEEK';


  -------------------HRMS---
  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT REPORT';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT RECENT CANDIDATES';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENTS CALLS FOR TODAY';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT CALLS FOR TODAY';
  update  "0".reporting set sorder=5, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT OPEN VACANCIES';
  update  "0".reporting set sorder=6, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT RECENT PLACEMENTS';
  update  "0".reporting set sorder=7, folderid=(select distinct id from "0".folders where name='Recruitments' and category_id=6) where code='RECRUITMENT SHORTLIST';

  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS UNAVAILABLE EMPLOYEES TODAY';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS TODAY';
  update  "0".reporting set sorder=3, folderid=(select distinct id from "0".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS THIS WEEK';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Leave Requests' and category_id=6) where code='LEAVE REQUESTS FOR CURRENT AND NEXT WEEK';

  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Appraisals' and category_id=6) where code='YOUR PENDING APPRAISALS';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Appraisals' and category_id=6) where code='COMPLETED APPRAISALS';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Appraisals' and category_id=6) where code='DRAFT APPRAISALS';

  update  "0".reporting set sorder=1, folderid=(select distinct id from "0".folders where name='Goals' and category_id=6) where code='PERSONAL GOALS';
  update  "0".reporting set sorder=2, folderid=(select distinct id from "0".folders where name='Goals' and category_id=6) where code='COMPANY GOALS';

  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=6) where code='EMPLOYEE REPORT';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=6) where code='COMPANY HOLIDAYS';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=6) where code='COMPANY NEWS';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=6) where code='WAITING FOR YOUR REVIEW';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=6) where code='WAITING FOR APPROVAL';
  update  "0".reporting set sorder=4, folderid=(select distinct id from "0".folders where name='Others' and category_id=6) where code='UNAVAILABLE_EMPLOYEES';