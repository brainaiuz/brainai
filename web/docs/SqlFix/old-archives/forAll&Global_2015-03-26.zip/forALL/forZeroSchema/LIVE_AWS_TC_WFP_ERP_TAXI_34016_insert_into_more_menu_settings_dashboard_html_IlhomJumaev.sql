
insert into "0".moreMenuSettings (actionName,enabled,linkName) values ('Dashboard.html', true, 'Dashboard.html');