
-- SCHEMAUPDATE DAN KIYIN YURGIZILSIN--

ALTER TABLE "0".wfp_block DROP CONSTRAINT wfp_block_external_guid_key CASCADE;
ALTER TABLE "0".wfp_block ADD CONSTRAINT wfp_block_external_guid_key UNIQUE (uuid, website_id);

ALTER TABLE "0".wfp_custom_entity_group DROP CONSTRAINT wfp_custom_entity_group_uuid_key CASCADE;
ALTER TABLE "0".wfp_custom_entity_group ADD CONSTRAINT wfp_custom_entity_group_uuid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_custom_entities DROP CONSTRAINT wfp_custom_entities_external_guid_key CASCADE;
ALTER TABLE "0".wfp_custom_entities ADD CONSTRAINT wfp_custom_entities_external_guid_key UNIQUE (external_guid, websiteid);

ALTER TABLE "0".wfp_custom_forms DROP CONSTRAINT wfp_custom_forms_external_guid_key CASCADE;
ALTER TABLE "0".wfp_custom_forms ADD CONSTRAINT wfp_custom_forms_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_custom_list_entity_look_up DROP CONSTRAINT wfp_custom_list_entity_look_up_pkey CASCADE;
ALTER TABLE "0".wfp_custom_list_entity_look_up ADD CONSTRAINT wfp_custom_list_entity_look_up_pkey UNIQUE (id, website_id);

ALTER TABLE "0".wfp_menu_group DROP CONSTRAINT wfp_menu_group_external_guid_key CASCADE;
ALTER TABLE "0".wfp_menu_group ADD CONSTRAINT wfp_menu_group_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_page DROP CONSTRAINT wfp_page_external_guid_key CASCADE;
ALTER TABLE "0".wfp_page ADD CONSTRAINT wfp_page_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_page_block DROP CONSTRAINT wfp_page_block_external_guid_key CASCADE;
ALTER TABLE "0".wfp_page_block ADD CONSTRAINT wfp_page_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_page_layout DROP CONSTRAINT wfp_page_external_guid_key CASCADE;
ALTER TABLE "0".wfp_page_layout ADD CONSTRAINT wfp_page_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_page_layout_block DROP CONSTRAINT wfp_page_layout_block_external_guid_key CASCADE;
ALTER TABLE "0".wfp_page_layout_block ADD CONSTRAINT wfp_page_layout_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_website_layout DROP CONSTRAINT wfp_website_layout_external_guid_key CASCADE;
ALTER TABLE "0".wfp_website_layout ADD CONSTRAINT wfp_website_layout_external_guid_key UNIQUE (external_guid, websiteid);

ALTER TABLE "0".wfp_website_layout_block DROP CONSTRAINT wfp_website_layout_block_external_guid_key CASCADE;
ALTER TABLE "0".wfp_website_layout_block ADD CONSTRAINT wfp_website_layout_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "0".wfp_website_script DROP CONSTRAINT wfp_website_script_name_key CASCADE;
ALTER TABLE "0".wfp_website_script ADD CONSTRAINT wfp_website_script_name_key UNIQUE (name, websiteid);

