insert into "0".reference (code, name, isremovable, issystemreference, shared, iscustombutton)
values ('_EMAIL_TEMPLATE_MODULE', 'Email Template Modules', false, true, false, false);

 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (1, 'ET_EVENT_MODULE', 'Event', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (2, 'ET_CASE_MODULE', 'Case', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (3, 'ET_CONTACT_MODULE', 'Contact', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (4, 'ET_LEAD_MODULE', 'Lead', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (5, 'ET_CRM_ACCOUNT_MODULE', 'CRM Account', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (6, 'ET_OPPORTUNITY_MODULE', 'Opportunity', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (7, 'ET_MASS_MAIL_MODULE', 'Mass Mail', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (8, 'ET_MESSAGE_CENTER_MODULE', 'Message Center', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (9, 'ET_PROJECT_MODULE', 'Project', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (10, 'ET_TASK_MODULE', 'Task', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (11, 'ET_ISSUE_MODULE', 'Issue', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (12, 'ET_ACTIVATION_MODULE', 'Activation', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (13, 'ET_LR_MODULE', 'Leave Request', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (14, 'ET_BUSINESS_GOAL_MODULE', 'Business Goal', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (15, 'ET_DEPARTMENT_GOAL_MODULE', 'Department Goal', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (16, 'ET_PERSONAL_GOAL_MODULE', 'Personal Goal', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (17, 'ET_PROJECT_GOAL_MODULE', 'Project Goal', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (18, 'ET_EXPENSE_MODULE', 'Expense', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (19, 'ET_INVOICE_MODULE', 'Invoice', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (20, 'ET_PURCHASE_ORDER_MODULE', 'Purchase Order', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (21, 'ET_SALES_QUOTE_MODULE', 'Sales Quote', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (22, 'ET_BALANCE_MODULE', 'Customer/Supplier Balance', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (23, 'ET_PRODUCT_MODULE', 'Product', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (24, 'ET_PAYROLL_MODULE', 'Payroll', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (25, 'ET_SMS_MODULE', 'SMS', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (26, 'ET_WEB_FORM_MODULE', 'Web Form', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (27, 'ET_REPORTING_SYSTEM_MODULE', 'Reporting System', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));
 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (28, 'ET_TRAINING_CENTER_MODULE', 'Training Center', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));

