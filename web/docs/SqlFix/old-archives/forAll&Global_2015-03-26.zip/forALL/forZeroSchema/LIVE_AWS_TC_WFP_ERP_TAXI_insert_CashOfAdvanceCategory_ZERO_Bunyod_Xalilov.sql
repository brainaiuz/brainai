

insert into "0".category(code, name, type, pensionable, arabic) values('CASH_ADVANCE','Cash Advance', 'Deduction', true, true);
