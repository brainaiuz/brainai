UPDATE "0".reporting set targetLink='Accounting.html#report|profitLoss' WHERE code = 'Profit and Loss';
UPDATE "0".reporting set targetLink ='Accounting.html#report|trialBalance' WHERE code='Trial Balance';
UPDATE "0".reporting set targetLink ='Accounting.html#report|arAgingSummary' WHERE code='Aged Receivables';
UPDATE "0".reporting set targetLink ='Accounting.html#report|apAgingSummary' WHERE code='Aged Payables';