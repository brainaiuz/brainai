 ---Sherali M. dan so'rasayz aytadi qaysi company uchun urish kk ligini

 insert into "anv".genericSettings (key, value) values('RU_SHOW_PROJECTS_WITHOUT_TASKS', 'YES');