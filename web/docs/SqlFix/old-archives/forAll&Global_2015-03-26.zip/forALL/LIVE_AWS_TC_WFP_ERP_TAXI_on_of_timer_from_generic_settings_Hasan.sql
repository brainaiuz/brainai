



INSERT INTO "0".genericsettings (key, value) VALUES  ('ENABLE_TIMER_WIDGET', 'YES');


INSERT INTO "anv".genericsettings (key, value) VALUES  ('ENABLE_TIMER_WIDGET', 'YES');
