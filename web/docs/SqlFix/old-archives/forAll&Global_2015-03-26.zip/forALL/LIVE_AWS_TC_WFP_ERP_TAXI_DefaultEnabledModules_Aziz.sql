--update permission set modulecode = 'CORE';

insert into "0".mymodule (code) values('CORE');
--WORKSPACE_MODULE
insert into "0".mymodule (code) values('WORKSPACE');
insert into "0".mymodule (code) values('WORKSPACE_CALENDAR');
insert into "0".mymodule (code) values('STUFF_UPDATES');
insert into "0".mymodule (code) values('COMPANY_NEWS');
insert into "0".mymodule (code) values('NOTES');

-- PM_MODULE
insert into "0".mymodule (code) values('PM');
insert into "0".mymodule (code) values('TASK_MANAGEMENT');
insert into "0".mymodule (code) values('ISSUE_TRACKING');
insert into "0".mymodule (code) values('TIMESHEET');
insert into "0".mymodule (code) values('GANTT_CHART');
insert into "0".mymodule (code) values('TIMER');
insert into "0".mymodule (code) values('IMPORT_FROM_MS_PROJECT');
insert into "0".mymodule (code) values('PROJECT_EMAILS');
insert into "0".mymodule (code) values('CUSTOMER_CENTER');

--CRM_MODULE
insert into "0".mymodule (code) values('CRM_MODULE');
insert into "0".mymodule (code) values('LEAD_MANAGEMENT');
insert into "0".mymodule (code) values('CONTACT_MANAGEMENT');
insert into "0".mymodule (code) values('OPPORTUNITY_TRACKING');
insert into "0".mymodule (code) values('ACTIVITIES');
insert into "0".mymodule (code) values('CRM_CALENDAR');
insert into "0".mymodule (code) values('WEB_FORMS');
insert into "0".mymodule (code) values('CASE_MANAGEMENT');
insert into "0".mymodule (code) values('MESSAGE_CENTER');

--ACCOUNTING MODULE
insert into "0".mymodule (code) values('ACCOUNTING_MODULE');
insert into "0".mymodule (code) values('SALES_INVOICING');
insert into "0".mymodule (code) values('PURCHASE_ORDERS');
insert into "0".mymodule (code) values('PURCHASE_INVOICING');
insert into "0".mymodule (code) values('RECCURING_INVOICES');
insert into "0".mymodule (code) values('INVENTORY_MANAGEMENT');
insert into "0".mymodule (code) values('EXPENSE_REPORTING');
insert into "0".mymodule (code) values('FIXED_ASSESTS');
insert into "0".mymodule (code) values('CHECKS');
insert into "0".mymodule (code) values('MANUAL_TRANSLATIONS');
insert into "0".mymodule (code) values('ACCOUNTING_CUSTOMER_CENTER');

--HRMS MODULE
insert into "0".mymodule (code) values('HRMS_MODULE');
insert into "0".mymodule (code) values('LEAVE_MANAGEMENT');
insert into "0".mymodule (code) values('ATTENDING_TRACKING');
insert into "0".mymodule (code) values('PERFORMANCE_APPRAISAL');
insert into "0".mymodule (code) values('GOAL_MANAGEMENT');
insert into "0".mymodule (code) values('RECRUITMENT_SYSTEM');
insert into "0".mymodule (code) values('EMPLOYEE_EXPENSES');
insert into "0".mymodule (code) values('EMPLOYEE_INCIDENTS');

--ADDITIONAL_MODULE 
insert into "0".mymodule (code) values('ADDITIONAL_MODULE');
insert into "0".mymodule (code) values('PAYROLL');
insert into "0".mymodule (code) values('REPORTING_SYSTEM');
insert into "0".mymodule (code) values('DOCUMENT_MANAGEMENT');
insert into "0".mymodule (code) values('CUSTOM_FIELDS');
insert into "0".mymodule (code) values('SYNCRONIZE_WITH_GOOGLE');
insert into "0".mymodule (code) values('REMINDERS');


-------------------FOR ALL

insert into "anv".mymodule (code) values('CORE');
--WORKSPACE_MODULE
insert into "anv".mymodule (code) values('WORKSPACE');
insert into "anv".mymodule (code) values('WORKSPACE_CALENDAR');
insert into "anv".mymodule (code) values('STUFF_UPDATES');
insert into "anv".mymodule (code) values('COMPANY_NEWS');
insert into "anv".mymodule (code) values('NOTES');

-- PM_MODULE
insert into "anv".mymodule (code) values('PM');
insert into "anv".mymodule (code) values('TASK_MANAGEMENT');
insert into "anv".mymodule (code) values('ISSUE_TRACKING');
insert into "anv".mymodule (code) values('TIMESHEET');
insert into "anv".mymodule (code) values('GANTT_CHART');
insert into "anv".mymodule (code) values('TIMER');
insert into "anv".mymodule (code) values('IMPORT_FROM_MS_PROJECT');
insert into "anv".mymodule (code) values('PROJECT_EMAILS');
insert into "anv".mymodule (code) values('CUSTOMER_CENTER');

--CRM_MODULE
insert into "anv".mymodule (code) values('CRM_MODULE');
insert into "anv".mymodule (code) values('LEAD_MANAGEMENT');
insert into "anv".mymodule (code) values('CONTACT_MANAGEMENT');
insert into "anv".mymodule (code) values('OPPORTUNITY_TRACKING');
insert into "anv".mymodule (code) values('ACTIVITIES');
insert into "anv".mymodule (code) values('CRM_CALENDAR');
insert into "anv".mymodule (code) values('WEB_FORMS');
insert into "anv".mymodule (code) values('CASE_MANAGEMENT');
insert into "anv".mymodule (code) values('MESSAGE_CENTER');

--ACCOUNTING MODULE
insert into "anv".mymodule (code) values('ACCOUNTING_MODULE');
insert into "anv".mymodule (code) values('SALES_INVOICING');
insert into "anv".mymodule (code) values('PURCHASE_ORDERS');
insert into "anv".mymodule (code) values('PURCHASE_INVOICING');
insert into "anv".mymodule (code) values('RECCURING_INVOICES');
insert into "anv".mymodule (code) values('INVENTORY_MANAGEMENT');
insert into "anv".mymodule (code) values('EXPENSE_REPORTING');
insert into "anv".mymodule (code) values('FIXED_ASSESTS');
insert into "anv".mymodule (code) values('CHECKS');
insert into "anv".mymodule (code) values('MANUAL_TRANSLATIONS');
insert into "anv".mymodule (code) values('ACCOUNTING_CUSTOMER_CENTER');

--HRMS MODULE
insert into "anv".mymodule (code) values('HRMS_MODULE');
insert into "anv".mymodule (code) values('LEAVE_MANAGEMENT');
insert into "anv".mymodule (code) values('ATTENDING_TRACKING');
insert into "anv".mymodule (code) values('PERFORMANCE_APPRAISAL');
insert into "anv".mymodule (code) values('GOAL_MANAGEMENT');
insert into "anv".mymodule (code) values('RECRUITMENT_SYSTEM');
insert into "anv".mymodule (code) values('EMPLOYEE_EXPENSES');
insert into "anv".mymodule (code) values('EMPLOYEE_INCIDENTS');

--ADDITIONAL_MODULE
insert into "anv".mymodule (code) values('ADDITIONAL_MODULE');
insert into "anv".mymodule (code) values('PAYROLL');
insert into "anv".mymodule (code) values('REPORTING_SYSTEM');
insert into "anv".mymodule (code) values('DOCUMENT_MANAGEMENT');
insert into "anv".mymodule (code) values('CUSTOM_FIELDS');
insert into "anv".mymodule (code) values('SYNCRONIZE_WITH_GOOGLE');
insert into "anv".mymodule (code) values('REMINDERS');

