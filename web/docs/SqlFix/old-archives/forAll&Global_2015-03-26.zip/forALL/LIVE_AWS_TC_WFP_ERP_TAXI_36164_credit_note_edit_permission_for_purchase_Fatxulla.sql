insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ACCOUNTING', 'Purchase Invoice Full Edit Access', '12', 'false', (select id from permission where code='ACCOUNTING_PURCHASE_INVOICE_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'ACCOUNTING', 'Purchase Credit Note Edit', '13', 'false', (select id from permission where code='ACCOUNTING_PURCHASE_INVOICE_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ACCOUNTING', 'Purchase Credit Note Full Edit Access', '14', 'false', (select id from permission where code='ACCOUNTING_PURCHASE_INVOICE_LIST'), 'false', 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
