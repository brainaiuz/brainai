CREATE UNIQUE INDEX customfield_column_unique_idx
ON "anv".companyCustomFieldsSettings (columnCode, entityName)
  WHERE relationship IS NULL;

CREATE UNIQUE INDEX customfield_column_unique_idx
ON "0".companyCustomFieldsSettings (columnCode, entityName)
  WHERE relationship IS NULL;