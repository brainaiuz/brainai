--for globalauth DB

--update support package

update support_package set price = '27500' where hostname like '%appiev%' and packagename = 'SP_BASIC';
update support_package set price = '60000' where hostname like '%appiev%' and packagename = 'SP_STANDARD';
update support_package set price = '90000' where hostname like '%appiev%' and packagename = 'SP_BRONZE';