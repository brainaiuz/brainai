                                                    -------------Insert REPMISSIONS (public schema)--------
insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('PM_SHOW_ALL_EMPLOYEES', 'PM', 'f', 'Show all employees', '2', (select id from permission where code='PM_RESOURCE_UTILIZATION_LIST'), 'RESOURCE_PLANNING');

insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('PM_SHOW_DEPARTMENT_EMPLOYEES', 'PM', 'f', 'Show department employees', '3', (select id from permission where code='PM_RESOURCE_UTILIZATION_LIST'), 'RESOURCE_PLANNING');

insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'PM', 'f', 'Show project employees', '4', (select id from permission where code='PM_RESOURCE_UTILIZATION_LIST'), 'RESOURCE_PLANNING');

insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('PM_SHOW_SUPERVISED_EMPLOYEES', 'PM', 'f', 'Show supervised employees', '5', (select id from permission where code='PM_RESOURCE_UTILIZATION_LIST'), 'RESOURCE_PLANNING');

-------------------------------------------------------------------for 'anv'-----------
----------------------- Show all employees ----- default -----
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_ALL_EMPLOYEES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_ALL_EMPLOYEES', 'DR', 'ALLOW');

-------------------------- Show all department ----- default -----
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_DEPARTMENT_EMPLOYEES', 'TL', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_DEPARTMENT_EMPLOYEES', 'DLOFPR', 'ALLOW');

--------------------------- Show all project ----- default -----
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'PMOFPR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'BMOFPR', 'ALLOW');

------------------------ Show all supervised ----- default -----
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_SUPERVISED_EMPLOYEES', 'SUPERVISOR', 'ALLOW');

------------------------------------------------------------------------ for 0 schema -----------
------------------------ Show all employees ----- default -----
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_ALL_EMPLOYEES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_ALL_EMPLOYEES', 'DR', 'ALLOW');
------------------------ Show all department ----- default -----
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_DEPARTMENT_EMPLOYEES', 'TL', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_DEPARTMENT_EMPLOYEES', 'DLOFPR', 'ALLOW');
------------------------ Show all project ----- default -----
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'PMOFPR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_PROJECT_EMPLOYEES', 'BMOFPR', 'ALLOW');
------------------------- Show all supervised ----- default -----
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_SHOW_SUPERVISED_EMPLOYEES', 'SUPERVISOR', 'ALLOW');