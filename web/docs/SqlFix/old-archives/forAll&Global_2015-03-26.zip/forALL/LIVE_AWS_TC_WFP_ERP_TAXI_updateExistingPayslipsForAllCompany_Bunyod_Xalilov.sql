-
-- get year from creation date and set as year for payslip table
-

update "anv".paysliptable
	set year = myt.currentyear
	from (select pt.id as myid,  EXTRACT(YEAR FROM pt.creationdate) as currentyear from "anv".paysliptable pt) myt
	where id=myt.myid;