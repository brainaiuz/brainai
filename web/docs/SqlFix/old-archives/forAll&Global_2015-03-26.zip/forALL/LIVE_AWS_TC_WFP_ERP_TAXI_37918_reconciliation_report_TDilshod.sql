update "0".bankStatement as bs set uploadedfiledeleted = (select COALESCE(baa.isDeleted,false) from "0".bankaccountattachement as baa where baa.id=bs.bankaccountattachementid limit 1);
update "0".bankStatementItem as bsi set uploadedfiledeleted = (select COALESCE(bs.uploadedFileDeleted,false) from "0".bankStatement as bs where bs.id=bsi.bankstatementid limit 1);

update "anv".bankStatement as bs set uploadedfiledeleted = (select COALESCE(baa.isDeleted,false) from "anv".bankaccountattachement as baa where baa.id=bs.bankaccountattachementid limit 1);
update "anv".bankStatementItem as bsi set uploadedfiledeleted = (select COALESCE(bs.uploadedFileDeleted,false) from "anv".bankStatement as bs where bs.id=bsi.bankstatementid limit 1);
