insert into permission(code,context,"name",parent,modulecode) values
                       ('SHOW_IMPORT_EXPENCE','HRMS','Import Employee from csv', (select id from permission where code = 'ACCOUNTING_EXPENSE_REPORT_LIST'),'HRMS_MODULE');


-- for zero schema
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('SHOW_IMPORT_EXPENCE', 'ADMIN', 'ALLOW');



-- for all schema
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('SHOW_IMPORT_EXPENCE', 'ADMIN', 'ALLOW');