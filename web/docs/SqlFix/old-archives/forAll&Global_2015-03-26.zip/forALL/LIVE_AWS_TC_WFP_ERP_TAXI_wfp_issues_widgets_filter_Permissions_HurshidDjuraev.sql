
--Recent issues
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('RECENT ISSUE_SHOW_ALL', 'WORKSPACE', 'All items', '1', 'false', (select id from permission where code='WFP_BLOCK_181a36e9-cb8e-4aa4-ab86-2e3fecb909ac'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('RECENT ISSUE_MY_ITEMS', 'WORKSPACE', 'Assigned to me', '2', 'false', (select id from permission where code='WFP_BLOCK_181a36e9-cb8e-4aa4-ab86-2e3fecb909ac'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('RECENT ISSUE_RELATED_ITEMS', 'WORKSPACE', 'Related to me', '3', 'false', (select id from permission where code='WFP_BLOCK_181a36e9-cb8e-4aa4-ab86-2e3fecb909ac'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('RECENT ISSUE_NON_RELATED_ITEMS', 'WORKSPACE', 'Non-assigned items', '4', 'false', (select id from permission where code='WFP_BLOCK_181a36e9-cb8e-4aa4-ab86-2e3fecb909ac'), 'false', 'WORKSPACE');


--Employee tasks by status
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS TASK_SHOW_ALL', 'WORKSPACE', 'All items', '1', 'false', (select id from permission where code='WFP_BLOCK_86622a8a-ac7e-4ba1-877d-a38c4ff410fc'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS TASK_MY_ITEMS', 'WORKSPACE', 'Assigned to me', '2', 'false', (select id from permission where code='WFP_BLOCK_86622a8a-ac7e-4ba1-877d-a38c4ff410fc'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS TASK_RELATED_ITEMS', 'WORKSPACE', 'Related to me', '3', 'false', (select id from permission where code='WFP_BLOCK_86622a8a-ac7e-4ba1-877d-a38c4ff410fc'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'WORKSPACE', 'Non-assigned items', '4', 'false', (select id from permission where code='WFP_BLOCK_86622a8a-ac7e-4ba1-877d-a38c4ff410fc'), 'false', 'WORKSPACE');


--Employee issues by status
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS ISSUE_SHOW_ALL', 'WORKSPACE', 'All items', '1', 'false', (select id from permission where code='WFP_BLOCK_3bfa5cf2-d701-418a-8441-6070a94a9c03'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS ISSUE_MY_ITEMS', 'WORKSPACE', 'Assigned to me', '2', 'false', (select id from permission where code='WFP_BLOCK_3bfa5cf2-d701-418a-8441-6070a94a9c03'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS ISSUE_RELATED_ITEMS', 'WORKSPACE', 'Related to me', '3', 'false', (select id from permission where code='WFP_BLOCK_3bfa5cf2-d701-418a-8441-6070a94a9c03'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'WORKSPACE', 'Non-assigned items', '4', 'false', (select id from permission where code='WFP_BLOCK_3bfa5cf2-d701-418a-8441-6070a94a9c03'), 'false', 'WORKSPACE');



--Schema 0
--Recent issues
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_SHOW_ALL', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_SHOW_ALL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_SHOW_ALL', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_MY_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_MY_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_MY_ITEMS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_RELATED_ITEMS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_NON_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_NON_RELATED_ITEMS', 'HR', 'ALLOW');


--Employee tasks by status
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_SHOW_ALL', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_SHOW_ALL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_SHOW_ALL', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_MY_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_MY_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_MY_ITEMS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_RELATED_ITEMS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'HR', 'ALLOW');


--Employee issues by status
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_SHOW_ALL', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_SHOW_ALL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_SHOW_ALL', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_MY_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_MY_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_MY_ITEMS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_RELATED_ITEMS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'HR', 'ALLOW');







--Recent issues
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_SHOW_ALL', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_SHOW_ALL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_SHOW_ALL', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_MY_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_MY_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_MY_ITEMS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_RELATED_ITEMS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_NON_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('RECENT ISSUE_NON_RELATED_ITEMS', 'HR', 'ALLOW');


--Employee tasks by status
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_SHOW_ALL', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_SHOW_ALL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_SHOW_ALL', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_MY_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_MY_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_MY_ITEMS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_RELATED_ITEMS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS TASK_NON_RELATED_ITEMS', 'HR', 'ALLOW');


--Employee issues by status
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_SHOW_ALL', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_SHOW_ALL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_SHOW_ALL', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_MY_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_MY_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_MY_ITEMS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_RELATED_ITEMS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('BY_STATUS ISSUE_NON_RELATED_ITEMS', 'HR', 'ALLOW');



