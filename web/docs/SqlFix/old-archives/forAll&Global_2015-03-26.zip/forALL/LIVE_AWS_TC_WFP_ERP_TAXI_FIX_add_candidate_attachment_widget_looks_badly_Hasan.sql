UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CANDIDATE_FORM' AND field_id = 'ATTACHMENTS';
UPDATE modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE field_id = 'ATTACHMENTS';


UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CANDIDATE_FORM' AND field_id = 'ATTACHMENTS';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE field_id = 'ATTACHMENTS';
