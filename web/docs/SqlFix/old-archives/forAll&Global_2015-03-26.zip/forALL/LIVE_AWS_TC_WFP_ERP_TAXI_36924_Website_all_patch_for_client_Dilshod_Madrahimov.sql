--AWS URILGAN, FAQAT LIFE UCHUN

--first
update "anv".wfp_block set code = title;

update "anv".wfp_block set code = replace(code, 'BLOCK  -  ', '');
update "anv".wfp_block set code = replace(code, 'BLOCK  - ', '');
update "anv".wfp_block set code = replace(code, 'BLOCK -  ', '');
update "anv".wfp_block set code = replace(code, 'BLOCK - ', '');
update "anv".wfp_block set code = replace(code, 'BLOCK- ', '');
update "anv".wfp_block set code = replace(code, 'BLOCK -', '');
update "anv".wfp_block set code = replace(code, 'BLOCK-', '');
update "anv".wfp_block set code = replace(code, 'BLOCK', '');

update "anv".wfp_block set code = replace(code, 'Block  -  ', '');
update "anv".wfp_block set code = replace(code, 'Block  - ', '');
update "anv".wfp_block set code = replace(code, 'Block -  ', '');
update "anv".wfp_block set code = replace(code, 'Block - ', '');
update "anv".wfp_block set code = replace(code, 'Block- ', '');
update "anv".wfp_block set code = replace(code, 'Block -', '');
update "anv".wfp_block set code = replace(code, 'Block-', '');
update "anv".wfp_block set code = replace(code, 'Block', '');

update "anv".wfp_block set code = replace(code, ' ', '_');

update "anv".wfp_block set code = replace(code, code, UPPER(code));

--second
update "anv".wfp_website_layout   set content = layout ;


--third
update "anv".wfp_page p set content =(select layout from "anv".wfp_page_layout pl  where  p.pagelayout_guid=pl.external_guid limit 1);


--fourth
update "anv".wfp_page_layout pl set content =(select p.content from "anv".wfp_page p where p.pagelayout_guid=pl.external_guid limit 1);

