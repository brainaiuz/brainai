insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_CAN_APPROVE_EXPENSE_CLAIM_DOUBLE_APPROVE', 'ACCOUNTING', 'Accountant Approval in Expense Claim', '7', 'false', (select id from permission where code='ACCOUNTING_EXPENSE_REPORT_LIST'), 'false', 'CORE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CAN_APPROVE_EXPENSE_CLAIM_DOUBLE_APPROVE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CAN_APPROVE_EXPENSE_CLAIM_DOUBLE_APPROVE', 'ADMIN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CAN_APPROVE_EXPENSE_CLAIM_DOUBLE_APPROVE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CAN_APPROVE_EXPENSE_CLAIM_DOUBLE_APPROVE', 'ADMIN', 'ALLOW');