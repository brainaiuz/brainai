
--Buni faqat so'ralgan clientlarga yoqib berish kerak. Hammaga companyga urush kerakmas

INSERT INTO "COMPANY_ID".genericsettings (key, value) VALUES  ('VIEW_TASK_COMMENTS', 'YES');