insert into permission(code, context, name, ismainmenu, modulecode) values('PAYROLL_EMPLOYEE_ADD', 'PAYROLL', 'Add New Employee', false, 'CORE');


insert into "0".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'ADMIN');
insert into "0".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'DR');
insert into "0".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'HR');
insert into "0".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'PM');


insert into "anv".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'ADMIN');
insert into "anv".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'DR');
insert into "anv".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'HR');
insert into "anv".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_ADD', 'PM');