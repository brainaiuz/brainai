insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_CUSTOMER_IMPORT', 'PM', 'Customer Import', '4', 'false', (select id from permission where code='PM_CUSTOMER_LIST'), 'false', 'CORE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_CUSTOMER_EXPORT', 'PM', 'Customer Export', '5', 'false', (select id from permission where code='PM_CUSTOMER_LIST'), 'false', 'CORE');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_ACCOUNTS_IMPORT', 'CRM', 'Accounts Import', '12', 'false', (select id from permission where code='CRM_ACCOUNTS_LIST'), 'false', 'CORE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_ACCOUNTS_EXPORT', 'CRM', 'Accounts Export', '13', 'false', (select id from permission where code='CRM_ACCOUNTS_LIST'), 'false', 'CORE');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_CONTACTS_IMPORT', 'CRM', 'Contacts Import', '18', 'false', (select id from permission where code='CRM_CONTACTS_LIST'), 'false', 'CORE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_CONTACTS_EXPORT', 'CRM', 'Contacts Export', '19', 'false', (select id from permission where code='CRM_CONTACTS_LIST'), 'false', 'CORE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_GOOGLE_CONTACTS', 'CRM', 'Google Contacts', '20', 'false', (select id from permission where code='CRM_CONTACTS_LIST'), 'false', 'CORE');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_CUSTOMER_IMPORT', 'ACCOUNTING', 'Customer Import', '6', 'false', (select id from permission where code='ACCOUNTING_CUSTOMER_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_CUSTOMER_EXPORT', 'ACCOUNTING', 'Customer Export', '7', 'false', (select id from permission where code='ACCOUNTING_CUSTOMER_LIST'), 'false', 'ACCOUNTING_MODULE');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SUPPLIER_IMPORT', 'ACCOUNTING', 'Supplier Import', '5', 'false', (select id from permission where code='ACCOUNTING_SUPPLIER_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SUPPLIER_EXPORT', 'ACCOUNTING', 'Supplier Export', '6', 'false', (select id from permission where code='ACCOUNTING_SUPPLIER_LIST'), 'false', 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'ACCOUNTANT', 'ALLOW');




insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_IMPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CUSTOMER_EXPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_EXPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_EXPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_GOOGLE_CONTACTS', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_IMPORT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CUSTOMER_EXPORT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_IMPORT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_EXPORT', 'ACCOUNTANT', 'ALLOW');









