
                                                           ------ SALES QUOTE ----------------

--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_QUOTE_PDF','CRM','Sales Quote PDF',6,'false',(select id from permission where code='CRM_SALES_QUOTE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_PDF', 'PM', 'ALLOW');


                                                    -----      SALES INVOICE -----------
--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_INVOICE_PDF','CRM','Sales Invoice PDF',6,'false',(select id from permission where code='CRM_SALES_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_PDF', 'PM', 'ALLOW');


                                                            --------  PURCHASE INVOICE ---------------

--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_INVOICE_PDF','CRM','Purchase Invoice PDF',6,'false',(select id from permission where code='CRM_PURCHASE_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_PDF', 'PM', 'ALLOW');




                                                       --------  PURCHASE ORDER  ------------
--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_ORDER_PDF','CRM','Purchase Order PDF',6,'false',(select id from permission where code='CRM_PURCHASE_ORDER_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_PDF', 'PM', 'ALLOW');



                                                             --------  SALES ORDER  ------------
--- PDF
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_ORDER_PDF','CRM','Sales Order PDF',6,'false',(select id from permission where code='CRM_SALES_ORDER_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_ORDER_PDF', 'PM', 'ALLOW');






