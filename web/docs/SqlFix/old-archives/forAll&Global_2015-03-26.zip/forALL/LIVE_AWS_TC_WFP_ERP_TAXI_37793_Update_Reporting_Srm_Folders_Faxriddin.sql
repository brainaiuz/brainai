update "anv".reporting set folderid=(select id from "anv".folders where name='Case Reports') where folderid=(select id from "anv".folders where name='CRM Case Reports');
update "anv".folders set sorder =1,description='Show lead details per their Source, Owner, Status and Comments' where name='Lead Reports';
update "anv".folders set sorder =10,description='Show how your business is performing based on sales and probability' where name='Opportunity Reports';
update "anv".folders set sorder =20,name='Account and Contact Reports',description='Show details of your contacts and CRM accounts.' where name='Contact Reports';
update "anv".folders set sorder =50,description='Show case details per their Origin, Priorities, Status and Comments' where name='Case Reports';
update "anv".folders set deleted=true where name='CRM Case Reports';
delete from "anv".folders where name='Activity Reports';
insert into "anv".folders (domainname,name,showhide,type,creationdate,modificationdate,description,category_id,sorder)
select domainname,'Activity Reports',true,'System',now(),now(),'Show details of the call/event in your activities.',2,30 from "anv".folders where category_id=2 and deleted is not true limit 1;
delete from "anv".folders where name='Campaign Reports';
insert into "anv".folders (domainname,name,showhide,type,creationdate,modificationdate,description,category_id,sorder)
select domainname,'Campaign Reports',true,'System',now(),now(),'Leads/Contacts which are marketed to through this Campaign.',2,40 from "anv".folders where category_id=2 and deleted is not true limit 1;

update "0".reporting set folderid=(select id from "0".folders where name='Case Reports') where folderid=(select id from "0".folders where name='CRM Case Reports');
update "0".folders set sorder =1,description='Show lead details per their Source, Owner, Status and Comments' where name='Lead Reports';
update "0".folders set sorder =10,description='Show how your business is performing based on sales and probability' where name='Opportunity Reports';
update "0".folders set sorder =20,name='Account and Contact Reports',description='Show details of your contacts and CRM accounts.' where name='Contact Reports';
update "0".folders set sorder =50,description='Show case details per their Origin, Priorities, Status and Comments' where name='Case Reports';
update "0".folders set deleted=true where name='CRM Case Reports';
delete from "0".folders where name='Activity Reports';
insert into "0".folders (domainname,name,showhide,type,creationdate,modificationdate,description,category_id,sorder)
select domainname,'Activity Reports',true,'System',now(),now(),'Show details of the call/event in your activities.',2,30 from "0".folders where category_id=2 and deleted is not true limit 1;
delete from "0".folders where name='Campaign Reports';
insert into "0".folders (domainname,name,showhide,type,creationdate,modificationdate,description,category_id,sorder)
select domainname,'Campaign Reports',true,'System',now(),now(),'Leads/Contacts which are marketed to through this Campaign.',2,40 from "0".folders where category_id=2 and deleted is not true limit 1;
