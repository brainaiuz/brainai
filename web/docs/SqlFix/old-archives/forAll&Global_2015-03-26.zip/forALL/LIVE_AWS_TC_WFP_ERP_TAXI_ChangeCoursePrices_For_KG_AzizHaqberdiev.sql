--'CHA', 'FW', 'IFR', 'IND', 'NORMA', 'NORMS' courselar uchun
update "31287".scheduledcourse set price = '48'
where course_id in (select id from "31287".course where number in ('CHA', 'FW', 'IFR', 'IND', 'NORMA', 'NORMS'))
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012';
update "31287".scheduledcourse set price = '32'
where course_id in (select id from "31287".course where number in ('CHA', 'FW', 'IFR', 'IND', 'NORMA', 'NORMS', 'CHAS', 'CMC', 'SLE', 'EA', 'H2S', 'SCBA', 'DHR'))
and location_id in (select id from "31287".location where city = 'HSE TC Fahud' or city = 'HSE TC Nimr')
and startdate > '01-10-2012';
update "31287".scheduledcourse set price = '34'
where course_id in (select id from "31287".course where number in ('CHA', 'FW', 'IFR', 'IND', 'NORMA', 'NORMS', 'CHAS', 'CMC', 'SLE', 'EA', 'H2S', 'SCBA', 'DHR'))
and location_id in (select id from "31287".location where city = 'Other Interior')
and startdate > '01-10-2012';

--'CHAS', 'CMC', 'SLE' courselar uchun
update "31287".scheduledcourse set price = '72'
where course_id in (select id from "31287".course where number in ('CHAS', 'CMC', 'SLE'))
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012';

--'EA', 'H2S', 'SCBA', 'DHR' courselar uchun
update "31287".scheduledcourse set price = '62'
where course_id in (select id from "31287".course where number in ('EA', 'H2S', 'SCBA', 'DHR'))
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012';

--OTCO course uchun
update "31287".scheduledcourse set price = '113'
where course_id in (select id from "31287".course where number = 'OTCO')
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012';
update "31287".scheduledcourse set price = '97'
where course_id in (select id from "31287".course where number = 'OTCO')
and location_id in (select id from "31287".location where city = 'HSE TC Fahud' or city = 'HSE TC Nimr')
and startdate > '01-10-2012';
update "31287".scheduledcourse set price = '100'
where course_id in (select id from "31287".course where number = 'OTCO')
and location_id in (select id from "31287".location where city = 'Other Interior')
and startdate > '01-10-2012';

--IFRR course uchun
update "31287".scheduledcourse set price = '12'
where course_id in (select id from "31287".course where number = 'IFRR')
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012';
update "31287".scheduledcourse set price = '10'
where course_id in (select id from "31287".course where number = 'IFRR')
and location_id in (select id from "31287".location where city <> 'Coastal')
and startdate > '01-10-2012';
--FLOPR course uchun
update "31287".scheduledcourse set price = '22'
where course_id in (select id from "31287".course where number = 'FLOPR')
and startdate > '01-10-2012';

--AHAF course uchun
update "31287".scheduledcourse set price = '100'
where course_id in (select id from "31287".course where number = 'AHAF')
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012';
update "31287".scheduledcourse set price = '110'
where course_id in (select id from "31287".course where number = 'AHAF')
and location_id in (select id from "31287".location where city <> 'Coastal')
and startdate > '01-10-2012';

--TPB course uchun
update "31287".scheduledcourse set price = '999'
where course_id in (select id from "31287".course where number = 'TPB')
and startdate > '01-10-2012';

--'HIAB OLD', 'RNB OLD', 'RNB', 'HIAB' courselar uchun
update "31287".scheduledcourse set price = '50'
where course_id in (select id from "31287".course where number in ('HIAB OLD', 'RNB OLD', 'RNB', 'HIAB'))
and (startdate between '01-10-2012' and '26-07-2013');

--MCOP course uchun
update "31287".scheduledcourse set price = '255'
where course_id in (select id from "31287".course where number = 'MCOP')
and startdate > '01-10-2012';

--HTS course uchun
update "31287".scheduledcourse set price = '118'
where course_id in (select id from "31287".course where number = 'HTS')
and startdate > '01-10-2012';

--DHR, HTS courselar uchun stopFee change
update "31287".scheduledcourse set stopfee = '12'
where course_id in (select id from "31287".course where number in ('DHR', 'HTS'))
and startdate > '01-10-2012';

update "31287".courseschedulestudent css set price = (select price from "31287".scheduledcourse where id=css.courseschedule_id), 
stopfee = (select stopfee from "31287".scheduledcourse where id=css.courseschedule_id);

--AHAF course uchun PDO
update "31287".courseschedulestudent css set price = '102'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number = 'AHAF')
and startdate > '01-10-2012')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;

--TPB course uchun PDO
update "31287".courseschedulestudent css set price = '100'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number = 'TPB')
and startdate > '01-10-2012')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;

--HTS course uchun PDO
update "31287".courseschedulestudent css set price = '118'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number = 'HTS')
and startdate > '01-10-2012')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;

--DHR course uchun PDO
update "31287".courseschedulestudent css set price = '62'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number = 'DHR')
and location_id in (select id from "31287".location where city = 'Coastal')
and startdate > '01-10-2012')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;
update "31287".courseschedulestudent css set price = '32'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number = 'DHR')
and location_id in (select id from "31287".location where city = 'HSE TC Fahud' or city = 'HSE TC Nimr')
and startdate > '01-10-2012')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;
update "31287".courseschedulestudent css set price = '34'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number = 'DHR')
and location_id in (select id from "31287".location where city = 'Other Interior')
and startdate > '01-10-2012')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;

--DHR, HTS courselar uchun stopFee change PDO
update "31287".courseschedulestudent css set stopfee = '0'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number in ('DHR', 'HTS'))
and startdate > '01-05-2013')
and (select customer_id from "31287".coursebooking where id=css.coursebooking_id) = 33;


--26 Julydan kngilar
--'RNB', 'HIAB' courselar uchun
update "31287".scheduledcourse set price = '153'
where course_id in (select id from "31287".course where number in ('RNB', 'HIAB'))
and startdate > '26-07-2013';

--'RNB', 'HIAB' courselar uchun studentga
update "31287".courseschedulestudent css set price = '153'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id in (select id from "31287".course where number in ('RNB', 'HIAB'))
and startdate > '26-07-2013');