insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_TASK_LINKS', 'PM', 'Task Links', '11', 'false', (select id from permission where code='PM_TASKS_LIST'), 'false', 'CORE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'TL', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_TASK_LINKS', 'TL', 'ALLOW');