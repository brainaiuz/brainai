--email_templates_module_categories_change_AzizHaqberdiev.sql patchdan keyin urilsin

update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_INVOICE_MODULE')
where code in ('SALES_INVOICE_CATEGORY', 'RECURRING_INVOICE_CATEGORY', 'RECEIPT_CATEGORY', 'CREDIT_NOTE_CATEGORY', 'OVERDUE_INVOICE_REMINDER_FOR_CLIENT_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_SALES_QUOTE_MODULE')
where code in ('SALES_QUOTE_MANAGER_CATEGORY', 'SALES_QUOTE_CATEGORY', 'SALES_ORDER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PURCHASE_ORDER_MODULE')
where code in ('PURCHASE_ORDER_CATEGORY', 'PURCHASE_ORDER_MANAGER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_EXPENSE_MODULE')
where code in ('EXPENSE_CLAIM_CATEGORY_SUBMIT', 'EXPENSE_CLAIM_CATEGORY_RESUBMIT');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_CASE_MODULE')
where code in ('CASE_REPLIED_CATEGORY', 'CASE_AUTO_RESPONSE_CATEGORY', 'CASE_CLOSE_NOTIFICATION_CATEGORY', 'CASE_CLOSE_NOTIFICATION_CATEGORY_FOR_REPORTER', 'DOC_UPLOAD_TO_CASE_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_OPPORTUNITY_MODULE')
where code in ('OPPORTUNITY_CREATED_CATEGORY', 'OPPORTUNITY_ASSIGNED_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_CONTACT_MODULE')
where code in ('GOOGLE_CONTACT_SYNC_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_BALANCE_MODULE')
where code in ('SUPPLIER_BALANCE_CATEGORY', 'CUSTOMER_BALANCE_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_REPORTING_SYSTEM_MODULE')
where code in ('REPORTING_SYSTEM', 'REPORT_REMINDER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_EVENT_MODULE')
where code in ('CALENDAR_EVENT_ADD_CATEGORY', 'CALENDAR_INVITATION_TO_GUESTS_ADD_CATEGORY', 'CALENDAR_INVITATION_TO_GUESTS_EDIT_CATEGORY',
'CALENDAR_INVITATION_TO_GUESTS_DELETE_CATEGORY', 'CALENDAR_EVENT_EDIT_CATEGORY', 'CALENDAR_EVENT_DELETE_CATEGORY', 'CALENDAR_EVENT_SHARE_CATEGORY',
'CALENDAR_EVENT_SHARE_EDIT_CATEGORY', 'CALENDAR_EVENT_REMINDER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_BUSINESS_GOAL_MODULE')
where code in ('BUSINESS_GOAL_ASSIGN_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_DEPARTMENT_GOAL_MODULE')
where code in ('DEPARTMENT_GOAL_ASSIGN_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PERSONAL_GOAL_MODULE')
where code in ('PERSONAL_GOAL_ASSIGN_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PROJECT_GOAL_MODULE')
where code in ('PROJECT_GOAL_ASSIGN_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PRODUCT_MODULE')
where code in ('PRODUCT_STOCK_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_TASK_MODULE')
where code in ('TASK_ASSIGN_CATEGORY', 'MULTI_TASK_ASSIGN_CATEGORY', 'TASK_DELETE_CATEGORY', 'TASK_UPDATE_CATEGORY', 'TASK_COMPLETED_PREDECESSOR_CATEGORY',
'TASK_COMPLETED_CATEGORY', 'DOC_UPLOAD_TO_TASK_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PROJECT_MODULE')
where code in ('PROJECT_ADD_CATEGORY', 'PROJECT_DELETE_CATEGORY', 'PROJECT_UPDATE_CATEGORY', 'PROJECT_ASSIGN_CATEGORY', 'PROJECT_MANAGER_ASSIGN_CATEGORY',
'BACKUP_MANAGER_ASSIGN_CATEGORY', 'DOC_UPLOAD_TO_PROJECT_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_ACTIVATION_MODULE')
where code in ('CLIENT_ACTIVATION_NEW_USER_CATEGORY', 'CLIENT_ACTIVATION_EXISTING_USER_CATEGORY', 'EMPLOYEE_ACTIVATION_NEW_USER_CATEGORY', 'EMPLOYEE_ACTIVATION_EXISTING_USER_CATEGORY',
'USER_ACCOUNT_CONFIRMATION_CATEGORY', 'EMPLOYEE_ACTIVATED_BY_MANAGER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_LR_MODULE')
where code in ('EMPLOYEE_LEAVE_REQUESTS_CATEGORY', 'ADMIN_LEAVE_REQUESTS_CATEGORY', 'EMPLOYEE_RESPONSE_LEAVE_REQUEST_CATEGORY', 'ADD_LEAVE_REQUEST_SEND_TO_ADMIN_CATEGORY',
'LEAVE_REQUEST_CONFIRMED_SEND_TO_DR_CATEGORY', 'ADD_LEAVE_REQUEST_SEND_TO_APPROVER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_MESSAGE_CENTER_MODULE')
where code in ('MESSAGE_CENTER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_WEB_FORM_MODULE')
where code in ('CRM_WEB_FORM_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_SMS_MODULE')
where code in ('SMS_TEMPLATE_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_MASS_MAIL_MODULE')
where code in ('CRM_MASS_MAILING_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PURCHASE_ORDER_MODULE')
where code in ('REQUEST_FOR_PURCHASE_SEND_TO_MANAGER_CATEGORY', 'REQUEST_FOR_PURCHASE_SEND_TO_EMPLOYEE_FROM_MANAGER_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_PAYROLL_MODULE')
where code in ('EMPLOYEE_PAYSLIP_CATEGORY', 'NEW_EMPLOYEE_PAYSLIP_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_ISSUE_MODULE')
where code in ('ISSUE_ADD_CATEGORY', 'ISSUE_ASSIGN_CATEGORY', 'ISSUE_DELETE_CATEGORY', 'ISSUE_UPDATE_CATEGORY', 'DOC_UPLOAD_TO_ISSUE_CATEGORY');
update "anv".reference set parentid = (select id from "anv".reference where code = 'ET_TRAINING_CENTER_MODULE')
where code in ('COURSE_BOOKING_CONFIRMATION_CATEGORY', 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY', 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY_WITHOUT_MAP',
'COURSE_BOOKING_APPROVE_CATEGORY', 'COURSE_BOOKING_REJECT_CATEGORY', 'COURSE_BOOKING_SMS_SEND_CATEGORY', 'COURSE_REJECTION_SMS_SEND_CATEGORY');


-- for existing templates
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_INVOICE_MODULE')
where categoryid in (select id from "anv".reference where code in ('SALES_INVOICE_CATEGORY', 'RECURRING_INVOICE_CATEGORY', 'RECEIPT_CATEGORY', 'CREDIT_NOTE_CATEGORY',
'OVERDUE_INVOICE_REMINDER_FOR_CLIENT_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_SALES_QUOTE_MODULE')
where categoryid in (select id from "anv".reference where code in ('SALES_QUOTE_MANAGER_CATEGORY', 'SALES_QUOTE_CATEGORY', 'SALES_ORDER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PURCHASE_ORDER_MODULE')
where categoryid in (select id from "anv".reference where code in ('PURCHASE_ORDER_CATEGORY', 'PURCHASE_ORDER_MANAGER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_EXPENSE_MODULE')
where categoryid in (select id from "anv".reference where code in ('EXPENSE_CLAIM_CATEGORY_SUBMIT', 'EXPENSE_CLAIM_CATEGORY_RESUBMIT'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_CASE_MODULE')
where categoryid in (select id from "anv".reference where code in ('CASE_REPLIED_CATEGORY', 'CASE_AUTO_RESPONSE_CATEGORY', 'CASE_CLOSE_NOTIFICATION_CATEGORY',
'CASE_CLOSE_NOTIFICATION_CATEGORY_FOR_REPORTER', 'DOC_UPLOAD_TO_CASE_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_OPPORTUNITY_MODULE')
where categoryid in (select id from "anv".reference where code in ('OPPORTUNITY_CREATED_CATEGORY', 'OPPORTUNITY_ASSIGNED_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_CONTACT_MODULE')
where categoryid in (select id from "anv".reference where code in ('GOOGLE_CONTACT_SYNC_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_BALANCE_MODULE')
where categoryid in (select id from "anv".reference where code in ('SUPPLIER_BALANCE_CATEGORY', 'CUSTOMER_BALANCE_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_REPORTING_SYSTEM_MODULE')
where categoryid in (select id from "anv".reference where code in ('REPORTING_SYSTEM', 'REPORT_REMINDER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE')
where categoryid in (select id from "anv".reference where code in ('CALENDAR_EVENT_ADD_CATEGORY', 'CALENDAR_INVITATION_TO_GUESTS_ADD_CATEGORY',
'CALENDAR_INVITATION_TO_GUESTS_EDIT_CATEGORY', 'CALENDAR_INVITATION_TO_GUESTS_DELETE_CATEGORY', 'CALENDAR_EVENT_EDIT_CATEGORY', 'CALENDAR_EVENT_DELETE_CATEGORY',
'CALENDAR_EVENT_SHARE_CATEGORY', 'CALENDAR_EVENT_SHARE_EDIT_CATEGORY', 'CALENDAR_EVENT_REMINDER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_BUSINESS_GOAL_MODULE')
where categoryid in (select id from "anv".reference where code in ('BUSINESS_GOAL_ASSIGN_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_DEPARTMENT_GOAL_MODULE')
where categoryid in (select id from "anv".reference where code in ('DEPARTMENT_GOAL_ASSIGN_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PERSONAL_GOAL_MODULE')
where categoryid in (select id from "anv".reference where code in ('PERSONAL_GOAL_ASSIGN_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PROJECT_GOAL_MODULE')
where categoryid in (select id from "anv".reference where code in ('PROJECT_GOAL_ASSIGN_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PRODUCT_MODULE')
where categoryid in (select id from "anv".reference where code in ('PRODUCT_STOCK_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_TASK_MODULE')
where categoryid in (select id from "anv".reference where code in ('TASK_ASSIGN_CATEGORY', 'MULTI_TASK_ASSIGN_CATEGORY', 'TASK_DELETE_CATEGORY', 'TASK_UPDATE_CATEGORY',
'TASK_COMPLETED_PREDECESSOR_CATEGORY', 'TASK_COMPLETED_CATEGORY', 'DOC_UPLOAD_TO_TASK_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PROJECT_MODULE')
where categoryid in (select id from "anv".reference where code in ('PROJECT_ADD_CATEGORY', 'PROJECT_DELETE_CATEGORY', 'PROJECT_UPDATE_CATEGORY', 'PROJECT_ASSIGN_CATEGORY',
'PROJECT_MANAGER_ASSIGN_CATEGORY', 'BACKUP_MANAGER_ASSIGN_CATEGORY', 'DOC_UPLOAD_TO_PROJECT_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_ACTIVATION_MODULE')
where categoryid in (select id from "anv".reference where code in ('CLIENT_ACTIVATION_NEW_USER_CATEGORY', 'CLIENT_ACTIVATION_EXISTING_USER_CATEGORY',
'EMPLOYEE_ACTIVATION_NEW_USER_CATEGORY', 'EMPLOYEE_ACTIVATION_EXISTING_USER_CATEGORY', 'USER_ACCOUNT_CONFIRMATION_CATEGORY', 'EMPLOYEE_ACTIVATED_BY_MANAGER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_LR_MODULE')
where categoryid in (select id from "anv".reference where code in ('EMPLOYEE_LEAVE_REQUESTS_CATEGORY', 'ADMIN_LEAVE_REQUESTS_CATEGORY', 'EMPLOYEE_RESPONSE_LEAVE_REQUEST_CATEGORY',
'ADD_LEAVE_REQUEST_SEND_TO_ADMIN_CATEGORY', 'LEAVE_REQUEST_CONFIRMED_SEND_TO_DR_CATEGORY', 'ADD_LEAVE_REQUEST_SEND_TO_APPROVER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_MESSAGE_CENTER_MODULE')
where categoryid in (select id from "anv".reference where code in ('MESSAGE_CENTER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_WEB_FORM_MODULE')
where categoryid in (select id from "anv".reference where code in ('CRM_WEB_FORM_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_SMS_MODULE')
where categoryid in (select id from "anv".reference where code in ('SMS_TEMPLATE_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_MASS_MAIL_MODULE')
where categoryid in (select id from "anv".reference where code in ('CRM_MASS_MAILING_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PURCHASE_ORDER_MODULE')
where categoryid in (select id from "anv".reference where code in ('REQUEST_FOR_PURCHASE_SEND_TO_MANAGER_CATEGORY', 'REQUEST_FOR_PURCHASE_SEND_TO_EMPLOYEE_FROM_MANAGER_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_PAYROLL_MODULE')
where categoryid in (select id from "anv".reference where code in ('EMPLOYEE_PAYSLIP_CATEGORY', 'NEW_EMPLOYEE_PAYSLIP_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_ISSUE_MODULE')
where categoryid in (select id from "anv".reference where code in ('ISSUE_ADD_CATEGORY', 'ISSUE_ASSIGN_CATEGORY', 'ISSUE_DELETE_CATEGORY', 'ISSUE_UPDATE_CATEGORY',
'DOC_UPLOAD_TO_ISSUE_CATEGORY'));
update "anv".emailTemplate set module_id = (select id from "anv".reference where code = 'ET_TRAINING_CENTER_MODULE')
where categoryid in (select id from "anv".reference where code in ('COURSE_BOOKING_CONFIRMATION_CATEGORY', 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY',
'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY_WITHOUT_MAP', 'COURSE_BOOKING_APPROVE_CATEGORY', 'COURSE_BOOKING_REJECT_CATEGORY', 'COURSE_BOOKING_SMS_SEND_CATEGORY',
'COURSE_REJECTION_SMS_SEND_CATEGORY'));