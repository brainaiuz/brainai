insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_STATUS', 'Workflow Statuses', 0, null);
--insert into "0".reference(code, name, sorder, parentid) values('ACTIVE', 'Active', 1, (select id from "0".reference where code = '_WORKFLOW_STATUS' limit 1));
--insert into "0".reference(code, name, sorder, parentid) values('INACTIVE', 'Inactive', 2, (select id from "0".reference where code = '_WORKFLOW_STATUS' limit 1));

insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE', 'Workflow Modules', 0, null);
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE_CONTACT', 'Contact', 1, (select id from "0".reference where code = '_WORKFLOW_MODULE' limit 1));
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE_LEAD', 'Lead', 2, (select id from "0".reference where code = '_WORKFLOW_MODULE' limit 1));

insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA', 'Workflow EXECUTION CRITERIA', 0, null);
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_EDIT', 'EDIT(Executes the rule when records are edited)', 1, (select id from "0".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_CREATE', 'CREATE(Executes the rule when new records are created)', 2, (select id from "0".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_CREATE_EDIT', 'CREATE or EDIT(Executes the rule when new records are created or modified)', 3, (select id from "0".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_UPDATE_SPECIFIED_FIELD', 'UPDATE SPECIFIED FIELD(Executes the rule when the value of specified field changed)', 4, (select id from "0".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_REMOVE', 'REMOVE(Executes the rule when record(s) are deleted)', 5, (select id from "0".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));

insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_STATUS', 'Workflow Statuses', 0, null);
--insert into "anv".reference(code, name, sorder, parentid) values('ACTIVE', 'Active', 1, (select id from "anv".reference where code = '_WORKFLOW_STATUS' limit 1));
--insert into "anv".reference(code, name, sorder, parentid) values('INACTIVE', 'Inactive', 2, (select id from "anv".reference where code = '_WORKFLOW_STATUS' limit 1));

insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE', 'Workflow Modules', 0, null);
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE_CONTACT', 'Contact', 1, (select id from "anv".reference where code = '_WORKFLOW_MODULE' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE_LEAD', 'Lead', 2, (select id from "anv".reference where code = '_WORKFLOW_MODULE' limit 1));

insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA', 'Workflow EXECUTION CRITERIA', 0, null);
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_EDIT', 'EDIT(Executes the rule when records are edited)', 1, (select id from "anv".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_CREATE', 'CREATE(Executes the rule when new records are created)', 2, (select id from "anv".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_CREATE_EDIT', 'CREATE or EDIT(Executes the rule when new records are created or modified)', 3, (select id from "anv".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_UPDATE_SPECIFIED_FIELD', 'UPDATE SPECIFIED FIELD(Executes the rule when the value of specified field changed)', 4, (select id from "anv".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_REMOVE', 'REMOVE(Executes the rule when record(s) are deleted)', 5, (select id from "anv".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
