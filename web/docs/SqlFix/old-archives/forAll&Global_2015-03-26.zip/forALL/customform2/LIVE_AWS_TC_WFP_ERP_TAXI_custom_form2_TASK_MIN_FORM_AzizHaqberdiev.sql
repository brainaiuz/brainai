delete from  modelfield where form_ID ='TASK_MIN_FORM';
delete from  model where formID ='TASK_MIN_FORM';



insert into model(active, formID, title, viewname) values(true, 'TASK_MIN_FORM', 'Add Edit Task', 'Task');

--Task details
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,   section,       widget,       form_ID,   noWrapperFor, labelless ) values
                      (01,     true ,      false,  false,       '',           true,            '',     'NAME',        'DESCRIPTION', 'TextBox'  ,  'TASK_MIN_FORM','', false ),
                      (02,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION', 'DESCRIPTION', 'TextArea'  , 'TASK_MIN_FORM','', false ),
                      (03,     false,      false,  false,       '',           false,           '',     'BILLIBLE',  'DESCRIPTION', 'CheckBox'  ,  'TASK_MIN_FORM','', false );

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='TASK_MIN_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='TASK_MIN_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd'  where form_ID ='TASK_MIN_FORM' AND noLabelFor is not null AND noLabelFor != '';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='TASK_MIN_FORM';
UPDATE modelfield set halfSetStyle = ''  where form_ID ='TASK_MIN_FORM' AND noLabelFor is not null AND noLabelFor != '';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='TASK_MIN_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='TASK_MIN_FORM';


delete from "anv".modelfield where form_ID ='TASK_MIN_FORM';
delete from "anv".model where formID ='TASK_MIN_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('TASK_MIN_FORM', 'Task')) IS NOT NULL;

