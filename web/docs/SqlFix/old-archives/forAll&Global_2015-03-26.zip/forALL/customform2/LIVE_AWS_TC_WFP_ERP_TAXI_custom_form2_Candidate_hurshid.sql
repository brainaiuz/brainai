

---------------------------------------------------------------------------------------------------------------------------------
---ATTENTION:                                                                                                                       |
--Bu patch xato bersa, bundan oldin LIVE_AWS_TC_custom_form_convert_custom_fields_to_modelfield_Hayot.sql patchni urvorish kerak.   |
---------------------------------------------------------------------------------------------------------------------------------



delete from "model"  where formid = 'CANDIDATE_FORM';
delete from "modelfield"  where form_id = 'CANDIDATE_FORM';

insert into model(formID, active, title, viewname) values('CANDIDATE_FORM', true, 'Candidate Form', 'Candidate');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, labelless, field_ID,         section,                 widget      ,form_ID,               noLabelFor) values
                      (01,     false,      false,  false,          null,           false,           false,'NUMBER',          'CONTACT_INFORMATION',   'UNKNOWN'  ,   'CANDIDATE_FORM',  ''),
                      (02,     false,      false,  false,          null,           false,           false,'OWNER',           'CONTACT_INFORMATION',   'DropDown'  ,  'CANDIDATE_FORM',  ''),
                      (03,     false,      false,  false,          null,           true ,           false,'FIRST_NAME',      'CONTACT_INFORMATION',   'UNKNOWN'  ,   'CANDIDATE_FORM',  ''),
                      (04,     false,      false,  false,          null,           true ,           false,'LAST_NAME',       'CONTACT_INFORMATION',   'TextBox'  ,   'CANDIDATE_FORM',  ''),
                      (05,     false,      false,  false,          null,           false,           false,'BIRTH_DAY',       'CONTACT_INFORMATION',   'UNKNOWN'  ,   'CANDIDATE_FORM',  ''),
                      (06,     false,      false,  false,          null,           false,           false,'CREATED_DATE',    'CONTACT_INFORMATION',   'DatePicker'  ,'CONTACT_FORM',  ''),
                      (07,     false,      false,  false,          null,           false,           false,'LEAD_SOURCE',     'CONTACT_INFORMATION',   'DropDown'  ,  'CANDIDATE_FORM',  ''),
                      (08,     false,      false,  false,          null,           false,           false,'VACANCIES',       'CONTACT_INFORMATION',   'UNKNOWN'  ,   'CANDIDATE_FORM',  ''),
                      (09,     false,      false,  false,          null,           false,           false,'WORK_EXPERIENCE', 'CONTACT_INFORMATION',   'UNKNOWN'  ,   'CANDIDATE_FORM',  ''),
                      (10,     false,      false,  false,          null,           false,           false,'CURRENT_EMPLOYER','CONTACT_INFORMATION',   'TextBox'  ,   'CANDIDATE_FORM',  ''),
                      (11,     false,      false,  false,          null,           false,           false,'EXPECTED_SALARY', 'CONTACT_INFORMATION',   'TextBox'  ,   'CANDIDATE_FORM',  ''),
                      (12,     false,      false,  false,          null,           false,           false,'STATUS',          'CONTACT_INFORMATION',   'DropDown'  ,  'CANDIDATE_FORM',  ''),
                      (13,     false,      false,  false,          null,           false,           false,'LOCATION',        'CONTACT_INFORMATION',   'DropDown'  ,  'CANDIDATE_FORM',  ''),
                      (14,     false,      false,  false,          null,           false,           false,'SKILLS',          'CONTACT_INFORMATION',   'TextArea'  ,  'CANDIDATE_FORM',  ''),

                      (15,     false,      false,  false,          null,           false,           false,'PHONE',            'INFORMATION',   'MULTITABLE'  ,       'CANDIDATE_FORM',  ''),
                      (16,     false,      false,  false,          null,           false,           false,'EMAIL',            'INFORMATION',   'MULTITABLE'  ,       'CANDIDATE_FORM',  ''),
                      (17,     false,      false,  false,          null,           false,           false,'IM_ADDRESS',       'INFORMATION',   'MULTITABLE'  ,       'CANDIDATE_FORM',  ''),
                      (18,     false,      false,  false,          null,           false,           false,'WEB_ADDRESS',      'INFORMATION',   'MULTITABLE'  ,       'CANDIDATE_FORM',  ''),

                      (19,     false,      false,  false,          null,           false,           true ,'CRM_NOTE',         'CRM_NOTE',              'NoteWidget',  'CANDIDATE_FORM',  'addForm,editForm,viewForm'),

                      (20,     false,      false,  false,          null,           false,           true ,'ADDRESS',          'ADDRESS_INFORMATION',   'UNKNOWN'  ,   'CANDIDATE_FORM',  'addForm,editForm,viewForm'),

                      (21,     false,      false,  false,          null,           false,           true ,'LINKS',            'LINKS',   'UNKNOWN'  ,                 'CANDIDATE_FORM',  'addForm,editForm,viewForm'),

                      (22,     false,      false,  false,          null,           false,           true ,'ATTACHMENTS',      'ATTACHMENTS',           'UNKNOWN'  ,   'CANDIDATE_FORM',  'addForm,editForm,viewForm');



UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CANDIDATE_FORM' AND field_id = 'ATTACHMENTS';

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='CANDIDATE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='CANDIDATE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='CANDIDATE_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='CANDIDATE_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='CANDIDATE_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='CANDIDATE_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='CANDIDATE_FORM';

delete from "anv"."model"  where formid = 'CANDIDATE_FORM';
delete from "anv"."modelfield"  where form_id = 'CANDIDATE_FORM';

update company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('CANDIDATE_FORM', 'Candidate')) is not null;
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CANDIDATE_FORM' AND field_id = 'ATTACHMENTS';
