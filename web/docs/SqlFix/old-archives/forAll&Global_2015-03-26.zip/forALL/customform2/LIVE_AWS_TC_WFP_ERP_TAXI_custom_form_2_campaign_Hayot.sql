insert into model(formID, active, title) values('CAMPAIGN_FORM', true, 'Campaign');
insert into modelfield(form_ID,         field_ID,                       sorder, mandatory,  hide,   isCustomField,  section,                defaultValue, widget      ,systemmandatory) values
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_ASSIGNEE',        1,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'DropDown'  ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_NAME',            2,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'TextBox'   ,true             ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_TYPE',            3,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'DropDown'  ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_STATUS',          4,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'DropDown'  ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_STARTDATE',       5,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'DatePicker',false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_ENDDATE',         6,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'DatePicker',false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_EXPECTEDREVENUE', 7,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'TextBox'   ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_BUDGETCOST',      8,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'TextBox'   ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_BUDGETCOST',      9,      false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'TextBox'   ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_EXPECTEDRESPONSE',10,     false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'TextBox'   ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_CAMPAIGN_NUMBERSENT',      11,     false,      false,  false,          'CAMPAIGN_INFORMATION', '',           'TextBox'   ,false            ),
                      ('CAMPAIGN_FORM', 'CRM_NOTE',                     12,     false,      false,  false,          'NOTES',                '',           'NoteWidget',false            );