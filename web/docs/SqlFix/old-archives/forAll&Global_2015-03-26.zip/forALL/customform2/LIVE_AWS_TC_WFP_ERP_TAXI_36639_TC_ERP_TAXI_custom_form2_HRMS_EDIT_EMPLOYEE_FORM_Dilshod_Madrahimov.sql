-- PASSPORT_ISSUE field qo'shildi.Fieldlar Orderi o'zgardi
-- Bu patchdan keyin Aziz Xaqberdievni separate_style_fileds_AzizHaqberdiev.sql patchni urvorish kk

delete from  modelfield where form_ID ='HRMS_EMPLOYEE_FORM';
delete from  model where formID ='HRMS_EMPLOYEE_FORM';

insert into model(active,formID, title,viewname) values(true,'HRMS_EMPLOYEE_FORM', 'HRMS Employee Form','Employee');
 

-- HRMS EMPLOYEE EDIT FORM 
 -- drawEmployeeInformation 
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',     'FIRST_NAME',                     'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (02,     false,      false,  false,          '',           true ,           '',     'LAST_NAME',                      'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (03,     false,      false,  false,          '',           false ,          '',     'MIDDLE_NAME',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (04,     false,      false,  false,          '',           false,           '',     'BIRTH_DAY',                      'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      
		              (05,     false,      false,  false,          '',           false,           '',     'GENDER',                         'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (06,     false,      false,  false,          '',           false,           '',     'NATIONALITY',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (07,     false,      false,  false,          '',           false,           '',     'MARTIAL_STATUS',                 'EMPLOYEE_INFORMATION',   'DropDown' ,   'HRMS_EMPLOYEE_FORM',''),
                      (08,     false,      false,  false,          '',           false,           '',     'LANGUAGE',                       'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM','');

-- drawContactDetails
					  
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (09,     false,      false,  false,          '',           true,            '',     'EMAIL',                         'CONTACT_INFORMATION',   'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM',''),
                      (10,     false,      false,  false,          '',           false ,          '',     'PHONE',                         'CONTACT_INFORMATION',   'MULTITABLE'  ,   'HRMS_EMPLOYEE_FORM',''),
                      
					  (11,     false,      false,  false,          '',           false ,          '',     'IM_ADDRESS',                    'CONTACT_INFORMATION',   'MULTITABLE'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (12,     false,      false,  false,          '',           false ,          '',     'WEB_ADDRESS',                   'CONTACT_INFORMATION',   'MULTITABLE'  ,   'HRMS_EMPLOYEE_FORM','');
					  					  
--- drawAddressInformation             
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor,                        field_ID,    section,                 widget      ,form_ID,     noWrapperFor ) values
                      (13,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'ADDRESS',    'ADDRESS_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');
					  
--drawEmploymentInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (14,     false,      false,  false,          '',           false,            '',     'EMPLOYEE_CODE',            'EMPLOYMENT_INFORMATION',   'NUMBER'  , 'HRMS_EMPLOYEE_FORM',''),
                      (15,     false,      false,  false,          '',           false,            '',     'DEPARTMENT',               'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (16,     false,      false,  false,          '',           false,            '',     'POSITION',                 'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (17,     false,      false,  false,          '',           false,            '',     'LOCATION_FIELD',           'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (18,     false,      false,  false,          '',           false,            '',     'SUPERVISOR',               'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (19,     false,      false,  false,          '',           false,            '',     'WAGE_RATE',                'EMPLOYMENT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (20,     false,      false,  false,          '',           false,            '',     'CLIENT_CHARGE_RATE',       'EMPLOYMENT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      
					  (21,     false,      false,  false,          '',           false,            '',     'HIRE_DATE',                'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (22,     false,      false,  false,          '',           false,            '',     'RESIGNATION_DATE',         'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (23,     false,      false,  false,          '',           false,            '',     'EMPLOYMENT_CONTACT_TERMS', 'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (24,     false,      false,  false,          '',           false,            '',     'EMPLOYMENT_MODE',          'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (25,     false,      false,  false,          '',           false,            '',     'SALARY_GRADE',             'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (26,     false,      false,  false,          '',           false,            '',     'JOB_TITLE',             'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (27,     false,      false,  false,          '',           false,            '',     'SALARY_AMOUNT',            'EMPLOYMENT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (28,     false,      false,  false,          '',           false,            '',     'QUALIFICATION',            'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM','');
					  
--bank information
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (29,     false,      false,  false,          '',           false,            '',     'BANK_NAME',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (30,     false,      false,  false,          '',           false,            '',     'ACCOUNT_NUMBER',           'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (31,     false,      false,  false,          '',           false,            '',     'ACCOUNT_NAME',             'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (32,     false,      false,  false,          '',           false,            '',     'BANK_ADDRESS',             'BANK_ACCOUNT_INFORMATION',   'TextArea'  , 'HRMS_EMPLOYEE_FORM',''),
                      
					  (33,     false,      false,  false,          '',           false,            '',     'SWIFT_CODE',               'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (34,     false,      false,  false,          '',           false,            '',     'SORT_CODE',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (35,     false,      false,  false,          '',           false,            '',     'IBAN_CODE',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (36,     false,      false,  false,          '',           false,            '',     'AGENT_ID',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM','');

					  
--- drawAccountInformation             
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (37,     false,      false,  false,          '',           false,            '',     'ACCOUNT_ROLES',             'ACCOUNT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (38,     false,      false,  false,          '',           false,            '',     'ACCOUNT_STATUS',            'ACCOUNT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM','');
 
---drawPersonalIdentityInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (39,     false,      false,  false,          '',           false,            '',     'PASSPORT_NUMBER',              'PERSONAL_IDENTITY_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (40,     false,      false,  false,          '',           false,            '',     'PASSPORT_ISSUE',              'PERSONAL_IDENTITY_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (41,     false,      false,  false,          '',           false,            '',     'PASSPORT_ISSUE_DATE',          'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (42,     false,      false,  false,          '',           false,            '',     'PASSPORT_EXPIRY_DATE',         'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (43,     false,      false,  false,          '',           false,            '',     'INSURANCE_NUMBER',             'PERSONAL_IDENTITY_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      
					  (44,     false,      false,  false,          '',           false,            '',     'VISA_NUMBER',                  'PERSONAL_IDENTITY_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (45,     false,      false,  false,          '',           false,            '',     'VISA_ISSUE_DATE',              'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (46,     false,      false,  false,          '',           false,            '',     'VISA_EXPIRATION_DATE',         'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (47,     false,      false,  false,          '',           false,            '',     'VISA_EXPIRATION_DATE_REMINDER','PERSONAL_IDENTITY_INFORMATION',   'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM','');
 
--- drawAttachments             
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,   section,                 widget      ,form_ID,     noWrapperFor ) values
                      (49,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'ATTACHMENTS', 'ATTACHMENTS',           'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');
           
            
--------------------------------------------------------------------------------------------------------------------
delete from "anv".modelfield where form_ID ='HRMS_EMPLOYEE_FORM';
delete from "anv".model where formID ='HRMS_EMPLOYEE_FORM';
