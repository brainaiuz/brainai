delete from  modelfield where form_ID ='TASK_MAX_FORM';
delete from  model where formID ='TASK_MAX_FORM';


insert into model(active, formID, title, viewname) values(true, 'TASK_MAX_FORM', 'Add Edit Task', 'Task');

--Task details
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,   section,       widget,       form_ID,   noWrapperFor, labelless ) values
                      (01,     true ,      false,  false,       '',           true,            '',     'PROJECT',     'TASK_DETAILS', 'LOOKUP'  ,  'TASK_MAX_FORM','',  false ),
                      (02,     true ,      false,  false,       '',           false ,          '',     'NUMBER',      'TASK_DETAILS', 'TextBox'  ,  'TASK_MAX_FORM','', false ),
                      (03,     true ,      false,  false,       '',           true,            '',     'NAME',        'TASK_DETAILS', 'TextBox'  ,  'TASK_MAX_FORM','', false ),
                      (04,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION', 'TASK_DETAILS', 'TextArea'  , 'TASK_MAX_FORM','', false ),

                      (05,     true ,      false,  false,       '',           true ,           '',     'START_DATE',  'TASK_DETAILS', 'DatePicker', 'TASK_MAX_FORM','', false ),
                      (06,     true ,      false,  false,       '',           true ,           '',     'DUE_DATE',    'TASK_DETAILS', 'DatePicker', 'TASK_MAX_FORM','', false ),
                      (07,     false,      false,  false,       '',           false ,           '',     'RECALCULATE_HOURS_ON_RESOURCE_UTIL',    'TASK_DETAILS', 'CheckBox', 'TASK_MAX_FORM','', true ),
                      (08,     false,      false,  false,       '',           false,           '',     'PRIORITY',    'TASK_DETAILS', 'DropDown'  , 'TASK_MAX_FORM','', false ),
                      (09,     true ,      false,  false,       '',           false,           '',     'STATUS',      'TASK_DETAILS', 'DropDown'  , 'TASK_MAX_FORM','', false ),
--                       (10,     false,      false,  false,       '',           false,           '',     'PERCENT',     'TASK_DETAILS', 'TextBox'  ,  'TASK_MAX_FORM','', false ),
                      (11,     false,      false,  false,       '',           false,           '',     'BILLIBLE',  'TASK_DETAILS', 'CheckBox'  ,  'TASK_MAX_FORM','', false );

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,        widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (13,     true,      false,  false,        '',           true ,           '',     'ASSIGNEE',   'ASSIGNEES',    'UNKNOWN',   'TASK_MAX_FORM',   '',     false );


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (14,     false,      false,  false,       '',           false,            '',     'PARENT_WORKSTREAM', 'DEPENDENCIES', 'TextBox',   'TASK_MAX_FORM',   '', false ),
                      (15,     false,      false,  false,       '',           false,            '',     'DUE_DATE_REMINDER', 'DEPENDENCIES', 'TextBox',   'TASK_MAX_FORM',   '', false ),
                      (16,     false,      false,  false,       '',           false,            '',     'PREDECESSOR_TASK',  'DEPENDENCIES', 'TextBox',   'TASK_MAX_FORM',   '', false ),
                      (17,     false,      false,  false,       '',           false,            '',     'SUCCESSOR_TASK',    'DEPENDENCIES', 'TextBox',   'TASK_MAX_FORM',   '', false );


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,    section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (18,     false,      false,  false,       '',           false,            'addForm,editForm',     'ATTACHMENTS',  'ATTACHMENTS', 'UNKNOWN', 'TASK_MAX_FORM',   'editForm, addForm',     true);

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,     widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (19,     false,      false, false,          '',           false,            'addForm,editForm',     'LINKS',    'LINKS',    'UNKNOWN',   'TASK_MAX_FORM',   'editForm, addForm', true);

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor,  field_ID,     section,        widget      ,form_ID,              noWrapperFor, labelless  ) values
                      (20,     false,      false, false,          '',           false,            'editForm, addForm', 'TASK_NOTES', 'TASK_NOTES', 'NoteWidget',   'TASK_MAX_FORM',   'editForm, addForm',     true );

insert into modelfield(sorder, mandatory,  hide,  isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,     section,            widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (21,     false,      false,  false,          '',           false,            '',     'RECURRENING',  'ADVANCED_OPTIONS', 'UNKNOWN',   'TASK_MAX_FORM',   '',     false );

update modelfield set split=true where field_ID='DESCRIPTION' and form_ID='TASK_MAX_FORM';

delete from "anv".modelfield where form_ID ='TASK_MAX_FORM';
delete from "anv".model where formID ='TASK_MAX_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('TASK_MAX_FORM', 'Task')) IS NOT NULL;

update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='TASK_MAX_FORM' and field_id='LINKS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='TASK_MAX_FORM' and field_id='ATTACHMENTS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='TASK_MAX_FORM' and field_id='TASK_NOTES';

update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='TASK_MAX_FORM';

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='TASK_MAX_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='TASK_MAX_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_MAX_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='TASK_MAX_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_MAX_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='TASK_MAX_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='TASK_MAX_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1' where form_ID ='TASK_MAX_FORM' and field_id='ATTACHMENTS';

UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' where form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' where form_ID ='TASK_MAX_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' where form_ID ='TASK_MAX_FORM' and field_id='ATTACHMENTS';
