-- Schema Updatedan kn urilsin
DELETE FROM "model"  WHERE formid = 'LEAD_FORM';
DELETE FROM "modelfield"  WHERE form_id = 'LEAD_FORM';

INSERT INTO model(formID, active, title, viewname) VALUES('LEAD_FORM', TRUE, 'Lead Form', 'Lead');
INSERT INTO modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, field_ID,                         SECTION,                 widget      ,form_ID) VALUES
                      (01,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'LEAD_OWNER',                          'LEAD_INFORMATION',   'DropDown'  , 'LEAD_FORM'),
                      (02,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'ASSIGNEE',                            'LEAD_INFORMATION',   'DropDown'  , 'LEAD_FORM'),
                      (03,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'BACKUP_ASSIGNEE',                     'LEAD_INFORMATION',   'DropDown'  , 'LEAD_FORM'),
                      (04,     FALSE,      FALSE,  FALSE,          '',           TRUE ,           'FIRST_NAME',                     'LEAD_INFORMATION',   'UNKNOWN'  ,       'LEAD_FORM'),
                      (05,     FALSE,      FALSE,  FALSE,          '',           TRUE ,           'LAST_NAME',                      'LEAD_INFORMATION',   'TextBox'  ,       'LEAD_FORM'),
                      (06,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'JOB_TITLE',                      'LEAD_INFORMATION',   'TextBox'  ,       'LEAD_FORM'),
                      (07,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'PHONE',                          'LEAD_INFORMATION',   'MULTITABLE'  ,    'LEAD_FORM'),
                      (08,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'EMAIL',                          'LEAD_INFORMATION',   'MULTITABLE'  ,    'LEAD_FORM'),
                      (09,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'IM_ADDRESS',                     'LEAD_INFORMATION',   'MULTITABLE'  ,    'LEAD_FORM'),
                      (10,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'WEB_ADDRESS',                    'LEAD_INFORMATION',   'MULTITABLE'  ,    'LEAD_FORM'),
                      (11,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_NAME',               'LEAD_INFORMATION',   'LOOKUP'  ,        'LEAD_FORM'),
                      (12,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_TYPE',               'LEAD_INFORMATION',   'MULTITABLE'  ,    'LEAD_FORM'),
                      (13,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'STATUS',               'LEAD_INFORMATION',   'DropDown'  ,                'LEAD_FORM'),
                      (14,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'LEAD_SOURCE',               'LEAD_INFORMATION',   'DropDown'  ,           'LEAD_FORM'),
                      (15,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_CAMPAIGN_NAME',              'LEAD_INFORMATION',   'LOOKUP'  ,        'LEAD_FORM'),
                      (16,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_INDUSTRY',           'LEAD_INFORMATION',   'DropDown'  ,      'LEAD_FORM'),
                      (17,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_ORGANIZATION_TYPE',  'LEAD_INFORMATION',   'DropDown'  ,      'LEAD_FORM'),
                      (18,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE', 'LEAD_INFORMATION',   'DropDown'  ,      'LEAD_FORM'),
                      (19,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'RATING',          'LEAD_INFORMATION',   'DropDown'  ,                     'LEAD_FORM'),
                      (20,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_OWNERSHIP',          'LEAD_INFORMATION',   'DropDown'  ,      'LEAD_FORM'),
                      (21,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACCOUNT_ANNUAL_REVENUE',     'LEAD_INFORMATION',   'DropDown'  ,      'LEAD_FORM'),

                      (22,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_ACTIVITIES',                 'CRM_ACTIVITIES',        'UNKNOWN'  ,    'LEAD_FORM'),
                      (23,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'CRM_NOTE',                       'CRM_NOTE',              'NoteWidget'  , 'LEAD_FORM'),

                      (24,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'COPY_CRMACCOUNT_ADDRESS',        'ADDRESS_INFORMATION',   'UNKNOWN'  ,    'LEAD_FORM'),
                      (25,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'ADDRESS',                        'ADDRESS_INFORMATION',   'UNKNOWN'  ,    'LEAD_FORM'),
                      (26,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'PARENT_ADDRESSES',               'ADDRESS_INFORMATION',   'UNKNOWN'  ,    'LEAD_FORM'),

                      (27,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'STATUS_HISTORY',                 'STATUS_HISTORY',        'UNKNOWN'  ,    'LEAD_FORM'),
                      (28,     FALSE,      FALSE,  FALSE,          '',           FALSE,           'ATTACHMENTS',                    'ATTACHMENTS',           'UNKNOWN'  ,    'LEAD_FORM');

DELETE FROM "anv"."model"  WHERE formid = 'LEAD_FORM';
DELETE FROM "anv"."modelfield"  WHERE form_id = 'LEAD_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('LEAD_FORM', 'Lead')) IS NOT NULL;
