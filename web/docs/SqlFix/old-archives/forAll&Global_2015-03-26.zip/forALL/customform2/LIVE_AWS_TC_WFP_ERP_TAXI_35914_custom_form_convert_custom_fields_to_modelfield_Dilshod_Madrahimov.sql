DROP function if EXISTS "anv".convertCustomFieldsToModelFields(modelFormID text, viewName text);
CREATE OR replace function "anv".convertCustomFieldsToModelFields(modelFormID text, viewName text)
  returns INTEGER AS
  $body$
DECLARE  customField record;counter INTEGER;
    BEGIN
            DELETE FROM "anv".model m WHERE m.formid = modelFormID;
            DELETE FROM "anv".modelfield ml WHERE ml.form_id = modelFormID;
            INSERT INTO "anv".model(viewName,title,active, formid) SELECT m.viewName, m.title, m.active, m.formid FROM model m WHERE m.formid = modelFormID;
            INSERT INTO "anv".modelfield(label, customlabel, form_id, field_id, sorder,widget,TYPE, mandatory, systemmandatory,hide,iscustomfield, SECTION, noLabelFor, noWrapperFor, fullWidth) SELECT ml.label, ml.customlabel, ml.form_id, ml.field_id, ml.sorder,ml.widget,ml.type, ml.mandatory, ml.systemmandatory,ml.hide,ml.iscustomfield, ml.section, ml.noLabelFor, ml.noWrapperFor, ml.fullWidth FROM modelfield ml WHERE ml.form_id = modelFormID;
            counter = (SELECT MAX(ml.sorder) FROM modelfield ml WHERE ml.form_id = modelFormID) + 1;
            FOR customField IN (SELECT * FROM "anv".companyCustomFieldsSettings WHERE entityname =viewName)
            loop
                INSERT INTO "anv".modelfield(sorder,  label,                  mandatory,                                                              hide,    isCustomField,  defaultValue, systemmandatory,               labelless,  field_ID,               SECTION,                  widget,             form_ID) VALUES
                                              (counter, customField.fieldname,  customField.isRequired IS NOT NULL AND customField.isRequired IS TRUE,  FALSE,   TRUE,           '',           customField.isRequired,        FALSE,      customField.columncode, 'ADDITIONAL_INFORMATION', customField.uitype, modelFormID);
                counter = counter + 1;
            END loop;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".convertCustomFieldsToModelFields(modelFormID text, viewName text) owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('HRMS_EMPLOYEE_FORM', 'Employee')) IS NOT NULL;
