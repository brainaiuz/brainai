delete from  modelfield where form_ID ='PAYROLL_EMPLOYEE_FORM';
delete from  model where formID ='PAYROLL_EMPLOYEE_FORM';

insert into model(active,formID, title,viewname) values(true,'PAYROLL_EMPLOYEE_FORM', 'Payroll Employee Form','Employee');


---  PAYROLL EMPLOYEE FORM EDIT
-- General Details 
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor,  field_ID,                         section,             widget,       form_ID,                  noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',         'FIRST_NAME',                     'EMPLOYEE_DETAILS',   'TextBox',   'PAYROLL_EMPLOYEE_FORM',    ''),
                      (02,     false,      false,  false,          '',           true ,           '',         'LAST_NAME',                      'EMPLOYEE_DETAILS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (03,     false,      false,  false,          '',           true ,           '',         'EMAIL',                          'EMPLOYEE_DETAILS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (04,     false,      false,  false,          '',           false,           '',         'HIRE_DATE',                      'EMPLOYEE_DETAILS',   'DatePicker', 'PAYROLL_EMPLOYEE_FORM',    ''),
                      (05,     false,      false,  false,          '',           false,           '',         'BIRTH_DAY',                      'EMPLOYEE_DETAILS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    '');
----Payment Settings					  
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget     ,form_ID,                  noWrapperFor ) values
                      (06,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_IS_PAID',               'PAYMENT_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (07,     false,      false,  false,          '',            false,          '',         'SALARY_GRADE',                   'PAYMENT_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (08,     false,      false,  false,          '',           false,           '',         'PAY_PERIOD',                     'PAYMENT_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (09,     false,      false,  false,          '',           false,           '',         'PAY_METHOD',                     'PAYMENT_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (10,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_BONUS',                 'PAYMENT_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    '');
----Payroll Settings
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget,     form_ID,                   noWrapperFor ) values
                      (11,     false,      false,  false,          '',           false,           '',         'FAMILY_STATUS',                  'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (12,     false,      false,  false,          '',           false,           '',         'GENDER',                         'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (13,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_CODE',                  'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (14,     false,      false,  false,          '',           false,           '',         'WPS_NO',                         'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (15,     false,      false,  false,          '',           false,           '',         'WAGE_RATE',                      'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (16,     false,      false,  false,          '',           false,           '',         'RESIGNATION_DATE',               'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
					  
                      (17,     false,      false,  false,          '',           false,           '',         'START_DATE',                     'PAYROLL_SETTINGS',   'DatePicker',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (18,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_HAS_FORM',              'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (19,     false,      false,  false,          '',           false,           '',          'JOB_DETAILS',                     'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (20,     false,      false,  false,          '',           false,           '',         'DUE_DATE',                       'PAYROLL_SETTINGS',   'DatePicker',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (21,     false,      false,  false,          '',           false,           '',         'OFFICE_VIA_REFERENCE_NUMBER',    'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (22,     false,      false,  false,          '',           false,           '',         'PREVIOUS_TAX_CODE_VIA_PREV_WK1_MNTH1','PAYROLL_SETTINGS','UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (23,     false,      false,  false,          '',           false,           '',         'CURRENT_TAX_CODE_VIA_PREV_WK1_MNTH1', 'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (24,     false,      false,  false,          '',           false,           '',         'WEEK_MONTH_TYPE',                 'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (25,     false,      false,  false,          '',           false,           '',         'WEEK_MONTH_NUMBER',               'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (26,     false,      false,  false,          '',           false,           '',         'TOTAL_PAY_TO_DATE',               'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (27,     false,      false,  false,          '',           false,           '',         'TOTAL_TAX_TO_DATE',               'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (28,     false,      false,  false,          '',           false,           '',         'STUDENT_LOAN',                    'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (29,     false,      false,  false,          '',           false,           '',         'HAVE_ANOTHER_JOB',                'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (30,     false,      false,  false,          '',           false,           '',         'NI_NUMBER',                      'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (31,     false,      false,  false,          '',           false,           '',         'NI_CATEGORY',                    'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (32,     false,      false,  false,          '',           false,           '',         'PENSION_SCHEME',                  'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (33,     false,      false,  false,          '',           false,           '',         'NOT_MEMBER_OF_COOPS',             'PAYROLL_SETTINGS',   'CheckBox',    'PAYROLL_EMPLOYEE_FORM',    '');

					 
                      
				
----bankAccountInformation					  
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                      widget    ,form_ID,                     noWrapperFor ) values
                      (34,     false,      false,  false,          '',           false,           '',         'BANK_NAME',                      'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (35,     false,      false,  false,          '',           false,           '',         'ACCOUNT_NUMBER',                 'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (36,     false,      false,  false,          '',           false,           '',         'ACCOUNT_NAME',                   'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (37,     false,      false,  false,          '',           false,           '',         'BANK_ADDRESS',                   'BANK_ACCOUNT_INFORMATION',   'TextArea',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (38,     false,      false,  false,          '',           false,           '',         'SWIFT_CODE',                     'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (39,     false,      false,  false,          '',           false,           '',         'SORT_CODE',                      'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (40,     false,      false,  false,          '',           false,           '',         'IBAN_CODE',                      'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (41,     false,      false,  false,          '',           false,           '',         'AGENT_ID',                       'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    '');

					  
---  PAYROLL EMPLOYEE FORM VIEW

-- General Details 
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,              widget    ,   form_ID,                noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',         'FIRST_NAME',                     'EMPLOYEE_DETAILS',   'TextBox',   'PAYROLL_EMPLOYEE_FORM',    ''),
                      (02,     false,      false,  false,          '',           true ,           '',         'LAST_NAME',                      'EMPLOYEE_DETAILS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (03,     false,      false,  false,          '',           true ,           '',         'EMAIL',                          'EMPLOYEE_DETAILS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (04,     false,      false,  false,          '',           false,           '',         'HIRE_DATE',                      'EMPLOYEE_DETAILS',   'DatePicker',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (05,     false,      false,  false,          '',           false,           '',         'BIRTH_DAY',                      'EMPLOYEE_DETAILS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    '');
----Payment Settings					  
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget    ,form_ID,                   noWrapperFor ) values
                      (06,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_IS_PAID',               'PAYMENT_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (07,     false,      false,  false,          '',            false,          '',         'SALARY_GRADE',                   'PAYMENT_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (08,     false,      false,  false,          '',           false,           '',         'PAY_PERIOD',                     'PAYMENT_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (09,     false,      false,  false,          '',           false,           '',         'PAY_METHOD',                     'PAYMENT_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (10,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_BONUS',                 'PAYMENT_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    '');
----Payroll Settings
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget,     form_ID,                   noWrapperFor ) values
                      (11,     false,      false,  false,          '',           false,           '',         'FAMILY_STATUS',                  'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (12,     false,      false,  false,          '',           false,           '',         'GENDER',                         'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (13,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_CODE',                  'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (14,     false,      false,  false,          '',           false,           '',         'WPS_NO',                         'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (15,     false,      false,  false,          '',           false,           '',         'WAGE_RATE',                      'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (16,     false,      false,  false,          '',           false,           '',         'RESIGNATION_DATE',               'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
					  
                      (17,     false,      false,  false,          '',           false,           '',         'START_DATE',                     'PAYROLL_SETTINGS',   'DatePicker',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (18,     false,      false,  false,          '',           false,           '',         'EMPLOYEE_HAS_FORM',              'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (19,     false,      false,  false,          '',           false,           '',         'JOB_DETAILS',                     'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (20,     false,      false,  false,          '',           false,           '',         'DUE_DATE',                       'PAYROLL_SETTINGS',   'DatePicker',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (21,     false,      false,  false,          '',           false,           '',         'OFFICE_VIA_REFERENCE_NUMBER',    'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (22,     false,      false,  false,          '',           false,           '',         'PREVIOUS_TAX_CODE_VIA_PREV_WK1_MNTH1','PAYROLL_SETTINGS','UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (23,     false,      false,  false,          '',           false,           '',         'CURRENT_TAX_CODE_VIA_PREV_WK1_MNTH1', 'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (24,     false,      false,  false,          '',           false,           '',         'WEEK_MONTH_TYPE',                 'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (25,     false,      false,  false,          '',           false,           '',         'WEEK_MONTH_NUMBER',               'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (26,     false,      false,  false,          '',           false,           '',         'TOTAL_PAY_TO_DATE',               'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (27,     false,      false,  false,          '',           false,           '',         'TOTAL_TAX_TO_DATE',               'PAYROLL_SETTINGS',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (28,     false,      false,  false,          '',           false,           '',         'STUDENT_LOAN',                    'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (29,     false,      false,  false,          '',           false,           '',         'HAVE_ANOTHER_JOB',                'PAYROLL_SETTINGS',   'DropDown',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (30,     false,      false,  false,          '',           false,           '',         'NI_NUMBER',                      'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (31,     false,      false,  false,          '',           false,           '',         'NI_CATEGORY',                    'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (32,     false,      false,  false,          '',           false,           '',         'PENSION_SCHEME',                  'PAYROLL_SETTINGS',   'UNKNOWN',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (33,     false,      false,  false,          '',           false,           '',         'NOT_MEMBER_OF_COOPS',             'PAYROLL_SETTINGS',   'CheckBox',    'PAYROLL_EMPLOYEE_FORM',    '');

----bankAccountInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget    ,form_ID,                           noWrapperFor ) values
                      (34,     false,      false,  false,          '',           false,           '',         'BANK_NAME',                      'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (35,     false,      false,  false,          '',           false,           '',         'ACCOUNT_NUMBER',                 'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (36,     false,      false,  false,          '',           false,           '',         'ACCOUNT_NAME',                   'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (37,     false,      false,  false,          '',           false,           '',         'BANK_ADDRESS',                   'BANK_ACCOUNT_INFORMATION',   'TextArea',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (38,     false,      false,  false,          '',           false,           '',         'SWIFT_CODE',                     'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (39,     false,      false,  false,          '',           false,           '',         'SORT_CODE',                      'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (40,     false,      false,  false,          '',           false,           '',         'IBAN_CODE',                      'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    ''),
                      (41,     false,      false,  false,          '',           false,           '',         'AGENT_ID',                       'BANK_ACCOUNT_INFORMATION',   'TextBox',    'PAYROLL_EMPLOYEE_FORM',    '');

delete from "anv".modelfield where form_ID ='PAYROLL_EMPLOYEE_FORM';
delete from  "anv".model where formID ='PAYROLL_EMPLOYEE_FORM';


      					  