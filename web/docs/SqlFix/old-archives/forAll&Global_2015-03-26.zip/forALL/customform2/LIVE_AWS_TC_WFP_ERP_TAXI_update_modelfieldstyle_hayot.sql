DROP function if EXISTS "anv".updateModelFieldStyle();
CREATE OR replace function "anv".updateModelFieldStyle()
  returns INTEGER AS
  $body$
DECLARE  d record;
    BEGIN
            FOR d IN (SELECT * FROM modelfield)
            loop
                update "anv".modelfield set fieldsetstyle=d.fieldsetstyle, fieldstyle=d.fieldstyle,halfsetstyle=d.halfsetstyle,rowstyle=d.rowstyle,sectionstyle=d.sectionstyle where form_id=d.form_id and field_id=d.field_id;
            END loop;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".updateModelFieldStyle() owner TO wfmtest;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".updateModelFieldStyle()) IS NOT NULL;