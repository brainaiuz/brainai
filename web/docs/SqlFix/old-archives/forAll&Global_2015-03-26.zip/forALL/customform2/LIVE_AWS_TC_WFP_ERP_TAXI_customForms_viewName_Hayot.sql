update "model" set viewname = 'Contact' where formid = 'CONTACT_FORM';
update "model" set viewname = 'Campain' where formid = 'CAMPAIGN_FORM';

update "anv"."model" set viewname = 'Contact' where formid = 'CONTACT_FORM';
update "anv"."model" set viewname = 'Campain' where formid = 'CAMPAIGN_FORM';