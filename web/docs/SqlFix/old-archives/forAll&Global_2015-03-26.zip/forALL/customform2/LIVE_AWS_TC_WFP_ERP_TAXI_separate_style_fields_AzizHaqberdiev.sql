UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '';
UPDATE modelfield set rowStyle = 'row hideCustomField';
UPDATE modelfield set fieldStyle = 'field';
--alohida fieldlar uchun
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CASE_FORM' AND field_id = 'SUBJECT';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE field_id = 'CRM_NOTE';
--fullwidth
UPDATE modelfield SET fullWidth = false;
UPDATE modelfield SET fullWidth = true WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'STATUS_HISTORY';
UPDATE modelfield SET fullWidth = true WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'ATTACHMENTS';
UPDATE modelfield SET fullWidth = true WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'CRM_ACTIVITIES';


UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField';
UPDATE "anv".modelfield set fieldStyle = 'field';
--alohida fieldlar uchun
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CASE_FORM' AND field_id = 'SUBJECT';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE field_id = 'CRM_NOTE';
--fullwidth
UPDATE "anv".modelfield SET fullWidth = false;
UPDATE "anv".modelfield SET fullWidth = true WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'STATUS_HISTORY';
UPDATE "anv".modelfield SET fullWidth = true WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'ATTACHMENTS';
UPDATE "anv".modelfield SET fullWidth = true WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'CRM_ACTIVITIES';



