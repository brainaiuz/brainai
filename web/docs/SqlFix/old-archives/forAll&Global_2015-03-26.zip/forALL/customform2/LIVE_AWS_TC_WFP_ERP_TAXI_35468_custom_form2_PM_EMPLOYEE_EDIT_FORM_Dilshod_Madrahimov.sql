delete from  modelfield where form_ID ='PM_EMPLOYEE_FORM';
delete from  model where formID ='PM_EMPLOYEE_FORM';

insert into model(active,formID, title,viewname) values(true,'PM_EMPLOYEE_FORM', 'PM Employee Form','Employee');

-- PM EMPLOYEE EDIT FORM 
 -- drawEmployeeInformation 
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',     'FIRST_NAME',                     'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'PM_EMPLOYEE_FORM',''),
                      (02,     false,      false,  false,          '',           true ,           '',     'LAST_NAME',                      'EMPLOYEE_INFORMATION',   'TextBox'  ,   'PM_EMPLOYEE_FORM',''),
                      (03,     false,      false,  false,          '',           false ,          '',     'MIDDLE_NAME',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'PM_EMPLOYEE_FORM',''),
                      (04,     false,      false,  false,          '',           false,           '',     'BIRTH_DAY',                      'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'PM_EMPLOYEE_FORM',''),
                      (05,     false,      false,  false,          '',           false,           '',     'GENDER',                         'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'PM_EMPLOYEE_FORM',''),
                      (06,     false,      false,  false,          '',           false,           '',     'MARTIAL_STATUS',                 'EMPLOYEE_INFORMATION',   'DropDown' ,   'PM_EMPLOYEE_FORM',''),
                      (07,     false,      false,  false,          '',           false,           '',     'LANGUAGE',                       'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'PM_EMPLOYEE_FORM','');

-- drawContactDetails
					  
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (08,     false,      false,  false,          '',           true,            '',     'EMAIL',                          'CONTACT_INFORMATION',   'MULTITABLE'  , 'PM_EMPLOYEE_FORM',''),
                      (09,     false,      false,  false,          '',           false ,          '',     'PHONE',                          'CONTACT_INFORMATION',   'MULTITABLE'  ,   'PM_EMPLOYEE_FORM',''),
                      (10,     false,      false,  false,          '',           false ,          '',     'IM_ADDRESS',                     'CONTACT_INFORMATION',   'MULTITABLE'  ,   'PM_EMPLOYEE_FORM',''),
                      (11,     false,       false,  false,          '',          false ,          '',     'WEB_ADDRESS',                    'CONTACT_INFORMATION',   'MULTITABLE'  ,   'PM_EMPLOYEE_FORM','');
					  
					  
---- drawAddressInformation             
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (12,     false,      false,  false,          '',           false,            'editForm',     'ADDRESS',            'ADDRESS_INFORMATION',         'UNKNOWN'  , 'PM_EMPLOYEE_FORM','');
					  
--drawEmploymentInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (13,     false,      false,  false,          '',           false,            '',     'DEPARTMENT',              'EMPLOYMENT_INFORMATION',   'DropDown'  , 'PM_EMPLOYEE_FORM',''),
                      (14,     false,      false,  false,          '',           false,            '',     'POSITION',                 'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'PM_EMPLOYEE_FORM',''),
                      (15,     false,      false,  false,          '',           false,            '',     'LOCATION_FIELD',           'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'PM_EMPLOYEE_FORM',''),
                      (16,     false,      false,  false,          '',           false,            '',     'WAGE_RATE',               'EMPLOYMENT_INFORMATION',   'TextBox'  , 'PM_EMPLOYEE_FORM',''),
                      (17,     false,      false,  false,          '',           false,            '',     'CLIENT_CHARGE_RATE',      'EMPLOYMENT_INFORMATION',   'TextBox'  , 'PM_EMPLOYEE_FORM','');
                     
                     					  
--- drawAccountInformation             
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (18,     false,      false,  false,          '',           false,            '',     'ACCOUNT_ROLES',             'ACCOUNT_INFORMATION',   'UNKNOWN'  , 'PM_EMPLOYEE_FORM',''),
                      (19,     false,      false,  false,          '',           false,            '',     'ACCOUNT_STATUS',            'ACCOUNT_INFORMATION',   'DropDown'  , 'PM_EMPLOYEE_FORM','');
                        

delete from "anv".modelfield where form_ID ='PM_EMPLOYEE_FORM';
delete from  "anv".model where formID ='PM_EMPLOYEE_FORM';

					  