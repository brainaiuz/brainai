delete from  modelfield where form_ID ='PROJECT_SUMMARY_FORM';
delete from  model where formID ='PROJECT_SUMMARY_FORM';

insert into model(active, formID, title, viewname) values(true, 'PROJECT_SUMMARY_FORM', 'Project Summary', 'Project');

--Project details
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,   section,       widget,       form_ID,   noWrapperFor, labelless ) values
                      (01,     false,      false,  false,       '',           false ,          '',     'NUMBER',      'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM','', false ),
                      (02,     false,      false,  false,       '',           false,            '',     'NAME',        'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM','', false ),
                      (03,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION', 'DETAILS', 'TextArea'  , 'PROJECT_SUMMARY_FORM','', false ),
                      (04,     false,      false,  false,       '',           false,           '',     'START_DATE',  'DETAILS', 'DatePicker', 'PROJECT_SUMMARY_FORM','', false ),
                      (05,     false,      false,  false,       '',           false,           '',     'DUE_DATE',    'DETAILS', 'DatePicker', 'PROJECT_SUMMARY_FORM','', false ),
                      (06,     false,      false,  false,       '',           false,           '',     'STATUS',      'DETAILS', 'DropDown'  , 'PROJECT_SUMMARY_FORM','', false ),
                      (07,     false,      false,  false,       '',           false,           '',     'COMPLETED',   'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM','', false ),
                      (08,     false,      false,  false,       '',           false,           '',     'PDF_VERSION',  'DETAILS', 'UNKNOWN'  ,  'PROJECT_SUMMARY_FORM','', false );

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (20,     false,      false,  false,        '',           false,           'viewForm',     'INVOLVED_EMPLOYEE',   'INVOLVED_EMPLOYEES',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm',     true);


insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                       (25,     false,      false,  false,          '',           false,            '',     'MANAGER',  'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (26,     false,      false,  false,          '',           false,            '',     'BACKUP_MANAGER',  'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (27,     false,      false,  false,          '',           false,            '',     'CLIENT',           'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (28,     false,      false,  false,          '',           false,            '',     'ACTUAL_START_DATE','MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (29,     false,      false,  false,          '',           false,            '',     'ACTUAL_END_DATE',  'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (30,     false,      false,  false,          '',           false,            '',     'ESTIMATED_TIME',   'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (31,     false,      false,  false,          '',           false,            '',     'TIME_SPENT',       'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (32,     false,      false,  false,          '',           false,            '',     'ACTUAL_TIME_SPENT','MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (33,     false,      false,  false,          '',           false,            '',     'ESTIMATED_COST',   'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (34,     false,      false,  false,          '',           false,            '',     'ACTUAL_COST',      'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (35,     false,      false,  false,          '',           false,            '',     'WAITING_HOURS',   'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (36,     false,      false,  false,          '',           false,            '',     'REJECTED_HOURS',      'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false );

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                       (40,     false,      false,  false,          '',           false,            '',     'NOT_STARTED_TASKS',  'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (41,     false,      false,  false,          '',           false,            '',     'IN_PORGRESS_TASKS',  'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (42,     false,      false,  false,          '',           false,            '',     'COMPLETED_TASKS',    'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (43,     false,      false,  false,          '',           false,            '',     'CANCELLED_TASKS',    'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (44,     false,      false,  false,          '',           false,            '',     'WAITING_FOR_SOMEONE_ELSE',  'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false ),
                       (45,     false,      false,  false,          '',           false,            '',     'CLOSED_TASKS',       'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '',     false );


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,    section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (50,     false,      false,  false,       '',           false,            'viewForm',     'ATTACHMENTS',  'ATTACHMENTS', 'UNKNOWN', 'PROJECT_SUMMARY_FORM',   'viewForm',     true);

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,     widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (51,     false,      false, false,          '',           false,            'viewForm',     'LINKS',    'LINKS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm',     true );

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor,  field_ID,     section,        widget      ,form_ID,              noWrapperFor, labelless  ) values
                      (52,     false,      false, false,          '',           false,            'viewForm', 'PROJECT_NOTE', 'PROJECT_NOTE', 'NoteWidget',   'PROJECT_SUMMARY_FORM',   'viewForm',     true );


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,noLabelFor,field_ID,   section,    widget      ,form_ID,   noWrapperFor, labelless  ) values
                      (55,     false,      false, false,          '',           false,            '', 'CREATED_BY', 'UPDATES',  'TextBox',  'PROJECT_SUMMARY_FORM', '',     false),
                      (56,     false,      false, false,          '',           false,            '', 'CREATED_DATE', 'UPDATES','TextBox',  'PROJECT_SUMMARY_FORM', '',     false),
                      (57,     false,      false, false,          '',           false,            '', 'UPDATED_BY', 'UPDATES',  'TextBox',  'PROJECT_SUMMARY_FORM', '',     false),
                      (58,     false,      false, false,          '',           false,            '', 'UPDATED_DATE', 'UPDATES','TextBox',  'PROJECT_SUMMARY_FORM', '',     false);

update modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';
update modelfield set split=true where field_ID='CREATED_DATE' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'ATTACHMENTS';




delete from "anv".modelfield where form_ID ='PROJECT_SUMMARY_FORM';
delete from "anv".model where formID ='PROJECT_SUMMARY_FORM';
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('PROJECT_SUMMARY_FORM', 'Project')) IS NOT NULL;

update "anv".modelfield set nolabelfor='viewForm' where form_ID ='PROJECT_SUMMARY_FORM' and field_id='LINKS';
update "anv".modelfield set nolabelfor='viewForm' where form_ID ='PROJECT_SUMMARY_FORM' and field_id='ATTACHMENTS';
update "anv".modelfield set nolabelfor='viewForm' where form_ID ='PROJECT_SUMMARY_FORM' and field_id='INVOLVED_EMPLOYEE';
update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';


update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';
update "anv".modelfield set split=true where field_ID='CREATED_DATE' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'ATTACHMENTS';