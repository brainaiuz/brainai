--faqat AWSga urilsa yetarli web\docs\SqlFix\forALL\customform2\custom_form_convert_custom_fields_to_modelfield_Hayot.sql  dan keyin urilsin

delete from "model"  where formid = 'CASE_FORM';
delete from "modelfield"  where form_id = 'CASE_FORM';

delete from "anv"."model"  where formid = 'CASE_FORM';
delete from "anv"."modelfield"  where form_id = 'CASE_FORM';

insert into model(active,formID, title,viewname) values(true,'CASE_FORM', 'Case Form','CrmCase');
insert into modelfield(form_ID,     field_ID,                sorder, mandatory,  hide,   isCustomField,  section,          defaultValue, widget, systemmandatory,             nolabelfor,              nowrapperfor, fullWidth) values
                      ('CASE_FORM', 'SUBJECT',                  1,      false,   false,       false,   'DESCRIPTION',           '',    'TextBox',     true,                      '',                        '',       false),
                      ('CASE_FORM', 'DESCRIPTION',              2,      false,   false,       false,   'DESCRIPTION',           '',    'MULTITABLE',  false,        'addForm,editForm,viewForm',            '',       false),
                      ('CASE_FORM', 'REPORTED_BY',              3,      false,   false,       false,   'DESCRIPTION',           '',    'MULTITABLE',  false,                     '',                        '',       false),
                      ('CASE_FORM', 'CASE_DESCRIPTION',         4,      false,   false,       false,   'DESCRIPTION',           '',    'UNKNOWN',     false,                     '',                        '',       false),
                      ('CASE_FORM', 'NOTIFY_REPORTER',          5,      false,   false,       false,   'DESCRIPTION',           '',    'CheckBox',    false,                     '',                        '',       false),
                      ('CASE_FORM', 'CASE_ID',                  6,      false,   false,       false,   'CASE_INFORMATION',      '',    'UNKNOWN',     true,                      '',                        '',       false),
                      ('CASE_FORM', 'TYPE',                     7,      false,   false,       false,   'CASE_INFORMATION',      '',    'DropDown',    false,                     '',                        '',       false),
                      ('CASE_FORM', 'CASE_ORIGIN',              8,      false,   false,       false,   'CASE_INFORMATION',      '',    'DropDown',    true ,                     '',                        '',       false),
                      ('CASE_FORM', 'CASE_REASON',              9,      false,   false,       false,   'CASE_INFORMATION',      '',    'DropDown',    false,                     '',                        '',       false),
                      ('CASE_FORM', 'SLA',                      10,     false,   false,       false,   'CASE_INFORMATION',      '',    'DropDown',    false,                     '',                        '',       false),
                      ('CASE_FORM', 'PRIORITY',                 11,     false,   false,       false,   'CASE_INFORMATION',      '',    'DropDown',    false,                     '',                        '',       false),
                      ('CASE_FORM', 'STATUS',                   12,     false,   false,       false,   'CASE_INFORMATION',      '',    'DropDown',    true ,                     '',                        '',       false),
                      ('CASE_FORM', 'ASSIGNEE',                 13,     false,   false,       false,   'CASE_INFORMATION',      '',    'LOOKUP',      false,                     '',                        '',       false),
                      ('CASE_FORM', 'RESOLVER',                 14,     false,   false,       false,   'CASE_INFORMATION',      '',    'LOOKUP',      false,                     '',                        '',       false),
                      ('CASE_FORM', 'BILLABLE',                 15,     false,   false,       false,   'CASE_INFORMATION',      '',    'CheckBox',    false,                     '',                        '',       false),
                      ('CASE_FORM', 'CRM_NOTE',                 16,     false,   false,       false,   'NOTES',                 '',    'NoteWidget',  false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'LINKS',                    17,     false,   false,       false,   'LINKS',                 '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'ATTACHMENTS',              18,     false,   false,       false,   'ATTACHMENTS',           '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'SLA_TIMER',                19,     false,   false,       false,   'SLA_TIMER',             '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'STATUS_HISTORY',           20,     false,   false,       false,   'STATUS_HISTORY',        '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'CASE_HISTORY_LOG',         21,     false,   false,       false,   'CASE_HISTORY_LOG',      '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'CRM_ACTIVITIES',           22,     false,   false,       false,   'CRM_ACTIVITIES',        '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'CRM_TASKS',                23,     false,   false,       false,   'CRM_TASKS',             '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true),
                      ('CASE_FORM', 'CRM_CASE_TIMER',           24,     false,   false,       false,   'CRM_CASE_TIMER',        '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',           '',       true);


UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id = 'CASE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id = 'CASE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'CASE_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id = 'CASE_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'CASE_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id = 'CASE_FORM';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id = 'CASE_FORM';
--alohida fieldlar uchun
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CASE_FORM' AND field_id = 'SUBJECT';

--set case fields usable by workflow
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'SUBJECT';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

update modelfield set "type" ='Text' where form_id = 'CASE_FORM' and field_id = 'SUBJECT';
update modelfield set source='REFERENCE@_CASE_TYPE' where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update modelfield set source='REFERENCE@_CASE_ORIGIN' where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update modelfield set source='REFERENCE@_CASE_REASON' where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update modelfield set source='REFERENCE@_CASE_PRIORITY' where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update modelfield set source='REFERENCE@_CASE_STATUS' where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update modelfield set source='CRM@CASE_ASSIGNEE' where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update modelfield set source='CRM@CASE_RESOLVER' where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('CASE_FORM', 'CrmCase')) IS NOT NULL;
