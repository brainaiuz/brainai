-- Schema updatedan keyin urilsin

delete from "anv"."model"  where formid = 'WORKFLOW_EVENT_FORM';
delete from "anv"."modelfield"  where form_id = 'WORKFLOW_EVENT_FORM';

delete from "anv"."model"  where formid = 'WORKFLOW_CALL_LOG_FORM';
delete from "anv"."modelfield"  where form_id = 'WORKFLOW_CALL_LOG_FORM';


delete from "model"  where formid = 'WORKFLOW_EVENT_FORM';
delete from "modelfield"  where form_id = 'WORKFLOW_EVENT_FORM';

insert into model(formID, active, title,viewname) values('WORKFLOW_EVENT_FORM', true, 'Workflow Event Form','Workflow Event');
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, nolabelfor,nowrapperfor, field_ID,                         section,                 widget      ,form_ID) values
                      (01,     false,      false,  false,          '',           true,            null,null,'WHAT',                          'INFORMATION',   'TextBox'  ,   'WORKFLOW_EVENT_FORM'),
                      (02,     false,      false,  false,          '',           false,           null,null,'WHEN',                          'INFORMATION',   'UNKNOWN'  ,   'WORKFLOW_EVENT_FORM'),
                      (03,     false,      false,  false,          '',           false,           null,null,'WHERE',                          'INFORMATION',   'TextBox'  ,   'WORKFLOW_EVENT_FORM'),
                      (04,     false,      false,  false,          '',           false,           null,null,'DESCRIPTION',                          'INFORMATION',   'TextArea'  ,   'WORKFLOW_EVENT_FORM'),
                      (05,     false,      false,  false,          '',           false,           'addForm,editForm,viewForm', 'addForm,editForm,viewForm', 'WORKFLOW_TIME_BASED',                          'WORKFLOW_TIME_BASED_HEADER',   'UNKNOWN'  ,   'WORKFLOW_EVENT_FORM');


delete from "model"  where formid = 'WORKFLOW_CALL_LOG_FORM';
delete from "modelfield"  where form_id = 'WORKFLOW_CALL_LOG_FORM';

update modelfield set formtype = 'addForm' where formtype is null;
insert into model(formID, active, title,viewname) values('WORKFLOW_CALL_LOG_FORM', true, 'Workflow Call Log Form','Event');
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, nolabelfor, nowrapperfor, field_ID,                         section,                 widget      ,form_ID) values
  (01,     false,      false,  false,          '',           true,            null,null,'WHAT',                          'INFORMATION',   'TextBox'  ,   'WORKFLOW_CALL_LOG_FORM'),
  (02,     false,      false,  false,          '',           false,           null,null,'CALL_TYPE',                          'INFORMATION',   'DropDown'  ,   'WORKFLOW_CALL_LOG_FORM'),
  (03,     false,      false,  false,          '',           false,           null,null,'WHEN',                          'INFORMATION',   'UNKNOWN'  ,   'WORKFLOW_CALL_LOG_FORM'),
  (04,     false,      false,  false,          '',           false,           null,null,'WHERE',                          'INFORMATION',   'TextBox'  ,   'WORKFLOW_CALL_LOG_FORM'),
  (05,     false,      false,  false,          '',           false,           null,null,'DESCRIPTION',                          'INFORMATION',   'TextArea'  ,   'WORKFLOW_CALL_LOG_FORM'),
  (05,     false,      false,  false,          '',           false,           'addForm,editForm,viewForm', 'addForm,editForm,viewForm', 'WORKFLOW_TIME_BASED',                          'WORKFLOW_TIME_BASED_HEADER',   'UNKNOWN'  ,   'WORKFLOW_CALL_LOG_FORM');


update modelfield set systemmandatory = true where field_id = 'WHEN' and (form_id = 'WORKFLOW_CALL_LOG_FORM' or form_id = 'WORKFLOW_EVENT_FORM');
update modelfield set nolabelfor='addForm,editForm,viewForm' where form_id = 'WORKFLOW_FORM' and  (field_id = 'EXECUTION_CRITERIA' or field_id = 'RULE_CRITERIA');

update "anv".modelfield set systemmandatory = true where field_id = 'WHEN' and (form_id = 'WORKFLOW_CALL_LOG_FORM' or form_id = 'WORKFLOW_EVENT_FORM');
update "anv".modelfield set nolabelfor='addForm,editForm,viewForm' where form_id = 'WORKFLOW_FORM' and  (field_id = 'EXECUTION_CRITERIA' or field_id = 'RULE_CRITERIA');

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');
UPDATE modelfield set fieldStyle = 'field' WHERE form_id in ('WORKFLOW_CALL_LOG_FORM', 'WORKFLOW_EVENT_FORM');


