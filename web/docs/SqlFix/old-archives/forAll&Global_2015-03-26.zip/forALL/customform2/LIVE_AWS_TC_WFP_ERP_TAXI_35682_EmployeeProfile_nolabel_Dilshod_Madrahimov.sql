update modelfield set nolabelfor='addForm,editForm' where form_ID ='HRMS_EMPLOYEE_FORM' and field_id='ADDRESS';
update modelfield set nolabelfor='addForm,editForm' where form_ID ='PAYROLL_EMPLOYEE_FORM' and field_id='ADDRESS';
update modelfield set nolabelfor='addForm,editForm' where form_ID ='SETTINGS_EMPLOYEE_FORM' and field_id='ADDRESS';
update modelfield set nolabelfor='addForm,editForm' where form_ID ='PM_EMPLOYEE_FORM' and field_id='ADDRESS';
update modelfield set nolabelfor='addForm,editForm' where form_ID ='INSTRUCTOR_FORM' and field_id='ADDRESS';

update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='HRMS_EMPLOYEE_FORM' and field_id='ADDRESS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PAYROLL_EMPLOYEE_FORM' and field_id='ADDRESS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='SETTINGS_EMPLOYEE_FORM' and field_id='ADDRESS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PM_EMPLOYEE_FORM' and field_id='ADDRESS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='INSTRUCTOR_FORM' and field_id='ADDRESS';