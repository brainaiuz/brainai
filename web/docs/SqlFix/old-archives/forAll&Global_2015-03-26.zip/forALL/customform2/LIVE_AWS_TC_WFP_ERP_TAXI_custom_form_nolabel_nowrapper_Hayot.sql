--todo alter table modelfield, "anv".modelfield add noLabelFOr,noWrapperFor columns.

UPDATE modelfield SET nolabelfor = NULL;
UPDATE "anv".modelfield SET nolabelfor = NULL;

UPDATE "anv".modelfield SET nolabelfor = NULL, nowrapperfor = 'viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'EMAIL';
UPDATE "anv".modelfield SET nolabelfor = NULL, nowrapperfor = 'viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'PHONE';
UPDATE "anv".modelfield SET nolabelfor = NULL, nowrapperfor = 'viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'IM_ADDRESS';
UPDATE "anv".modelfield SET nolabelfor = NULL, nowrapperfor = 'viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'WEB_ADDRESS';


UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'CRM_ACTIVITIES';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'CRM_NOTE';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'COPY_CRMACCOUNT_ADDRESS';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'ADDRESS';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'PARENT_ADDRESSES';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'STATUS_HISTORY';
UPDATE "anv".modelfield SET nolabelfor = 'addForm,editForm,viewForm' WHERE (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM') AND field_id = 'ATTACHMENTS';