delete from  modelfield where form_ID ='TASK_SUMMARY_FORM';
delete from  model where formID ='TASK_SUMMARY_FORM';

insert into model(active, formID, title, viewname) values(true, 'TASK_SUMMARY_FORM', 'Task Sumary', 'Task');

--Task details
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,   section,       widget,       form_ID,   noWrapperFor, labelless ) values
                      (01,     false ,     false,  false,       '',           false,            '',     'PROJECT',     'TASK_DETAILS', 'LOOKUP'  ,  'TASK_SUMMARY_FORM','',  false ),
                      (02,     false,      false,  false,       '',           false ,          '',     'NUMBER',      'TASK_DETAILS', 'TextBox'  ,  'TASK_SUMMARY_FORM','', false ),
                      (03,     false,      false,  false,       '',           false,            '',     'NAME',        'TASK_DETAILS', 'TextBox'  ,  'TASK_SUMMARY_FORM','', false ),
                      (04,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION', 'TASK_DETAILS', 'TextArea'  , 'TASK_SUMMARY_FORM','', false ),
                      (05,     false,      false,  false,       '',           false,           '',     'START_DATE',  'TASK_DETAILS', 'DatePicker', 'TASK_SUMMARY_FORM','', false ),
                      (06,     false,      false,  false,       '',           false,           '',     'DUE_DATE',    'TASK_DETAILS', 'DatePicker', 'TASK_SUMMARY_FORM','', false ),
                      (07,     false ,     false,  false,       '',           false,           '',     'PRIORITY',    'TASK_DETAILS', 'DropDown'  , 'TASK_SUMMARY_FORM','', false ),
                      (08,     false,      false,  false,       '',           false,           '',     'STATUS',      'TASK_DETAILS', 'DropDown'  , 'TASK_SUMMARY_FORM','', false ),
                      (09,     false,      false,  false,       '',           false,           '',     'PERCENT',     'TASK_DETAILS', 'TextBox'  ,  'TASK_SUMMARY_FORM','', false ),
                      (10,     false,      false,  false,       '',           false,           '',     'BILLIBLE',  'TASK_DETAILS', 'CheckBox'  ,  'TASK_SUMMARY_FORM','', false ),
--                       (11,     false,      false,  false,       '',           false,           '',     'LOG_TIME',  'TASK_DETAILS', 'UNKNOWN'  ,  'TASK_SUMMARY_FORM','', false ),
--                       (12,     false,      false,  false,       '',           false,           '',     'TIMER',  'TASK_DETAILS', 'UNKNOWN'  ,  'TASK_SUMMARY_FORM','', false ),
                      (13,     false,      false,  false,       '',           false,           '',     'PDF_VERSION',  'TASK_DETAILS', 'UNKNOWN'  ,  'TASK_SUMMARY_FORM','', false );

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,        widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (20,     false,      false,  false,        '',           false,           '',     'ASSIGNEE',   'ASSIGNEES',    'UNKNOWN',   'TASK_SUMMARY_FORM',   'viewForm',     true);


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (25,     false,      false,  false,       '',           false,            '',     'PARENT_WORKSTREAM', 'DEPENDENCIES', 'TextBox',   'TASK_SUMMARY_FORM',   '', false ),
                      (26,     false,      false,  false,       '',           false,            '',     'DUE_DATE_REMINDER', 'DEPENDENCIES', 'TextBox',   'TASK_SUMMARY_FORM',   '', false ),
                      (27,     false,      false,  false,       '',           false,            '',     'PREDECESSOR_TASK',  'DEPENDENCIES', 'TextBox',   'TASK_SUMMARY_FORM',   '', false ),
                      (28,     false,      false,  false,       '',           false,            '',     'SUCCESSOR_TASK',    'DEPENDENCIES', 'TextBox',   'TASK_SUMMARY_FORM',   '', false );


insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                       (35,     false,      false,  false,          '',           false,            '',     'PROJECT_MANAGER',  'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (36,     false,      false,  false,          '',           false,            '',     'BACKUP_MANAGERS',  'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (37,     false,      false,  false,          '',           false,            '',     'CLIENT',           'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (38,     false,      false,  false,          '',           false,            '',     'ACTUAL_START_DATE','MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (39,     false,      false,  false,          '',           false,            '',     'ACTUAL_END_DATE',  'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (40,     false,      false,  false,          '',           false,            '',     'ESTIMATED_TIME',   'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (41,     false,      false,  false,          '',           false,            '',     'TIME_SPENT',       'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (42,     false,      false,  false,          '',           false,            '',     'ACTUAL_TIME_SPENT','MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (43,     false,      false,  false,          '',           false,            '',     'ESTIMATED_COST',   'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (44,     false,      false,  false,          '',           false,            '',     'ACTUAL_COST',      'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (45,     false,      false,  false,          '',           false,            '',     'WAITING_HOURS',    'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false ),
                       (46,     false,      false,  false,          '',           false,            '',     'REJECTED_HOURS',   'MORE_DETAILS', 'TextBox',   'TASK_SUMMARY_FORM',   '',     false );

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,    section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (50,     false,      false,  false,       '',           false,            'viewForm',     'ATTACHMENTS',  'ATTACHMENTS', 'UNKNOWN', 'TASK_SUMMARY_FORM',   'viewForm',     true);

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,     widget      ,form_ID,     noWrapperFor, labelless  ) values
                      (51,     false,      false, false,          '',           false,            'viewForm',     'LINKS',    'LINKS',    'UNKNOWN',   'TASK_SUMMARY_FORM',   'viewForm',     true );

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor,  field_ID,     section,        widget      ,form_ID,              noWrapperFor, labelless  ) values
                      (52,     false,      false, false,          '',           false,            'viewForm', 'TASK_NOTES', 'TASK_NOTES', 'NoteWidget',   'TASK_SUMMARY_FORM',   'viewForm',     true );


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,noLabelFor,field_ID,   section,    widget      ,form_ID,   noWrapperFor, labelless  ) values
                      (55,     false,      false, false,          '',           false,            '', 'CREATED_BY', 'UPDATES',  'TextBox',  'TASK_SUMMARY_FORM', '',     false),
                      (56,     false,      false, false,          '',           false,            '', 'CREATED_DATE', 'UPDATES','TextBox',  'TASK_SUMMARY_FORM', '',     false),
                      (57,     false,      false, false,          '',           false,            '', 'UPDATED_BY', 'UPDATES',  'TextBox',  'TASK_SUMMARY_FORM', '',     false),
                      (58,     false,      false, false,          '',           false,            '', 'UPDATED_DATE', 'UPDATES','TextBox',  'TASK_SUMMARY_FORM', '',     false);

update modelfield set split=true where field_ID='DESCRIPTION' and form_ID='TASK_SUMMARY_FORM';
update modelfield set split=true where field_ID='CREATED_DATE' and form_ID='TASK_SUMMARY_FORM';

delete from "anv".modelfield where form_ID ='TASK_SUMMARY_FORM';
delete from "anv".model where formID ='TASK_SUMMARY_FORM';


UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('TASK_SUMMARY_FORM', 'Task')) IS NOT NULL;

update "anv".modelfield set nolabelfor='viewForm' where form_ID ='TASK_SUMMARY_FORM' and field_id='LINKS';
update "anv".modelfield set nolabelfor='viewForm' where form_ID ='TASK_SUMMARY_FORM' and field_id='ATTACHMENTS';
update "anv".modelfield set nolabelfor='viewForm' where form_ID ='TASK_SUMMARY_FORM' and field_id='ASSIGNEE';
update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='TASK_SUMMARY_FORM';
update "anv".modelfield set split=true where field_ID='CREATED_DATE' and form_ID='TASK_SUMMARY_FORM';



UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='TASK_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1' where form_ID ='TASK_SUMMARY_FORM' and field_id='ATTACHMENTS';
UPDATE modelfield set halfSetStyle = 'halfSet-1' where form_ID ='TASK_SUMMARY_FORM' and field_id='ASSIGNEE';


UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' where form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' where form_ID ='TASK_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' where form_ID ='TASK_SUMMARY_FORM' and field_id='ATTACHMENTS';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' where form_ID ='TASK_SUMMARY_FORM' and field_id='ASSIGNEE';