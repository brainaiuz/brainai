  delete from  modelfield where form_ID ='PROJECT_FORM';
  delete from  model where formID ='PROJECT_FORM';

  insert into model(active, formID, title, viewname) values(true, 'PROJECT_FORM', 'Add Edit Project', 'Project');

  --Project details
  insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,    widget,       form_ID,   noWrapperFor, labelless ) values
                        (01,     false,      false,  false,       '',           false,            '',     'CREATE_CLONE_WIDGET', 'DETAILS', 'UNKNOWN'  ,  'PROJECT_FORM','addForm,editForm',  false ),
                        (02,     true ,      false,  false,       '',           true ,          '',     'NUMBER',              'DETAILS', 'TextBox'  ,  'PROJECT_FORM','', false ),
                        (03,     true ,      false,  false,       '',           true,            '',     'NAME',                'DETAILS', 'TextBox'  ,  'PROJECT_FORM','', false ),
                        (04,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION',         'DETAILS', 'TextArea'  , 'PROJECT_FORM','', false ),

                        (05,     true ,      false,  false,       '',           true ,           '',     'START_DATE',          'DETAILS', 'DatePicker', 'PROJECT_FORM','', false ),
                        (06,     true ,      false,  false,       '',           true ,           '',     'DUE_DATE',            'DETAILS', 'DatePicker', 'PROJECT_FORM','', false ),
                        (08,     false,      false,  false,       '',           false,           '',     'CLIENT',              'DETAILS', 'DropDown'  , 'PROJECT_FORM','', false ),
                        (09,     true ,      false,  false,       '',           false,           '',     'STATUS',              'DETAILS', 'DropDown'  , 'PROJECT_FORM','', false ),
                        (10,     false ,     false,  false,       '',           false,           '',     'DUE_DATE_REMINDER',   'DETAILS', 'DropDown'  , 'PROJECT_FORM','', false ),
                        (11,     false,      false,  false,       '',           false,           '',     'LOCATION',            'DETAILS', 'DropDown'  , 'PROJECT_FORM','', false );

  insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor, labelless  ) values
                        (15,     true,      false,  false,        '',           true,           '',     'INVOLVED_EMPLOYEE',      'INVOLVED_EMPLOYEES', 'UNKNOWN',   'PROJECT_FORM',   '',     false ),
                        (16,     true,      false,  false,        '',           false,           '',     'ASSIGN_NEW_MEMBERS_TO_PROJECT',      'INVOLVED_EMPLOYEES', 'CHECKBOX',   'PROJECT_FORM',   '',     true),
                        (17,     true ,     false,  false,       '',           true,            '',     'MANAGER',       'INVOLVED_EMPLOYEES', 'DropDown'  ,  'PROJECT_FORM','',  false ),
                        (18,     false,     false,  false,       '',           false,            '',     'BACKUP_MANAGER', 'INVOLVED_EMPLOYEES', 'DropDown'  ,  'PROJECT_FORM','',  false );


  insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,    section,       widget      ,form_ID,     noWrapperFor, labelless  ) values
                        (25,     false,      false,  false,       '',           false,            'addForm,editForm',     'ATTACHMENTS',  'ATTACHMENTS', 'UNKNOWN', 'PROJECT_FORM',   'editForm, addForm',     true);

  insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,     widget      ,form_ID,     noWrapperFor, labelless  ) values
                        (30,     false,      false, false,          '',           false,            'addForm,editForm',     'LINKS',    'LINKS',    'UNKNOWN',   'PROJECT_FORM',   'editForm, addForm', true);

  insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor,  field_ID,     section,        widget      ,form_ID,              noWrapperFor, labelless  ) values
                        (35,     false,      false, false,          '',           false,            'editForm, addForm', 'PROJECT_NOTE', 'PROJECT_NOTE', 'NoteWidget',   'PROJECT_FORM',   'editForm, addForm',     true );



update modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_FORM';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id = 'PROJECT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id = 'PROJECT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_id = 'PROJECT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id = 'PROJECT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_id = 'PROJECT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id = 'PROJECT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id = 'PROJECT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_FORM' AND field_id = 'ATTACHMENTS';


delete from "anv".modelfield where form_ID ='PROJECT_FORM';
delete from "anv".model where formID ='PROJECT_FORM';
update company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('PROJECT_FORM', 'Project')) is not null;

update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PROJECT_FORM' and field_id='LINKS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PROJECT_FORM' and field_id='ATTACHMENTS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PROJECT_FORM' and field_id='PROJECT_NOTE';



update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' where form_ID='PROJECT_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_FORM' AND field_id = 'ATTACHMENTS';