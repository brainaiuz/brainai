--Bu patchdan keyin  LIVE_AWS_TC_ERP_TAXI_36128_separate_style_fields_AzizHaqberdiev.sql patchni urvorish kk
delete from  modelfield where form_ID ='INSTRUCTOR_FORM';
delete from  model where formID ='INSTRUCTOR_FORM';


insert into model(active,formID, title,viewname) values(true,'INSTRUCTOR_FORM', 'TC Instructor Form','Instructor');


-- TC INSTRUCTOR ADD , EDIT FORM
 -- drawEmployeeInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',     'FIRST_NAME',                     'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'INSTRUCTOR_FORM',''),
                      (02,     false,      false,  false,          '',           true ,           '',     'LAST_NAME',                      'EMPLOYEE_INFORMATION',   'TextBox'  ,   'INSTRUCTOR_FORM',''),
                      (03,     false,      false,  false,          '',           false ,          '',     'MIDDLE_NAME',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'INSTRUCTOR_FORM',''),
                      (04,     false,      false,  false,          '',           false,           '',     'BIRTH_DAY',                      'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'INSTRUCTOR_FORM',''),
                      (05,     false,      false,  false,          '',           false,           '',     'LOCATION',                 'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'INSTRUCTOR_FORM',''),

		              (06,     false,      false,  false,          '',           false,           '',     'GENDER',                         'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'INSTRUCTOR_FORM',''),
                      (07,     false,      false,  false,          '',           false,           '',     'MARTIAL_STATUS',                 'EMPLOYEE_INFORMATION',   'DropDown' ,   'INSTRUCTOR_FORM',''),
                      (08,     false,      false,  false,          '',           false,           '',     'LANGUAGE',                       'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'INSTRUCTOR_FORM','');

-- drawContactDetails

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (09,     false,      false,  false,          '',           true,            '',     'EMAIL',                         'CONTACT_INFORMATION',   'MULTITABLE'  , 'INSTRUCTOR_FORM',''),
                      (10,     false,      false,  false,          '',           false ,          '',     'PHONE',                         'CONTACT_INFORMATION',   'MULTITABLE'  ,   'INSTRUCTOR_FORM',''),

					  (11,     false,      false,  false,          '',           false ,          '',     'IM_ADDRESS',                    'CONTACT_INFORMATION',   'MULTITABLE'  ,   'INSTRUCTOR_FORM',''),
                      (12,     false,      false,  false,          '',           false ,          '',     'WEB_ADDRESS',                   'CONTACT_INFORMATION',   'MULTITABLE'  ,   'INSTRUCTOR_FORM','');

--- drawAddressInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (13,     false,      false,  false,          '',           false,            'addFrom,editForm,viewForm',     'ADDRESS',            'ADDRESS_INFORMATION',   'UNKNOWN'  , 'INSTRUCTOR_FORM','');

--- drawAccountInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (14,     false,      false,  false,          '',           false,            '',     'ACCOUNT_STATUS',            'ACCOUNT_INFORMATION',   'DropDown'  , 'INSTRUCTOR_FORM','');

--- drawCourses
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (15,     false,      false,  false,          '',           false,            '',        'COURSES',                   'INSTRUCTOR_COURSES',         'UNKNOWN'  , 'INSTRUCTOR_FORM','');


--- drawAttachments
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (16,     false,      false,  false,          '',           false,            'addFrom,editForm,viewForm',     'ATTACHMENTS',                   'ATTACHMENTS',           'UNKNOWN'  , 'INSTRUCTOR_FORM','');


delete from "anv".modelfield where form_ID ='INSTRUCTOR_FORM';
delete from  "anv".model where formID ='INSTRUCTOR_FORM';
