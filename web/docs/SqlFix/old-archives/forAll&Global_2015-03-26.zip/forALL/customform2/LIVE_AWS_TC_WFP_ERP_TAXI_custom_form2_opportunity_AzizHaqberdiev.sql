DELETE FROM "model"  WHERE formid = 'OPPORTUNITY_FORM';
DELETE FROM "modelfield"  WHERE form_id = 'OPPORTUNITY_FORM';

insert into model(active, formID, title, viewname) values(true, 'OPPORTUNITY_FORM', 'Opportunity Form', 'Opportunity');
insert into modelfield(form_ID,     field_ID,                                   sorder, mandatory,  hide,   isCustomField,  section,                     defaultValue, widget, systemmandatory,             nolabelfor,                   nowrapperfor,            fullWidth, split) values
                      ('OPPORTUNITY_FORM', 'CRM_NOTE',                             1,      false,   false,       false,   'CRM_NOTE',                         '',    'NoteWidget',  false,         'addForm,editForm,viewForm',               '',                     true,   false),
                      ('OPPORTUNITY_FORM', 'CRM_ACTIVITIES',                       2,      false,   false,       false,   'CRM_ACTIVITIES',                   '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',               '',                     true,   false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_ASSIGNEE',             3,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'DropDown',    false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_BACKUP_ASSIGNEE',      4,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'DropDown',    false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_NUMBER',               5,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_NAME',                 6,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     true,                      '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_ACCOUNT_NAME',         7,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'LOOKUP',      false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_CONTACT_NAME',         8,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'LOOKUP',      false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_TYPE',                 9,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'DropDown',    false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_NEXT_STEP',           10,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     false,                     '',                            '',                     false,  true),
                      ('OPPORTUNITY_FORM', 'LATEST_ESTIMATE',                     11,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_AMOUNT',              12,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CURRENCY',                            13,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'UNKNOWN',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_CLOSING_DATE',        14,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'DatePicker',  false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_STAGE',               15,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'DropDown',    false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_PROBABILITY',         16,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_EXPECTED_REVENUE',    17,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'TextBox',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_CAMPAIGN_SOURCE',     18,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'LOOKUP',      false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_LEAD_SOURCE',         19,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'DropDown',    false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_ESTIMETOR',                       20,      false,   false,       false,   'OPPORTUNITY_INFORMATION',          '',    'UNKNOWN',     false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_STAGE_HISTORY',       21,      false,   false,       false,   'CRM_OPPORTUNITY_STAGE_HISTORY',    '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',               '',                     true,   false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_ATTACHMENTS',         22,      false,   false,       false,   'CRM_OPPORTUNITY_ATTACHMENTS',      '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',               '',                     true,   false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_LINKS',               23,      false,   false,       false,   'CRM_OPPORTUNITY_LINKS',            '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',               '',                     true,   false),
                      ('OPPORTUNITY_FORM', 'GET_PRODUCT',                         24,      false,   false,       false,   'CRM_OPPORTUNITY_INCLUDE_ITEMS',    '',    'CheckBox',    false,                     '',                            '',                     false,  false),
                      ('OPPORTUNITY_FORM', 'CRM_OPPORTUNITY_INCLUDE_ITEMS',       25,      false,   false,       false,   'CRM_OPPORTUNITY_INCLUDE_ITEMS',    '',    'UNKNOWN',     false,         'addForm,editForm,viewForm',               '',                     true,   false);


UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id = 'OPPORTUNITY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id = 'OPPORTUNITY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'OPPORTUNITY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id = 'OPPORTUNITY_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'OPPORTUNITY_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id = 'OPPORTUNITY_FORM';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id = 'OPPORTUNITY_FORM';

DELETE FROM "anv"."model"  WHERE formid = 'OPPORTUNITY_FORM';
DELETE FROM "anv"."modelfield"  WHERE form_id = 'OPPORTUNITY_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('OPPORTUNITY_FORM', 'Opportunity')) IS NOT NULL;


