DELETE FROM modelfield where form_id = 'LEAD_FORM' and field_id in ('SUBSCRIPTION_LIST', 'EMAIL_OPT_OUT');
DELETE FROM "anv".modelfield where form_id = 'LEAD_FORM';

INSERT INTO modelfield(sorder, mandatory, hide, isCustomField, defaultValue, systemmandatory, field_ID, SECTION, widget ,form_ID) VALUES
(27, FALSE, FALSE, FALSE, '', FALSE, 'SUBSCRIPTION_LIST', 'CRM_DETAILS', 'UNKNOWN' , 'LEAD_FORM'),
(28, FALSE, FALSE, FALSE, '', FALSE, 'EMAIL_OPT_OUT', 'CRM_DETAILS', 'CheckBox' , 'LEAD_FORM');

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where field_id in ('SUBSCRIPTION_LIST', 'EMAIL_OPT_OUT') and form_id = 'LEAD_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where field_id in ('SUBSCRIPTION_LIST', 'EMAIL_OPT_OUT') and form_id = 'LEAD_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where field_id in ('SUBSCRIPTION_LIST', 'EMAIL_OPT_OUT') and form_id = 'LEAD_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where field_id in ('SUBSCRIPTION_LIST', 'EMAIL_OPT_OUT') and form_id = 'LEAD_FORM';
UPDATE modelfield set fieldStyle = 'field' where field_id in ('SUBSCRIPTION_LIST', 'EMAIL_OPT_OUT') and form_id = 'LEAD_FORM';

UPDATE modelfield set sorder = 29 where form_id = 'LEAD_FORM' and field_id = 'STATUS_HISTORY';
UPDATE modelfield set sorder = 30 where form_id = 'LEAD_FORM' and field_id = 'ATTACHMENTS';


UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('LEAD_FORM', 'Lead')) IS NOT NULL;


