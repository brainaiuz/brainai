

insert into "anv".category(code, name, type, pensionable, arabic) values('JOB_ALLOWANCE','Job Allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('PHONE_ALLOWANCE','Phone allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('FAR_LOCATION_ALLOWANCE','Far Location allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('EXTRA_ADDITIONAL','Extra Additional', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('BONUS_AWARD','Bonus Award', 'Payment', true, true);