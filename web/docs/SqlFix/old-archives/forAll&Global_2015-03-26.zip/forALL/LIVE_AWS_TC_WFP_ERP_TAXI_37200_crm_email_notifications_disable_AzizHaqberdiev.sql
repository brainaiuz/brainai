UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';
UPDATE modelfield set fieldStyle = 'field' where form_id= 'CONTACT_FORM' and field_id = 'ATTACHMENTS';

UPDATE "anv".companyEmailNotificationSettings set isenabled = false where category = 'CATEGORY_CRM';