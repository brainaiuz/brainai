
insert into "anv".category(code, name, type, pensionable, arabic) values('BASIC_SALARY','Basic Salary', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('HOUSING_ALLOWANCE','Housing allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('EDUCATION_ALLOWANCE','Education allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('RELOCATION_ALLOWANCE','Relocation allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('TRANSPORTATION ALLOWANCE','Transportation allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('AIR_TICKET_ALLOWANCE','Air ticket allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('COST_LIVING_ALLOWANCE','Cost of living allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('FAMILY_ALLOWANCE','Family allowance', 'Payment', true, true);

insert into "anv".category(code, name, type, pensionable, arabic) values('SALARY_ADVANCE','Salary Advance', 'Deduction', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('UNPAID_LEAVES','Unpaid Leaves', 'Deduction', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('INSURANCE_DEDUCTIBLES','Insurance deductibles', 'Deduction', true, true);
insert into "anv".category(code, name, type, pensionable, arabic) values('LOANS','Loans', 'Deduction', true, true);