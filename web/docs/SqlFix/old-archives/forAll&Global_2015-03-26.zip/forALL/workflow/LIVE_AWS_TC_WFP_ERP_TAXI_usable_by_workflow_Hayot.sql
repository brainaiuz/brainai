update modelfield set usableByWorkflow=false where form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'FIRST_NAME' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'LAST_NAME' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'CRM_ACCOUNT_NAME' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'JOB_TITLE' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'LEAD_OWNER' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'LEAD_NAME' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'ADDRESS' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'OWNER' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'CRM_CAMPAIGN_NAME' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'ASSIGNEE' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'BACKUP_ASSIGNEE' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'LEAD_SOURCE' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'STATUS' and form_id = 'LEAD_FORM';
update modelfield set usableByWorkflow=true where field_id = 'RATING' and form_id = 'LEAD_FORM';

update "0".modelfield set usableByWorkflow=false where form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'FIRST_NAME' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'LAST_NAME' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'CRM_ACCOUNT_NAME' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'JOB_TITLE' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'LEAD_OWNER' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'LEAD_NAME' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'ADDRESS' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'OWNER' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'CRM_CAMPAIGN_NAME' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'ASSIGNEE' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'BACKUP_ASSIGNEE' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'LEAD_SOURCE' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'STATUS' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow=true where field_id = 'RATING' and form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow = true where isCustomField is true and widget in ('DatePicker', 'TextBox', 'DropDown');
update "0".modelfield set type = 'Text' where usableByWorkflow is true and type = 'text';
update "0".modelfield set type = 'Number' where usableByWorkflow is true and isCustomField is true and widget in ('TextBox', 'DropDown') and field_id like 'double_value%';
update "0".modelfield set type = 'Date' where usableByWorkflow is true and isCustomField is true and widget = 'DatePicker';

DROP function if EXISTS "0".updateModelFieldSource();
CREATE OR replace function "0".updateModelFieldSource()
  returns INTEGER AS
  $body$
DECLARE  customField record;
    BEGIN
            FOR customField IN (SELECT * FROM "0".companyCustomFieldsSettings WHERE entityname in ('Lead', 'CrmCase', 'Contact') AND uiType = 'DropDown')
            loop
                UPDATE "0".modelfield set source = customField.predefinedValues WHERE form_id = (CASE WHEN customField.entityName='Lead' THEN 'LEAD_FORM' WHEN customField.entityName='Contact' THEN 'CONTACT_FORM' ELSE 'CASE_FORM' END) AND field_id = customfield.columnCode;
            END loop;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "0".updateModelFieldSource() owner TO wfmtest;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "0".updateModelFieldSource()) IS NOT NULL;


update "anv".modelfield set usableByWorkflow=false where form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'FIRST_NAME' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'LAST_NAME' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'CRM_ACCOUNT_NAME' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'JOB_TITLE' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'LEAD_OWNER' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'LEAD_NAME' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'ADDRESS' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'OWNER' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'CRM_CAMPAIGN_NAME' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'ASSIGNEE' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'BACKUP_ASSIGNEE' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'LEAD_SOURCE' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'STATUS' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow=true where field_id = 'RATING' and form_id = 'LEAD_FORM';
update "anv".modelfield set usableByWorkflow = true where isCustomField is true and widget in ('DatePicker', 'TextBox', 'DropDown');
update "anv".modelfield set type = 'Text' where usableByWorkflow is true and type = 'text';
update "anv".modelfield set type = 'Number' where usableByWorkflow is true and isCustomField is true and widget in ('TextBox', 'DropDown') and field_id like 'double_value%';
update "anv".modelfield set type = 'Date' where usableByWorkflow is true and isCustomField is true and widget = 'DatePicker';

DROP function if EXISTS "anv".updateModelFieldSource();
CREATE OR replace function "anv".updateModelFieldSource()
  returns INTEGER AS
  $body$
DECLARE  customField record;
    BEGIN
            FOR customField IN (SELECT * FROM "anv".companyCustomFieldsSettings WHERE entityname in ('Lead', 'CrmCase', 'Contact') AND uiType = 'DropDown')
            loop
                UPDATE "anv".modelfield set source = customField.predefinedValues WHERE form_id = (CASE WHEN customField.entityName='Lead' THEN 'LEAD_FORM' WHEN customField.entityName='Contact' THEN 'CONTACT_FORM' ELSE 'CASE_FORM' END) AND field_id = customfield.columnCode;
            END loop;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".updateModelFieldSource() owner TO wfmtest;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".updateModelFieldSource()) IS NOT NULL;