delete from  modelfield where form_ID ='WORKFLOW_TASK_MIN_FORM';
delete from  model where formID ='WORKFLOW_TASK_MIN_FORM';

insert into model(active, formID, title, viewname) values(true, 'WORKFLOW_TASK_MIN_FORM', 'Add Workflow Task', 'Workflow Task');

--Task details
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,   section,       widget,       form_ID,   noWrapperFor, labelless ) values
                      (01,     true ,      false,  false,       '',           true,            '',     'PROJECT',     'DESCRIPTION', 'LOOKUP'  ,  'WORKFLOW_TASK_MIN_FORM','',  false ),
                      (02,     true ,      false,  false,       '',           false ,          '',     'NUMBER',      'DESCRIPTION', 'TextBox'  ,  'WORKFLOW_TASK_MIN_FORM','', false ),
                      (03,     true ,      false,  false,       '',           true,            '',     'NAME',        'DESCRIPTION', 'TextBox'  ,  'WORKFLOW_TASK_MIN_FORM','', false ),
                      (04,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION', 'DESCRIPTION', 'TextArea'  , 'WORKFLOW_TASK_MIN_FORM','', false ),
                      (05,     true ,      false,  false,       '',           false ,           '',    'WORKFLOW_DATE', 'DESCRIPTION', 'DatePicker', 'WORKFLOW_TASK_MIN_FORM','', false ),
                      (06,     false,      false,  false,       '',           false,           '',     'PRIORITY',    'DESCRIPTION', 'DropDown'  , 'WORKFLOW_TASK_MIN_FORM','', false ),
                      (07,     true ,      false,  false,       '',           false,           '',     'STATUS',      'DESCRIPTION', 'DropDown'  , 'WORKFLOW_TASK_MIN_FORM','', false ),

                      (08,     false ,      false,  false,       '',           false,           'addForm,editForm,viewForm',     'WORKFLOW_TIME_BASED', 'WORKFLOW_TIME_BASED_HEADER', 'UNKNOWN'  , 'WORKFLOW_TASK_MIN_FORM','addForm,editForm,viewForm', false);


UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='WORKFLOW_TASK_MIN_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='WORKFLOW_TASK_MIN_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd'  where form_ID ='WORKFLOW_TASK_MIN_FORM' AND noLabelFor is not null AND noLabelFor != '';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='WORKFLOW_TASK_MIN_FORM';
UPDATE modelfield set halfSetStyle = ''  where form_ID ='WORKFLOW_TASK_MIN_FORM' AND noLabelFor is not null AND noLabelFor != '';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='WORKFLOW_TASK_MIN_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='WORKFLOW_TASK_MIN_FORM';


delete from "anv".modelfield where form_ID ='WORKFLOW_TASK_MIN_FORM';
delete from "anv".model where formID ='WORKFLOW_TASK_MIN_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('WORKFLOW_TASK_MIN_FORM', 'Workflow Task')) IS NOT NULL;
