update modelfield set usableByWorkflow = false where field_id in ('WEB_ADDRESS', 'IM_ADDRESS', 'PHONE', 'EMAIL') and (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM');
update modelfield set usableByworkflow = false
where field_id in ('CRM_ACCOUNT_ORGANIZATION_TYPE', 'CRM_ACCOUNT_ANNUAL_REVENUE', 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE', 'CRM_ACCOUNT_OWNERSHIP', 'CRM_ACCOUNT_INDUSTRY', 'CRM_ACCOUNT_TYPE')
and form_id in ('LEAD_FORM','CONTACT_FORM');

update "anv".modelfield set usableByWorkflow = false where field_id in ('WEB_ADDRESS', 'IM_ADDRESS', 'PHONE', 'EMAIL') and (form_id = 'LEAD_FORM' OR form_id = 'CONTACT_FORM');
update "anv".modelfield set usableByworkflow = false
where field_id in ('CRM_ACCOUNT_ORGANIZATION_TYPE', 'CRM_ACCOUNT_ANNUAL_REVENUE', 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE', 'CRM_ACCOUNT_OWNERSHIP', 'CRM_ACCOUNT_INDUSTRY', 'CRM_ACCOUNT_TYPE')
and form_id in ('LEAD_FORM','CONTACT_FORM');