--for public schema
insert into model(active,formID, title,viewname) values(true,'PAYRUN_FORM', 'Payrun Form','Payrun');

insert into modelfield(form_ID,     field_ID, usableByWorkflow, source, widget) values
('PAYRUN_FORM', 'STATUS',  true, 'REFERENCE@PAYRUN_STATUS', 'LOOKUP');
insert into modelfield(form_ID,     field_ID, usableByWorkflow, source, widget) values
('PAYRUN_FORM', 'STATUS2',  true, 'REFERENCE@PAYRUN_STATUS', 'LOOKUP');

--for zero schema
insert into "0".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_PAYRUN', 'Payrun', 4, (select id from "0".reference where code = '_WORKFLOW_MODULE'));


--for all
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_PAYRUN', 'Payrun', 4, (select id from "anv".reference where code = '_WORKFLOW_MODULE'));

