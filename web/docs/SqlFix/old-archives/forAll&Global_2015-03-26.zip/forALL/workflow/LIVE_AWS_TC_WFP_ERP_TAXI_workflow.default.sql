
insert into model(formID, active, title) values('WORKFLOW_FORM', true, 'Workflow');
insert into modelfield(form_ID,         field_ID,                       sorder, mandatory,  hide,   isCustomField,  section,                defaultValue, widget      ,systemmandatory,nolabelfor) values
                      ('WORKFLOW_FORM', 'NAME',        1,      true,       false,  false,          'RULE_INFORMATION', '',           'TextBox'   ,false            ,null),
                      ('WORKFLOW_FORM', 'MODULE',        2,      true,      false,  false,          'RULE_INFORMATION', '',           'DropDown'  ,false            ,null),
                      ('WORKFLOW_FORM', 'STATUS',        3,      false,      false,  false,          'RULE_INFORMATION', '',           'RadioButton'  ,false            ,null),
                      ('WORKFLOW_FORM', 'DESCRIPTION',        4,      false,      false,  false,          'RULE_INFORMATION', '',           'TextArea'  ,false            ,null),

                      ('WORKFLOW_FORM', 'EXECUTION_CRITERIA',        5,      false,      false,  false,          'EXECUTION_CRITERIA', '',           'MatrixTable'  ,false            , 'addForm,editForm,viewForm'),

                      ('WORKFLOW_FORM', 'RULE_CRITERIA',        6,      false,      false,  false,          'RULE_CRITERIA', '',           'UNKNOWN'  ,false            , 'addForm,editForm,viewForm');

insert into permission(code, context, ismainmenu, name) values('SETTINGS_REMOVE_WORKFLOW', 'SETTINGS', false,'Remore Workflow');