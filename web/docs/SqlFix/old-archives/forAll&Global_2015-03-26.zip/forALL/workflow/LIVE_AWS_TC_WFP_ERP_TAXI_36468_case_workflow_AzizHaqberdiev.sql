update modelfield set split = true where form_id = 'WORKFLOW_FORM' and field_id = 'STATUS';
update "0".modelfield set split = true where form_id = 'WORKFLOW_FORM' and field_id = 'STATUS';
update "anv".modelfield set split = true where form_id = 'WORKFLOW_FORM' and field_id = 'STATUS';

--case module
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CASE', 'Case', 3, (select id from "anv".reference where code = '_WORKFLOW_MODULE'));

--set case fields usable by workflow
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'SUBJECT';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

update modelfield set "type" ='Text' where form_id = 'CASE_FORM' and field_id = 'SUBJECT';
update modelfield set source='REFERENCE@_CASE_TYPE' where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update modelfield set source='REFERENCE@_CASE_ORIGIN' where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update modelfield set source='REFERENCE@_CASE_REASON' where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update modelfield set source='REFERENCE@_CASE_PRIORITY' where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update modelfield set source='REFERENCE@_CASE_STATUS' where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update modelfield set source='CRM@EMPLOYEE' where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update modelfield set source='CRM@EMPLOYEE' where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'SUBJECT';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update "0".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

update "0".modelfield set "type" ='Text' where form_id = 'CASE_FORM' and field_id = 'SUBJECT';
update "0".modelfield set source='REFERENCE@_CASE_TYPE' where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update "0".modelfield set source='REFERENCE@_CASE_ORIGIN' where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update "0".modelfield set source='REFERENCE@_CASE_REASON' where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update "0".modelfield set source='REFERENCE@_CASE_PRIORITY' where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update "0".modelfield set source='REFERENCE@_CASE_STATUS' where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update "0".modelfield set source='CRM@EMPLOYEE' where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update "0".modelfield set source='CRM@EMPLOYEE' where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'SUBJECT';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update "anv".modelfield set usableByWorkflow = true where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';

update "anv".modelfield set "type" ='Text' where form_id = 'CASE_FORM' and field_id = 'SUBJECT';
update "anv".modelfield set source='REFERENCE@_CASE_TYPE' where form_id = 'CASE_FORM' AND field_id = 'TYPE';
update "anv".modelfield set source='REFERENCE@_CASE_ORIGIN' where form_id = 'CASE_FORM' AND field_id = 'CASE_ORIGIN';
update "anv".modelfield set source='REFERENCE@_CASE_REASON' where form_id = 'CASE_FORM' AND field_id = 'CASE_REASON';
update "anv".modelfield set source='REFERENCE@_CASE_PRIORITY' where form_id = 'CASE_FORM' AND field_id = 'PRIORITY';
update "anv".modelfield set source='REFERENCE@_CASE_STATUS' where form_id = 'CASE_FORM' AND field_id = 'STATUS';
update "anv".modelfield set source='CRM@EMPLOYEE' where form_id = 'CASE_FORM' AND field_id = 'ASSIGNEE';
update "anv".modelfield set source='CRM@EMPLOYEE' where form_id = 'CASE_FORM' AND field_id = 'RESOLVER';