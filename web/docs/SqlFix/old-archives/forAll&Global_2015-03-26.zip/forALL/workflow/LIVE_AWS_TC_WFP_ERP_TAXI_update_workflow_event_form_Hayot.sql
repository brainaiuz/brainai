update modelfield set systemmandatory = true where field_id = 'WHEN' and (form_id = 'WORKFLOW_CALL_LOG_FORM' or form_id = 'WORKFLOW_EVENT_FORM');
update modelfield set nolabelfor='addForm,editForm,viewForm' where form_id = 'WORKFLOW_FORM' and  (field_id = 'EXECUTION_CRITERIA' or field_id = 'RULE_CRITERIA');

update "anv".modelfield set systemmandatory = true where field_id = 'WHEN' and (form_id = 'WORKFLOW_CALL_LOG_FORM' or form_id = 'WORKFLOW_EVENT_FORM');
update "anv".modelfield set nolabelfor='addForm,editForm,viewForm' where form_id = 'WORKFLOW_FORM' and  (field_id = 'EXECUTION_CRITERIA' or field_id = 'RULE_CRITERIA');