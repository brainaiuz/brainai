update "0".modelfield set usableByWorkflow = true where isCustomField is true and widget in ('DatePicker', 'TextBox', 'DropDown');
update "0".modelfield set type = 'Text' where isCustomField is true and usableByWorkflow is true and type = 'text';

update "anv".modelfield set usableByWorkflow = true where isCustomField is true and widget in ('DatePicker', 'TextBox', 'DropDown');
update "anv".modelfield set type = 'Text' where isCustomField is true and usableByWorkflow is true and type = 'text';
