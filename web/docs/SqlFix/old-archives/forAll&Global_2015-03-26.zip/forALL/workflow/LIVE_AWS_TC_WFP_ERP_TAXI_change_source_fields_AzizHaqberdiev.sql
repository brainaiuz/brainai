
update modelfield set source = 'CRM@LEAD_ASSIGNEE' where (form_id = 'CONTACT_FORM' or form_id = 'LEAD_FORM') and field_id in ('LEAD_OWNER', 'ASSIGNEE', 'BACKUP_ASSIGNEE');
update modelfield set source = 'CRM@CASE_ASSIGNEE' where form_id = 'CASE_FORM' and field_id = 'ASSIGNEE';
update modelfield set source = 'CRM@CASE_RESOLVER' where form_id = 'CASE_FORM' and field_id = 'RESOLVER';

update "0".modelfield set source = 'CRM@LEAD_ASSIGNEE' where (form_id = 'CONTACT_FORM' or form_id = 'LEAD_FORM') and field_id in ('LEAD_OWNER', 'ASSIGNEE', 'BACKUP_ASSIGNEE');
update "0".modelfield set source = 'CRM@CASE_ASSIGNEE' where form_id = 'CASE_FORM' and field_id = 'ASSIGNEE';
update "0".modelfield set source = 'CRM@CASE_RESOLVER' where form_id = 'CASE_FORM' and field_id = 'RESOLVER';

update "anv".modelfield set source = 'CRM@LEAD_ASSIGNEE' where (form_id = 'CONTACT_FORM' or form_id = 'LEAD_FORM') and field_id in ('LEAD_OWNER', 'ASSIGNEE', 'BACKUP_ASSIGNEE');
update "anv".modelfield set source = 'CRM@CASE_ASSIGNEE' where form_id = 'CASE_FORM' and field_id = 'ASSIGNEE';
update "anv".modelfield set source = 'CRM@CASE_RESOLVER' where form_id = 'CASE_FORM' and field_id = 'RESOLVER';
