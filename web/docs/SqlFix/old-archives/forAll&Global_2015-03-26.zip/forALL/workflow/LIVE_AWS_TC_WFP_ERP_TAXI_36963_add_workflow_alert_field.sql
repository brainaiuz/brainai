insert into modelfield(form_ID,field_ID,sorder, mandatory,hide,isCustomField,section,defaultValue,widget,systemmandatory,nolabelfor,nowrapperfor)
values('WORKFLOW_ALERT_FORM', 'FROM_USER', 4, false, false, false, 'INFORMATION', '', 'DropDown', false, null, null);

update modelfield set sorder = 5 where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'SUBJECT';
update modelfield set sorder = 6 where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'CONTENT';
update modelfield set sorder = 7 where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'WORKFLOW_TIME_BASED';

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';
UPDATE modelfield set fieldStyle = 'field' where form_id= 'WORKFLOW_ALERT_FORM' and field_id = 'FROM_USER';