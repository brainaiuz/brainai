delete from "0".reference where parentid = (select id from "0".reference where code = '_WORKFLOW_STATUS' limit 1);
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_STATUS_ACTIVE', 'Active', 1, (select id from "0".reference where code = '_WORKFLOW_STATUS' limit 1));
insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_STATUS_INACTIVE', 'Inactive', 2, (select id from "0".reference where code = '_WORKFLOW_STATUS' limit 1));


delete from "anv".reference where parentid = (select id from "anv".reference where code = '_WORKFLOW_STATUS' limit 1);
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_STATUS_ACTIVE', 'Active', 1, (select id from "anv".reference where code = '_WORKFLOW_STATUS' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_STATUS_INACTIVE', 'Inactive', 2, (select id from "anv".reference where code = '_WORKFLOW_STATUS' limit 1));
