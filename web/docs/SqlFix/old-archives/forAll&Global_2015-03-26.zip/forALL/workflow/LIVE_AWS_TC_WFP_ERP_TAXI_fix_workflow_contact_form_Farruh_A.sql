update modelfield set usableByWorkflow = FALSE where  form_id = 'CONTACT_FORM';
update modelfield set usableByWorkflow = TRUE where field_id in ('ADDRESS', 'CRM_CAMPAIGN_NAME', 'FIRST_NAME', 'LAST_NAME', 'EMAIL', 'JOB_TITLE', 'CRM_NOTE', 'OWNER', 'CRM_ACCOUNT_NAME') and  form_id = 'CONTACT_FORM';
update modelfield set usableByWorkflow = TRUE where field_id = 'EMAIL' and  form_id = 'LEAD_FORM';
update "0".modelfield set usableByWorkflow = TRUE where field_id = 'EMAIL' and  form_id = 'LEAD_FORM';

update "0".modelfield set usableByWorkflow = FALSE where  form_id = 'CONTACT_FORM';
update "0".modelfield set usableByWorkflow = TRUE where field_id in ('ADDRESS', 'CRM_CAMPAIGN_NAME', 'FIRST_NAME', 'LAST_NAME', 'EMAIL', 'JOB_TITLE', 'CRM_NOTE', 'OWNER', 'CRM_ACCOUNT_NAME') and  form_id = 'CONTACT_FORM';

update "anv".modelfield set usableByWorkflow = FALSE where  form_id = 'CONTACT_FORM';
update "anv".modelfield set usableByWorkflow = TRUE where field_id in ('ADDRESS', 'CRM_CAMPAIGN_NAME', 'FIRST_NAME', 'LAST_NAME', 'EMAIL', 'JOB_TITLE', 'CRM_NOTE', 'OWNER', 'CRM_ACCOUNT_NAME') and  form_id = 'CONTACT_FORM';

update "anv".modelfield set usableByWorkflow = TRUE where field_id = 'EMAIL' and  form_id = 'LEAD_FORM';