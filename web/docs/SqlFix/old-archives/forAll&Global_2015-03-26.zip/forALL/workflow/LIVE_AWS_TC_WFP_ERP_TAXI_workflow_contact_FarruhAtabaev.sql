insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE_CONTACT', 'Contact', 1, (select id from "0".reference where code = '_WORKFLOW_MODULE' limit 1));
update modelfield set usableByWorkflow = true where  form_id = 'CONTACT_FORM';
update "0".modelfield set usableByWorkflow = true where  form_id = 'CONTACT_FORM';
update modelfield set usableByWorkflow = false where field_id in ('REPORTS_TO', 'DEPARTMENT', 'EMAIL_OPT_OUT', 'CATEGORY', 'RELATIONSHIP', 'WEB_ADDRESS', 'IM_ADDRESS', 'PHONE', 'EMAIL') and  form_id = 'CONTACT_FORM';
update modelfield set usableByworkflow = false
where field_id in ('CRM_ACCOUNT_ORGANIZATION_TYPE', 'CRM_ACCOUNT_ANNUAL_REVENUE', 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE', 'CRM_ACCOUNT_OWNERSHIP', 'CRM_ACCOUNT_INDUSTRY', 'CRM_ACCOUNT_TYPE')
and form_id ='CONTACT_FORM';
update "0".modelfield set usableByWorkflow = false where field_id in ('REPORTS_TO', 'DEPARTMENT', 'EMAIL_OPT_OUT', 'CATEGORY', 'RELATIONSHIP', 'WEB_ADDRESS', 'IM_ADDRESS', 'PHONE', 'EMAIL') and form_id = 'CONTACT_FORM';
update "0".modelfield set usableByworkflow = false
where field_id in ('CRM_ACCOUNT_ORGANIZATION_TYPE', 'CRM_ACCOUNT_ANNUAL_REVENUE', 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE', 'CRM_ACCOUNT_OWNERSHIP', 'CRM_ACCOUNT_INDUSTRY', 'CRM_ACCOUNT_TYPE')
and form_id ='CONTACT_FORM';

update modelfield set source='CRM@EMPLOYEE' where field_id = 'OWNER' and form_id = 'CONTACT_FORM';
update modelfield set source='CRM@ACCOUNT' where field_id = 'CRM_ACCOUNT_NAME' and form_id = 'CONTACT_FORM';
update modelfield set source='CRM@CAMPAIGN' where field_id = 'CRM_CAMPAIGN_NAME' and form_id = 'CONTACT_FORM';

update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'FIRST_NAME';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'LAST_NAME';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'JOB_TITLE';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'EMAIL';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'PHONE';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'IM_ADDRESS';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'WEB_ADDRESS';
update modelfield set "type" ='Text' where form_id = 'CONTACT_FORM' and field_id = 'ADDRESS';


update "0".modelfield set source='CRM@EMPLOYEE' where field_id = 'OWNER' and form_id = 'CONTACT_FORM';
update "0".modelfield set source='CRM@ACCOUNT' where field_id = 'CRM_ACCOUNT_NAME' and form_id = 'CONTACT_FORM';
update "0".modelfield set source='CRM@CAMPAIGN' where field_id = 'CRM_CAMPAIGN_NAME' and form_id = 'CONTACT_FORM';

update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'FIRST_NAME';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'LAST_NAME';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'JOB_TITLE';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'EMAIL';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'PHONE';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'IM_ADDRESS';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'WEB_ADDRESS';
update "0".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'ADDRESS';



insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_MODULE_CONTACT', 'Contact', 1, (select id from "anv".reference where code = '_WORKFLOW_MODULE' limit 1));
update "anv".modelfield set usableByWorkflow = true where  form_id = 'CONTACT_FORM';
update "anv".modelfield set usableByWorkflow = false where field_id in ('REPORTS_TO', 'DEPARTMENT', 'EMAIL_OPT_OUT', 'CATEGORY', 'RELATIONSHIP', 'WEB_ADDRESS', 'IM_ADDRESS', 'PHONE', 'EMAIL') and form_id = 'CONTACT_FORM';
update "anv".modelfield set usableByworkflow = false
where field_id in ('CRM_ACCOUNT_ORGANIZATION_TYPE', 'CRM_ACCOUNT_ANNUAL_REVENUE', 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE', 'CRM_ACCOUNT_OWNERSHIP', 'CRM_ACCOUNT_INDUSTRY', 'CRM_ACCOUNT_TYPE')
and form_id ='CONTACT_FORM';

update "anv".modelfield set source='CRM@EMPLOYEE' where field_id = 'OWNER' and form_id = 'CONTACT_FORM';
update "anv".modelfield set source='CRM@ACCOUNT' where field_id = 'CRM_ACCOUNT_NAME' and form_id = 'CONTACT_FORM';
update "anv".modelfield set source='CRM@CAMPAIGN' where field_id = 'CRM_CAMPAIGN_NAME' and form_id = 'CONTACT_FORM';

update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'FIRST_NAME';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'LAST_NAME';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'JOB_TITLE';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'EMAIL';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'PHONE';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'IM_ADDRESS';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'WEB_ADDRESS';
update "anv".modelfield set type ='Text' where form_id = 'CONTACT_FORM' and field_id = 'ADDRESS';
