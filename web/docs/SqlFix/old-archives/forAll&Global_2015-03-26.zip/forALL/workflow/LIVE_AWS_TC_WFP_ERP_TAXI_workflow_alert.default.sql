delete from model where formID = 'WORKFLOW_ALERT_FORM';
delete from modelfield where form_ID = 'WORKFLOW_ALERT_FORM';

insert into model(formID, active, title) values('WORKFLOW_ALERT_FORM', true, 'Workflow Alert');
insert into modelfield(form_ID,               field_ID,                       sorder, mandatory,  hide,   isCustomField,  section,                defaultValue, widget      ,systemmandatory,nolabelfor,nowrapperfor) values
                      ('WORKFLOW_ALERT_FORM', 'FROM_USER',       1,      false,      false,  false,          'INFORMATION', '',           'DropDown'  ,false      ,null,null),
                      ('WORKFLOW_ALERT_FORM', 'RECEPIENT',       2,      true,       false,  false,          'INFORMATION', '',           'TextBox'  ,false       ,null,null),
                      ('WORKFLOW_ALERT_FORM', 'BCC_CC_PANEL',    3,      false,      false,  false,          'INFORMATION', '',           'UNKNOWN'  ,false       ,null, 'addForm,editForm,viewForm'),
                      ('WORKFLOW_ALERT_FORM', 'TEMPLATE',        4,      false,      false,  false,          'INFORMATION', '',           'DropDown'  ,false      ,null,null),
                      ('WORKFLOW_ALERT_FORM', 'SUBJECT',         5,      true,       false,  false,          'INFORMATION', '',           'TextBox'   ,true        ,null,null),
                      ('WORKFLOW_ALERT_FORM', 'CONTENT',         6,      false,      false,  false,          'CONTENT',     '',           'TextArea'  ,false       ,null,null),
                      ('WORKFLOW_ALERT_FORM', 'WORKFLOW_TIME_BASED',        7,       false,      false,  false,          'WORKFLOW_TIME_BASED_HEADER', '',           'UNKNOWN'  ,false  ,'addForm,editForm,viewForm', 'addForm,editForm,viewForm');

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id= 'WORKFLOW_ALERT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id= 'WORKFLOW_ALERT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_id= 'WORKFLOW_ALERT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id= 'WORKFLOW_ALERT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_id= 'WORKFLOW_ALERT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id= 'WORKFLOW_ALERT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id= 'WORKFLOW_ALERT_FORM';

delete from "anv".model where formID = 'WORKFLOW_ALERT_FORM';
delete from "anv".modelfield where form_ID = 'WORKFLOW_ALERT_FORM';