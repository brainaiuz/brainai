update modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'LEAD_OWNER'                    and form_id = 'LEAD_FORM';
update modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'ASSIGNEE'                      and form_id = 'LEAD_FORM';
update modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'BACKUP_ASSIGNEE'               and form_id = 'LEAD_FORM';
update modelfield set source='CRM@ACCOUNT' where field_id = 'CRM_ACCOUNT_NAME'              and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@_CRM_ACCOUNT_TYPE' where field_id = 'CRM_ACCOUNT_TYPE'              and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@_LEAD_STATUS' where field_id = 'STATUS'                        and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@_LEAD_SOURCE' where field_id = 'LEAD_SOURCE'                   and form_id = 'LEAD_FORM';
update modelfield set source='CRM@CAMPAIGN' where field_id = 'CRM_CAMPAIGN_NAME'             and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@_COMPANY_WORKAREA' where field_id = 'CRM_ACCOUNT_INDUSTRY'          and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@CONTACT_ORGANIZATION_TYPES' where field_id = 'CRM_ACCOUNT_ORGANIZATION_TYPE' and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@CONTACT_NUMBER_OF_EMPLOYEES' where field_id = 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE'and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@_LEAD_RATING' where field_id = 'RATING'                        and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@_OWNERSHIP' where field_id = 'CRM_ACCOUNT_OWNERSHIP'         and form_id = 'LEAD_FORM';
update modelfield set source='REFERENCE@CONTACT_ANNUAL_REVENUE' where field_id = 'CRM_ACCOUNT_ANNUAL_REVENUE'    and form_id = 'LEAD_FORM';

update modelfield set "type" ='Text' where form_id = 'LEAD_FORM' and field_id = 'FIRST_NAME';
update modelfield set "type" ='Text' where form_id = 'LEAD_FORM' and field_id = 'LAST_NAME';
update modelfield set "type" ='Text' where form_id = 'LEAD_FORM' and field_id = 'JOB_TITLE';


update "0".modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'LEAD_OWNER'                    and form_id = 'LEAD_FORM';
update "0".modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'ASSIGNEE'                      and form_id = 'LEAD_FORM';
update "0".modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'BACKUP_ASSIGNEE'               and form_id = 'LEAD_FORM';
update "0".modelfield set source='CRM@ACCOUNT' where field_id = 'CRM_ACCOUNT_NAME'              and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@_CRM_ACCOUNT_TYPE' where field_id = 'CRM_ACCOUNT_TYPE'              and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@_LEAD_STATUS' where field_id = 'STATUS'                        and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@_LEAD_SOURCE' where field_id = 'LEAD_SOURCE'                   and form_id = 'LEAD_FORM';
update "0".modelfield set source='CRM@CAMPAIGN' where field_id = 'CRM_CAMPAIGN_NAME'             and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@_COMPANY_WORKAREA' where field_id = 'CRM_ACCOUNT_INDUSTRY'          and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@CONTACT_ORGANIZATION_TYPES' where field_id = 'CRM_ACCOUNT_ORGANIZATION_TYPE' and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@CONTACT_NUMBER_OF_EMPLOYEES' where field_id = 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE'and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@_LEAD_RATING' where field_id = 'RATING'                        and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@_OWNERSHIP' where field_id = 'CRM_ACCOUNT_OWNERSHIP'         and form_id = 'LEAD_FORM';
update "0".modelfield set source='REFERENCE@CONTACT_ANNUAL_REVENUE' where field_id = 'CRM_ACCOUNT_ANNUAL_REVENUE'    and form_id = 'LEAD_FORM';

update "0".modelfield set type ='Text' where form_id = 'LEAD_FORM' and field_id = 'FIRST_NAME';
update "0".modelfield set type ='Text' where form_id = 'LEAD_FORM' and field_id = 'LAST_NAME';
update "0".modelfield set type ='Text' where form_id = 'LEAD_FORM' and field_id = 'JOB_TITLE';

update "anv".modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'LEAD_OWNER'                    and form_id = 'LEAD_FORM';
update "anv".modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'ASSIGNEE'                      and form_id = 'LEAD_FORM';
update "anv".modelfield set source='CRM@LEAD_ASSIGNEE' where field_id = 'BACKUP_ASSIGNEE'               and form_id = 'LEAD_FORM';
update "anv".modelfield set source='CRM@ACCOUNT' where field_id = 'CRM_ACCOUNT_NAME'              and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@_CRM_ACCOUNT_TYPE' where field_id = 'CRM_ACCOUNT_TYPE'              and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@_LEAD_STATUS' where field_id = 'STATUS'                        and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@_LEAD_SOURCE' where field_id = 'LEAD_SOURCE'                   and form_id = 'LEAD_FORM';
update "anv".modelfield set source='CRM@CAMPAIGN' where field_id = 'CRM_CAMPAIGN_NAME'             and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@_COMPANY_WORKAREA' where field_id = 'CRM_ACCOUNT_INDUSTRY'          and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@CONTACT_ORGANIZATION_TYPES' where field_id = 'CRM_ACCOUNT_ORGANIZATION_TYPE' and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@CONTACT_NUMBER_OF_EMPLOYEES' where field_id = 'CRM_ACCOUNT_NUMBER_OF_EMPLOYEE'and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@_LEAD_RATING' where field_id = 'RATING'                        and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@_OWNERSHIP' where field_id = 'CRM_ACCOUNT_OWNERSHIP'         and form_id = 'LEAD_FORM';
update "anv".modelfield set source='REFERENCE@CONTACT_ANNUAL_REVENUE' where field_id = 'CRM_ACCOUNT_ANNUAL_REVENUE'    and form_id = 'LEAD_FORM';

update "anv".modelfield set type ='Text' where form_id = 'LEAD_FORM' and field_id = 'FIRST_NAME';
update "anv".modelfield set type ='Text' where form_id = 'LEAD_FORM' and field_id = 'LAST_NAME';
update "anv".modelfield set type ='Text' where form_id = 'LEAD_FORM' and field_id = 'JOB_TITLE';
