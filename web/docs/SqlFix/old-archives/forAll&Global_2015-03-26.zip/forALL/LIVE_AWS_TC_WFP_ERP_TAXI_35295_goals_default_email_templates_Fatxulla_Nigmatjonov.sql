insert into "anv".emailtemplate (deleted, isdefault, messagehtml, name, subject, categoryid, fromUserId, isCompanyEmailTemplate, locale)
values(false, true,'<p>Dear ${firstname} ${lastname},</p>
<p>Please be advised that ${creator} assigned you to ${title} Business goal on ${date}.</p>
<table width="705" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tr>
<td width="368" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="368" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%" style="vertical-align:top;">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Goal Summary</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Goal name:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${title}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Description:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${description}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Status:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${status}</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
<td width="9">&nbsp;</td>
<td width="328" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td height="70" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Additional Details</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Creator:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${creator}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Assignees:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${assignees}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
<tr>
<td height="89" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<td height="19" bgcolor="#ffffff" valign="top" colspan="2">&nbsp;</td>
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Dates</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Start Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${startdate}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Due Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${duedate}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<p>Click <a href="${url}" title="View Business Goal">here</a> to view the business goal</p>
<p>* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: </p>
<p><span style="color: #0033FF">${url}</span></p>', 'Businees Goal Assignee', 'Business Goal Assign', (select id from "anv".reference where code='BUSINESS_GOAL_ASSIGN_CATEGORY'), -1, 'DEFAULT_EMAIL_TEMPLATE', 'en');

insert into "anv".emailtemplate (deleted, isdefault, messagehtml, name, subject, categoryid, fromUserId, isCompanyEmailTemplate, locale)
values(false, true,'<p>Dear ${firstname} ${lastname},</p>
<p>Please be advised that ${creator} assigned you to ${title} Project goal on ${date}.</p>
<table width="705" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tr>
<td width="368" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="368" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%" style="vertical-align:top;">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Goal Summary</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Goal name:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${title}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Description:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${description}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Status:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${status}</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
<td width="9">&nbsp;</td>
<td width="328" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td height="70" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Additional Details</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Creator:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${creator}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Assignees:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${assignees}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
<tr>
<td height="89" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<td height="19" bgcolor="#ffffff" valign="top" colspan="2">&nbsp;</td>
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Dates</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Start Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${startdate}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Due Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${duedate}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<p>Click <a href="${url}" title="View Project Goal">here</a> to view the project goal</p>
<p>* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: </p>
<p><span style="color: #0033FF">${url}</span></p>', 'Project Goal Assign', 'Project Goal Assign', (select id from "anv".reference where code='PROJECT_GOAL_ASSIGN_CATEGORY'), -1, 'DEFAULT_EMAIL_TEMPLATE', 'en');


insert into "anv".emailtemplate (deleted, isdefault, messagehtml, name, subject, categoryid, fromUserId, isCompanyEmailTemplate, locale)
values(false, true,'<p>Dear ${firstname} ${lastname},</p>
<p>Please be advised that ${creator} assigned you to ${title} Department goal on ${date}.</p>
<table width="705" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tr>
<td width="368" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="368" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%" style="vertical-align:top;">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Goal Summary</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Goal name:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${title}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Description:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${description}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Status:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${status}</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
<td width="9">&nbsp;</td>
<td width="328" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td height="70" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Additional Details</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Creator:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${creator}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Assignees:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${assignees}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
<tr>
<td height="89" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<td height="19" bgcolor="#ffffff" valign="top" colspan="2">&nbsp;</td>
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Dates</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Start Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${startdate}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Due Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${duedate}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<p>Click <a href="${url}" title="View Department Goal">here</a> to view the department goal</p>
<p>* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: </p>
<p><span style="color: #0033FF">${url}</span></p>', 'Department Goal Assign', 'Department Goal Assign', (select id from "anv".reference where code='DEPARTMENT_GOAL_ASSIGN_CATEGORY'), -1, 'DEFAULT_EMAIL_TEMPLATE', 'en');


insert into "anv".emailtemplate (deleted, isdefault, messagehtml, name, subject, categoryid, fromUserId, isCompanyEmailTemplate, locale)
values(false, true,'<p>Dear ${firstname} ${lastname},</p>
<p>Please be advised that ${creator} assigned you to ${title} Personal goal on ${date}.</p>
<table width="705" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tr>
<td width="368" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="368" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%" style="vertical-align:top;">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Goal Summary</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Goal name:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${title}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Description:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${description}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Status:</td>
<td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${status}</td>
</tr>
</table>
</td>
</tr>
</table>
</td>
<td width="9">&nbsp;</td>
<td width="328" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td height="70" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Additional Details</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Creator:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${creator}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Assignees:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${assignees}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
<tr>
<td height="89" width="328" valign="top">
<table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
<td height="19" bgcolor="#ffffff" valign="top" colspan="2">&nbsp;</td>
<tr>
<td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
Dates</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Start Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${startdate}</td>
</tr>
<tr>
<td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
Due Date:</td>
<td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
${duedate}</td>
</tr>
<tr><td height="9"></td></tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<p>Click <a href="${url}" title="View Personal Goal">here</a> to view the personal goal</p>
<p>* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: </p>
<p><span style="color: #0033FF">${url}</span></p>', 'Personal Goal Assign', 'Personal Goal Assign', (select id from "anv".reference where code='PERSONAL_GOAL_ASSIGN_CATEGORY'), -1, 'DEFAULT_EMAIL_TEMPLATE', 'en');