
-- for all
update "anv".account set key=103 where name='Prepayments';

-- for public schema
update accounttemplate set key=103 where name='Prepayments';
