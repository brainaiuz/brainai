update permission set name='Sales Invoice Full Edit Access' where code='ACCOUNTING_SALES_INVOICE_FULL_EDIT_ACCESS';
update permission set name='Sales Quote Full Edit Access' where code='ACCOUNTING_SALES_QUOTE_FULL_EDIT_ACCESS';
update permission set name='Sales Order Full Edit Access' where code='ACCOUNTING_SALES_ORDER_FULL_EDIT_ACCESS';
