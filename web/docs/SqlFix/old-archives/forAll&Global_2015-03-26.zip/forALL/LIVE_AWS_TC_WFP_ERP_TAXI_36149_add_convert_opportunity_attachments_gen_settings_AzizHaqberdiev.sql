INSERT INTO "anv".genericSettings (key, value) values ('OPPORTUNITY_CONVERT_ATTACHMENTS', 'NO');
update "anv".genericsettings set value = 'YES' where key = 'OPPORTUNITY_CONVERT_ATTACHMENTS';