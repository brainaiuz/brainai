insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'ACCOUNTING', 'Sales invoice full list access', '10', 'false', (select id from permission where code='ACCOUNTING_SALES_INVOICE_LIST'), 'false', 'SALES_INVOICING');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'ACCOUNTING', 'Sales quote full list access', '11', 'false', (select id from permission where code='ACCOUNTING_SALES_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'ACCOUNTING', 'Sales order full list access', '12', 'false', (select id from permission where code='ACCOUNTING_SALES_ORDER_LIST'), 'false', 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'SALESMAN', 'ALLOW');
             
             
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'SALESMAN', 'ALLOW');
             
             
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_INVOICE_FULL_LIST_ACCESS', 'SALESMAN', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_QUOTE_FULL_LIST_ACCESS', 'SALESMAN', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SALES_ORDER_FULL_LIST_ACCESS', 'SALESMAN', 'ALLOW');

