Insert into "0".reference(code,name,sorder, parentid) values('PRODUCT_STOCK_CATEGORY','Product Stock',56,(select id from "0".reference where code='_EMAIL_TEMPLATE_CATEGORY'));

Insert into "anv".reference(code,name,sorder, parentid) values('PRODUCT_STOCK_CATEGORY','Product Stock',56,(select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY'));