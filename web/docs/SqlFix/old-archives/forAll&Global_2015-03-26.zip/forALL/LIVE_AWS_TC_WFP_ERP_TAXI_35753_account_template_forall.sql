update accounttemplate set name = 'Discounts Allowed' where id = 188;

update "anv".account set name = 'Discounts Allowed' where id = 2619;