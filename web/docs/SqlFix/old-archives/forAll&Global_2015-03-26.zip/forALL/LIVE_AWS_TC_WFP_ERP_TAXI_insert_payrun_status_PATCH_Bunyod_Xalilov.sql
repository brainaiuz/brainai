-- for zero schema
insert into "0".reference(code, name) values('PAYRUN_STATUS', 'PAYRUN_STATUS');
insert into "0".reference(code, name, issystemreference, sorder, parentid) values('PY_DRAFT', 'Draft', true, 1, (select id from "0".reference where code='PAYRUN_STATUS' limit 1));
insert into "0".reference(code, name, issystemreference, sorder, parentid) values('PY_OPEN', 'Open', true, 2, (select id from "0".reference where code='PAYRUN_STATUS' limit 1));
insert into "0".reference(code, name, issystemreference, sorder, parentid) values('PY_APPROVED', 'Approved', true, 3, (select id from "0".reference where code='PAYRUN_STATUS' limit 1));

-- for all
insert into "anv".reference(code, name) values('PAYRUN_STATUS', 'PAYRUN_STATUS');
insert into "anv".reference(code, name, issystemreference, sorder, parentid) values('PY_DRAFT', 'Draft', true, 1, (select id from "anv".reference where code='PAYRUN_STATUS' limit 1));
insert into "anv".reference(code, name, issystemreference, sorder, parentid) values('PY_OPEN', 'Open', true, 2, (select id from "anv".reference where code='PAYRUN_STATUS' limit 1));
insert into "anv".reference(code, name, issystemreference, sorder, parentid) values('PY_APPROVED', 'Approved', true, 3, (select id from "anv".reference where code='PAYRUN_STATUS' limit 1));
