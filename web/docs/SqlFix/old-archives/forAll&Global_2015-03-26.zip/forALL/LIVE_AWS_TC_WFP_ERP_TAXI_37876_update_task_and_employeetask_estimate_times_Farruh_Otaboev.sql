UPDATE "anv".task set estimatedtime = a.estimatedtime
FROM (SELECT ta.id, SUM(CASE WHEN ts.dailyEstimatedTime is not null THEN ts.dailyEstimatedTime ELSE 0 END) as estimatedtime
FROM "anv".timesheet ts 
left join "anv".employeetask et on(et.id=ts.employeetaskid)
left join "anv".task ta on (et.taskid=ta.id )
left join "anv".projectemployee pe on(et.projectemployeeid=pe.id )
left join "anv".project p on (pe.projectid=p.id )
left join "anv".teamemployee te on (pe.employeedepartmentid=te.id )
left join "anv".myuser mu on (te.employeeid=mu.id)
left join "anv".team t on (t.id=te.teamid)

WHERE ts.employeetaskid=et.id
and et.deleted<>true
and ta.deleted<>true 
and pe.isdeleted<>true
and p.isdeleted<>true
and te.isdeleted<>true
and mu.deleted<>true
and t.isdeleted<>true
group by ta.id
order by ta.id asc) as a
WHERE a.id = task.id;



UPDATE "anv".employeetask set estimatedtime = a.estimatedtime
FROM (
SELECT et.id, SUM(CASE WHEN ts.dailyEstimatedTime is not null THEN ts.dailyEstimatedTime ELSE 0 END) as estimatedtime
FROM "anv".timesheet ts 
left join "anv".employeetask et on(et.id=ts.employeetaskid)
left join "anv".task ta on (et.taskid=ta.id )
left join "anv".projectemployee pe on(et.projectemployeeid=pe.id )
left join "anv".project p on (pe.projectid=p.id )
left join "anv".teamemployee te on (pe.employeedepartmentid=te.id )
left join "anv".myuser mu on (te.employeeid=mu.id)
left join "anv".team t on (t.id=te.teamid)

WHERE ts.employeetaskid=et.id
and et.deleted<>true
and ta.deleted<>true 
and pe.isdeleted<>true
and p.isdeleted<>true
and te.isdeleted<>true
and mu.deleted<>true
and t.isdeleted<>true
group by et.id
order by et.id asc
) as a
WHERE a.id = employeetask.id;