Insert into "anv".reference(code,name,sorder, parentid) values('PERSONAL_GOAL_ASSIGN_CATEGORY','Personal Goal Assignee',52,(select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY'));
Insert into "anv".reference(code,name,sorder, parentid) values('DEPARTMENT_GOAL_ASSIGN_CATEGORY','Department Goal Assignee',53,(select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY'));
Insert into "anv".reference(code,name,sorder, parentid) values('PROJECT_GOAL_ASSIGN_CATEGORY','Project Goal Assignee',54,(select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY'));
Insert into "anv".reference(code,name,sorder, parentid) values('BUSINESS_GOAL_ASSIGN_CATEGORY','Business Goal Assignee',55,(select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY'));
