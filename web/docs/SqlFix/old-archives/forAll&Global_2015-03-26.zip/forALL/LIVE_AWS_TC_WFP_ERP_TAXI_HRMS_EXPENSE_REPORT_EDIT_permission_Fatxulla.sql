insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_EXPENSE_REPORT_EDIT', 'HRMS', 'Edit Expense Report', '2', 'false', (select id from permission where code='HRMS_EXPENCE_REPORT'), 'false', 'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EXPENSE_REPORT_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EXPENSE_REPORT_EDIT', 'DR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EXPENSE_REPORT_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EXPENSE_REPORT_EDIT', 'DR', 'ALLOW');
