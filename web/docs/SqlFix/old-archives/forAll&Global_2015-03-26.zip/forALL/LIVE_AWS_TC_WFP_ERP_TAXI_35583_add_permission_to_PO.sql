
insert into "0".mymodule (code) values('PURCHASE_ORDER');

insert into "anv".mymodule (code) values('PURCHASE_ORDER');