--schema updatedan keyin urilsin
update "anv".mailmessage set notSpammer = true;
update companySettings set opportunityItemsConvertEnabled = true;
