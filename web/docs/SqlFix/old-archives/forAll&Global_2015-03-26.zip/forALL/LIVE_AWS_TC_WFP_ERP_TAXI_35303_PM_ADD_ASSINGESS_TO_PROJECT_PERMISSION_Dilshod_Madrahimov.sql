
-- public schema
insert into permission(code,context,"name",sorder,ismainmenu,parent,description,iscore,companyid,modulecode) values
                       ('PM_ADD_ASSIGNEES_TO_PROJECT','PM','Add assignees to project',21,false,46,null,false,null,'CORE');


-- for zero schema
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode,  rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode,  rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'TL', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'ADMIN_LOCATION', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'PM', 'ALLOW');


-- for company schema
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode,  rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode,  rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'TL', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) VALUES('PM_ADD_ASSIGNEES_TO_PROJECT', 'PM', 'ALLOW');



