
UPDATE "0".paymentinstruction SET text='' where deleted<>'true' and type in (4, 5, 6);

UPDATE "anv".paymentinstruction SET text='' where deleted<>'true' and type in (4, 5, 6);
