INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Riyadh', 'SAXX0017', (select id from country  where code='AE'));
