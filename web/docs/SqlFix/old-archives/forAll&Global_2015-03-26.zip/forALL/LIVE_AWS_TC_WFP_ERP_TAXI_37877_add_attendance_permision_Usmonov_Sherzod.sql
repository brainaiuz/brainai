-- for zero schema
delete from "0".rolepermission  where permissioncode = 'HRMS_ATTENDANCE_WELCOME' and rolecode = 'MEM';

-- for all schema
delete from "anv".rolepermission  where permissioncode = 'HRMS_ATTENDANCE_WELCOME' and rolecode = 'MEM';