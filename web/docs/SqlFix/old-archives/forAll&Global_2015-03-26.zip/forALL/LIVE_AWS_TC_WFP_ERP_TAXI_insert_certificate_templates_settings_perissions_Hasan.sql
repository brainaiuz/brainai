INSERT INTO permission (code, context, name, sorder, ismainmenu, parent, modulecode) values
('CETIFICATE_TEMPLATE_LIST', 'SETTINGS', 'Certificate Template List', 1, false, (select id from permission where code='SETTINGS_HRMS_SETTINGS'), 'CORE');
INSERT INTO permission (code, context, name, sorder, ismainmenu, parent, modulecode) values
('CETIFICATE_TEMPLATE_EDIT', 'SETTINGS', 'Certificate Template Edit', 2, false, (select id from permission where code='CETIFICATE_TEMPLATE_LIST'), 'CORE');
INSERT INTO permission (code, context, name, sorder, ismainmenu, parent, modulecode) values
('CETIFICATE_TEMPLATE_ADD', 'SETTINGS', 'Certificate Template ADD', 1, false, (select id from permission where code='CETIFICATE_TEMPLATE_LIST'), 'CORE');
INSERT INTO permission (code, context, name, sorder, ismainmenu, parent, modulecode) values
('CETIFICATE_TEMPLATE_DELETE', 'SETTINGS', 'Certificate Template ADD', 3, false, (select id from permission where code='CETIFICATE_TEMPLATE_LIST'), 'CORE');






INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_ADD', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_ADD', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_ADD', 'HR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_LIST', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_LIST', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_LIST', 'HR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_EDIT', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_EDIT', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_EDIT', 'HR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_DELETE', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_DELETE', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_DELETE', 'HR', 'ALLOW');



INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_LIST', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_LIST', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_LIST', 'HR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_EDIT', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_EDIT', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_EDIT', 'HR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_ADD', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_ADD', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_ADD', 'HR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_DELETE', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_DELETE', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) values ('CETIFICATE_TEMPLATE_DELETE', 'HR', 'ALLOW');