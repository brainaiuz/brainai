insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ACCOUNTING', 'Purchase Order Save and Approve Button', '7', 'false', (select id from permission where code='ACCOUNTING_PURCHASE_ORDER_LIST'), 'false', 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'CLIENT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'CLIENT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'SALESMAN', 'ALLOW');

