insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Position Reports','System',1,'#',1,'Show how your business is positioned based on assets, liabilities and equity.';


update "anv".reporting set folderid=(select id from "anv".folders where name='Position Reports' and category_id=1), targetLink='Accounting.html#report|arAgingSummary' where code='Aged Receivables';
update "anv".reporting set folderid=(select id from "anv".folders where name='Position Reports' and category_id=1), targetLink='Accounting.html#report|apAgingSummary' where code='Aged Payables';
update "anv".reporting set folderid=(select id from "anv".folders where name='Position Reports' and category_id=1), targetLink='Accounting.html#report|balanceSheet' where code='Balance Sheet';
update "anv".reporting set folderid=(select id from "anv".folders where name='Position Reports' and category_id=1) where code='Depreciation Schedule';
update "anv".reporting set folderid=(select id from "anv".folders where name='Position Reports' and category_id=1) where code='Fixed Asset Reconciliation';
update "anv".reporting set folderid=(select id from "anv".folders where name='Position Reports' and category_id=1) where code='Movements in Equity';




update "anv".folders set sorder=1 where name='Performance Reports' and category_id=1;
update "anv".folders set sorder=2 where name='Position Reports' and category_id=1;
update "anv".folders set sorder=3 where name='Cash Reports' and category_id=1;
update "anv".folders set sorder=4 where name='Detail Reports' and category_id=1;
update "anv".folders set sorder=5 where name='Pay Run Reports' and category_id=1;
update "anv".folders set sorder=6, name='Custom Reports' where name='Customisation Reports' and category_id=1;
update "anv".folders set sorder=7 where name='Other Reports' and category_id=1;