 update "anv".employee e set startdateforonlypayroll=(select to_date(value,'DD Mon YYYY') from "anv".EmployeePayrollSettings s where key='START_DATE_FOR_ONLY_PAYROLL' and s.employeeid=e.id);
 update "anv".employee e set prevenddate=(select to_date(value,'DD Mon YYYY') from "anv".EmployeePayrollSettings s where key='PREV_END_DATE' and s.employeeid=e.id);

  update "0".employee e set startdateforonlypayroll=(select to_date(value,'DD Mon YYYY') from "0".EmployeePayrollSettings s where key='START_DATE_FOR_ONLY_PAYROLL' and s.employeeid=e.id);
 update "0".employee e set prevenddate=(select to_date(value,'DD Mon YYYY') from "0".EmployeePayrollSettings s where key='PREV_END_DATE' and s.employeeid=e.id);