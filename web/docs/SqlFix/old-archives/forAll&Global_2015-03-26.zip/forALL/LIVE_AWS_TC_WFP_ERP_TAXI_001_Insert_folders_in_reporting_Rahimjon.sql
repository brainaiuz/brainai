---------- ACOOUNTING
 insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Performance Reports','System',1,'#',1,'Show how your business is performing based on revenue and expenses.';
 insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Cash Reports','System',1,'#',2,'Show how your cash levels are changing.';
 insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Pay Run Reports','System',1,'#',3,'Show details of your pay run transactions.';
 insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Detail Reports','System',1,'#',4,'Show details of the transactions in your accounts.';
 insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Customisation Reports','System',1,'#',5,'Show your custom reports.';
 insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Other Reports','System',1,'#',6,'Show your other business reports.';


----Project Management
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Project','System',3,'#',1,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Task','System',3,'#',2,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Timesheet','System',3,'#',3,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Other Reports','System',3,'#',4,'Show your other business reports.';



  ---- CRM
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Leads','System',2,'#',1,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Opportunities','System',2,'#',2,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Contacts','System',2,'#',3,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Cases','System',2,'#',4,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Others','System',2,'#',4,'';



  -------------------HRMS---
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Leave Requests','System',6,'#',2,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Recruitments','System',6,'#',1,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Attendancies','System',6,'#',3,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Appraisals','System',6,'#',4,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Goals','System',6,'#',5,'';
  insert into "anv".folders (name,type,category_id,domainname,sorder,description) select 'Others','System',6,'#',6,'';
