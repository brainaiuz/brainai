
-- !!! only after schema update !!!

update "anv".category set forall=true where code='EXPENSE_REPORT';