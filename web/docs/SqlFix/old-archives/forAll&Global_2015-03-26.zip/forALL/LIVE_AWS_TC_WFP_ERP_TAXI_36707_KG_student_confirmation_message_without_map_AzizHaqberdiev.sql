insert into "anv".reference (code, name, description, parentid, isremovable, issystemreference, shared, iscustombutton)
values ('STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY_WITHOUT_MAP', 'Student course booking confirmation category without map',
'Student course booking confirmation category without map',
(select parentid from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'),
(select isremovable from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'),
(select issystemreference from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'),
(select shared from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'),
(select iscustombutton from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'));

INSERT INTO "anv".emailtemplate (deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, messagehtml, name, sendemail, subject,
categoryid, fromusername, customentityaction, activitytext, entitytype, toemailquery, code, locale)
values (
(select deleted from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select fromemail from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select fromuserid from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select iscompanyemailtemplate from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select isdefault from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
'<p><b>Scheduled Course #</b>: $number</p><p><b>Nominee’s Name</b>: $fullname</p><p><b>Company Name</b>: $companyname</p>
 <p><b>Reference Indicator</b>: $companynumber</p><p><b>Course Title</b>: $course</p><p><b>Course Code</b>: $coursecode
 </p><p><b>Course Location</b>: $location</p><p><b>Course Start Date</b>: $startdate</p><p><b>Course End Date</b>:
     $enddate</p><p><b>Language</b>: $language</p><p></p><p><b>Standard Pre Requisites:</b></p><p>$prerequisites</p>
 <p></p><p><b>Other Pre Requisites:</b></p><p>$otherprerequisites</p> ',
'Student course booking confirmation without map',
(select sendemail from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
'Student course booking confirmation without map',
(select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY_WITHOUT_MAP'),
(select fromusername from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select customentityaction from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select activitytext from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select entitytype from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
(select toemailquery from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY')),
'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY',
(select locale from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'))
);