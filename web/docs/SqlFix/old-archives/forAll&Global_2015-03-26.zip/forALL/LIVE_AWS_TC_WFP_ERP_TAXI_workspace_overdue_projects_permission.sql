insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('REPORTING_TEMPLATE_OVERDUE PROJECTS', 'WORKSPACE', 'Overdue Projects', '71', 'false', (select id from permission where name='Project Management' and code='REPORTING_TEMPLATE_CATEGORY_PROJECT MANAGEMENT'), 'false', 'WORKSPACE');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('OVERDUE PROJECTS_SHOW_ALL', 'WORKSPACE', 'All items', '1', 'false', (select id from permission where name='Overdue Projects' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('OVERDUE PROJECTS_MY_ITEMS', 'WORKSPACE', 'Assigned to me', '2', 'false', (select id from permission where name='Overdue Projects' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('OVERDUE PROJECTS_RELATED_ITEMS', 'WORKSPACE', 'Related to me', '3', 'false', (select id from permission where name='Overdue Projects' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'WORKSPACE', 'Non-assigned items', '4', 'false', (select id from permission where name='Overdue Projects' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');


insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PROGRESS PROJECTS_SHOW_ALL', 'WORKSPACE', 'All items', '1', 'false', (select id from permission where name='Project Progress' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PROGRESS PROJECTS_MY_ITEMS', 'WORKSPACE', 'Assigned to me', '2', 'false', (select id from permission where name='Project Progress' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PROGRESS PROJECTS_RELATED_ITEMS', 'WORKSPACE', 'Related to me', '3', 'false', (select id from permission where name='Project Progress' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'WORKSPACE', 'Non-assigned items', '4', 'false', (select id from permission where name='Project Progress' and modulecode='WORKSPACE'), 'false', 'WORKSPACE');



insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_SHOW_ALL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_SHOW_ALL', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_SHOW_ALL', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_MY_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_MY_ITEMS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_MY_ITEMS', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_RELATED_ITEMS', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_SHOW_ALL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_SHOW_ALL', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_SHOW_ALL', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_MY_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_MY_ITEMS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_MY_ITEMS', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_RELATED_ITEMS', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'MEM', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_SHOW_ALL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_SHOW_ALL', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_SHOW_ALL', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_MY_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_MY_ITEMS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_MY_ITEMS', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_RELATED_ITEMS', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('OVERDUE PROJECTS_NON_RELATED_ITEMS', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_SHOW_ALL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_SHOW_ALL', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_SHOW_ALL', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_MY_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_MY_ITEMS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_MY_ITEMS', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_RELATED_ITEMS', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PROGRESS PROJECTS_NON_RELATED_ITEMS', 'MEM', 'ALLOW');
