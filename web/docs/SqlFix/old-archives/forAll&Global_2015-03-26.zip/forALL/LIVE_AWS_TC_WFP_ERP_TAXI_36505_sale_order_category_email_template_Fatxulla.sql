update "0".emailtemplate set messagehtml='<p>Dear ${firstname} ${lastname},</p><p>This is a sales order for the date of ${startdate} and is valid until ${duedate}. Please see the attached sales order PDF document for reference.</p><p>If you agree with the terms and conditions of the sales order, we will send you sales invoice.</p><p>Thank you for your business and please feel free to contact ${name} at ${email} should you have any questions regarding the sales order.</p><p>Sincerely yours,${companyname}</p>', name='Default Sales Order', subject='Sales Order' where  categoryid = (select id from "0".reference where code='SALES_ORDER_CATEGORY');

update "anv".emailtemplate set messagehtml='<p>Dear ${firstname} ${lastname},</p><p>This is a sales order for the date of ${startdate} and is valid until ${duedate}. Please see the attached sales order PDF document for reference.</p><p>If you agree with the terms and conditions of the sales order, we will send you sales invoice.</p><p>Thank you for your business and please feel free to contact ${name} at ${email} should you have any questions regarding the sales order.</p><p>Sincerely yours,${companyname}</p>', name='Default Sales Order', subject='Sales Order' where  categoryid = (select id from "anv".reference where code='SALES_ORDER_CATEGORY');




