update "anv".invoice set deleted = true where id in (select salesinvoiceid from "anv".fixedasset f inner join "anv".invoice i on i.id = f.salesinvoiceid where f.deleted is true and i.deleted is not true);
update "anv".invoice set deleted = true where id in (select purchaseinvoiceid from "anv".fixedasset f inner join "anv".invoice i on i.id = f.purchaseinvoiceid where f.deleted is true and i.deleted is not true);

--deleted invoice payment if its invoice was deleted
update "anv".invoicepayments set deleted = true where deleted is not true and invoiceid in (select id from "anv".invoice where deleted is true);

--delete transaction when invoice has double transaction
update "anv".transaction set deleted = true where id in (select t from (select invoiceid, count(id) c, max(id) t from "anv".transaction where deleted is not true and invoiceid is not null and reversalid is null group by invoiceid) t where c > 1);
update "anv".transaction set deleted = true where id in (select t from (select invoicepaymentid, count(id) c, max(id) t from "anv".transaction where deleted is not true and invoicepaymentid is not null and reversalid is null group by invoicepaymentid) t1 where c > 1);
update "anv".transaction set deleted = true where id in (select id from (select t.id, count(ti.id) c from "anv".transaction t left join "anv".transactionitem ti on ti.transactionid = t.id where t.deleted is not true group by t.id) t where c = 0);
--delete transaction if its invoice payment was deleted
update "anv".transaction set deleted = true where id in (select distinct t.id from "anv".invoicepayments ip inner join "anv".transaction t on t.invoicepaymentid = ip.id where ip.deleted is true and t.deleted is not true);
--delete transaction if its invoice was deleted
update "anv".transaction set deleted = true where id in (select t.id from "anv".transaction t inner join "anv".invoice i on i.id = t.invoiceid where t.deleted is not true and i.deleted is true);

--update account with balance calculated is false
update "anv".account set balanceCalculated = false;
update "anv".crmaccount set balanceCalculated = false;

--set client/supplier to the transaction if transaction went wrong data
update "anv".transaction t set clientid =
	(select
	  sa.client_id
	from "anv".saleinvoice sa
	inner join "anv".invoice i on i.id = sa.id
	inner join "anv".invoicepayments ip on (ip.invoiceid = i.id or ip.creditnoteid = i.id)
	where i.deleted is not true and ip.deleted is not true and  ip.id = t.invoicepaymentid limit 1),

	supplierid = (select
	  pi.supplier_id
	from "anv".purchaseinvoice pi
	inner join "anv".invoice i on i.id = pi.id
	inner join "anv".invoicepayments ip on (ip.invoiceid = i.id or ip.creditnoteid = i.id)
	where i.deleted is not true and ip.deleted is not true and  ip.id = t.invoicepaymentid limit 1)
	where t.deleted is not true and t.dtype = 'EdsInvoicePaymentTransaction' and t.clientid is null and t.supplierid is null;

--set client/supplier to the transaction if transaction went wrong data
update "anv".transaction t set clientid = (select
	  si.client_id
	from "anv".fixedasset fa
	inner join "anv".saleinvoice si on si.id = fa.salesinvoiceid
	where fa.deleted is not true and fa.id = t.fixedassetid limit 1),

	supplierid = (select
	  pinv.supplier_id
	from "anv".fixedasset fa
	inner join "anv".purchaseinvoice pinv on pinv.id = fa.purchaseinvoiceid
	where fa.deleted is not true and fa.id = t.fixedassetid limit 1)
	where t.deleted is not true and t.dtype = 'EdsFixedAssetTransaction' and t.clientid is null and t.supplierid is null;
	
--delete customer transaction if it isn't customer at the moment
update "anv".transaction set deleted = true where id in (select t.id from "anv".transactionitem ti
inner join "anv".transaction t on t.id = ti.transactionid
inner join "anv".crmaccount c on c.id = t.clientid
where t.deleted is not true and c is not null and c.id not in (select c.id from "anv".crmaccount c
                                              inner join "anv".crmaccount_types ct on ct.crmaccount_id = c.id
                                              inner join "anv".reference cs on cs.id = ct.type_id
                                              where c.deleted is not true and cs.code = 'CUSTOMER')
and t.dtype = 'EdsCustomerTransaction'
group by t.id);

--delete supplier transaction if it isn't supplier at the moment
update "anv".transaction set deleted = true where id in (select t.id from "anv".transactionitem ti
inner join "anv".transaction t on t.id = ti.transactionid
inner join "anv".crmaccount c on c.id = t.supplierid
where t.deleted is not true and c.id not in (select c.id from "anv".crmaccount c
                                              inner join "anv".crmaccount_types ct on ct.crmaccount_id = c.id
                                              inner join "anv".reference cs on cs.id = ct.type_id
                                              where c.deleted is not true and cs.code = 'SUPPLIER')
and t.dtype = 'EdsSupplierTransaction'
group by t.id);






--sale invoice dirty data
update "anv".transaction t set clientid = (select si.client_id from "anv".saleinvoice si where si.id = t.invoiceid limit 1)
 where t.deleted is not true and t.id in (select t.id from "anv".saleinvoice si inner join "anv".transaction t on t.invoiceid = si.id where t.deleted is not true and t.clientid != si.client_id);

update "anv".transaction t1 set clientid = (select client_id from "anv".saleinvoice si
												inner join "anv".invoicepayments ip on ip.invoiceid = si.id
												inner join "anv".transaction t on t.invoicepaymentid = ip.id
												where  t.id = t1.id limit 1)
 where t1.deleted is not true and t1.id in (select t.id from "anv".saleinvoice si
												inner join "anv".invoicepayments ip on ip.invoiceid = si.id
												inner join "anv".transaction t on t.invoicepaymentid = ip.id
												where ip.deleted is not true and t.deleted is not true and si.client_id != t.clientid);


--purchase invoice dirty data
update "anv".transaction t set supplierid = (select pi.supplier_id from "anv".purchaseinvoice pi where pi.id = t.invoiceid limit 1)
 where t.deleted is not true and t.id in (select t.id from "anv".purchaseinvoice pi inner join "anv".transaction t on t.invoiceid = pi.id where t.deleted is not true and t.supplierid != pi.supplier_id);

update "anv".transaction t1 set supplierid = (select supplier_id from "anv".purchaseinvoice pi
												inner join "anv".invoicepayments ip on ip.invoiceid = pi.id
												inner join "anv".transaction t on t.invoicepaymentid = ip.id
												where  t.id = t1.id limit 1)
 where t1.deleted is not true and t1.id in (select t.id from "anv".purchaseinvoice pi
												inner join "anv".invoicepayments ip on ip.invoiceid = pi.id
												inner join "anv".transaction t on t.invoicepaymentid = ip.id
												where ip.deleted is not true and t.deleted is not true and pi.supplier_id != t.supplierid);