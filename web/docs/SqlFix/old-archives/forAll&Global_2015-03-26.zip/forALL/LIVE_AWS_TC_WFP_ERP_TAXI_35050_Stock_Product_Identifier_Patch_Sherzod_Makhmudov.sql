-- Schema updatedan keyin hamma company schemalarga apply qilish kerak

update "anv".item_stock set product_identifier=1;