-- updated expense claim(report) UI. Set opportunity lookup for join opportunity
update defaultlayout set layout='<div>
    <div class="contentBar tool-invoice">
        <div class="contentScroll">
            <table class="bindContent" cellpadding="0" cellspacing="0">
                <tbody><tr>
                    <td class="mainBar">
                        <div class="invoice-block">
                            <div class="sect clear group" style="margin-bottom: 20px">
                                <div class="invoice-title">
                                    $$label:title$$
                                </div>
                            </div>
                            <div class="sect group">
                                <div class="lineItem">
                                    $$label:date$$
                                    $$input:date$$
                                </div>
                                <div class="lineItem">
                                    $$label:exptitle$$
                                    $$input:exptitle$$
                                </div>
                                <div class="lineItem">
                                    $$label:introduction$$
                                    $$input:introduction$$
                                </div>
                                <div class="lineItem" style="float: right;">
                                    $$label:number$$
                                    $$input:number$$
                                </div>

                            </div>
                            <div class="sect group">
                                <div class="lineItem">
                                    $$label:project$$
                                    $$input:project$$
                                </div>
                                <div class="lineItem">
                                    $$label:ponumber$$
                                    $$input:ponumber$$
                                </div>
                                <div class="lineItem">
                                    $$label:submitter$$
                                    $$input:submitter$$
                                </div>
                                <div class="lineItem">
                                    $$label:manager$$
                                    $$input:manager$$
                                </div>
								<div class="lineItem">
                                    $$label:opportunity$$
                                    $$input:opportunity$$
                                </div>
                                <div class="lineItem">
                                    $$label:manager2$$
                                    $$input:manager2$$
                                </div>
								<div class="lineItem" style="padding-top: 14px;float: left;margin-left: 0px;">
                                    $$input:exrate$$
                                </div>
                            </div>
                            <div class="sect">
                                $$input:itemtable$$
                            </div>
                            <div class="invoice-paymentpanel">
                                <div class="invoice-paymentsave">
                                    $$input:paymentpanel$$
                                </div>
                            </div>
                            <div class="half right">
                                <div class="sect invoice-subtotal">
                                    <span class="corner lt"></span>
                                    <span class="corner rt"></span>
                                    <span class="corner lb"></span>
                                    <span class="corner rb"></span>
                                    $$input:totalstable$$
                                </div>
                            </div>

                            <div class="invoice-btns-row sect clear">
                                <div class="invoice-btn-save">
                                    $$input:saveButton$$
                                </div>
                                <div class="invoice-btn-save-approve">
                                    $$input:saveAndApproveButton$$
                                </div>
                                <div class="invoice-btn-save-approve">
                                    $$input:rejectButton$$
                                </div>
                                <div class="invoice-btn-approve">
                                    $$input:approveAndSendButton$$
                                </div>
                                <div class="invoice-btn-default">
                                    $$input:deleteButton$$
                                </div>
                                <div class="invoice-btn-pdf">
                                    $$input:pdfVersionButton$$
                                </div>
                            </div>
                        </div>
                    </td>
                    <!-- End  col -->
                    <td class="sidebar">
                        <div class="inv-OptBar">
                            <div class="optBarBlock invoice-customfields">
                                $$label:customfieldtitle$$
                                $$input:customfields$$
                            </div>
                            <div class="optBarBlock invoice-attachments">
                                $$label:attachments$$
                                $$input:attachments$$
                                $$input:uploadbutton$$
                            </div>
                            <div class="optBarBlock notes">
                                $$label:notes$$
                                $$input:notes$$
                                $$input:addnote$$
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody></table>
        </div>
    </div>
</div>' where sections='ACCOUNTING_SECTION' and formid='EXPENSE_REPORT';