--for ADMINISTRATORS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), false);
--for DIRECTORS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), false);
--for PROJECT_MANAGERS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'PROJECT_MANAGERS' AND entrytype = 2), false);
--for DEPARTMENT_LEADERS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'DEPARTMENT_LEADERS' AND entrytype = 2), false);
--for HRS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'HRS' AND entrytype = 2), false);
--for MEMBERS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'MEMBERS' AND entrytype = 2), false);
--for ACCOUNTANTS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ACCOUNTANTS' AND entrytype = 2), false);
--for SALESMEN
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), false);
--for CUSTOMER_SERVICE_REPRESENTATIVES
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), false);
--for ONE_OFFS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ONE_OFFS' AND entrytype = 2), false);
--for SALESPERSONS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION',(SELECT id FROM "anv".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), false);
--for ADMIN_LOCATIONS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), false);
--for CALENDAR_EDITORS
insert into "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "anv".trusteegroup WHERE constantname = 'CALENDAR_EDITORS' AND entrytype = 2), false);



--for ADMINISTRATORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), false);
--for DIRECTORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), false);
--for PROJECT_MANAGERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'PROJECT_MANAGERS' AND entrytype = 2), false);
--for DEPARTMENT_LEADERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DEPARTMENT_LEADERS' AND entrytype = 2), false);
--for HRS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'HRS' AND entrytype = 2), false);
--for MEMBERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'MEMBERS' AND entrytype = 2), false);
--for ACCOUNTANTS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ACCOUNTANTS' AND entrytype = 2), false);
--for SALESMEN
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), false);
--for CUSTOMER_SERVICE_REPRESENTATIVES
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), false);
--for ONE_OFFS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ONE_OFFS' AND entrytype = 2), false);
--for SALESPERSONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION',(SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), false);
--for ADMIN_LOCATIONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), false);
--for CALENDAR_EDITORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Project Stock','PRODUCT_STOCK_NOTIFICATION', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CALENDAR_EDITORS' AND entrytype = 2), false);
