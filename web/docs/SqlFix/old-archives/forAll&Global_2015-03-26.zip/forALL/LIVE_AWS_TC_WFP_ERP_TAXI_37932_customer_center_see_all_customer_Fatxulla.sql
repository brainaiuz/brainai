insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'ACCOUNTING', 'See All Customers', '8', 'false', (select id from permission where code='ACCOUNTING_CUSTOMER_LIST'), 'false', 'CORE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('SETTINGS_USER_CREDENTIALS', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SETTINGS_PROFILE_SETTINGS', 'SALESPERSON', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SEE_ALL_CUSTOMERS_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('SETTINGS_USER_CREDENTIALS', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SETTINGS_PROFILE_SETTINGS', 'SALESPERSON', 'ALLOW');
