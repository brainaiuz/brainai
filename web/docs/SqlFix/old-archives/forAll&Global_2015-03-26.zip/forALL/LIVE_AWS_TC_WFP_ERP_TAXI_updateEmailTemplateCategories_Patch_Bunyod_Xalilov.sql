


update "anv".reference set name='Purchase Order Manager' where code='PURCHASE_ORDER_MANAGER_CATEGORY';
update "anv".reference set name='Sales Quote Manager' where code='SALES_QUOTE_MANAGER_CATEGORY';