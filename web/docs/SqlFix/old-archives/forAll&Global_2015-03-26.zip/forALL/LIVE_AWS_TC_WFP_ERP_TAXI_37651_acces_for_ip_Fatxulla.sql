insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCESS_FOR_IP', 'SETTINGS', 'Disable IP restriction', '0', 'false', (select id from permission where code='SETTINGS_MAIN_MENU'), 'true', 'CORE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCESS_FOR_IP', 'ADMIN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCESS_FOR_IP', 'ADMIN', 'ALLOW');
