
                                                           ------ CRM SALES QUOTE ----------------

--- LIST
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_QUOTE_LIST','CRM','Sales Quote List',1,'false',(select id from permission where code='CRM_MAIN_MENU'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_LIST', 'ACCOUNTANT', 'ALLOW');

---ADD
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_QUOTE_ADD','CRM','Sales Quote Add',2,'false',(select id from permission where code='CRM_SALES_QUOTE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_ADD', 'ACCOUNTANT', 'ALLOW');

---EDIT
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_QUOTE_EDIT','CRM','Sales Quote Edit',3,'false',(select id from permission where code='CRM_SALES_QUOTE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_EDIT', 'ACCOUNTANT', 'ALLOW');

---DELETE
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_QUOTE_DELETE','CRM','Sales Quote Delete',4,'false',(select id from permission where code='CRM_SALES_QUOTE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_DELETE', 'ACCOUNTANT', 'ALLOW');

---SUMMARY
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_QUOTE_SUMMARY','CRM','Sales Quote Summary',5,'false',(select id from permission where code='CRM_SALES_QUOTE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_QUOTE_SUMMARY', 'ACCOUNTANT', 'ALLOW');

                                                    -----   CMR  SALES INVOICE -----------
--- LIST
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_INVOICE_LIST','CRM','Sales Invoice List',1,'false',(select id from permission where code='CRM_MAIN_MENU'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_LIST', 'ACCOUNTANT', 'ALLOW');

---ADD
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_INVOICE_ADD','CRM','Sales Invoice Add',2,'false',(select id from permission where code='CRM_SALES_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');

---EDIT
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_INVOICE_EDIT','CRM','Sales Invoice Edit',3,'false',(select id from permission where code='CRM_SALES_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_EDIT', 'ACCOUNTANT', 'ALLOW');

---DELETE
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_INVOICE_DELETE','CRM','Sales Invoice Delete',4,'false',(select id from permission where code='CRM_SALES_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_DELETE', 'ACCOUNTANT', 'ALLOW');

---SUMMARY
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_SALES_INVOICE_SUMMARY','CRM','Sales Invoice Summary',5,'false',(select id from permission where code='CRM_SALES_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SALES_INVOICE_SUMMARY', 'ACCOUNTANT', 'ALLOW');

                                                            -------- CMR PURCHASE INVOICE ---------------

--- LIST
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_INVOICE_LIST','CRM','Purchase Invoice List',1,'false',(select id from permission where code='CRM_MAIN_MENU'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_LIST', 'ACCOUNTANT', 'ALLOW');

---ADD
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_INVOICE_ADD','CRM','Purchase Invoice Add',2,'false',(select id from permission where code='CRM_PURCHASE_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');

---EDIT
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_INVOICE_EDIT','CRM','Purchase Invoice Edit',3,'false',(select id from permission where code='CRM_PURCHASE_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_EDIT', 'ACCOUNTANT', 'ALLOW');

---DELETE
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_INVOICE_DELETE','CRM','Purchase Invoice Delete',4,'false',(select id from permission where code='CRM_PURCHASE_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_DELETE', 'ACCOUNTANT', 'ALLOW');

---SUMMARY
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_INVOICE_SUMMARY','CRM','Purchase Invoice Summary',5,'false',(select id from permission where code='CRM_PURCHASE_INVOICE_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_INVOICE_SUMMARY', 'ACCOUNTANT', 'ALLOW');

                                                       -------- CMR PURCHASE ORDER  ------------
--- LIST
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_ORDER_LIST','CRM','Purchase Order List',1,'false',(select id from permission where code='CRM_MAIN_MENU'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_LIST', 'ACCOUNTANT', 'ALLOW');

---ADD
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_ORDER_ADD','CRM','Purchase Order Add',2,'false',(select id from permission where code='CRM_PURCHASE_ORDER_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_ADD', 'ACCOUNTANT', 'ALLOW');

---EDIT
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_ORDER_EDIT','CRM','Purchase Order Edit',3,'false',(select id from permission where code='CRM_PURCHASE_ORDER_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_EDIT', 'ACCOUNTANT', 'ALLOW');

---DELETE
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_ORDER_DELETE','CRM','Purchase Order Delete',4,'false',(select id from permission where code='CRM_PURCHASE_ORDER_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_DELETE', 'ACCOUNTANT', 'ALLOW');

---SUMMARY
insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,modulecode) values('CRM_PURCHASE_ORDER_SUMMARY','CRM','Purchase Order Summary',5,'false',(select id from permission where code='CRM_PURCHASE_ORDER_LIST'),'false','CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_PURCHASE_ORDER_SUMMARY', 'ACCOUNTANT', 'ALLOW');


