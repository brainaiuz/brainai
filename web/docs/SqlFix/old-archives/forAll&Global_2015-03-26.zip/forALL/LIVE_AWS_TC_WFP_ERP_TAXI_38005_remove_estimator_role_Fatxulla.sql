delete from "anv".customfield_permissions where role_id=(select id from "anv".role where code='ESTIMATOR');
delete from "anv".rolepermission where rolecode='ESTIMATOR';
delete from "anv".role where code='ESTIMATOR';

delete from "0".customfield_permissions where role_id=(select id from "0".role where code='ESTIMATOR');
delete from "0".rolepermission where rolecode='ESTIMATOR';
delete from "0".role where code='ESTIMATOR';