update "anv".wfp_block set code = replace(code, '-', '_');

update "anv".wfp_block set code = replace(code,  substring(code from 0 for 2),'') where substring(code from 0 for 2)='_';