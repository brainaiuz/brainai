you need to apply 34971 patch before this patch!

---FOR ALL SCHEMA

insert into permission (code,context,name,sorder,ismainmenu,parent,iscore)
select distinct 'REPORTING_SAVED_REPORT_'||r.code, 'REPORTING', r.name,r.id sorder,false,p.id parent,false
	from reporttemplate t
		join rolereporttemplate rrt on t.code=rrt.reporttemplatecode
		join reporttemplatecategory rtc on rtc.id=t.categoryid
		join permission p on p.code='REPORTING_SAVED_REPORT_CATEGORY_'||upper(rtc.name)
		join "anv".reporting r on r.viewcode=t.code
		join "anv".folders f on r.folderid=f.id
	where 'REPORTING_SAVED_REPORT_'||r.code not in (select code from permission) and t.isLibrary is true and t.iscustom is not true;


insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,companyId)
select distinct 'REPORTING_SAVED_REPORT_'||r.code||'_'||anv, 'REPORTING', r.name,r.id sorder,false,p.id parent,false,anv
	from reporttemplate t
		join rolereporttemplate rrt on t.code=rrt.reporttemplatecode
		join reporttemplatecategory rtc on rtc.id=t.categoryid
		join permission p on p.code='REPORTING_SAVED_REPORT_CATEGORY_'||upper(rtc.name)
		join "anv".reporting r on r.viewcode=t.code
		join "anv".folders f on r.folderid=f.id
	where 'REPORTING_SAVED_REPORT_'||r.code||'_'||anv not in (select code from permission) and f.type!='Private' and  t.isLibrary is not true;


insert into permission (code,context,name,sorder,ismainmenu,parent,iscore,companyId)
select distinct 'REPORTING_SAVED_REPORT_'||r.code||'_'||anv, 'REPORTING', r.name,r.id sorder,false,p.id parent,false,anv
	from reporttemplate t
		join rolereporttemplate rrt on t.code=rrt.reporttemplatecode
		join reporttemplatecategory rtc on rtc.id=t.categoryid
		join permission p on p.code='REPORTING_SAVED_REPORT_CATEGORY_'||upper(rtc.name)
		join "anv".reporting r on r.viewcode=t.code
		join "anv".folders f on r.folderid=f.id
		join customReportTemplate ct on ct.reportcode=t.code and ct.companyId=anv
	where 'REPORTING_SAVED_REPORT_'||r.code||'_'||anv not in (select code from permission) and f.type!='Private' and t.iscustom is true;


insert into "anv".rolepermission(permissioncode,rolecode,access)
select code,'SALESMAN','ALLOW' from permission
where context='REPORTING' and coalesce(companyId,anv)=anv and code not in (select permissioncode from "anv".rolepermission where rolecode='SALESMAN')
union all
select code,'ADMIN','ALLOW' from permission
where context='REPORTING' and coalesce(companyId,anv)=anv and code not in (select permissioncode from "anv".rolepermission where rolecode='ADMIN')
union all
select code,'DR','ALLOW' from permission
where context='REPORTING' and coalesce(companyId,anv)=anv and code not in (select permissioncode from "anv".rolepermission where rolecode='DR')
union all
select code,'ACCOUNTANT','ALLOW' from permission
where context='REPORTING' and coalesce(companyId,anv)=anv and code not in (select permissioncode from "anv".rolepermission where rolecode='ACCOUNTANT');
