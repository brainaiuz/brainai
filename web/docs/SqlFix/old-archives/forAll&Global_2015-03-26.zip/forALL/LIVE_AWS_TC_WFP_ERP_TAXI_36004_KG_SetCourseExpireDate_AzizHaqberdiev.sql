--uploaddan kn urilsin
update "31287".scheduledCourse set expiredate = null;
update "31287".scheduledCourse cs
set expiredate = (cs.enddate + ((select validity from "31287".course where id = cs.course_id) || ' MONTH')::INTERVAL)
where (select validity from "31287".course where id = cs.course_id) is not null;