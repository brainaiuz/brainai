-- AWSda UI dan update qilolmadim, AWS upload olinganda xato chiqsa uriladi!

update localization set defaulttext='Payment must be paid strictly within {0} days for this invoice number {1} as indicated in due date of {2}.'  where code='instructionTemplate';
update localization set en='Payment must be paid strictly within {0} days for this invoice number {1} as indicated in due date of {2}.'  where code='instructionTemplate';
update localization set ru='Оплата должна быть произведена строго в течении {0} дней как отражено в сроках:{1} {2}'  where code='instructionTemplate';
update localization set neder='Betalingen moeten binnen {0} dagen worden gedaan voor de vervaldag {1} {2}.' where code='instructionTemplate';
update localization set turkish='Ödemeler kesinlikle şablonlarda {0} gösterilen günler içerisinde ödenmelidir{1} {2}.' where code='instructionTemplate';
update localization set arabic='يجب أن تدفع دفعة بدقة داخل {0} يوما لهذا العدد فاتورة {1} كما هو مبين في الموعد المحدد من {2}.' where code='instructionTemplate';