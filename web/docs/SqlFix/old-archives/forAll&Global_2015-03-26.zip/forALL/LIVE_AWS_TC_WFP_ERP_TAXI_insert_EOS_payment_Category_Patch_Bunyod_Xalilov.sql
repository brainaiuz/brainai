
insert into "anv".category(code, name, type, pensionable, arabic) values('END_OF_SERVICE','End Of Service Gratuity', 'Payment', true, true);