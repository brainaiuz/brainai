---new reason type Unauthorized Leave

insert into "anv".reference (code, deleted, isremovable, issystemreference, name, shared, sorder, iscustombutton, parentid)
values ('LR_TYPE_UNAUTHORIZED_LEAVE', false, false, true, 'Unauthorized Leave', true, 6, false, (select id from "anv".reference where code='_LEAVE_REQUEST_TYPE'));
