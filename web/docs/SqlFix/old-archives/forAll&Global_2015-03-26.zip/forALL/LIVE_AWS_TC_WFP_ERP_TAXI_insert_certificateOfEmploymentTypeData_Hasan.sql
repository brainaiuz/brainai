INSERT INTO "anv".certificateofemploymenttype ("name", defaulthtml) VALUES ('Certificate of employment', '<div class="mainStyle_reset">
<table cellpadding="10" cellspacing="0" class="section" style="border-top: 1px solid rgb(221, 221, 221);" width="620">
	<tbody>
		<tr>
			<td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
		</tr>
		<tr>
			<td>
			<table align="left" border="0" cellpadding="10" cellspacing="0" height="120" style="border: 1px solid rgb(221, 221, 221);" width="40%">
				<tbody>
					<tr>
						<th align="left" height="120" valign="top" width="30"><label style="font-size: 14px;">From: </label></th>
						<td style="font-size: 12px;" valign="top">${companyname},<br />
						${companyaddress}</td>
					</tr>
				</tbody>
			</table>

			<table align="right" border="0" cellpadding="10" cellspacing="0" height="120" style="border: 1px solid rgb(221, 221, 221);" width="40%">
				<tbody>
					<tr>
						<th align="left" height="120" valign="top" width="30"><label for="hrCert_to" style="font-size: 14px;">To: </label></th>
						<td style="font-size: 12px;" valign="top">$$input:textarea1$$</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<td style="color: rgb(187, 187, 187);">Date: ${realytime}</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="620">
	<tbody>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="620">
	<tbody>
		<tr>
			<td>
			<h1 style="text-align: center; margin: 0pt; font: bold 28px/1.4 Arial;">Certificate of Employment</h1>
			</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="620">
	<tbody>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="620">
	<tbody>
		<tr>
			<td align="left"><span style="line-height:1.6;">This is to certify that ${salutation} ${firstname} ${lastname}, Passport <strong>No.${passportnumber} </strong> and his monthly gross salary is <strong>SR </strong>${salaryamount} He is working in <strong>${companyname}</strong> as ${position} from<strong> </strong> ${hiredate} till this date. He wants to spend his annual vacation in the $$input:textbox1$$ for the purpose of tourism. </span>
       <br/>
       <br/>
			<p><small>This certificate is granted upon his/her request and without any responsibility on the part of <strong>${companyname}</strong>t.</small></p>
			</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="620">
	<tbody>
		<tr>
			<td>Regards,<br />
			<table border="0" cellpadding="0" cellspacing="0" width="30%">
				<tbody>
					<tr>
						<td style="padding-bottom: 4px;">${yourname}</td>
					</tr>
					<tr>
						<td style="border-top: 1px solid rgb(221, 221, 221); padding-top: 4px;"><strong>${yourrole}</strong></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</div>');