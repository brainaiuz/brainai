
-- Schema Update dan kiyin urilsin!!!

update "anv".emailtemplate emtemplate set customentity_websiteid =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=emtemplate.customentity_guid);
