INSERT INTO "anv".reference (code, description, name, sorder, shared) values ('CERTIFICATE_TEMPLATE_TYPE', 'Certificate Type', 'Certificate Template', 1, true);
INSERT INTO "anv".reference (code, description, name, sorder, parentid, shared) values ('CERTIFICATE_OF_EMPLOYMENT', 'Certificate of Employment', 'Certificate of Employment', 1,
(SELECT id from "anv".reference where code='CERTIFICATE_TEMPLATE_TYPE'), true);



INSERT INTO "0".reference (code, description, name, sorder, shared) values ('CERTIFICATE_TEMPLATE_TYPE', 'Certificate Type', 'Certificate Template', 1, true);
INSERT INTO "0".reference (code, description, name, sorder, parentid, shared) values ('CERTIFICATE_OF_EMPLOYMENT', 'Certificate of Employment', 'Certificate of Employment', 1,
(SELECT id from "0".reference where code='CERTIFICATE_TEMPLATE_TYPE'), true);