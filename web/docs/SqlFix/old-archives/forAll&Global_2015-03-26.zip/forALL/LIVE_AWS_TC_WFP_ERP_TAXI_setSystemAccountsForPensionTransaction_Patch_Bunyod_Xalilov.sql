
-- for public schema
update accounttemplate set key=7007 where code='7007';
update accounttemplate set key=2230 where code='2230';

-- for company schema
update "anv".account set key=7007 where accountcode='7007';
update "anv".account set key=2230 where accountcode='2230';

