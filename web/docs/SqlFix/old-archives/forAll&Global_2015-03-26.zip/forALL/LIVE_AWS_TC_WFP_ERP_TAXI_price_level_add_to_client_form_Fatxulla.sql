insert into modelfield(form_ID,field_ID,sorder, mandatory,  hide,   isCustomField, section, defaultValue, widget, systemmandatory, nolabelfor,nowrapperfor,fullWidth, split)
values ('CLIENT_FORM', 'PRICE_LEVEL', 34,  false,false,false, 'CRM_ACCOUNT_FINANCIAL_INFORMATION','', 'UNKNOWN', false, '', '',false,   false);

insert into "anv".modelfield(form_ID,field_ID,sorder, mandatory,  hide,   isCustomField, section, defaultValue, widget, systemmandatory, nolabelfor,nowrapperfor,fullWidth, split)
values ('CLIENT_FORM', 'PRICE_LEVEL', 34,  false,false,false, 'CRM_ACCOUNT_FINANCIAL_INFORMATION','', 'UNKNOWN', false, '', '',false,   false);