insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'ACCOUNTING', 'Add New Category (chart of accounts)', '6', 'false', (select id from permission where code='ACCOUNTING_EXPENSE_REPORT_LIST'), 'false', 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_CLAIM_ADD_CATEGORY', 'ACCOUNTANT', 'ALLOW');
