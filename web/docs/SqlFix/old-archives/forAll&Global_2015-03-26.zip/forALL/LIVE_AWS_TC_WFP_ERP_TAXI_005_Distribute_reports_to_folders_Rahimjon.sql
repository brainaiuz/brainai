UPDATE "anv".reporting set targetLink='Accounting.html#report|profitLoss' WHERE code = 'Profit and Loss';
UPDATE "anv".reporting set targetLink ='Accounting.html#report|trialBalance' WHERE code='Trial Balance';
UPDATE "anv".reporting set targetLink ='Accounting.html#report|arAgingSummary' WHERE code='Aged Receivables';
UPDATE "anv".reporting set targetLink ='Accounting.html#report|apAgingSummary' WHERE code='Aged Payables';