insert into region (name, alias, countryid) values ('Distrito Federal', 'Distrito Federal', (select id from country where name = 'Mexico'));
update region set name = 'Estado de México', alias = 'Estado de México' where name = 'Mexico';
