


-- Hech qayerga urilmasin 



ALTER TABLE "anv".page_category RENAME TO wfp_page_category;
