
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_LEADS_IMPORT', 'CRM', 'Leads Import', '5', 'false', (select id from permission where code='CRM_LEADS_LIST'), 'false', 'CORE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CRM_LEADS_EXPORT', 'CRM', 'Leads Export', '6', 'false', (select id from permission where code='CRM_LEADS_LIST'), 'false', 'CORE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_IMPORT', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEADS_EXPORT', 'SALESMAN', 'ALLOW');


