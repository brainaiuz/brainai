insert into permission(context, code, name) values('SETTINGS', 'SETTINGS_WORKFLOW','');
insert into permission(context, code, name,parent) values('SETTINGS', 'SETTINGS_SUMMARY_WORKFLOW','Workflow View', (select id from permission where code = 'SETTINGS_WORKFLOW' and context = 'SETTINGS'));
insert into permission(context, code, name,parent) values('SETTINGS', 'SETTINGS_EDIT_WORKFLOW'   ,'Workflow Edit', (select id from permission where code = 'SETTINGS_WORKFLOW' and context = 'SETTINGS'));
insert into permission(context, code, name,parent) values('SETTINGS', 'SETTINGS_ADD_WORKFLOW'    ,'Workflow Add', (select id from permission where code = 'SETTINGS_WORKFLOW' and context = 'SETTINGS'));
insert into permission(context, code, name,parent) values('SETTINGS', 'SETTINGS_REMOVE_WORKFLOW'    ,'Workflow Remove', (select id from permission where code = 'SETTINGS_WORKFLOW' and context = 'SETTINGS'));

INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_WORKFLOW' ,'ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_ADD_WORKFLOW'     ,'ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_EDIT_WORKFLOW'    ,'ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_SUMMARY_WORKFLOW' ,'ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_REMOVE_WORKFLOW'     ,'ADMIN','ALLOW');

INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_WORKFLOW' ,'ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_ADD_WORKFLOW'     ,'ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_EDIT_WORKFLOW'    ,'ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_SUMMARY_WORKFLOW' ,'ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('SETTINGS_REMOVE_WORKFLOW'     ,'ADMIN','ALLOW');

update permission set name = 'Workflow Settings', sorder=15, parent = 28,iscore=false, modulecode='CORE', ismainmenu=false where code = 'SETTINGS_WORKFLOW';
