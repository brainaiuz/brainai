
INSERT INTO "anv".genericsettings (key, value) VALUES  ('ADVANCED_SEARCH_ENABLED', 'NO');