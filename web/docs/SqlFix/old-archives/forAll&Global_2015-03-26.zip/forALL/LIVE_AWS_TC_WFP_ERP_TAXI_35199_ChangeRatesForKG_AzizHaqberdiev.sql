--IFRR course uchun
update "31287".scheduledcourse set price = '12'
where course_id = (select id from "31287".course where number = 'IFRR')
and location_id = (select id from "31287".location where city = 'Coastal')
and (startdate between '01-10-2012' and '24-04-2014');
update "31287".scheduledcourse set price = '10'
where course_id = (select id from "31287".course where number = 'IFRR')
and location_id in (select id from "31287".location where city <> 'Coastal')
and (startdate between '01-10-2012' and '24-04-2014');
--FLOPR course uchun
update "31287".scheduledcourse set price = '22'
where course_id = (select id from "31287".course where number = 'FLOPR')
and (startdate between '01-10-2012' and '24-04-2014');

--StudentTablega
--IFRR course uchun
update "31287".courseschedulestudent css set price = '12'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id = (select id from "31287".course where number = 'IFRR')
and location_id = (select id from "31287".location where city = 'Coastal')
and startdate between '01-10-2012' and '24-04-2014');
update "31287".courseschedulestudent css set price = '10'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id = (select id from "31287".course where number = 'IFRR')
and location_id in (select id from "31287".location where city <> 'Coastal')
and startdate between '01-10-2012' and '24-04-2014');
--FLOPR course uchun
update "31287".courseschedulestudent css set price = '22'
where courseschedule_id in (select id from "31287".scheduledcourse
where course_id = (select id from "31287".course where number = 'FLOPR')
and startdate between '01-10-2012' and '24-04-2014');



