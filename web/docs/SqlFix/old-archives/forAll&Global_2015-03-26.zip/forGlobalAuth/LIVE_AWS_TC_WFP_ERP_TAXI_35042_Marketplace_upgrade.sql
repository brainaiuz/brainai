ALTER TABLE "public"."hostbasedsetting"
DROP COLUMN "googleauthsubprivatekeypath",
DROP COLUMN "imagemagickpath",
DROP COLUMN "chatdomain",
DROP COLUMN "googlemarketplacerealm",
DROP COLUMN "uploadresourcedirpath",

ADD COLUMN "marketplaceServiceAccount" varchar(1000),
ADD COLUMN "marketplacePrivateKey" varchar(1000);

update hostbasedsetting set "marketplaceServiceAccount"  = 'All:296775148492-a15rcjqpknvvd9iup11eh28otmhfjovp@developer.gserviceaccount.com', "marketplacePrivateKey" = 'All:/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/marketplace/f5717ba77753ea9cabcc645d59af8235ce1d48fd-privatekey.p12' where hostname = 'app.kpi.com';
update hostbasedsetting set "marketplaceServiceAccount" = 'All:660821534839-fjsc3ga6skjr66jh7h9c553ameeesagf@developer.gserviceaccount.com', "marketplacePrivateKey" = 'All:/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/3fd82cbda96d872b8e8a615002f9442df0445032-privatekey.p12' where hostname = 'aws.kpi.com';
