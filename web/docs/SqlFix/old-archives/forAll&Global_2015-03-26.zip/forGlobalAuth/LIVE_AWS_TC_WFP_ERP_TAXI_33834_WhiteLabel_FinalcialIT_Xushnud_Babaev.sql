-- app.financialit.net

INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyFinancialIT.jks', 'app.financialit.net', null,
            null, 'app.financialit.net', null, TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'Financial IT', '/customisation/financial+it/images/logo.png', 'financialit.net', 'info@financialit.net',
            'financialit', '+44 (0) 207 148 4285', 'Finnet Limited 15 Kings Avenue, Bromley BR1 4HN', '/customisation/financial+it/images/logo.png', 'Financial IT', 'financialitmail.properties',
            'Financial IT', false, 'en','fitmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null
    );






