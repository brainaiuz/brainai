update hostbasedsetting set paypalaccount='accounts@sahara.com' where hostname='aws.1erp.sa';
update hostbasedsetting set paypalaccount='accounts@sahara.com' where hostname='app.1erp.sa';







