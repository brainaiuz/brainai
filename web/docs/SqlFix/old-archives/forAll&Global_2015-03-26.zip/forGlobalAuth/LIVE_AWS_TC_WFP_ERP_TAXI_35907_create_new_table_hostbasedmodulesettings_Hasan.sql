CREATE TABLE hostbasedmodulesettings(
   id  SERIAL,
   code           varchar(50)     NOT NULL,
   host           varchar(50)     NOT NULL,
   PRIMARY KEY (id),
   UNIQUE (code, host)
);