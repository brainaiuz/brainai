update hostbasedsetting set   skype='mynfra', phone='+3113 82 00 966', issslsupported=true where hostname='app.mynfra.com';





