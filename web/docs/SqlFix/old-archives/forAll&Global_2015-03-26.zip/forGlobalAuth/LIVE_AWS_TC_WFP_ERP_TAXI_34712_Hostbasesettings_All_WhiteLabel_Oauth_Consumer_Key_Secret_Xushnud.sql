-- White Label: Smebu
update hostbasedsetting  SET
oauth2consumerkey = '749778792140-nqsrclhgcmll7eq3vn0svkra149okgea.apps.googleusercontent.com',
oauth2ConsumerSecret = 'UOSZvzJ1KcL7yYXarv9G0jWj' where hostname='app.smebu.com' or hostname='aws.smebu.com';

-- White Label: Appiev

update hostbasedsetting  SET
oauth2consumerkey = '357628383986-tc24vph1bgjmo83vbmdl1gahsjjcjo4v.apps.googleusercontent.com',
oauth2ConsumerSecret = 'vUVbJX3POChrkZ_gtKZT7CcI' where hostname='aws.appiev.com' or hostname='erp.appiev.com';

-- White Label: Telemanaged

update hostbasedsetting  SET
oauth2consumerkey = '72735153740-ft3up81nqgc3q3jt3tq68j01uu9tsiff.apps.googleusercontent.com',
oauth2ConsumerSecret = 'xwGchQEG-CXWaXTnBRKJr983' where hostname='app.telemanaged.com' or hostname='aws.telemanaged.com';

-- White Label: Ezyadmin

update hostbasedsetting  SET
oauth2consumerkey = '166781012488-er9g01q2o6mdl8dtaq9fb1r6occr1idu.apps.googleusercontent.com',
oauth2ConsumerSecret = 'bPdEAtFAXq7qQNw8wJrPoyoQ' where hostname='aws.ezyadmin.com' or hostname='app.ezyadmin.com';

-- White Label: Tjilo

update hostbasedsetting  SET
oauth2consumerkey = '634613886922-n3prkpkqtl9f3ib5s2qe4ftu621vkgq4.apps.googleusercontent.com',
oauth2ConsumerSecret = 'DbH0Q_qZKQmdKHtEy278a1Rq' where hostname='app.tjilo.com' or hostname='aws.tjilo.com';

-- White Label: Kah.sa

update hostbasedsetting  SET
oauth2consumerkey = '695132546770-5s92k3lr83gklk8h9fd6o160s3ar9k2v.apps.googleusercontent.com',
oauth2ConsumerSecret = 'RQGF84zEA0CDfLdRZLGT9rzY' where hostname='aws.kah.sa' or hostname='app.kah.sa';

-- White Label: Upshot

update hostbasedsetting  SET
oauth2consumerkey = '714095631975-pqpgnpi3mgb53rqjv5e21m80n70apr17.apps.googleusercontent.com',
oauth2ConsumerSecret = 'pqUTPs07rAojPEQMN4H1ccoM' where hostname='aws.upshot.ae' or hostname='erp.upshot.ae';

-- White Label: Iisholding

update hostbasedsetting  SET
oauth2consumerkey = '276762139360-an8c8p1pv2tbnb33tgiifmtb4gh92g4m.apps.googleusercontent.com',
oauth2ConsumerSecret = 'QS3iR_QZFSEO2USh4pu3-kOH' where hostname='aws.iisholding.com' or hostname='app.iisholding.com';

-- White Label: Omandatapark

update hostbasedsetting  SET
oauth2consumerkey = '58163972850-b7t2p5ophmhmqrd2nkekph0rhsgb1mtd.apps.googleusercontent.com',
oauth2ConsumerSecret = '7_w-XHhe9UiIa3xNBP5ID5BA' where hostname='aws.omandatapark.com' or hostname='app.omandatapark.com';

-- White Label: Technosolutions

update hostbasedsetting  SET
oauth2consumerkey = '62270394806-070939nk5iksr5goqerrk8eml2qioubq.apps.googleusercontent.com',
oauth2ConsumerSecret = 'jdjX8IPmntGTyUQoIAf70BtH' where hostname='erp.technosolutions.net' or hostname='aws.technosolutions.net';

-- White Label: Zairzaidi

update hostbasedsetting  SET
oauth2consumerkey = '848917456445-cm8etttk8euigiden6kd64eihbfhre6i.apps.googleusercontent.com',
oauth2ConsumerSecret = 'srLPBTSa_xZlAKbL6Mx4kYD5' where hostname='aws.zairzaidi.com' or hostname='erp.zairzaidi.com';

-- White Label:  Talibro

update hostbasedsetting  SET
oauth2consumerkey = '729588014745-vku872e4jov58qu1mmo1b0g9q18gna60.apps.googleusercontent.com',
oauth2ConsumerSecret = 'bt4ZiYH09GllwBM3hjSkreE6' where hostname='aws.talibro.net' or hostname='app.talibro.net';

-- White Label: Stefanodesigns

update hostbasedsetting  SET
oauth2consumerkey = '707196289229-dbr521p97boe2ks629t17vd5hvf9dbvi.apps.googleusercontent.com',
oauth2ConsumerSecret = 'aove5CrK9rLeZbcLEo5WtoS6' where hostname='erp.stefanodesigns.com' or hostname='aws.stefanodesigns.com';

-- White Label: Mynfra

update hostbasedsetting  SET
oauth2consumerkey = '631251453181-9590fmb9ec4702tbh5bvrkq6okr7m1h2.apps.googleusercontent.com',
oauth2ConsumerSecret = 'RrMD5Yur5gmpTvq4fnAxDbB6' where hostname='app.mynfra.com' or hostname='erp.mynfra.com';

-- White Label: Financial IT

update hostbasedsetting  SET
oauth2consumerkey = '202728787221-cc38o2nec03fieqm6vrabuukcdkgb7ci.apps.googleusercontent.com',
oauth2ConsumerSecret = 'MQmKXV0_qmLWywaZJYpvY22j' where hostname='app.financialit.net' or hostname='aws.financialit.net';

-- White Label: Kpi Russian

update hostbasedsetting  SET
oauth2consumerkey = '296775148492-uadu6outg03bh7v15i6nmtcskclcin9f.apps.googleusercontent.com',
oauth2ConsumerSecret = 'ccbXXCQf1h3yA8O717BYPmz_' where hostname='aws.kpi.com.ru' or hostname='app.kpi.com.ru';
