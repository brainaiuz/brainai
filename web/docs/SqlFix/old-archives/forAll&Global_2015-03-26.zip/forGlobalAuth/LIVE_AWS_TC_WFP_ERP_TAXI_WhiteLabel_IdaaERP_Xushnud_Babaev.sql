-- app.idaaerpservices.com

INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey,
            oauth2consumerkey,oauth2ConsumerSecret)
    VALUES (
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'app.idaaerpservices.com',
            null, 'app.idaaerpservices.com',  TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            'idaaerpservices.com', '/customisation/idaA+hr+cloud/images/logo.png', 'idaaerpservices.com', 'support@idaaerpservices.com',
            'idaaerpservices', '+971506536006' , 'Office 117, Building A3, Dubai World Central Free zone, Dubai, UAE', '/customisation/idaA+hr+cloud/images/logo.png', 'idaaerpservices', 'idaaerpemail.properties',
            'idaA ERP Services', false, 'en','idaaerpmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null,
            null, null
    );



-- aws.idaaerpservices.com
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey,
            oauth2consumerkey,oauth2ConsumerSecret)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'aws.idaaerpservices.com',
            null, 'aws.idaaerpservices.com',  TRUE, null,

            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            'idaaerpservices.com', '/customisation/idaA+hr+cloud/images/logo.png', 'idaaerpservices.com', 'support@idaaerpservices.com',
            'idaaerpservices', '+971506536006' , 'Office 117, Building A3, Dubai World Central Free zone, Dubai, UAE', '/customisation/idaA+hr+cloud/images/logo.png', 'idaaerpservices', 'idaaerpemail.properties',
            'idaA ERP Services', false, 'en','idaaerpmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null,
            null, null
    );
