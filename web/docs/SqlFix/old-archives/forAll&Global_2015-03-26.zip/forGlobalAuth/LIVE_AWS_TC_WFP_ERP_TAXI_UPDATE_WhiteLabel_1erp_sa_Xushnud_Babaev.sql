update hostbasedsetting set address='Saudi Arabia, Dammam, Prince Mohammed Street, Al-Dabal Commercial' where hostname='app.1erp.sa';
update hostbasedsetting set helphost='1erp.kpi.com' where hostname='app.1erp.sa';
update hostbasedsetting set linkedinapikey='75wwfj9yb61usn', linkedinsecret = 'iQaTEPKR4WanOQ3C' where hostname='app.1erp.sa';


update hostbasedsetting set address='Saudi Arabia, Dammam, Prince Mohammed Street, Al-Dabal Commercial' where hostname='aws.1erp.sa';
update hostbasedsetting set helphost='1erp.kpi.com' where hostname='aws.1erp.sa';
update hostbasedsetting set linkedinapikey='75gipics1ouxf9', linkedinsecret = 'mE1JkPFb1r1mAgz8' where hostname='aws.1erp.sa';







