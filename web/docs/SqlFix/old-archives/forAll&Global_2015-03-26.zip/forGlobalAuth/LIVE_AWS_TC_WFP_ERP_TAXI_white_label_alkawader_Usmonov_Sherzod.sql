insert into hostbasedsetting  ( emlfiledirectory, facebookappid, facebooksecret, hostname, isliveenv, linkedinapikey,
linkedinsecret, projectrootpath, productname, logoimage,helphost, email, skype, phone, address,pdflogo, defaultfromname,
mailparamsfilename, productcompanyname, issslsupported, defaultlocale,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode, wikiurl, recaptcha_pubkey, recaptcha_privkey,
massmailparamsfilename, oauth2consumerkey,oauth2consumersecret)
values('/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT/', null, null,'aws.alkawader.com',
false, null, null, '/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT',
'alkawader', '/customisation/alkawader/images/logo.png', 'alkawader.com', 'support@taqneen.com', 'taqneen.support', '(+966) 12 653 3334',
'International Economy Tower P.O. Box 54087, Jeddah 21514 Saudi Arabia', '/customisation/alkawader/images/logo.png',
'alkawader.com','alkawader.properties','Taqneen Solutions', false, 'en', 'sales@alkawader.com', 0.20, 7, 'workforce', 'USD', null, null,
null, 'alkawadermassmailler.properties', null, null);

insert into hostbasedsetting  (emlfiledirectory, facebookappid, facebooksecret, hostname, isliveenv, linkedinapikey, linkedinsecret, projectrootpath, productname, logoimage,helphost, email, skype, phone, address,pdflogo, defaultfromname, mailparamsfilename, productcompanyname, issslsupported,defaultlocale,
paypalaccount, vat, freetrialdays,defaulttheme, currencycode, wikiurl, recaptcha_pubkey, recaptcha_privkey,
massmailparamsfilename, oauth2consumerkey,oauth2consumersecret)
values('/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT/', null, null,'apps.alkawader.com',
false, null, null, '/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT',
'alkawader', '/customisation/alkawader/images/logo.png', 'alkawader.com', 'support@taqneen.com', 'taqneen.support', '(+966) 12 653 3334; <br /> (+966) 92 002 3235;',
'International Economy Tower P.O. Box 54087, Jeddah 21514 Saudi Arabia', '/customisation/alkawader/images/logo.png',
'alkawader.com','alkawader.properties','Taqneen Solutions', false, 'en', 'sales@alkawader.com', 0.20, 7, 'workforce', 'USD', null, null,
null, 'alkawadermassmailler.properties', null, null);


/* for aws */
update hostbasedsetting set phone = '(+966) 12 653 3334; <br /> (+966) 92 002 3235;' where hostname = 'aws.alkawader.com';

/* for aws */
update hostbasedsetting set freetrialdays = 14 where hostname = 'aws.alkawader.com';

/* for app */
update hostbasedsetting set freetrialdays = 14 where hostname = 'apps.alkawader.com';