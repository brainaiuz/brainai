-- Table: module_price

-- DROP TABLE module_price;

CREATE TABLE module_price
(
  id integer,
  price numeric,
  code character varying,
  hostname character varying
)
WITH (
  OIDS=FALSE
);
ALTER TABLE module_price
  OWNER TO wftauth;
GRANT ALL ON TABLE module_price TO wftauth;


--Pricing packages
insert into pricing_package (id, hostname, packagename, price) values ((select count(id)+1 from pricing_package), 'app.kpi.com', 'PP_MINI', 299);
insert into pricing_package (id, hostname, packagename, price) values ((select count(*)+1 from pricing_package), 'app.kpi.com', 'PP_SMALL', 777);
insert into pricing_package (id, hostname, packagename, price) values ((select count(*)+1 from pricing_package), 'app.kpi.com', 'PP_STANDART', 1755);
insert into pricing_package (id, hostname, packagename, price) values ((select count(*)+1 from pricing_package), 'app.kpi.com', 'PP_SILVER', 3555);
insert into pricing_package (id, hostname, packagename, price) values ((select count(*)+1 from pricing_package), 'app.kpi.com', 'PP_ENTERPRISE2', 6555);

--Support packages
insert into support_package (id, hostname, packagename, price) values ((select max(id)+1 from support_package), 'app.kpi.com', 'SP_CONTRACTOR', 599);
insert into support_package (id, hostname, packagename, price) values ((select max(id)+1 from support_package), 'app.kpi.com', 'SP_SMALL_BUSINESS', 799);
insert into support_package (id, hostname, packagename, price) values ((select max(id)+1 from support_package), 'app.kpi.com', 'SP_PROFESSIONAL', 1550);
insert into support_package (id, hostname, packagename, price) values ((select max(id)+1 from support_package), 'app.kpi.com', 'SP_ENTERPRISE', 2995);

--Module price
insert into module_price (id, code, hostname, price) values (1, 'PM', 'app.kpi.com', 9.99);
insert into module_price (id, code, hostname, price) values (2, 'HRMS_MODULE', 'app.kpi.com', 9.99);
insert into module_price (id, code, hostname, price) values (3, 'CRM_MODULE', 'app.kpi.com', 9.99);
insert into module_price (id, code, hostname, price) values (4, 'ACCOUNTING_MODULE', 'app.kpi.com', 9.99);
update discount set onemonth=0.00, threemonth=0.10, sixmonth=0.15, twentymonth=0.20 where hostname='app.kpi.com';
