ALTER TABLE hostbasedsetting  ADD COLUMN uploaddir character varying(1000);
ALTER TABLE hostbasedsetting  ADD COLUMN uploadtype character varying(255);
update hostbasedsetting set uploadtype = 'AMAZON';
update hostbasedsetting set uploadtype = 'LOCAL' where hostname = 'aws.kpi.com';
update hostbasedsetting set uploaddir = '/home/lochin/upload' where hostname = 'aws.kpi.com';

