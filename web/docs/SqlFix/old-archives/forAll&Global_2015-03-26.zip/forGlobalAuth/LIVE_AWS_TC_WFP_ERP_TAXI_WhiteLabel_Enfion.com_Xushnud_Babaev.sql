-- enfion.com
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey,
            oauth2consumerkey,oauth2ConsumerSecret)
    VALUES (
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'enfion.com',
            null, 'app.enfion.com',  TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            'enfion', '/customisation/enfion/images/logo.png', 'enfion.com', 'support@enfion.com',
            null, '+62 21 3309 7200 , +62 31 77888577' , 'UOB Plaza 22nd Floor Jl. MH Thamrin No 10 Jakarta 10230, Indonesia', '/customisation/enfion/images/logo.png', 'enfion.com', 'enfionemail.properties',
            'PT. Eikon Technology', false, 'en','enfionmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null,
            '180085282678-tas6aj4mc21ndhvs3vntmn294o1j0e8e.apps.googleusercontent.com','ak6stPndXnZ-wflNqgq-_MFP'
    );



-- enfion.com
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey,
            oauth2consumerkey,oauth2ConsumerSecret)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'aws.enfion.com',
            null, 'aws.enfion.com',  TRUE, null,

            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            'enfion', '/customisation/enfion/images/logo.png', 'enfion.com', 'support@enfion.com',
            null, '+62 21 3309 7200 , +62 31 77888577' , 'UOB Plaza 22nd Floor Jl. MH Thamrin No 10 Jakarta 10230, Indonesia;  Plaza Segi 8 Block A-873 Jl. Pattimura, Surabaya Jawa Timur 60188, Indonesia ', '/customisation/enfion/images/logo.png', 'enfion.com', 'enfionemail.properties',
            'PT. Eikon Technology', false, 'en','enfionmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null,
            '180085282678-tas6aj4mc21ndhvs3vntmn294o1j0e8e.apps.googleusercontent.com','ak6stPndXnZ-wflNqgq-_MFP'
    );
