ALTER TABLE hostbasedsetting ADD COLUMN oauth2ConsumerKey character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN oauth2ConsumerSecret character varying(1000);




update hostbasedsetting  SET oauth2consumerkey = '296775148492-uadu6outg03bh7v15i6nmtcskclcin9f.apps.googleusercontent.com' where hostname='aws.kpi.com';
update hostbasedsetting  SET oauth2ConsumerSecret = 'ccbXXCQf1h3yA8O717BYPmz_' where hostname='aws.kpi.com';


update hostbasedsetting  SET oauth2consumerkey = '296775148492-uadu6outg03bh7v15i6nmtcskclcin9f.apps.googleusercontent.com' where hostname='app.kpi.com';
update hostbasedsetting  SET oauth2ConsumerSecret = 'ccbXXCQf1h3yA8O717BYPmz_' where hostname='app.kpi.com';