ALTER TABLE hostbasedsetting ADD COLUMN customMailTemplate boolean;

update hostbasedsetting  set customMailTemplate=true where productname='GoodSystems';