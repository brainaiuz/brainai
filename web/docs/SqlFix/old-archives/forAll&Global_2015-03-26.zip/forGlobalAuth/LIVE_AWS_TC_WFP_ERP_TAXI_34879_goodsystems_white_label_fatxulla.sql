insert into hostbasedsetting  ( emlfiledirectory, facebookappid, facebooksecret, hostname, isliveenv, linkedinapikey, linkedinsecret, projectrootpath, productname, logoimage,helphost, email, skype, phone, address,pdflogo, defaultfromname, mailparamsfilename, productcompanyname, issslsupported,defaultlocale,
paypalaccount, vat, freetrialdays,defaulttheme, currencycode, wikiurl, recaptcha_pubkey, recaptcha_privkey,
massmailparamsfilename, oauth2consumerkey,oauth2consumersecret)
values('/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT/', null,null,'aws.goodsystems.com.au',
false, null, null, '/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT',
'GoodSystems', '/customisation/goodsystems/images/logo.png', 'goodsystems.com.au', 'support@goodsystems.com.au', null, '(+965) 2227 1694',
'Shayma Tower, 10th Floor Omar Ibn Al Khattab Street Murgab, Block 3, Plot 8 A + 8 B P.O Box 5819 Safat Kuwait City, 13059', '/customisation/goodsystems/images/logo.png',
'goodsystems.com.au','goodsystemsemail.properties','Good Systems Pty Ltd', false, 'en', 'sales@goodsystems.com.au', 0.20, 7, 'workforce', 'USD', null, '6Lc4jtoSAAAAAD1hElrni1jQJRU4TlLI16MZopcR',
'6Lc4jtoSAAAAAOFKaW0ZUdFmego_N_WmCP5267Ex', 'goodsystemsmassmailler.properties', '964093635894-vdu8u95ghn1rs6nli4pcpncqts6fhu4a.apps.googleusercontent.com','YBaAtw7HVPoj0ylMbv0nUoPP');

insert into hostbasedsetting  (emlfiledirectory, facebookappid, facebooksecret, hostname, isliveenv, linkedinapikey, linkedinsecret, projectrootpath, productname, logoimage,helphost, email, skype, phone, address,pdflogo, defaultfromname, mailparamsfilename, productcompanyname, issslsupported,defaultlocale,
paypalaccount, vat, freetrialdays,defaulttheme, currencycode, wikiurl, recaptcha_pubkey, recaptcha_privkey,
massmailparamsfilename, oauth2consumerkey,oauth2consumersecret)
values('/usr/share/tomcat6/webapps/projects/app.workforcetrack.com/ROOT/', null,null,'app.goodsystems.com.au',
false, null, null, '/usr/share/tomcat6/webapps/projects/app.workforcetrack.com/ROOT',
 'GoodSystems', '/customisation/goodsystems/images/logo.png', 'goodsystems.com.au', 'support@goodsystems.com.au', null, '(+965) 2227 1694',
'Shayma Tower, 10th Floor Omar Ibn Al Khattab Street Murgab, Block 3, Plot 8 A + 8 B P.O Box 5819 Safat Kuwait City, 13059', '/customisation/goodsystems/images/logo.png',
'goodsystems.com.au','goodsystemsemail.properties','Good Systems Pty Ltd', false, 'en', 'sales@goodsystems.com.au', 0.20, 7, 'workforce', 'USD', null, '6Lc4jtoSAAAAAD1hElrni1jQJRU4TlLI16MZopcR',
'6Lc4jtoSAAAAAOFKaW0ZUdFmego_N_WmCP5267Ex', 'goodsystemsmassmailler.properties', '964093635894-vdu8u95ghn1rs6nli4pcpncqts6fhu4a.apps.googleusercontent.com','YBaAtw7HVPoj0ylMbv0nUoPP');
