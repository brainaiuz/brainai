-- app.1erp.sa

INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey,
            oauth2consumerkey,oauth2ConsumerSecret)
    VALUES (
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'app.1erp.sa',
            null, 'app.1erp.sa',  TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '1erp.sa', '/customisation/1erp.sa/images/logo.png', '1erp.sa', 'support@1erp.sa',
            'sahara.com', '+966138322299' , 'Saudi Arabia', '/customisation/1erp.sa/images/logo.png', '1erp.sa', '1erpsaemail.properties',
            'Sahara Net', false, 'en','1erpsamassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null,
            '85483249518.apps.googleusercontent.com','14C9DwIJIYq68rQ17_wvnT5r'
    );



-- aws.1erp.sa
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey,
            oauth2consumerkey,oauth2ConsumerSecret)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'aws.1erp.sa',
            null, 'aws.1erp.sa',  TRUE, null,

            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '1erp.sa', '/customisation/1erp.sa/images/logo.png', '1erp.sa', 'support@1erp.sa',
            'sahara.com', '+966138322299' , 'Saudi Arabia', '/customisation/1erp.sa/images/logo.png', '1erp.sa', '1erpsaemail.properties',
            'Sahara Net', false, 'en','1erpsamassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null,
            '85483249518.apps.googleusercontent.com','14C9DwIJIYq68rQ17_wvnT5r'
    );
