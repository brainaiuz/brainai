-- aws.technosolutions.net
INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateAPPTechnosolutions.jks', 'aws.technosolutions.net', null,
            'S-tjFYLJ5_YRDN7Y0_CLUo5N', 'aws.technosolutions.net', null, TRUE, null,

            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'Technosolutions ERP System', '/customisation/technosolutions+erp+system/images/logo.png', 'technosolutions.net', 'support@technosolutions.net',
            'technosolutions.net', '966508326157' , 'P.O.Box 2073, Jeddah 21451, Saudi Arabia', '/customisation/technosolutions+erp+system/images/logo.png', 'technosolutions.net', 'technosolutionsmail.properties',
            'Technosolutions ERP System', false, 'en','technosolutionsmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null
    );



-- erp.technosolutions.net
INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateAWSTechnosolutions.jks', 'erp.technosolutions.net', null,
            'ELsg0GQVNIdGVG6a_rjgzKAP', 'erp.technosolutions.net', null, TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'Technosolutions ERP System', '/customisation/technosolutions+erp+system/images/logo.png', 'technosolutions.net', 'support@technosolutions.net',
            'technosolutions.net', '966508326157' , 'P.O.Box 2073, Jeddah 21451, Saudi Arabia', '/customisation/technosolutions+erp+system/images/logo.png', 'technosolutions.net', 'technosolutionsmail.properties',
            'Technosolutions ERP System', false, 'en','technosolutionsmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null
    );






