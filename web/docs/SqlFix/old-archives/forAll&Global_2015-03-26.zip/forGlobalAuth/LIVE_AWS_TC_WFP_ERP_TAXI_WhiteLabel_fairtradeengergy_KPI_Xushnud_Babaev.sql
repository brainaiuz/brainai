-- fairtradeengergy.kpi.com
INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateFairtradeengergy.jks', 'fairtradeengergy.kpi.com', null,
            null, 'fairtradeengergy.kpi.com', null, TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'kpi.com', '/customisation/kpi.com/images/logo.png', 'kpi.com', 'support@kpi.com',
            'kpi.com', '+44 (0) 843 320 6551 (UK); +1-888-771-0476 (US)' , 'Kings Avenue Bromley BR1 4HN - UK', '/customisation/kpi.com/images/logo.png', 'kpi.com', 'kpimail.properties',
            'Finnet Limited', false, 'en','massmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null
    );

