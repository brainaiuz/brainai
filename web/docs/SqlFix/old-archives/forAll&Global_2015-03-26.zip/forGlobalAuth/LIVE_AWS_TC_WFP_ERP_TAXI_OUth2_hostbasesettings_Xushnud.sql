
update hostbasedsetting  SET oauth2consumerkey = '872820823402-v140lnm6kfvmkoksc87af3fjgovsbdn1.apps.googleusercontent.com' where hostname='aws.idaaerpservices.com';
update hostbasedsetting  SET oauth2ConsumerSecret = 'pBPasfillmbFXHLg7ar9kg2g' where hostname='aws.idaaerpservices.com';



update hostbasedsetting  SET oauth2consumerkey = '872820823402-v140lnm6kfvmkoksc87af3fjgovsbdn1.apps.googleusercontent.com' where hostname='app.idaaerpservices.com';
update hostbasedsetting  SET oauth2ConsumerSecret = 'pBPasfillmbFXHLg7ar9kg2g' where hostname='app.idaaerpservices.com';


update hostbasedsetting  SET phone = '+44 207 148 4280 (UK); +1-888-771-0476 (US)' where hostname='app.kpi.com';
update hostbasedsetting  SET phone = '+44 207 148 4280 (UK); +1-888-771-0476 (US)' where hostname='aws.kpi.com';




