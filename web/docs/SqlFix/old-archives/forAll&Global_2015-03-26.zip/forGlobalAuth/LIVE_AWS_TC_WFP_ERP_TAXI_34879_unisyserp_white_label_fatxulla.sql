insert into hostbasedsetting  (chatdomain, emlfiledirectory, facebookappid, facebooksecret, hostname, isliveenv, linkedinapikey, linkedinsecret, projectrootpath,
uploadresourcedirpath, productname, logoimage,helphost, email, skype, phone, address,pdflogo, defaultfromname, mailparamsfilename, productcompanyname, issslsupported,defaultlocale,
paypalaccount, vat, freetrialdays,defaulttheme, currencycode, wikiurl, recaptcha_pubkey, recaptcha_privkey,
massmailparamsfilename, oauth2consumerkey,oauth2consumersecret)
values('62.252.53.33', '/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT/', '226646624206512','2c1547e59084efdeb7c9fbebf2cfb68f','aws.unisyserp.com',
false, '758xez15pb5xnc', 'ymX7xGzs6CHSEKng', '/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT',
'/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'UnisysERP', '/customisation/unisyserp.com/images/logo.png', 'unisyserp.com', 'support@unisysint.com', null, '(+965) 2227 1694',
'Shayma Tower, 10th Floor Omar Ibn Al Khattab Street Murgab, Block 3, Plot 8 A + 8 B P.O Box 5819 Safat Kuwait City, 13059', '/customisation/kpi.com/images/kpilogo.png',
'unisyserp.com','unisyserpemail.properties','Unisys International', false, 'en', 'sales@vipworkspace.com', 0.20, 7, 'workforce', 'USD', null, '6Lc4jtoSAAAAAD1hElrni1jQJRU4TlLI16MZopcR',
'6Lc4jtoSAAAAAOFKaW0ZUdFmego_N_WmCP5267Ex', 'unisyserpmassmailler.properties', '649389145624-dou55o2ni0ef5k51d7v387bo5ido9e4f.apps.googleusercontent.com','lyOEACVMFz32axDz0PnuKfBL');

insert into hostbasedsetting  (chatdomain, emlfiledirectory, facebookappid, facebooksecret, hostname, isliveenv, linkedinapikey, linkedinsecret, projectrootpath,
uploadresourcedirpath, productname, logoimage,helphost, email, skype, phone, address,pdflogo, defaultfromname, mailparamsfilename, productcompanyname, issslsupported,defaultlocale,
paypalaccount, vat, freetrialdays,defaulttheme, currencycode, wikiurl, recaptcha_pubkey, recaptcha_privkey,
massmailparamsfilename, oauth2consumerkey,oauth2consumersecret)
values('62.252.53.33', '/usr/share/tomcat6/webapps/projects/app.workforcetrack.com/ROOT/', '213790835496267','6e10f3d87c48e6fbdac92eb2e393a1a5','app.unisyserp.com',
false, '758xez15pb5xnc', 'ymX7xGzs6CHSEKng', '/usr/share/tomcat6/webapps/projects/app.workforcetrack.com/ROOT',
'/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'UnisysERP', '/customisation/unisyserp.com/images/logo.png', 'unisyserp.com', 'support@unisysint.com', null, '(+965) 2227 1694',
'Shayma Tower, 10th Floor Omar Ibn Al Khattab Street Murgab, Block 3, Plot 8 A + 8 B P.O Box 5819 Safat Kuwait City, 13059', '/customisation/kpi.com/images/kpilogo.png',
'unisyserp.com','unisyserpemail.properties','Unisys International', false, 'en', 'sales@vipworkspace.com', 0.20, 7, 'workforce', 'USD', null, '6Lc4jtoSAAAAAD1hElrni1jQJRU4TlLI16MZopcR',
'6Lc4jtoSAAAAAOFKaW0ZUdFmego_N_WmCP5267Ex', 'unisyserpmassmailler.properties', '649389145624-dou55o2ni0ef5k51d7v387bo5ido9e4f.apps.googleusercontent.com','lyOEACVMFz32axDz0PnuKfBL');