CREATE TABLE blocked
(
  username character varying,
  block_time timestamp without time zone DEFAULT now()
)
WITH (
OIDS=FALSE
);