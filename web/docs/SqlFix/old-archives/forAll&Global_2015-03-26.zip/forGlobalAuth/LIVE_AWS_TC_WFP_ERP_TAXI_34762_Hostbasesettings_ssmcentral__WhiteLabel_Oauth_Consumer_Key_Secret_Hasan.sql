-- White Label: Smebu
update hostbasedsetting  SET
oauth2consumerkey = '906853219875-4jmlbon16imst3rek2mjvtps1005vdbu.apps.googleusercontent.com',
oauth2ConsumerSecret = 'uDj90-IDcrWLQxrtwRvnKmXl' where hostname='crm.ssmcentral.com';