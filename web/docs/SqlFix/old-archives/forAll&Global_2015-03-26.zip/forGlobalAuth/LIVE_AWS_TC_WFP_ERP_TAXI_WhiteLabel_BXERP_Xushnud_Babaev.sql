-- app.b2xcg.com
INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,

            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale, massmailparamsfilename,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateB2xcg.jks', 'app.b2xcg.com', null,
            null, 'app.b2xcg.com', null, TRUE, null,

            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'b2xERP', '/customisation/b2xerp/images/logo.png', 'b2xerp.com', 'support@b2xerp.com',
            'b2xerp', '567.455.8500' , '701 Jefferson Avenue, Toledo, Ohio 43560', '/customisation/b2xerp/images/logo.png', 'b2xERP', 'bxcgmail.properties',
            'b2xERP, Inc.', false, 'en','bxcgmassmailler.properties',
            'sales@workforcetrack.com', 0.20, 14, 'workforce', 'USD',
            null, null, null
    );




