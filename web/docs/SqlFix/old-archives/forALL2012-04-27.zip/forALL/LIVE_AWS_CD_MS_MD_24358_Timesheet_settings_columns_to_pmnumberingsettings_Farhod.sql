--'Schema update'dan keyin urilishi kerak
UPDATE "anv".pmnumberingsettings SET automatic = false;
UPDATE "anv".pmnumberingsettings SET automaticapproval = false;