/*1. Bu bir marta public schemaga patch qilinadi*/
INSERT INTO accounttemplate(code,codestring,key,name,enablepayments,showinexpense,accounttypeid) VALUES('4997','4997','4997','Gain on disposal',false,false,13);
INSERT INTO accounttemplate(code,codestring,key,name,enablepayments,showinexpense,accounttypeid) VALUES('9997','9997','9997','Loss on disposal',false,false,11);

/*2. Bu hamma companyga patch qilinadi*/
INSERT INTO "anv".account(accountcode,codestring,key,name,accounttypeid, balance,enablepayments,showinexpense) VALUES('4997','4997','4997','Gain on disposal',13,0,false,false);
INSERT INTO "anv".account(accountcode,codestring,key,name,accounttypeid, balance,enablepayments,showinexpense) VALUES('9997','9997','9997','Loss on disposal',11,0,false,false);