--for zero schema

ALTER TABLE "0".timesheet ALTER COLUMN managercomment TYPE VARCHAR(1000);

--for all schema

ALTER TABLE "anv".timesheet ALTER COLUMN managercomment TYPE VARCHAR(1000);