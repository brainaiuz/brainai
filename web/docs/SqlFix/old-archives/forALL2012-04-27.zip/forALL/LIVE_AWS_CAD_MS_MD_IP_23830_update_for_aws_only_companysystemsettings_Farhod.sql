--App ga urish shart emas
ALTER TABLE companysystemsettings ADD COLUMN oldhost character varying(255);
UPDATE companysystemsettings SET oldhost = host,  host = 'aws.kpi.com' where host = 'aws.workforcetrack.com';