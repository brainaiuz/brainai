--Run after schema update
update "0".skill set code = upper(replace(replace(replace(replace(name, '-', '_'), '/', '_'), ' ', '_'), '__', '_'));
update "0".skillgroup set code = upper(replace(replace(name, '/', '_'), ' ', '_'));
