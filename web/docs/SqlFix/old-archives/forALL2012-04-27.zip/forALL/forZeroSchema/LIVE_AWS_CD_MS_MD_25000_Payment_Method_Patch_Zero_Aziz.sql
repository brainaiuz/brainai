update "0".paymentmethod set code = 'CASH', sortorder = 0 where name = 'Cash';
update "0".paymentmethod set code = 'CREDIT_CARD', sortorder = 1 where name = 'Credit Card';
update "0".paymentmethod set code = 'DEBIT_CARD', sortorder = 2 where name = 'Debit Card';
update "0".paymentmethod set code = 'WIRE_TRANSFER', sortorder = 3 where name = 'Wire Transfer';
update "0".paymentmethod set code = 'CHEQUE', sortorder = 4 where name = 'Cheque';
