update "0".emailtemplate set messagehtml = '
<p>Dear ${firstname}  ${lastname},</p> <p>
                This is to confirm and thank you for the payment received on ${startdate}
                for the invoice No.: ${number} The receipt for this payment is attached for your attention.</p> <p>
                Thank you for your business and please contact us at <b><u> ${email}
                </u></b> should you have any questions regarding this invoice statement.</p>
                <p>Sincerely yours,</br>Accounting Department,</br><b> ${companyname} </b></p>'
                where (name = 'Default Receipt' and categoryid = (select id from reference where code='RECEIPT_CATEGORY') and isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' )