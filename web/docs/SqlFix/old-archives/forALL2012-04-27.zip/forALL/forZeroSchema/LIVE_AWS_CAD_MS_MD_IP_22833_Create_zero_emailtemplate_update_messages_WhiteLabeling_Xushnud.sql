-- Client activation new User
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname}, </p>
            <p>We are pleased  to inform you that ${managername} has created a client account for you at
            ${productName} (<a href="${loginpagelink}"> ${loginpagelink} </a>)</p>
            <p>${productName} is a new and exciting online business tool that  allows you to undertake
            the following tasks with less effort and more control: Project and Task Management, Workforce Management,
             Performance Appraisal, Time Tracking and Collaboration Tool.
            </p>
            <p>
            You can access ${productName}, which is web based, and review your Projects performance and development,
             view your Invoices, raise issues as well as receive alerts and reports on the Project Development process.
             Because it is web based it is easy to access anytime and assists you in keeping on top of your Project.
            </p>
            <p>Our support team is ready to take your calls and help you in any way.</P>
            <p>In order to activate your account please <a href="${activationlink}">click here</a>
            (or copy/paste the following address into your web browser: ${activationlink} )</p>

            <p> Thank you for your interest in our product. We are looking forward to working with you and helping you
             to discover the full potential of ${productName}. </p>
            <p><br />
            ${productName} support team<br />
            ${companyInfo} '
     where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
     categoryid = (SELECT id FROM "0".reference WHERE code='CLIENT_ACTIVATION_NEW_USER_CATEGORY') ;


-- Client activation existing User
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname}, </p>
            <p>We are pleased  to inform you that ${managername} has created a client account for you at
            ${productName} (<a href="${loginpagelink}"> ${loginpagelink}</a>)</p>
            <p>
            You can login to your new account with the same username and password you already have in the system.
            </p>
            <p>
            You can access ${productName}, which is web based, and review your Projects performance and development,
            view your Invoices, raise issues as well as receive alerts and reports on the Project Development process.
            Because it is web based it is easy to access anytime and assists you in keeping on top of your Project.
            </p>
            <p>Our support team is ready to take your calls and help you in any way.</p>

            <p> Thank you for your interest in our product. We are looking forward to working with you and helping
            you to discover the full potential of ${productName}. </p>
            <p><br />
            ${productName} support team<br />
            ${companyinfo} '
     where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
     categoryid = (SELECT id FROM "0".reference WHERE code='CLIENT_ACTIVATION_EXISTING_USER_CATEGORY') ;


-- Employee activation new User
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname}, </p>
            <p>Dear ${firstname} ${lastname}</a><br />
            <p>We would like to inform you that $admin.firstName ${managername} has created a user account for you
            at ${productName} (${loginpagelink}).</p>
            <p>
            You can login to your new account with the same username and password you already have in the system.
            </p>
            <p>Thank you for your interest in our product.</p>
            <p>${productName} support team <br />
            ${companyInfo} '
        where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
        categoryid = (SELECT id FROM "0".reference WHERE code='EMPLOYEE_ACTIVATION_EXISTING_USER_CATEGORY') ;


-- Employee activation existing User
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname}</a><br />
            <p>We would like to inform you that ${managername} has created a user account for you
            at ${productName} (${loginpagelink}).</p>
            <p>In order to activate your account please <a href="${activationlink}">click here</a><br />
            (or copy/paste and go to following link in your  web browser: ${activationlink} </p>

            <p>Thank you for your interest in our product.</p>
            <p>${productName}  support team <br />
            ${companyInfo} '
        where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
        categoryid = (SELECT id FROM "0".reference WHERE code='EMPLOYEE_ACTIVATION_NEW_USER_CATEGORY') ;



-- User account confirmation
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname}</p><br/>
            <p>We would like to inform you that your account at ${activationlink} has been activated.</p>
            <p>Your user name is ${username}.</p>
            <p>Your password is ${password}.</p>
            <p>In order to access your account please <a href="${loginpagelink}">click here</a><br/>
            (or copy/paste and go to following link in your web browser: ${loginpagelink}</p>
            <p>Thank you for your interest in our product.</p>
            <p>${productName} support team <br />
            ${companyInfo} '
        where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
        categoryid = (SELECT id FROM "0".reference WHERE code='USER_ACCOUNT_CONFIRMATION_CATEGORY') ;





-- Employee activated by Manager
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname},</p><br/>
            <p>${productName} account for ${companyname} has been created, and your personal account details are as follows:</p>
            <p>Username: ${username}<br />  Password: ${password}</p>
            <p>${firstname}, please keep this information safe and feel free to contact us if you have any questions.</p>
            <p>In order to access your account please <a href="${loginpagelink}">click here</a><br/>
            (or copy/paste and go to following link in your web browser: ${loginpagelink}</p>
            <p>${productName} support team <br />
            ${companyInfo} '
        where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
        categoryid = (SELECT id FROM "0".reference WHERE code='EMPLOYEE_ACTIVATED_BY_MANAGER_CATEGORY') ;



-- Project add category
update "0".emailtemplate set messagehtml = '
            <p>Dear ${firstname} ${lastname},</p>
            <p>Please be advised that ${creator} registered ${projectname} Project on ${date}.<br />
            Project details are below:</p><p>Project Manager: ${managername}<br />
            <p>Click <a href="${url}" title="View project">here</a>  to view the project</p>
            <p>* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: </p>
            <p><span style="color: #0033FF">${url}</span></p>
            <p>${productName} support team <br />
            ${companyInfo} '
        where isCompanyEmailTemplate = 'DEFAULT_EMAIL_TEMPLATE' AND
        categoryid = (SELECT id FROM "0".reference WHERE code='PROJECT_ADD_CATEGORY') ;




