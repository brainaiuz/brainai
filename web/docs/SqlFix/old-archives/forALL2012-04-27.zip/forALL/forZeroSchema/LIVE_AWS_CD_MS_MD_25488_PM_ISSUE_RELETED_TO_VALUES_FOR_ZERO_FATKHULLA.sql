--Ketma ketlik buzilmasin
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('RELATED_TO_ISSUE',  'ISSUE_TYPES', null);
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('TASK_ISSUE',  'Task', (select id from "0".reference  where code = 'RELATED_TO_ISSUE'));
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('PROJECT_ISSUE',  'Project', (select id from "0".reference  where code = 'RELATED_TO_ISSUE'));
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('EMPLOYEE_ISSUE',  'Employee', (select id from "0".reference  where code = 'RELATED_TO_ISSUE'));
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('DEPARTMENT_ISSUE',  'Department', (select id from "0".reference  where code = 'RELATED_TO_ISSUE'));
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('CLIENT_CUSTOMER_ISSUE',  'Client/Customer', (select id from "0".reference  where code = 'RELATED_TO_ISSUE'));
INSERT INTO "0".reference(code,  "name", parentid) VALUES ('SUPPLIER_ISSUE',  'Supplier', (select id from "0".reference  where code = 'RELATED_TO_ISSUE'));
