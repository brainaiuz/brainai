--Run after schema update
update "0".emailtemplate set name = trim(name) where isdefault is true;
update "0".emailtemplate set code = upper(replace(replace(replace(replace(replace(name, '-', '_'), ')', '_'), '(', '_'), ' ', '_'), '__', '_')) where isdefault is true;
update "0".emailtemplate set locale = 'en' where isdefault is true;