/*ADD EMAIL RELATIONSHIP*/

INSERT INTO "0".relationship (code, entityname, entrytype, name, rank, relationtype)
      VALUES ('EMAIL_OWNER', 'EMAIL', 2, 'Owner of useremail', 1, 'DIRECT');
INSERT INTO "0".relationship (code, entityname, entrytype, name, rank, relationtype)
      VALUES ('EMAIL_VIEWER', 'EMAIL', 2, 'Viewer of useremail', 2, 'DIRECT');

