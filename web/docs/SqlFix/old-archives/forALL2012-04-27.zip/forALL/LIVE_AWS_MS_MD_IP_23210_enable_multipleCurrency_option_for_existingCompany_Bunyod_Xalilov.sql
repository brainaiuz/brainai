
/* bu patch schemaUpdate dan keyin  uriladi */

update financialsettings set enable_multiple_currency = true;
