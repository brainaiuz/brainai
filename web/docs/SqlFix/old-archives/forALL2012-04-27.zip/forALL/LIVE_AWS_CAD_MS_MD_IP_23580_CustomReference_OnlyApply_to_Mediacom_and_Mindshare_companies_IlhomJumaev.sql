-- apply to Mediacom and Mindshare companies;

insert into "3465".reference(code,name,parentid) VALUES('TRAVEL_REQUEST_LEAVE','Travel Request',(select id from "3465".reference where code='_REASON'));
insert into "8687".reference(code,name,parentid) VALUES('TRAVEL_REQUEST_LEAVE','Travel Request',(select id from "8687".reference where code='_REASON'));