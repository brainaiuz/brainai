-- targetUser da employee ni LazyarizableException tashlagani uchun myUser ga o`zgartirildi
ALTER TABLE "anv".reportingemployee DROP CONSTRAINT if exists "fkd4399edc7fa9a837";