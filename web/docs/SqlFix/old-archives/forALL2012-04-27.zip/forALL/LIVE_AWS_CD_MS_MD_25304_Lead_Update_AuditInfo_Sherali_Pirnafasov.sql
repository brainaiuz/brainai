update "anv".crmContact set createdby_id=owner where createdby_id is null;
update "anv".crmContact set modifiedby_id=owner where modifiedby_id is null;
update "anv".crmContact set modificationdate=modifiedDate where modifiedDate is not null;
update "anv".crmContact set creationdate=creationTime where creationTime is not null;

ALTER TABLE "anv".crmContact DROP COLUMN modifiedDate;
ALTER TABLE "anv".crmContact DROP COLUMN creationTime;