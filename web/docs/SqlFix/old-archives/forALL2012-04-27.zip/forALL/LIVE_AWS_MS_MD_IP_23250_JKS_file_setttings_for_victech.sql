--for Globalauth
UPDATE hostbasedsetting SET googleconsumerkey = 'login.victechweb.com', googleappsconsumersecret = 'NPMH9v7z75F3Tq9Xo8TnFZ3l',
googleauthsubprivatekeypath = '/mnt/webapps/projects/aws.workforcetrack.com/ROOT/customisation/victech/GoogleAuthSubPrivateKeyVicTech.jks'
WHERE hostname = 'login.victechweb.com';