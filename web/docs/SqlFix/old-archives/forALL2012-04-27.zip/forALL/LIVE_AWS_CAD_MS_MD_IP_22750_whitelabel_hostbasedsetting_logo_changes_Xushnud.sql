--EzyAdmin
update hostbasedsetting set logoimage='/customisation/ezyadmin/images/ezyadminlogo.png' where hostname like ('%ezyadmin%');
update hostbasedsetting set pdflogo='/customisation/ezyadmin/images/ezyadminlogo.png' where hostname like ('%ezyadmin%');