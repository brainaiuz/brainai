/*Bu patch faqat bir marta publicga patch qilinadi*/

/*1.*/
DELETE FROM defaultlayout where formid='PRODUCT';


INSERT INTO defaultlayout(formid,layout) VALUES('PRODUCT', '<div>
    <div class="productcontent">
        <div class="contentScroll">
            <table cellspacing="0" cellpadding="0" class="bindContent">
                <tr>
                    <td class="mainBar">
                        <div class="invoice-block">
                            <div class="sect clear group" style="margin-bottom: 20px">
                                <div class="invoice-title">
                                    $$label:title$$
                                </div>
                            </div>
                            <div class="sect group">
                                <div class="lineItem">
                                    $$label:producttype$$
                                    $$input:producttype$$
                                </div>
                                <div class="lineItem">
                                    $$label:productname$$
                                    $$input:productname$$
                                </div>
                                <div class="lineItem">
                                    $$label:number$$
                                    $$input:number$$
                                </div>
                                <div class="lineItem">
                                    $$label:category$$
                                    $$input:category$$
                                </div>
                                <div class="lineItem">
                                    $$label:tax$$
                                    $$input:tax$$
                                </div>
                            </div>
                            <div class="sect clear group">
                                $$label:description$$
                                $$input:description$$
                            </div>
                            <div class="sect clear group">
                                $$input:inventory$$
                                $$input:noninventory$$
                            </div>
                            <div class="sect clear group" style="margin-top: 10px;">
                                $$input:moreoptionslink$$
                                $$input:moreoptionspanel$$
                            </div>
                            <div class="sect clear group">
                                $$input:inventorywarehouse$$
                                $$input:productkit$$
                                $$input:rentaloptions$$
                                $$input:advancedoptions$$
                                $$input:assemblyitems$$
                            </div>

                            <div class="invoice-btns-row sect clear">
                                <div class="invoice-btn-default">
                                    $$input:saveButton$$
                                </div>
                                <div class="invoice-btn-default">
                                    $$input:saveAndAddButton$$
                                </div>
                                <div class="invoice-btn-default">
                                    $$input:closeButton$$
                                </div>
                            </div>
                        </div>
                    </td>
                    <!-- End  col -->
                    <td class="sidebar">
                        <div class="inv-OptBar">
                            <div class="optBarBlock image-upload">
                                $$input:imageupload$$
                            </div>
                            <div class="optBarBlock storefront">
                                $$input:sfcheckbox$$
                                $$input:sfoptions$$
                            </div>
                            <div class="optBarBlock invoice-customfields">
                                $$label:customfieldtitle$$
                                $$input:customfields$$
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>');