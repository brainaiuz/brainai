ALTER TABLE wfp_website_xtemplate ALTER COLUMN template TYPE text;
ALTER TABLE wfp_website_xtemplate ALTER COLUMN image TYPE text;
ALTER TABLE wfp_website_theme  ALTER COLUMN image TYPE text;