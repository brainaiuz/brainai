UPDATE hostbasedsetting SET googleauthsubprivatekeypath = '/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKeyAPPRU.jks' WHERE hostname like 'app.workforcetrack.ru';
UPDATE hostbasedsetting SET googleconsumerkey = 'app.workforcetrack.ru' WHERE hostname like 'app.workforcetrack.ru';
UPDATE hostbasedsetting SET googlesignaturekey = 'cKv_pXAd_a1cUyd_NfaAo1ky' WHERE hostname like 'app.workforcetrack.ru';

