/*Bu patch faqat bir marta publicga patch qilinadi*/

/*1.*/
DELETE FROM defaultlayout where formid='saleinvoice';

/*2.*/
INSERT INTO defaultlayout(formid,layout) VALUES('saleinvoice','<div>
                                                                  <!--Start Content Place-->
                                                                  <div>
                                                                      <!-- <div class="contentPlaceCover"> -->
                                                                      <div class="contentBar tool-invoice c-block invoice-width">
                                                                          <div class="contentScroll">
                                                                              <table cellspacing="0" cellpadding="0" class="bindContent">
                                                                                  <tr>
                                                                                      <td class="mainBar">
                                                                                          <div class="invoice-block">
                                                                                              <div class="sect clear group">
                                                                                                  <div class="invoice-customer">
                                                                                                      $$label:crmaccount$$
                                                                                                      $$input:crmaccount$$
                                                                                                  </div>
                                                                                                  <div class="invoice-project">
                                                                                                      $$label:project$$
                                                                                                      <div style="float:left">
                                                                                                        $$input:project$$
                                                                                                        $$input:applyproject$$
                                                                                                      </div>
                                                                                                  </div>
                                                                                                  <div class="invoice-date">
                                                                                                      $$label:date$$
                                                                                                      $$input:date$$
                                                                                                  </div>
                                                                                                  <div class="invoice-due-date">
                                                                                                      $$label:duedate$$
                                                                                                      $$input:duedate$$
                                                                                                  </div>
                                                                                                  <div class="invoice-type">
                                                                                                      $$label:invoicetype$$
                                                                                                      $$input:invoicetype$$
                                                                                                  </div>
                                                                                              </div>
                                                                                              <div class="sect clear group">
                                                                                                  <div class="invoice-title">
                                                                                                      $$label:title$$
                                                                                                  </div>
                                                                                                  <div class="invoice-copyfrom">
                                                                                                      $$input:copyfrom$$
                                                                                                  </div>
                                                                                                  <div class="invoice-num">
                                                                                                      $$label:number$$
                                                                                                      $$input:number$$
                                                                                                  </div>
                                                                                              </div>
                                                                                              <div class="sect clear group">
                                                                                                  <div class="invoice-bill-to">
                                                                                                      <div class="addresshead">
                                                                                                          $$label:billaddress$$
                                                                                                          $$input:billaddress$$
                                                                                                          <div class="add-edit-links">
                                                                                                              $$input:addbilladdress$$ $$input:editbilladdress$$
                                                                                                          </div>
                                                                                                      </div>
                                                                                                      $$input:billaddressdata$$
                                                                                                  </div>
                                                                                                  <div id="invoiceshipto" class="invoice-ship-to">
                                                                                                      <div class="addresshead">
                                                                                                          $$label:mailaddress$$
                                                                                                          $$input:mailaddress$$
                                                                                                          <div class="add-edit-links">
                                                                                                              $$input:addmailaddress$$ $$input:editmailaddress$$
                                                                                                          </div>
                                                                                                      </div>
                                                                                                      $$input:mailaddressdata$$
                                                                                                  </div>
                                                                                              </div>
                                                                                              <div class="sect clear group">
                                                                                                  $$input:recurringview$$
                                                                                              </div>
                                                                                              <div id="invoiceshipvia" class="invoice-ship-via">
                                                                                                  $$label:shippingmethod$$
                                                                                                  $$input:shippingmethod$$
                                                                                              </div>
                                                                                              <div class="related-text">
                                                                                                  $$label:ponumber$$
                                                                                                  $$input:ponumber$$
                                                                                              </div>
                                                                                              <div class="related-text">
                                                                                                  $$label:quotenumber$$
                                                                                                  $$input:quotenumber$$
                                                                                              </div>
                                                                                              <div class="invoice-price-level">
                                                                                                  $$label:pricelevel$$
                                                                                                  $$input:pricelevel$$
                                                                                              </div>
                                                                                              <div class="invoice-amounts">
                                                                                                  $$label:taxcalc$$
                                                                                                  $$input:taxcalc$$
                                                                                              </div>
                                                                                              <div class="invoice-reference">
                                                                                                  $$label:reference$$
                                                                                                  $$input:reference$$
                                                                                              </div>
                                                                                              <div class="invoice-add-introduction">
                                                                                                  $$input:introductionlink$$
                                                                                                  $$input:introduction$$
                                                                                              </div>
                                                                                              <div class="invoice-products">
                                                                                                  $$input:itemtable$$
                                                                                              </div>
                                                                                              <div class="invoice-paymentpanel">
                                                                                                  <div class="invoice-paymentsave">
                                                                                                      $$input:paymentpanel$$
                                                                                                  </div>
                                                                                                  <div class="invoice-paymentexrate">
                                                                                                      $$input:paymentexratepanel$$
                                                                                                  </div>
                                                                                                  <div class="invoice-paymenthistory">
                                                                                                      $$input:paymenthistorypanel$$
                                                                                                  </div>
                                                                                              </div>
                                                                                              <div class="invoice-subtotal">
                                                                                                  <span class="corner lt"></span>
                                                                                                  <span class="corner rt"></span>
                                                                                                  <span class="corner lb"></span>
                                                                                                  <span class="corner rb"></span>
                                                                                                  $$input:totalstable$$
                                                                                              </div>
                                                                                              <div class="invoice-btn-expense" align="right">
                                                                                                  $$input:addBillExpButton$$
                                                                                              </div>

                                                                                              <div class="invoice-payment-instructions">
                                                                                                  <div style="float: left;">$$label:instruction$$</div>
                                                                                                  <div style="float: left;margin-left: 10px">$$input:instructionlist$$</div>
                                                                                                  $$input:instruction$$
                                                                                              </div>
                                                                                              <div class="invoice-btns-row">
                                                                                                  <div class="invoice-btn-save">
                                                                                                      $$input:saveButton$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-default">
                                                                                                      $$input:copyToNewButton$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-default">
                                                                                                      $$input:creditNoteAdd$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-save-approve">
                                                                                                      $$input:saveAndApproveButton$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-approve">
                                                                                                      $$input:approveAndSendButton$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-default">
                                                                                                      $$input:generateReceiptButton$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-default">
                                                                                                      $$input:sendReceiptButton$$
                                                                                                  </div>
                                                                                                  <div class="invoice-btn-pdf">
                                                                                                      $$input:pdfVersionButton$$
                                                                                                  </div>
                                                                                              </div>
                                                                                          </div>
                                                                                      </td>
                                                                                      <!-- End  col -->
                                                                                      <td class="sidebar">
                                                                                          <div class="inv-OptBar">
                                                                                              <div class="optBarBlock">
                                                                                                  <table class="">
                                                                                                      <tbody>
                                                                                                      <tr>
                                                                                                          <td class="exRate" colspan="2">
                                                                                                              $$input:baserate$$
                                                                                                              $$input:exrate$$
                                                                                                              $$input:currency$$
                                                                                                          </td>
                                                                                                      </tr>
                                                                                                      <tr class="bankDetails">
                                                                                                          <td>$$label:bank$$</td>
                                                                                                          <td>
                                                                                                              $$input:bank$$
                                                                                                          </td>
                                                                                                      </tr>
                                                                                                      </tbody>
                                                                                                  </table>
                                                                                              </div>
                                                                                              <div class="optBarBlock period">
                                                                                                  $$label:periodlabel$$<br/>
                                                                                                  $$input:periodstart$$<br/><br/>
                                                                                                  $$input:periodend$$
                                                                                              </div>
                                                                                              <div class="optBarBlock invoice-customfields">
                                                                                                  $$label:customfieldtitle$$
                                                                                                  $$input:customfields$$
                                                                                              </div>
                                                                                              <div class="optBarBlock invoice-attachments">
                                                                                                  $$label:attachments$$
                                                                                                  $$input:attachments$$
                                                                                                  $$input:uploadbutton$$
                                                                                              </div>
                                                                                              <div class="optBarBlock notes">
                                                                                                  $$label:notes$$
                                                                                                  $$input:notes$$
                                                                                                  $$input:addnote$$
                                                                                              </div>
                                                                                          </div>
                                                                                      </td>
                                                                                      <!-- End  col -->
                                                                                  </tr>
                                                                              </table>
                                                                          </div>
                                                                      </div>
                                                                      <!-- End contentBar -->
                                                                  </div>
                                                                  <!-- End contentPlaceCover -->
                                                              </div>');