--for zero schema
ALTER TABLE "0".position
    ALTER COLUMN description TYPE text,
    ALTER COLUMN primaryresponse TYPE text,
    ALTER COLUMN workingConditions TYPE text,
    ALTER COLUMN knowledge TYPE text,
    ALTER COLUMN expirence TYPE text,
    ALTER COLUMN skills TYPE text,
    ALTER COLUMN personalAttributes TYPE text,
    ALTER COLUMN qualification TYPE text;


--for all schemas
ALTER TABLE "anv".position
    ALTER COLUMN description TYPE text,
    ALTER COLUMN primaryresponse TYPE text,
    ALTER COLUMN workingConditions TYPE text,
    ALTER COLUMN knowledge TYPE text,
    ALTER COLUMN expirence TYPE text,
    ALTER COLUMN skills TYPE text,
    ALTER COLUMN personalAttributes TYPE text,
    ALTER COLUMN qualification TYPE text;