update "anv".myuser set uuid = id where uuid is null;
alter table "anv".myuser add CONSTRAINT "myuser_uuid_unique" UNIQUE (uuid);