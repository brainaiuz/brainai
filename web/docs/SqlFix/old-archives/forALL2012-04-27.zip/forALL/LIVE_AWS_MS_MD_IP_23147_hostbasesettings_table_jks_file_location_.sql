update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'free.mailforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'paid.mailforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'projects.logotime.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'login.victechweb.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'tracesoft.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'team.nextstag.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'projects.vaival.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'projects.spritelab.dk';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'my.atmonitor.co.uk';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'my.cooconnect.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'test.workspace.cooconnect.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'backend.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'aws.workforcetrack.tr';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'app.workforcetrack.tr';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'aws.workforcetrack.ru';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'app.workforcetrack.ru';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'aws.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/workforcetrack/GoogleAuthSubPrivateKey.jks'
where hostname like 'app.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/customisation/kpi/GoogleAuthSubPrivateKey.jks'
where hostname like 'aws.kpi.com';

update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/kpi/GoogleAuthSubPrivateKey.jks'
where hostname like 'app.kpi.com';



update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/customisation/ezyadmin/GoogleAuthSubPrivateKey.jks'
where hostname like 'aws.ezyadmin.com';

update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/customisation/ezyadmin/GoogleAuthSubPrivateKey.jks'
where hostname like 'app.ezyadmin.com';




