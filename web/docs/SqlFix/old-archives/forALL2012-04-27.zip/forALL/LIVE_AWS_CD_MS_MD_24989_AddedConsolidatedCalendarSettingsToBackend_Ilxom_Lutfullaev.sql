-- schema update dan keyin patch qilinadi.
update companySystemSettings set isShowConsolidateCalendar = true where companyid in (1, 6351, 8032, 20440, 26881);
update companySystemSettings set isShowConsolidateCalendar = false where companyid not in (1, 6351, 8032, 20440, 26881);
