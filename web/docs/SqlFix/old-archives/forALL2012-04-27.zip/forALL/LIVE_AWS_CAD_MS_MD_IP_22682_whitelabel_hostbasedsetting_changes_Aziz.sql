--Run for Globalauth database
ALTER TABLE hostbasedsetting ADD COLUMN defaultFromName character varying(255);

--KPI and default
update hostbasedsetting set defaultFromName='KPI.com' where hostname like ('%workforce%') or hostname like ('%localhost%') or hostname like ('%kpi%');
update hostbasedsetting set email = 'support+aws@workforcetrack.com' where hostname = 'aws.workforcetrack.com';
update hostbasedsetting set email = 'support+aws@workforcetrack.com' where hostname = 'aws.kpi.com';
update hostbasedsetting set email = 'support@workforcetrack.com' where hostname = 'app.kpi.com';
update hostbasedsetting set productName='KPI' where hostname like ('%workforce%') or hostname like ('%localhost%') or hostname like ('%kpi%');

--RU workforcetrack
update hostbasedsetting set defaultFromName='WorkforceTrack.ru' where hostname like ('%workforcetrack.ru%');
update hostbasedsetting set productName='WorkforceTrack' where hostname like ('%workforcetrack.ru%');

--COOConnect
update hostbasedsetting set defaultFromName='COOConnect' where hostname like ('%cooconnect%');
update hostbasedsetting set productName='COOConnect' where hostname like ('%cooconnect%');
update hostbasedsetting set email='support@cooconnect.com' where hostname like ('%cooconnect%');

--ATMonitor
update hostbasedsetting set defaultFromName='ATMonitor' where hostname like ('%atmonitor%');
update hostbasedsetting set productName='ATMonitor' where hostname like ('%atmonitor%');
update hostbasedsetting set email='support@atmonitor.co.uk' where hostname like ('%atmonitor%');

--EzyAdmin
update hostbasedsetting set defaultFromName='EzyAdmin.com' where hostname like ('%ezyadmin%');
update hostbasedsetting set email = 'admin+aws@ezyadmin.com' where hostname = 'aws.ezyadmin.com';