UPDATE hostbasedsetting SET pdflogo='/customisation/workforcetrack/images/workforcelogo_ru.png'
 WHERE hostname like ('%workforcetrack.ru%');


UPDATE hostbasedsetting SET pdflogo='/customisation/kpi/images/kpilogo.png'
 WHERE hostname like ('%workforcetrack.com%') or pdflogo like('/i/wfm_logo.png');
