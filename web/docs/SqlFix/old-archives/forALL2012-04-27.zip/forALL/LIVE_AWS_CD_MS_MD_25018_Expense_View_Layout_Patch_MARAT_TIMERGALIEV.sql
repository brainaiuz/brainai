/*Bu patch faqat bir marta publicga patch qilinadi*/

/*1.*/
DELETE FROM defaultlayout where formid='EXPENSE_REPORT';

/*2.*/
INSERT INTO defaultlayout(formid, layout) VALUES('EXPENSE_REPORT', '<div>
    <div class="contentBar tool-invoice c-block invoice-width">
        <div class="contentScroll">
            <table cellspacing="0" cellpadding="0" class="bindContent">
                <tr>
                    <td class="mainBar">
                        <div class="invoice-block">
                            <div class="sect clear group" style="margin-bottom: 20px">
                                <div class="invoice-title">
                                    $$label:title$$
                                </div>
                            </div>
                            <div class="sect group">
                                <div class="lineItem">
                                    $$label:date$$
                                    $$input:date$$
                                </div>
                                <div class="lineItem">
                                    $$label:exptitle$$
                                    $$input:exptitle$$
                                </div>
                                <div class="lineItem">
                                    $$label:introduction$$
                                    $$input:introduction$$
                                </div>
                                <div class="lineItem" style="float: right;">
                                    $$label:number$$
                                    $$input:number$$
                                </div>

                            </div>
                            <div class="sect group">
                                <div class="lineItem">
                                    $$label:project$$
                                    $$input:project$$
                                </div>
                                <div class="lineItem" style="margin-left: 8px">
                                    $$label:ponumber$$
                                    $$input:ponumber$$
                                </div>
                                <div class="lineItem" style="margin-left: 8px">
                                    $$label:manager$$
                                    $$input:manager$$
                                </div>
                                <div class="lineItem">
                                    $$label:manager2$$
                                    $$input:manager2$$
                                </div>
                                <div class="lineItem" style="padding-top: 14px;float: left;margin-left: 0px;">
                                    $$input:exrate$$
                                </div>
                            </div>
                            <div class="sect">
                                $$input:itemtable$$
                            </div>
                            <div class="invoice-paymentpanel">
                                <div class="invoice-paymentsave">
                                    $$input:paymentpanel$$
                                </div>
                            </div>
                            <div class="half right">
                                <div class="sect invoice-subtotal">
                                    <span class="corner lt"></span>
                                    <span class="corner rt"></span>
                                    <span class="corner lb"></span>
                                    <span class="corner rb"></span>
                                    $$input:totalstable$$
                                </div>
                            </div>

                            <div class="invoice-btns-row sect clear">
                                <div class="invoice-btn-save">
                                    $$input:saveButton$$
                                </div>
                                <div class="invoice-btn-save-approve">
                                    $$input:saveAndApproveButton$$
                                </div>
                                <div class="invoice-btn-save-approve">
                                    $$input:rejectButton$$
                                </div>
                                <div class="invoice-btn-approve">
                                    $$input:approveAndSendButton$$
                                </div>
                                <div class="invoice-btn-default">
                                    $$input:deleteButton$$
                                </div>
                                <div class="invoice-btn-pdf">
                                    $$input:pdfVersionButton$$
                                </div>
                            </div>
                        </div>
                    </td>
                    <!-- End  col -->
                    <td class="sidebar">
                        <div class="inv-OptBar">
                            <div class="optBarBlock invoice-customfields">
                                $$label:customfieldtitle$$
                                $$input:customfields$$
                            </div>
                            <div class="optBarBlock invoice-attachments">
                                $$label:attachments$$
                                $$input:attachments$$
                                $$input:uploadbutton$$
                            </div>
                            <div class="optBarBlock notes">
                                $$label:notes$$
                                $$input:notes$$
                                $$input:addnote$$
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>');