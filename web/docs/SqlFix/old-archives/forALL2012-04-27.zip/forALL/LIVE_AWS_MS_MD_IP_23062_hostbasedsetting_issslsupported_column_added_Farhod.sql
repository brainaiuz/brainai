--For Globalauth
ALTER TABLE hostbasedsetting ADD COLUMN isSSLSupported boolean NOT NULL default false;

UPDATE hostbasedsetting SET isSSLSupported = true WHERE hostname like '%workforcetrack.com%';