
update hostbasedsetting set skype='kpi.com' where hostname like ('%kpi%');

update hostbasedsetting set skype='kpi.com' where hostname like ('%workforcetrack%');