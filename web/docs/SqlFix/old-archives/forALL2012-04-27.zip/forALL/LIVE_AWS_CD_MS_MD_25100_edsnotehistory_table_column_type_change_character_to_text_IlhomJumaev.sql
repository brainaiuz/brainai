--for zero schema
ALTER TABLE "0".note ALTER COLUMN comment TYPE text;

--for all schemas
ALTER TABLE "anv".note ALTER COLUMN comment TYPE text;