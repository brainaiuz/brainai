update "anv".googlecalendar set active = true where active is null;
update "anv".googlecalendar set attempts = 0 where attempts is null;