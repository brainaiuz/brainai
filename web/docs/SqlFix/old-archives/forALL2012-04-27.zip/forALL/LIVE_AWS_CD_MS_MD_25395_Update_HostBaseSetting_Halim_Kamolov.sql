--Globalauthga patch
update hostbasedsetting set helphost='workforcetrack.ru' where hostname like '%workforcetrack.ru';