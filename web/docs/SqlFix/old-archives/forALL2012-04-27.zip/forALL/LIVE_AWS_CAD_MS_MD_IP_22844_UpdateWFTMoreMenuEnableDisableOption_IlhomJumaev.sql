-- for public schema

update companysystemsettings set enableWFTMoreMenuForMEM = true;
update companysystemsettings set enableWFTMoreMenuForADMIN = true;


-------------   Vaival's company update query
update companysystemsettings set enableWFTMoreMenuForMEM = false where companyid = 22026;
update companysystemsettings set enableWFTMoreMenuForMEM = false where companyid = 24021;