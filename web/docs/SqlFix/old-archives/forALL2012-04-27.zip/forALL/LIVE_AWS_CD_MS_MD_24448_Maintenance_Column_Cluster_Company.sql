ALTER TABLE clustercompany ADD COLUMN isMaintenance boolean;
ALTER TABLE clustercompany ALTER COLUMN isMaintenance SET DEFAULT false;
UPDATE clustercompany SET isMaintenance=false WHERE ismaintenance is null;
