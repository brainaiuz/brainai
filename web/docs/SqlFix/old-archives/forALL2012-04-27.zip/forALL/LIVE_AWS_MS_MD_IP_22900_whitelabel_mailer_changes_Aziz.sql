--Run for Globalauth database before starting Tomcat
ALTER TABLE hostbasedsetting ADD COLUMN mailParamsFileName character varying(255);
update hostbasedsetting set mailParamsFileName = 'mail.properties';
update hostbasedsetting set mailParamsFileName = 'ezyadminmail.properties' where hostname like '%ezyadmin.com%';
update hostbasedsetting set mailParamsFileName = 'kpimail.properties' where hostname like '%kpi.com%';
update hostbasedsetting set mailParamsFileName = 'cooconnectmail.properties' where hostname like '%cooconnect%';
update hostbasedsetting set mailParamsFileName = 'atmonitormail.properties' where hostname like '%atmonitor%';

update hostbasedsetting set googlemarketplacerealm = null;
update hostbasedsetting set phone='+44 (0) 7769 277 927' where hostname like ('%cooconnect%');
update hostbasedsetting set phone='+44 (0) 208 466 5650' where hostname like ('%atmonitor%');

ALTER TABLE hostbasedsetting ADD COLUMN productCompanyName character varying(255);
update hostbasedsetting set productCompanyName = 'Finnet Limited';