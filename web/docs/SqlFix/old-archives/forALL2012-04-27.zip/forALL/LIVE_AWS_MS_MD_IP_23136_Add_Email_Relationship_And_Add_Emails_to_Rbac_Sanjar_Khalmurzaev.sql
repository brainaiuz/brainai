/*added by Tulqin*/
update "anv".myuser set deleted = false where deleted is not true and (SELECT setval('"anv".relationship_id_seq', (select max(id) from "anv".relationship))) is null;

/* ADD NEW EMAIL RELATIONSHIP*/
INSERT INTO "anv".relationship (code, entityname, entrytype, name, rank, relationtype)
      VALUES ('EMAIL_OWNER', 'EMAIL', 2, 'Owner of useremail', 1, 'DIRECT');
INSERT INTO "anv".relationship (code, entityname, entrytype, name, rank, relationtype)
      VALUES ('EMAIL_VIEWER', 'EMAIL', 2, 'Viewer of useremail', 2, 'DIRECT');


 INSERT INTO "anv".useremailrbac (relationrank, relationship, trusteetype, emailsetting_id, userid)
  SELECT 2, 'EMAIL_OWNER', 2, id, user_id from "anv".autoresponse;