--Run after schema update
update "anv".emailtemplate set name = trim(name) where isdefault is true;
update "anv".emailtemplate set code = upper(replace(replace(replace(replace(replace(name, '-', '_'), ')', '_'), '(', '_'), ' ', '_'), '__', '_')) where isdefault is true;
update "anv".emailtemplate set locale = 'en' where isdefault is true;