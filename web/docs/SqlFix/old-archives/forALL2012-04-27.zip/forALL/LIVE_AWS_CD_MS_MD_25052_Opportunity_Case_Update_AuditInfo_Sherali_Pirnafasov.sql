update "anv".opportunity set createdby_id=owner where createdby_id is null;
update "anv".opportunity set modifiedby_id=owner where modifiedby_id is null;

update "anv".crmcase set createdby_id=owner where createdby_id is null;
update "anv".crmcase set modifiedby_id=owner where modifiedby_id is null;
update "anv".crmcase set modificationdate=lastupdateddate;
update "anv".crmcase set creationdate=createddate;

ALTER TABLE "anv".crmcase DROP COLUMN lastupdateddate;
ALTER TABLE "anv".crmcase DROP COLUMN createddate;