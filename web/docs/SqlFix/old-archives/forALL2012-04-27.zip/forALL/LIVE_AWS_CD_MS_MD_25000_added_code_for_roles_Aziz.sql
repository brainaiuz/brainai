--For free and paid db
--Run after schema update
update role set code = 'DR' where id = 1;
update role set code = 'TL' where id = 2;
update role set code = 'PM' where id = 3;
update role set code = 'HR' where id = 4;
update role set code = 'ADMIN' where id = 5;
update role set code = 'MEM' where id = 6;
update role set code = 'CLIENT' where id = 7;
update role set code = 'ONE_OFF' where id = 8;
update role set code = 'ACCOUNTANT' where id = 9;
update role set code = 'SALESMAN' where id = 10;
update role set code = 'CUSTOMER_SERVICE_REPRESENTATIVE' where id = 11;
update role set code = 'SALESPERSON' where id = 12;
update role set code = 'ADMIN_LOCATION' where id = 13;
update role set code = 'CALENDAR_EDITOR' where id = 14;
update role set code = 'CALENDAR_VIEWER' where id = 15;
update role set code = 'CHAT_EXPERT' where id = 16;
update role set code = 'TIMESHEET_EDITOR' where id = 17;
update role set code = 'GUEST' where id = 18;
update role set code = 'CUSTOM_MEMBER' where id = 19;

update country set name = 'Serbia', alias = 'Serbia;' where code='CS';
insert into country (alias, code, name, telcode, currencyid) values('Montenegro;', 'MN', 'Montenegro', '+382',130);