
--live paid ga bo'lmadi hali(11.04.12 - 16:26)

ALTER TABLE usageplan ALTER COLUMN deleted SET DEFAULT false;

UPDATE usageplan SET deleted = false WHERE deleted is null;
