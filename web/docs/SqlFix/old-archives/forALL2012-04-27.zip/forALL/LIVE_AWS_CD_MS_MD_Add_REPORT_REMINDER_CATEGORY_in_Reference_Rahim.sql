
insert into "anv".reference (code,description,name,parentid)
select 'REPORT_REMINDER_CATEGORY','REPORT_REMINDER_CATEGORY','Report Reminder',(select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY');