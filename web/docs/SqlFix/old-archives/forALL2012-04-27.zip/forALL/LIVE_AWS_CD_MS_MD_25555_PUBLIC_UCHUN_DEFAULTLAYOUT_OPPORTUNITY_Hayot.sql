--BU SQL EMAS>>>
--Backendga kirib (Add New+) submenudan Add Custom Form degani bor o'shanga kirib set qilish kerak... pastdagi HTMLni(yaxshisi mani(Hayot) chaqiringlar...
--bu OPPORTUNITYGA


<div class="contentBar" style="padding:0 20px;">

    <h1 class="title-2">Edit Opportunity</h1>

    <div class="sect lineBtnSet c">
        $$input:SAVEANDCLOSE$$
        $$input:SAVEANDADDANOTHER$$
        $$input:CLOSE$$
    </div>


    <div id="click1" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('click1');if(myclick && myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title"><div class="gwt-HTML">OPORTUNITY INFORMATION</div></h3>

        <fieldset class="slideDown-content group labelLine">
            <div class="halfSet-1 left">
                <div class="row">
                    $$label:CRM_OPPORTUNITY_ASSIGNEE$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_ASSIGNEE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_NUMBER$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_NUMBER$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_NAME$$
                    <div class="field">$$input:CRM_OPPORTUNITY_NAME$$</div>
                </div>

                <div class="row addFieldSet">
                    $$label:CRM_OPPORTUNITY_ACCOUNT_NAME$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_ACCOUNT_NAME$$
                    </div>
                    $$input:CRM_OPPORTUNITY_ACCOUNT_LINK$$
                </div>

                <div class="row addFieldSet">
                    $$label:CRM_OPPORTUNITY_CONTACT_NAME$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_CONTACT_NAME$$
                    </div>
                    $$input:CRM_OPPORTUNITY_CONTACT_LINK$$
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_LEAD_SOURCE$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_LEAD_SOURCE$$
                    </div>
                </div>
            </div>

            <div class="halfSet-1 left">
                <div class="row">
                    $$label:CRM_OPPORTUNITY_AMOUNT$$
                    <!-- <div class="field"><input class="fullWidth"  id="idToField-7" type="text" /><em class="fieldKey">(GBP)</em></div> -->
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_AMOUNT$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_CLOSING_DATE$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_CLOSING_DATE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_STAGE$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_STAGE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_PROBABILITY$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_PROBABILITY$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_EXPECTED_REVENUE$$
                    <div class="field">$$input:CRM_OPPORTUNITY_EXPECTED_REVENUE$$</div>
                </div>

                <div class="row">
                    $$label:CRM_OPPORTUNITY_CAMPAIGN_SOURCE$$
                    <div class="field">
                        $$input:CRM_OPPORTUNITY_CAMPAIGN_SOURCE$$
                    </div>
                </div>
            </div>
        </fieldset>

    </div>


    <div  id="click2" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('click2');if(myclick && myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:CRM_NOTE$$</h3>

        <fieldset class="slideDown-content group nobrd">
            <div class="halfSet-1 left" style="width:50%">
                $$input:CRM_NOTE$$
            </div>

            <h3 class="slideDown-halfTitle left">$$label:CRM_OPPORTUNITY_ATTACHMENTS$$</h3>
            <div class="overHide">
                $$input:CRM_OPPORTUNITY_ATTACHMENTS$$
            </div>
        </fieldset>

    </div>


    <div id="click3" class="slideDown-box group expand">
        <h3 onclick="var myclick=document.getElementById('click3');if(myclick && myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:CRM_OPPORTUNITY_INCLUDE_ITEMS$$</h3>

        <fieldset class="slideDown-content group nobrd">
            <div class="sect reachFullWidth">
                $$input:CRM_OPPORTUNITY_INCLUDE_ITEMS$$
            </div>

        </fieldset>

    </div>
    <div id="click4" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('click4');if(myclick && myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title"><div class="gwt-HTML">ADDITIONAL INFORMATION</div></h3>

        <fieldset class="slideDown-content group labelLine">
            <div class="halfSet-1 left">
                <div class="row hideCustomField"> $$label:string_value1$$<div class="field">$$input:string_value1$$</div></div>
                <div class="row hideCustomField"> $$label:string_value2$$<div class="field">$$input:string_value2$$</div></div>
                <div class="row hideCustomField"> $$label:string_value3$$<div class="field">$$input:string_value3$$</div></div>
                <div class="row hideCustomField"> $$label:string_value4$$<div class="field">$$input:string_value4$$</div></div>
                <div class="row hideCustomField"> $$label:string_value5$$<div class="field">$$input:string_value5$$</div></div>
                <div class="row hideCustomField"> $$label:string_value6$$<div class="field">$$input:string_value6$$</div></div>
                <div class="row hideCustomField"> $$label:string_value7$$<div class="field">$$input:string_value7$$</div></div>
                <div class="row hideCustomField"> $$label:string_value8$$<div class="field">$$input:string_value8$$</div></div>
                <div class="row hideCustomField"> $$label:string_value9$$<div class="field">$$input:string_value9$$</div></div>
                <div class="row hideCustomField"> $$label:string_value10$$<div class="field">$$input:string_value10$$</div></div>
                <div class="row hideCustomField"> $$label:double_value1$$<div class="field">$$input:double_value1$$</div></div>
                <div class="row hideCustomField"> $$label:double_value2$$<div class="field">$$input:double_value2$$</div></div>
                <div class="row hideCustomField"> $$label:double_value3$$<div class="field">$$input:double_value3$$</div></div>
                <div class="row hideCustomField"> $$label:double_value4$$<div class="field">$$input:double_value4$$</div></div>
                <div class="row hideCustomField"> $$label:double_value5$$<div class="field">$$input:double_value5$$</div></div>
            </div>

            <div class="halfSet-1 left">
                <div class="row hideCustomField"> $$label:double_value6$$<div class="field">$$input:double_value6$$</div></div>
                <div class="row hideCustomField"> $$label:double_value7$$<div class="field">$$input:double_value7$$</div></div>
                <div class="row hideCustomField"> $$label:double_value8$$<div class="field">$$input:double_value8$$</div></div>
                <div class="row hideCustomField"> $$label:double_value9$$<div class="field">$$input:double_value9$$</div></div>
                <div class="row hideCustomField"> $$label:double_value10$$<div class="field">$$input:double_value10$$</div></div>
                <div class="row hideCustomField"> $$label:date_value1$$<div class="field">$$input:date_value1$$</div></div>
                <div class="row hideCustomField"> $$label:date_value2$$<div class="field">$$input:date_value2$$</div></div>
                <div class="row hideCustomField"> $$label:date_value3$$<div class="field">$$input:date_value3$$</div></div>
                <div class="row hideCustomField"> $$label:date_value4$$<div class="field">$$input:date_value4$$</div></div>
                <div class="row hideCustomField"> $$label:date_value5$$<div class="field">$$input:date_value5$$</div></div>
                <div class="row hideCustomField"> $$label:date_value6$$<div class="field">$$input:date_value6$$</div></div>
                <div class="row hideCustomField"> $$label:date_value7$$<div class="field">$$input:date_value7$$</div></div>
                <div class="row hideCustomField"> $$label:date_value8$$<div class="field">$$input:date_value8$$</div></div>
                <div class="row hideCustomField"> $$label:date_value9$$<div class="field">$$input:date_value9$$</div></div>
                <div class="row hideCustomField"> $$label:date_value10$$<div class="field">$$input:date_value10$$</div></div>
            </div>
        </fieldset>
    </div>

    <div class="bothSect lineBtnSet c">
        $$input:SAVEANDCLOSE$$
        $$input:SAVEANDADDANOTHER$$
        $$input:CLOSE$$
    </div>

</div>

