-- Should be applied to GLOBALAUTH database
-- IMPORTANT NOTE
-- In production environments such as App, Coo etc.,
-- the patch should be run only and ONLY AFTER executing through browser, the following URL:
-- http://{hostname}/chatPasswordChange.html on the server (e.g. http://app.workforcetrack.com/chatPasswordChange.html)
-- Look at tomcat log, it should show the updates of chat passwords
-- Only after this process is completed, run this sql patch.

--CONVERT TO MD5 PATCH
ALTER TABLE userauth DROP COLUMN IF EXISTS password_old;
ALTER TABLE userauth ADD COLUMN password_old character varying(255);
update userauth ua set password_old = password where length(ua.password) != 32;
update userauth ua set password = md5(password) where length(ua.password) != 32;
ALTER TABLE userauth ADD CONSTRAINT pass_length_should_32 CHECK (length("password")>=32);