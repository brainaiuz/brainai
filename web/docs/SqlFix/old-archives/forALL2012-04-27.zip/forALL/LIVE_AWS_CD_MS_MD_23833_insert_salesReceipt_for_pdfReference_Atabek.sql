/*bir marta urilsin*/
INSERT  INTO pdfreference(code,name) VALUES ('SALES_RECEIPT','Sales Receipt');