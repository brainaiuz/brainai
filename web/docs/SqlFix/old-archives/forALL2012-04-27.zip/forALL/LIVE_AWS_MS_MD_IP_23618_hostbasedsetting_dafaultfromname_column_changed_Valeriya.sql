--For Globalauth

UPDATE hostbasedsetting SET defaultFromName = 'kpi.com' WHERE defaultFromName = 'KPI.com';
