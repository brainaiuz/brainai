UPDATE "anv".clock SET reset = true;
UPDATE "anv".clock SET started = false;
UPDATE "anv".clock SET startDate = null;
UPDATE "anv".clock SET endDate = null;
UPDATE "anv".clock SET cumulativeTime = 0;