/*1. Bu bir marta patch qilinadi*/
INSERT INTO accounttemplate(code,codestring,key,name,enablepayments,showinexpense,accounttypeid) VALUES('1100','1100','1100','Landing Cost',false,false,1);

/*2. Bu hamma companyga patch qilinadi*/
INSERT INTO "anv".account(accountcode,codestring,key,name,accounttypeid, balance,enablepayments,showinexpense) VALUES('1100','1100','1100','Landing Cost',1,0,false,false);