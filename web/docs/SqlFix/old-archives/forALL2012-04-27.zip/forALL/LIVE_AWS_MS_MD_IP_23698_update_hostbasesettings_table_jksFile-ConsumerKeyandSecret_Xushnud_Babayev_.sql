update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSworkforceRU.jks',
googleconsumerkey='aws.workforcetrack.ru',
googlesignaturekey='F-RhdILDh_Jn8WjNjJkSqVab'
where hostname like 'aws.workforcetrack.ru';

update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyNextstag.jks',
googleconsumerkey='team.nextstag.com',
googlesignaturekey='DXT-8_BGgiCuOa7E-_k5pI5Y'
where hostname like 'team.nextstag.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyVaival.jks',
googleconsumerkey='projects.vaival.com',
googlesignaturekey='iugBm0d0TTD7-feNgN3Q6iGW'
where hostname like 'projects.vaival.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeySpritelab.jks',
googleconsumerkey='projects.spritelab.dk',
googlesignaturekey='1uqB-AWX0a6zmR5gv5SGwUqE'
where hostname like 'projects.spritelab.dk';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAtmonitor.jks',
googleconsumerkey='my.atmonitor.co.uk',
googlesignaturekey='pZt6x_wmrELTHmWKkv3UEuyU'
where hostname like 'my.atmonitor.co.uk';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyCooconnect.jks',
googleconsumerkey='my.cooconnect.com',
googlesignaturekey='fNBmrXr4llYA0gU2FZXaG1g9'
where hostname like 'my.cooconnect.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyLogotime.jks',
googleconsumerkey='projects.logotime.com',
googlesignaturekey='NpsZ1cls3yZVGbLin0MIIW6c'
where hostname like 'projects.logotime.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyVicTech.jks',
googleconsumerkey='login.victechweb.com',
googlesignaturekey='NPMH9v7z75F3Tq9Xo8TnFZ3l'
where hostname like 'login.victechweb.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyTracesoft.jks',
googleconsumerkey='tracesoft.workforcetrack.com',
googlesignaturekey='jrD4g994JdJhWlNRZrKdE6bq'
where hostname like 'tracesoft.workforcetrack.com';

-- ***************************************************   only JKS **********************************************

update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKey.jks'
where hostname like 'free.mailforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKey.jks'
where hostname like 'paid.mailforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKey.jks'
where hostname like 'backend.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSworkforce.jks'
where hostname like 'aws.workforcetrack.tr';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAPPworkforce.jks'
where hostname like 'app.workforcetrack.tr';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSworkforce.jks'
where hostname like 'aws.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAPPworkforce.jks'
where hostname like 'app.workforcetrack.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSkpi.jks'
where hostname like 'aws.kpi.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAPPkpi.jks'
where hostname like 'app.kpi.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSEzyadmin.jks'
where hostname like 'aws.ezyadmin.com';


update hostbasedsetting set
googleauthsubprivatekeypath='/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/ezyadminGoogleAuthSubPrivateKeyAPPEzyadmin.jks'
where hostname like 'app.ezyadmin.com';