UPDATE "anv".reference SET sorder = 1 WHERE code = 'MR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TITLE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MRS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TITLE');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'MISS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TITLE');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'MS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TITLE');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'DR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TITLE');

UPDATE "anv".reference SET sorder = 1 WHERE code = '_TASK_DIFFICULTY_EASY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TASK_DIFFICULTY');
UPDATE "anv".reference SET sorder = 2 WHERE code = '_TASK_DIFFICULTY_MEDIUM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TASK_DIFFICULTY');
UPDATE "anv".reference SET sorder = 3 WHERE code = '_TASK_DIFFICULTY_DIFFICULT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TASK_DIFFICULTY');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_INCIDENT_LEVEL');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_INCIDENT_LEVEL');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'SICK_LEAVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'STUDY_LEAVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'ANNUAL_LEAVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'LATE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'SPECIAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAVE_REQUEST_TYPE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'AVAILABLE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIMETRACK_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'NOT_AVAILABLE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIMETRACK_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'BREAK'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIMETRACK_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'ON_LEAVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIMETRACK_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'LESS_THAN_1_YEAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');
UPDATE "anv".reference SET sorder = 2 WHERE code = '1_PLUS_TO_2_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');
UPDATE "anv".reference SET sorder = 3 WHERE code = '2_PLUS_TO_5_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');
UPDATE "anv".reference SET sorder = 4 WHERE code = '5_PLUS_TO_7_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');
UPDATE "anv".reference SET sorder = 5 WHERE code = '7_PLUS_TO_10_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');
UPDATE "anv".reference SET sorder = 6 WHERE code = '10_TO_15_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');
UPDATE "anv".reference SET sorder = 7 WHERE code = 'MORE_THAN_15_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EXPERIENCE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'NO_EXPERIENCE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'LESS_THAN_1_YEAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 3 WHERE code = '1_YEAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 4 WHERE code = '2_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 5 WHERE code = '3_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 6 WHERE code = '4_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 7 WHERE code = '5_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "anv".reference SET sorder = 8 WHERE code = 'MORE_THAN_5_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MANAGEMENT_EXPERIENCE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'NO_EXPERIENCE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'LESS_THAN_1_YEAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 3 WHERE code = '1_YEAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 4 WHERE code = '2_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 5 WHERE code = '3_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 6 WHERE code = '4_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 7 WHERE code = '5_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');
UPDATE "anv".reference SET sorder = 8 WHERE code = 'MORE_THAN_5_YEARS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_LEADERSHIP_EXPERIENCE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'INTERNAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CLIENT_TYPE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'EXTERNAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CLIENT_TYPE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'COMPLETED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'NOT_STARTED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'ONGOING'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'ALL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_PROJECT_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_INCIDENT_LEVEL');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_INCIDENT_LEVEL');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'LOW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_INCIDENT_LEVEL');

UPDATE "anv".reference SET sorder = 2 WHERE code = '2'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'REPORT_DAY');
UPDATE "anv".reference SET sorder = 3 WHERE code = '3'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'REPORT_DAY');
UPDATE "anv".reference SET sorder = 4 WHERE code = '4'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'REPORT_DAY');
UPDATE "anv".reference SET sorder = 5 WHERE code = '5'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'REPORT_DAY');
UPDATE "anv".reference SET sorder = 6 WHERE code = '6'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'REPORT_DAY');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'WEEKLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICING_PERIOD');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MONTHLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICING_PERIOD');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'QUARTERLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICING_PERIOD');

UPDATE "anv".reference SET sorder = 2 WHERE code = 'GOOGLE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_UPLOAD_TYPE');
UPDATE "anv".reference SET sorder = 1 WHERE code = 'AMAZON'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_UPLOAD_TYPE');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'LOCAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_UPLOAD_TYPE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'PAID'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SICK_TYPE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'NON_PAID'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SICK_TYPE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'WEEKLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_HOLIDAY_REPEAT');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MONTHLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_HOLIDAY_REPEAT');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'YEARLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_HOLIDAY_REPEAT');

UPDATE "anv".reference SET sorder = 3 WHERE code = 'EXPENSE_APPROVED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'EXPENSE_STATUS');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'EXPENSE_REVERSED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'EXPENSE_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'EXPENSE_DECLINED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'EXPENSE_STATUS');
UPDATE "anv".reference SET sorder = 1 WHERE code = 'EXPENSE_DRAFT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'EXPENSE_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'EXPENSE_SUBMITTED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'EXPENSE_STATUS');
UPDATE "anv".reference SET sorder = 6 WHERE code = 'EXPENSE_PAID'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'EXPENSE_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'NEW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'RESOLVED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'IGNORED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'DONE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_STATUS');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'UNDER INVESTIGATION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_STATUS');
UPDATE "anv".reference SET sorder = 6 WHERE code = 'IN PROGRESS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'Disable'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TSREPORT_NOTIFICATION');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'Daily'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TSREPORT_NOTIFICATION');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'Weekly'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TSREPORT_NOTIFICATION');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'Monthly'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TSREPORT_NOTIFICATION');

UPDATE "anv".reference SET sorder = 1 WHERE code = '_APPROVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIME_SHEET_ENTRY_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = '_REJECT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIME_SHEET_ENTRY_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = '_WAITING'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_TIME_SHEET_ENTRY_STATUS');

UPDATE "anv".reference SET sorder = 2 WHERE code = '_OPEN'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');
UPDATE "anv".reference SET sorder = 5 WHERE code = '_UNDER_INVESTIGATION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = '_IN_PROGRESS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = '_IN_REVIEW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');
UPDATE "anv".reference SET sorder = 6 WHERE code = '_RESOLVED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');
UPDATE "anv".reference SET sorder = 7 WHERE code = '_CLOSED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');
UPDATE "anv".reference SET sorder = 1 WHERE code = '_NEW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_ISSUE_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'CRITICAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_PRIORITY');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_PRIORITY');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_PRIORITY');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'LOW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_BUG_PRIORITY');

UPDATE "anv".reference SET sorder = 2 WHERE code = 'QUARTERLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TAX_PERIOD');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'ANNUAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TAX_PERIOD');
UPDATE "anv".reference SET sorder = 1 WHERE code = '1MONTHLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TAX_PERIOD');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_PRIORITY');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_PRIORITY');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'LOW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_PRIORITY');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'EMAIL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_ORIGIN');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'PHONE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_ORIGIN');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'WEB'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_ORIGIN');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'PROBLEM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_TYPE');
UPDATE "anv".reference SET sorder = 2WHERE code = 'FEATURE_REQUEST'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_TYPE');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'QUESTION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CASE_TYPE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'DRAFT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SOLUTION_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'REVIEWED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SOLUTION_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'DUPLICATE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SOLUTION_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'COMPLATE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'PLANNING'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'ACTIVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'INACTIVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'HIGHEST'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_PRIORITY');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_PRIORITY');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'NORMAL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_PRIORITY');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'LOW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_PRIORITY');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'LOWEST'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_PRIORITY');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'COMPLETED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'DEFERED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'NOT_STARTED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'IN_PROGRESS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_STATUS');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'WAITING_ON_SOME_ONE_ELSE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CRM_TASK_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'FULL TIME'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EMPLOYMENT_MODE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'PART TIME'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_EMPLOYMENT_MODE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'SINGLE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MARTIAL_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'MARRIED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MARTIAL_STATUS');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'WEEK_MONTH_WEEK'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'WEEK_MONTH');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'WEEK_MONTH_MONTH'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'WEEK_MONTH');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'WEEK_MONTH_YEAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'WEEK_MONTH');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'TIME_TYPES_FULL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TIME_TYPES');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'TIME_TYPES_PART'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'TIME_TYPES');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'DAILY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_RECURRING_PERIOD');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'WEEKLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_RECURRING_PERIOD');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'MONTHLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_RECURRING_PERIOD');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'YEARLY'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_RECURRING_PERIOD');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'DRAFT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MESSAGE_STATUSES');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'SENT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MESSAGE_STATUSES');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'QUEUED'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MESSAGE_STATUSES');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'IN_PROGRESS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_MESSAGE_STATUSES');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'LESS_THAN_20_000'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 2 WHERE code = '20_000_TO_50_000'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 3 WHERE code = '50_000_TO_100_000'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 4 WHERE code = '100_000_TO_500_000'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 5 WHERE code = '500_000_TO_1_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 6 WHERE code = 'ONE_TO_2.5_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 7 WHERE code = '2.5_TO_5_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 8 WHERE code = '5_TO_10_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 9 WHERE code = '10_TO_20_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 10 WHERE code = '20_TO_50_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 11 WHERE code = '50_TO_100_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 12 WHERE code = '100_TO_500_MILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 13 WHERE code = '500_TO_ONE_BILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');
UPDATE "anv".reference SET sorder = 14 WHERE code = 'OVER_ONE_BILLION'
AND parentid = (SELECT id FROM "anv".reference WHERE code = 'CONTACT_ANNUAL_REVENUE');

UPDATE "anv".reference SET sorder = 1 WHERE code = '_TASK_PRIORITY_HIGH' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_TASK_PRIORITY');
UPDATE "anv".reference SET sorder = 2 WHERE code = '_TASK_PRIORITY_MEDIUM' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_TASK_PRIORITY');
UPDATE "anv".reference SET sorder = 3 WHERE code = '_TASK_PRIORITY_LOW' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_TASK_PRIORITY');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'NOT_CONTACTED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'ATTEMPTED_TO_CONTACT' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'CONTACTED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'CONTACT_IN_FUTURE' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'PRE_QUALIFIED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');
UPDATE "anv".reference SET sorder = 6 WHERE code = 'JUNK_LEAD' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');
UPDATE "anv".reference SET sorder = 7 WHERE code = 'LOST_LEAD' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_LEAD_STATUS');

UPDATE "anv".reference SET sorder = 7 WHERE code = 'CLOSED_WON' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 1 WHERE code = 'QUALIFICATION' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'NEEDS_ANALYSIS' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'VALUE_PROPOSITION' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'ID_DECISION_MAKERS' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'PROPOSAL_PRICE_QUOTE' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 6 WHERE code = 'NEGOTIATION_REVIEW' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 8 WHERE code = 'CLOSED_LOST' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');
UPDATE "anv".reference SET sorder = 9 WHERE code = 'CLOSED_LOST_TO_COMPETITION' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_OPPORTUNITY_STAGE');

UPDATE "anv".reference SET sorder = 1 WHERE code = 'DRAFT' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 2 WHERE code = 'SUBMITTED_TO_MANAGER' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 3 WHERE code = 'APPROVE' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 4 WHERE code = 'REJECT' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 5 WHERE code = 'MANAGER_REJECT' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 6 WHERE code = 'CLIENT_APPROVE' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 7 WHERE code = 'OPEN' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 8 WHERE code = 'PAID' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 9 WHERE code = 'OVER_DUE' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 10 WHERE code = 'REVERSED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 11 WHERE code = 'CONVERTED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 12 WHERE code = 'RECEIVED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 13 WHERE code = 'PICKED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 14 WHERE code = 'PACKED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 15 WHERE code = 'SHIPPED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 16 WHERE code = 'SALE_ORDER' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');
UPDATE "anv".reference SET sorder = 17 WHERE code = 'INVOICE_STATUS_INVOICED' AND
parentid = (SELECT id FROM "anv".reference WHERE code = 'INVOICE_STATUS');

UPDATE "anv".reference SET sorder = 1, code = 'FULL_TIME' WHERE code = 'FULL TIME' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_EMPLOYMENT_MODE');
UPDATE "anv".reference SET sorder = 1, code = 'PART_TIME' WHERE code = 'PART TIME' AND
parentid = (SELECT id FROM "anv".reference WHERE code = '_EMPLOYMENT_MODE');