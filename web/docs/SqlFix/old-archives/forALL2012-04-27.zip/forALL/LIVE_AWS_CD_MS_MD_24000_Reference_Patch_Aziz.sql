update "anv".reference set name = 'Document upload to project' where code = 'DOC_UPLOAD_TO_PROJECT_CATEGORY';
update "anv".reference set name = 'Document upload to issue' where code = 'DOC_UPLOAD_TO_ISSUE_CATEGORY';
update "anv".reference set code = replace(code,' ', '_')where code like '% %';