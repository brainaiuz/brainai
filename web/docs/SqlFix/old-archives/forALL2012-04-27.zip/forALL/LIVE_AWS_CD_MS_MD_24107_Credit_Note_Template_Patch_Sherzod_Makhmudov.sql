DELETE FROM defaultlayout where formid='creditnote';

INSERT INTO defaultlayout(formid,layout) VALUES('creditnote','<div>
    <!--Start Content Place-->
    <div>
        <!-- <div class="contentPlaceCover"> -->
        <div class="contentBar tool-invoice c-block invoice-width">
            <div class="contentScroll">
                <table cellspacing="0" cellpadding="0" class="bindContent">
                    <tr>
                        <td class="mainBar">
                            <div class="invoice-block">
                                <div class="sect clear group">
                                    <div class="invoice-customer">
                                        $$label:crmaccount$$
                                        $$input:crmaccount$$
                                    </div>
                                    <div class="invoice-date">
                                        $$label:date$$
                                        $$input:date$$
                                    </div>
                                    <div class="invoice-due-date">
                                        $$label:duedate$$
                                        $$input:duedate$$
                                    </div>
                                </div>
                                <div class="sect clear group">
                                    <div class="invoice-title">
                                        $$label:title$$
                                    </div>
                                    <div class="invoice-num">
                                        $$label:number$$
                                        $$input:number$$
                                    </div>
                                </div>
                                <div class="sect clear group">
                                    <div class="invoice-bill-to">
                                        <div class="addresshead">
                                            $$label:billaddress$$
                                            $$input:billaddress$$
                                            <div class="add-edit-links">
                                                $$input:addbilladdress$$ $$input:editbilladdress$$
                                            </div>
                                        </div>
                                        $$input:billaddressdata$$
                                    </div>
                                    <div id="invoiceshipto" class="invoice-ship-to">
                                        <div class="addresshead">
                                            $$label:mailaddress$$
                                            $$input:mailaddress$$
                                            <div class="add-edit-links">
                                                $$input:addmailaddress$$ $$input:editmailaddress$$
                                            </div>
                                        </div>
                                        $$input:mailaddressdata$$
                                    </div>
                                </div>
                                <div style="padding: 10px 0 60px 0">
                                    <div class="invoice-amounts">
                                        $$label:taxcalc$$
                                        $$input:taxcalc$$
                                    </div>
                                </div>
                                <div class="invoice-products">
                                    $$input:itemtable$$
                                </div>
                                <div class="invoice-paymentpanel">
                                    <div class="invoice-paymentsave">
                                        $$input:paymentpanel$$
                                    </div>
                                    <div class="invoice-paymentexrate">
                                        $$input:paymentexratepanel$$
                                    </div>
                                </div>
                                <div class="invoice-subtotal">
                                    <span class="corner lt"></span>
                                    <span class="corner rt"></span>
                                    <span class="corner lb"></span>
                                    <span class="corner rb"></span>
                                    $$input:totalstable$$
                                </div>
                                <div class="invoice-btns-row">
                                    <div class="invoice-btn-save">
                                        $$input:saveButton$$
                                    </div>
                                    <div class="invoice-btn-save-approve">
                                        $$input:saveAndApproveButton$$
                                    </div>
                                    <div class="invoice-btn-approve">
                                        $$input:approveAndSendButton$$
                                    </div>
                                    <div class="invoice-btn-pdf">
                                        $$input:pdfVersionButton$$
                                    </div>
                                </div>
                            </div>
                        </td>
                        <!-- End  col -->
                        <td class="sidebar">
                            <div class="inv-OptBar">
                                <div class="optBarBlock">
                                    <table class="">
                                        <tbody>
                                        <tr>
                                            <td class="exRate" colspan="2">
                                                $$input:baserate$$
                                                $$input:exrate$$
                                                $$input:currency$$
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </td>
                        <!-- End  col -->
                    </tr>
                </table>
            </div>
        </div>
        <!-- End contentBar -->
    </div>
    <!-- End contentPlaceCover -->
</div>');