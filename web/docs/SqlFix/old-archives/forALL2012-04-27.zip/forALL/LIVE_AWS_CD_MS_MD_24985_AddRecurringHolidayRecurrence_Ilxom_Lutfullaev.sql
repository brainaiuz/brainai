alter table recurrencejob drop column busobjecttype;
alter table recurrencejob drop column jobtype;
insert into recurrencejob(id, name) values(12, 'Recurring Holiday');