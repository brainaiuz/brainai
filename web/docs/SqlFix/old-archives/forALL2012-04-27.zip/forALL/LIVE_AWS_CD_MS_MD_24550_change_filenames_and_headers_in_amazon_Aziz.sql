--Uploaddan keyin browserda mana bu linkni run qilib yuborish kerak.
--Bu script amazondagi fayllarni companylarni papkalariga tashlab, headerlarini tugirlab chiqadi.
--  Loglada kurinadi, 3-4 soat vaqt olishi mumkin.
http://app.kpi.com/changeAmazonFilename.html