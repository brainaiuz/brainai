 SELECT tt2.startdate,tt2.enddate,tmpsummary.* FROM  "1".timetrack tt2
 inner join (
      SELECT mu.id as employeeid,to_char(tt.startdate,'yyyy-mm-dd') as date, tt.statusid,rf.code, text(sum(date_trunc('minute', tt.enddate)-date_trunc('minute', tt.startdate))),
	tsi.starttime,tsi.endtime,mu.firstname ||' ' || mu.lastname, tmptsh.timespent,t.id, t.name  
	FROM 
	"1".timetrack tt 
 left outer join "1".teamemployee te on (tt.employeeid=te.employeeid) 
 left outer join "1".team t on (t.id=te.teamid) 
 left outer join "1".employee e on (e.id=tt.employeeid) 
 left outer join "1".myuser mu on (mu.id=e.id) 
 left outer join "1".timeslotitem tsi on (tsi.timeslotid=e.timeslotid) 
 left outer join "1".reference rf on(rf.id=tt.statusid) 
 left outer join 
	(SELECT tsh.employeeid as employeeid, to_char(tsh.date,'yyyy-mm-dd') as date, sum(tsh.timespent) as timespent 
	FROM "1".timesheet tsh left outer join "1".myuser mu1 on (mu1.id=tsh.employeeid) 
	left outer join "1".team t on (t.id=tsh.teamid) 
	WHERE tsh.timespent >0 and mu1.deleted<>true  
	and tsh.employeeid=65  and (tsh.date between 'Mon Feb 27 19:00:00 GMT 2012' and 'Fri Mar 16 18:59:59 GMT 2012') 
	GROUP BY tsh.employeeid,to_char(tsh.date,'yyyy-mm-dd') ) tmptsh 
ON e.id=tmptsh.employeeid and tmptsh.date=to_char(tt.startdate,'yyyy-mm-dd')
 
	WHERE mu.deleted<>true  and e.id=65  and (tt.startdate between 'Mon Feb 27 19:00:00 GMT 2012' and 'Fri Mar 16 18:59:59 GMT 2012') 
	and te.isdeleted<>true and t.isdeleted<>true  
	and EXTRACT(dow FROM tt.startdate)=tsi.day 
	GROUP BY  mu.id, to_char(tt.startdate,'yyyy-mm-dd'), 
	tt.statusid,rf.code,tsi.starttime,tsi.endtime,mu.firstname ||' ' || mu.lastname, tmptsh.timespent,t.id, t.name  ) tmpsummary 
	ON ( tt2.employeeid=tmpsummary.employeeid  and tmpsummary.date=to_char(tt2.startdate,'yyyy-mm-dd')  
	and tt2.statusid=tmpsummary.statusid and tmpsummary.date='2012-03-07') 