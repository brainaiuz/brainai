--Globalauth Database
update hostbasedsetting
set googleappsconsumerkey =
'All:1030510329229.apps.googleusercontent.com;Workspace:;ProjectManagement:;Hrms:692728198320.apps.googleusercontent.com;Crm:1092255882369.apps.googleusercontent.com;Accounting:841824559599.apps.googleusercontent.com;Payroll:;Documents:;Dashboard:;',
googleappsconsumersecret =
'All:SaGoLyqE6fHMaGwIrz3DvVDU;Workspace:;ProjectManagement:;Hrms:W1q8sFuoxbHmPZrU6OpLT6iL;Crm:pWtQGuwYZ3/gfYerJ3mKCoAU;Accounting:MB0i0Oi2zufY3_C3o0pysAuL;Payroll:;Documents:;Dashboard:;'
where hostname = 'app.workforcetrack.com';

update hostbasedsetting
set googleappsconsumerkey =
'All:1067007797308.apps.googleusercontent.com;Workspace:;ProjectManagement:;Hrms:589177723149.apps.googleusercontent.com;Crm:134202596391.apps.googleusercontent.com;Accounting:617922738560.apps.googleusercontent.com;Payroll:;Documents:;Dashboard:;',
googleappsconsumersecret =
'All:nkzh0HXq/GzUzaCBjBwhRCft;Workspace:;ProjectManagement:;Hrms:+FJMr/EYMR5xGqWCgsVi/j6i;Crm:F3OJEKWlMZ-Vdc1eGK6aXVlD;Accounting:u1SKmIfaj_Mjs9jHBCg37oFJ;Payroll:;Documents:;Dashboard:;'
where hostname = 'aws.workforcetrack.com' or hostname = 'localhost:8080';