ALTER TABLE hostbasedsetting ADD COLUMN productname character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN logoimage character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN helphost character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN email character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN skype character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN phone character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN address character varying(1000);
ALTER TABLE hostbasedsetting ADD COLUMN pdflogo character varying(1000);


update hostbasedsetting set productname='Workforcetrack' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set logoimage='/workforcelogo2.png' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set helphost='workforcetrack.com' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set email='support@workforcetrack.com' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set skype='workforce.team' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set phone='+44(0)207 096 1245' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set address='Kings Avenue Bromley BR1 4HN - UK' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set pdflogo='/i/wfm_logo.png' where hostname like ('%workforce%') or hostname like '%localhost%';
update hostbasedsetting set logoimage='/workforcelogo_ru.png' where hostname like ('%workforcetrack.ru');

update hostbasedsetting set productname='EzyAdmin' where hostname like ('%ezyadmin%');
update hostbasedsetting set logoimage='/customisation/ezyadmin/images/ezyadminlogo.jpg' where hostname like ('%ezyadmin%');
update hostbasedsetting set helphost='ezyadmin.com' where hostname like ('%ezyadmin%');
update hostbasedsetting set email='ezyadmin@ezymedia.com' where hostname like ('%ezyadmin%');
update hostbasedsetting set skype='abror.khasanov' where hostname like ('%ezyadmin%');
update hostbasedsetting set phone='+44 (0)843 006 7596' where hostname like ('%ezyadmin%');
update hostbasedsetting set address='Kings Avenue Bromley BR1 4HN - UK' where hostname like ('%ezyadmin%');
update hostbasedsetting set pdflogo='/customisation/ezyadmin/images/ezyadminlogo.jpg' where hostname like ('%ezyadmin%');