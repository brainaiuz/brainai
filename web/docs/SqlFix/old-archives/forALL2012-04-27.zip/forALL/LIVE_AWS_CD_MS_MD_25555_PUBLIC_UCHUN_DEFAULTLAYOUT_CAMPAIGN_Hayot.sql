<div class="contentBar" style="padding:0 10px;">

    <div id="click1" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('click1');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')&gt;=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title"><div class="gwt-HTML">CAMPAIGN INFORMATION</div></h3>

        <fieldset class="slideDown-content group labelLine">
            <div class="halfSet-1 left">
                <div class="row">
                    $$label:CRM_CAMPAIGN_ASSIGNEE$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_ASSIGNEE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_NAME$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_NAME$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_STARTDATE$$
                    <div class="field">$$input:CRM_CAMPAIGN_STARTDATE$$</div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_EXPECTEDREVENUE$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_EXPECTEDREVENUE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_ACTUALCOST$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_ACTUALCOST$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_NUMBERSENT$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_NUMBERSENT$$
                    </div>
                </div>
            </div>

            <div class="halfSet-1 left">
                <div class="row">
                    $$label:CRM_CAMPAIGN_TYPE$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_TYPE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_STATUS$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_STATUS$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_ENDDATE$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_ENDDATE$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_BUDGETCOST$$
                    <div class="field">
                        $$input:CRM_CAMPAIGN_BUDGETCOST$$
                    </div>
                </div>

                <div class="row">
                    $$label:CRM_CAMPAIGN_EXPECTEDRESPONSE$$
                    <div class="field">$$input:CRM_CAMPAIGN_EXPECTEDRESPONSE$$</div>
                </div>
            </div>
        </fieldset>

    </div>

    <div id="click2" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('click2');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')&gt;=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:CRM_NOTE$$</h3>

        <fieldset class="slideDown-content group nobrd">
            <div class="halfSet-1 left">
                $$input:CRM_NOTE$$
            </div>
        </fieldset>

    </div>

</div>