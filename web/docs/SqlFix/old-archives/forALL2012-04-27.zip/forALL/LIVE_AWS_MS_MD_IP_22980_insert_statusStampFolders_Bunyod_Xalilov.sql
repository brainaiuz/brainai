insert into "anv".reference(code,name,parentid) VALUES('FOR_APPROVE','FOR_APPROVE',(select id from "anv".reference    where code='_LOGO_TYPE'));
insert into "anv".reference(code,name,parentid) VALUES('FOR_RECEIVED','FOR_RECEIVED',(select id from "anv".reference    where code='_LOGO_TYPE'));
insert into "anv".reference(code,name,parentid) VALUES('FOR_OVERDUE','FOR_OVERDUE',(select id from "anv".reference    where code='_LOGO_TYPE'));
insert into "anv".reference(code,name,parentid) VALUES('FOR_PAID','FOR_PAID',(select id from "anv".reference    where code='_LOGO_TYPE'));