

--for needed companies -- OR so'ralgan company ga apply qilinadi!!!

insert into "COMPANY_ID".genericSettings (key, value) values ('SHOW_WITH_COMPLETED_PROJECTS', 'YES');
