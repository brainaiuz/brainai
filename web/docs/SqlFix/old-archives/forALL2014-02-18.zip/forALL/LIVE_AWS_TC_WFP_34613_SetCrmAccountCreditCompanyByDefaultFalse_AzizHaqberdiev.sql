--schemaUpdatedan keyin urilsin
update "anv".crmaccount set creditcompany = false;