insert into myupdatetype(code, description) values('COMPANY_CUSTOM_FIELD', 'All company custom fields related updates');

insert into myupdatetype(code, description, parentid) values('COMPANY_CUSTOM_FIELD_ADD', 'Records when user has added custom field', (select id from myupdatetype where code='COMPANY_CUSTOM_FIELD'));
insert into myupdatetype(code, description, parentid) values('COMPANY_CUSTOM_FIELD_EDIT', 'Records when user has edited custom field', (select id from myupdatetype where code='COMPANY_CUSTOM_FIELD'));
insert into myupdatetype(code, description, parentid) values('COMPANY_CUSTOM_FIELD_DELETE', 'Records when user has deleted custom field', (select id from myupdatetype where code='COMPANY_CUSTOM_FIELD'));