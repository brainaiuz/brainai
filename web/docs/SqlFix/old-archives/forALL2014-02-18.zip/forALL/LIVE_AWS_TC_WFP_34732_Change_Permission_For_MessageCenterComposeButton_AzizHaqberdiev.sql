insert into permission (code, context, ismainmenu, name, sorder, parent, iscore) 
values ('CRM_MESSAGE_CENTER_COMPOSE_BUTTON', 'CRM', false, 'Compose button in Message Center', 
(select sorder from permission where code = 'CRM_TASKS_COMPOSE'), (select parent from permission where code = 'CRM_TASKS_COMPOSE'), false); 
-----rename permissioncode of rolepermission
update "anv".rolepermission set permissioncode = 'CRM_MESSAGE_CENTER_COMPOSE_BUTTON' where permissioncode = 'CRM_TASKS_COMPOSE';
-----for zero schema
update "0".rolepermission set permissioncode = 'CRM_MESSAGE_CENTER_COMPOSE_BUTTON' where permissioncode = 'CRM_TASKS_COMPOSE';


delete from permission where code = 'CRM_TASKS_COMPOSE';
update permission set name = 'Crm Tasks Issue' where code = 'CRM_TASKS_ISSUE';


