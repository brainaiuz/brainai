-- Public schemaga apply qilinadi
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS', 'ACCOUNTING', 'Purchase Order Full List Access', 7, false, (select id from permission where code='ACCOUNTING_PURCHASE_ORDER_LIST'));
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'ACCOUNTING', 'Purchase Order Full Edit Access', 8, false, (select id from permission where code='ACCOUNTING_PURCHASE_ORDER_LIST'));
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS', 'ACCOUNTING', 'Supplier List Full Access', 5, false, (select id from permission where code='ACCOUNTING_SUPPLIER_LIST'));


--Company schemalarga apply qilinadi
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS','DR','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS','ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_LIST_ACCESS','ACCOUNTANT','ALLOW');

INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS','DR','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS','ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_PURCHASE_ORDER_FULL_EDIT_ACCESS','ACCOUNTANT','ALLOW');

INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS','DR','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS','ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode, rolecode, access) VALUES('ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS','ACCOUNTANT','ALLOW');
