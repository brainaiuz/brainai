update "anv".wfp_block set properties='<?xml version="1.0" encoding="UTF-8"?>
<fields>
<field>
<name>cssclass</name>
</field>
</fields>', widget_guid ='00e35d19-c4de-4cd8-922d-97227c0896e8' where external_guid ='999cc3e2-5e2e-45bb-a97a-9bff61302308';