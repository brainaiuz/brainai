
-- SCHEMAUPDATE DAN KIYIN YURGIZILSIN--

--1--
update "anv".wfp_custom_entity_group entitygroup set website_id =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=entitygroup.customentity_guid);
update "anv".wfp_custom_forms customform set website_id =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=customform.custom_entity_guid);
update "anv".wfp_custom_list_entity_look_up entitylookup set website_id =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=entitylookup.entity_guid);
update "anv".wfp_meta_data metadata set website_id =(select query.websiteID from "anv".websiteQuery query where query.queryName=metadata.queryname limit 1 );
update "anv".wfp_page_block pageblock set website_id =(select page.website_id from "anv".wfp_page page where page.external_guid=pageblock.page_guid);
update "anv".wfp_page_layout_block pagelayoutblock set website_id =(select pagelayout.website_id from "anv".wfp_page_layout pagelayout where pagelayout.external_guid=pagelayoutblock.pageLayout_guid);
update "anv".wfp_page_layout_holders pagelayoutholders set website_id =(select pagelayout.website_id from "anv".wfp_page_layout pagelayout where pagelayout.id=pagelayoutholders.page_layout_id);
update "anv".wfp_website_layout_block websitelayoutblock set website_id =(select websitelayout.websiteID from "anv".wfp_website_layout websitelayout where websitelayout.external_guid =websitelayoutblock.websitelayout_guid);
update "anv".wfp_website_layout_holders websitelayoutholders set website_id =(select websitelayout.websiteID from "anv".wfp_website_layout websitelayout where websitelayout.external_guid=websitelayoutholders.websitelayout_guid );
update "anv".wfp_website_menu websitemenu set website_id =(select menugroup.website_id from "anv".wfp_menu_group menugroup where menugroup.external_guid =websitemenu.menugroup_guid);
update "anv".websiteQuery websiteuery set websiteID =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=websiteuery.customEntityGUID);
update "anv".wfp_draggableposition draggableposition set website_id =(select block.website_id from "anv".wfp_block block where block.external_guid=draggableposition.draggablecontainer_block_guid);
update "anv".wfp_chat_message chatmessage set webisteID =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=chatmessage.entityid);

--1-- dan kiyin yurgizilsin

ALTER TABLE "anv".wfp_block DROP CONSTRAINT wfp_block_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_block ADD CONSTRAINT wfp_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_custom_entity_group DROP CONSTRAINT wfp_custom_entity_group_uuid_key CASCADE;
ALTER TABLE "anv".wfp_custom_entity_group ADD CONSTRAINT wfp_custom_entity_group_uuid_key UNIQUE (uuid, website_id);

ALTER TABLE "anv".wfp_custom_entities DROP CONSTRAINT wfp_custom_entities_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_custom_entities ADD CONSTRAINT wfp_custom_entities_external_guid_key UNIQUE (external_guid, websiteid);

ALTER TABLE "anv".wfp_custom_forms DROP CONSTRAINT wfp_custom_forms_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_custom_forms ADD CONSTRAINT wfp_custom_forms_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_custom_list_entity_look_up DROP CONSTRAINT wfp_custom_list_entity_look_up_pkey CASCADE;
ALTER TABLE "anv".wfp_custom_list_entity_look_up ADD CONSTRAINT wfp_custom_list_entity_look_up_pkey UNIQUE (id, website_id);

ALTER TABLE "anv".wfp_menu_group DROP CONSTRAINT wfp_menu_group_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_menu_group ADD CONSTRAINT wfp_menu_group_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_page DROP CONSTRAINT wfp_page_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_page ADD CONSTRAINT wfp_page_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_page_block DROP CONSTRAINT wfp_page_block_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_page_block ADD CONSTRAINT wfp_page_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_page_layout DROP CONSTRAINT wfp_page_layout_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_page_layout ADD CONSTRAINT wfp_page_layout_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_page_layout_block DROP CONSTRAINT wfp_page_layout_block_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_page_layout_block ADD CONSTRAINT wfp_page_layout_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_website_layout DROP CONSTRAINT wfp_website_layout_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_website_layout ADD CONSTRAINT wfp_website_layout_external_guid_key UNIQUE (external_guid, websiteid);

ALTER TABLE "anv".wfp_website_layout_block DROP CONSTRAINT wfp_website_layout_block_external_guid_key CASCADE;
ALTER TABLE "anv".wfp_website_layout_block ADD CONSTRAINT wfp_website_layout_block_external_guid_key UNIQUE (external_guid, website_id);

ALTER TABLE "anv".wfp_website_script DROP CONSTRAINT wfp_website_script_name_key CASCADE;
ALTER TABLE "anv".wfp_website_script ADD CONSTRAINT wfp_website_script_name_key UNIQUE (name, websiteid);
