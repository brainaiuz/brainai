
--for zero schema

update "0".reference set description = '100' where code = 'Q_QUALIFICATION_EXPERT';
update "0".reference set description = '75' where code = 'Q_QUALIFICATION_MIDDLE';
update "0".reference set description = '25' where code = 'Q_QUALIFICATION_BEGINNER';

--for all schemas

update "anv".reference set description = '100' where code = 'Q_QUALIFICATION_EXPERT';
update "anv".reference set description = '75' where code = 'Q_QUALIFICATION_MIDDLE';
update "anv".reference set description = '25' where code = 'Q_QUALIFICATION_BEGINNER';