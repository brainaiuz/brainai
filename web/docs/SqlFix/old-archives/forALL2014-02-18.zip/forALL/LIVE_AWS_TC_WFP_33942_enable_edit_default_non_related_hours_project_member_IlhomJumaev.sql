

--for 31741 (EGYPTIAN CPAs) -- OR so'ralgan company ga apply qilinadi!!!

insert into "COMPANY_ID".genericSettings (key, value) values ('ENABLE_EDIT_DEFAULT_NON_RELATED_HOURS_PROJECT_MEMBERS', 'YES');