--for public schema
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('CRM_ACCOUNTS_EDIT_ALL_ACCOUNTS', 'CRM', 'Edit All Accounts', 10, false, (select id from permission where code='CRM_ACCOUNTS_LIST'));
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('CRM_ACCOUNTS_DELETE_ALL_ACCOUNTS', 'CRM', 'Delete All Accounts', 10, false, (select id from permission where code='CRM_ACCOUNTS_LIST'));

INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('CRM_CONTACTS_EDIT_ALL_CONTACTS', 'CRM', 'Edit All Contacts', 4, false, (select id from permission where code='CRM_CONTACTS_LIST'));
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('CRM_CONTACTS_DELETE_ALL_CONTACTS', 'CRM', 'Delete All Contacts', 4, false, (select id from permission where code='CRM_CONTACTS_LIST'));



--for zero schema
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_EDIT_ALL_ACCOUNTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_EDIT_ALL_ACCOUNTS', 'DR', 'ALLOW');

insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_DELETE_ALL_ACCOUNTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_DELETE_ALL_ACCOUNTS', 'DR', 'ALLOW');

insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_EDIT_ALL_CONTACTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_EDIT_ALL_CONTACTS', 'DR', 'ALLOW');

insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_DELETE_ALL_CONTACTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_DELETE_ALL_CONTACTS', 'DR', 'ALLOW');




--for all schemas
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_EDIT_ALL_ACCOUNTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_EDIT_ALL_ACCOUNTS', 'DR', 'ALLOW');

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_DELETE_ALL_ACCOUNTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_ACCOUNTS_DELETE_ALL_ACCOUNTS', 'DR', 'ALLOW');

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_EDIT_ALL_CONTACTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_EDIT_ALL_CONTACTS', 'DR', 'ALLOW');

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_DELETE_ALL_CONTACTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('CRM_CONTACTS_DELETE_ALL_CONTACTS', 'DR', 'ALLOW');
