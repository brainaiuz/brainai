INSERT INTO "anv".genericsettings(key, value) values('MASS_MAIL_TRACK_URLS', 'NO');
