update "anv".address set deleted = false where deleted is null;
alter table "anv".address alter column deleted set default false;