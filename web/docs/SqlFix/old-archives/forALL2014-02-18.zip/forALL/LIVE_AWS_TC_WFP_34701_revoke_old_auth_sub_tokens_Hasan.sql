DELETE FROM "anv".googlecalendar;   
update "anv".employeeevent set googleId = null;
update "anv".employeetask set googleId = null;
DELETE FROM "anv".googlecontacts;   
update "anv".crmContact set googleId = null;
update "anv".googledocumentssettings set googledocumentsid = null;
DELETE FROM "anv".googledocuments;