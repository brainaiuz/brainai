INSERT INTO "anv".genericsettings(key, value) values('ENABLE_DASHBOARDS_AND_CUSTOM_REPORTS', 'NO');
