--for zero schema

insert into "0".reference(code, name, description, parentid ,sorder, id ) values(
        'TASK_COMPLETED_CATEGORY',
        'Task completion',
        'for Task completion',
        (select id from "0".reference where code='_EMAIL_TEMPLATE_CATEGORY'), 35,
        (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference))));

------------------------------------------------------------------------------------------------------------------------

-- --for all schemas
insert into "anv".reference(code, name, description, parentid ,sorder, id ) values(
        'TASK_COMPLETED_CATEGORY',
        'Task completion',
        'for Task completion',
        (select id from "anv".reference where code='_EMAIL_TEMPLATE_CATEGORY'), 35,
        (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference))));

------------------------------------------------------------------------------------------------------------------------