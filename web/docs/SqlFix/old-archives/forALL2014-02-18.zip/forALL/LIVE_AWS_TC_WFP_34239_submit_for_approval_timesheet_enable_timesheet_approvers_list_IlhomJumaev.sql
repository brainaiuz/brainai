

--for so'ralgan company ga apply qilinadi!!!

insert into "COMPANY_ID".genericSettings (key, value) values ('ENABLE_TIMESHEET_APPROVERS_DROPDOWN', 'YES');