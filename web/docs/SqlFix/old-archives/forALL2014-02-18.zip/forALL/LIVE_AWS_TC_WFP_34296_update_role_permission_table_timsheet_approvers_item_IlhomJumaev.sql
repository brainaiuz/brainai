
--for zero schema.

update "0".rolepermission set access = 'ALLOW' where permissioncode = 'PM_TIMESHEET_APPROVERS';

--for all schemas

update "anv".rolepermission set access = 'ALLOW' where permissioncode = 'PM_TIMESHEET_APPROVERS';
