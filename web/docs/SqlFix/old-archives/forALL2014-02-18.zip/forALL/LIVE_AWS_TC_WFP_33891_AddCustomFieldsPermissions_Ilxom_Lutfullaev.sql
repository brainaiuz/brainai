create or replace function "anv".addCustomFielsPermissions() returns void as $body$
    declare
      role record;
      ccf record;
BEGIN
  FOR ccf IN SELECT cf.* FROM (select id from "anv".companyCustomFieldsSettings order by id asc) as cf
    loop
      FOR role IN SELECT rl.* FROM (select id from "anv".role order by id asc) as rl
        loop
          insert into "anv".customfield_permissions(customfield_id, role_id) values(ccf.id, role.id);
        end loop;
    end loop;
  end;
$body$ language plpgsql;

drop function if exists "anv".addCustomFielsPermissions();