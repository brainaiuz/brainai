alter table "anv".corporateemailmessage drop constraint if exists "fk163f31d0a1446c54";

drop function if exists "anv".removeDuplicateEmailTrackers();
create or replace function "anv".removeDuplicateEmailTrackers() returns integer as $body$
    declare 
      r record; 
      ids record; 
      tracker_maxID integer;
      tracker_code varchar;
BEGIN
  FOR r IN SELECT t.* FROM (select distinct code, max(id) as maxid, count(id) as count_ from "anv".corpemailtracker group by code) as t where t.count_ > 1
    loop
      tracker_maxID = r.maxid;
      tracker_code = r.code;
      --(select id from "anv".corpemailtracker s where s.code = tracker_code)
      update "anv".crmcase set tracker_id = tracker_maxID where tracker_id in (select id from "anv".corpemailtracker s where s.code = tracker_code);
      update "anv".emails set tracker_id = tracker_maxID where tracker_id in (select id from "anv".corpemailtracker s where s.code = tracker_code);
      update "anv".emailattachments set emailtracker_id = tracker_maxID where emailtracker_id in (select id from "anv".corpemailtracker s where s.code = tracker_code);
      update "anv".relation set toid = tracker_maxID where totype = 'EMAIL_TRACKER' and toid in (select id from "anv".corpemailtracker s where s.code = tracker_code);
      update "anv".relation set fromid = tracker_maxID where fromtype = 'EMAIL_TRACKER' and fromid in (select id from "anv".corpemailtracker s where s.code = tracker_code);
--    update "anv".corporateemailmessage set tracker_id = tracker_maxID where tracker_id in (select id from "anv".corpemailtracker s where s.code = tracker_code);
      delete from "anv".corpemailtracker where id in (select id from "anv".corpemailtracker s where s.code = tracker_code) and id <> tracker_maxID;
      RAISE NOTICE '>>>>>>>>%|%|',tracker_maxID, tracker_code;
    end loop;
  
  return null;
end;
$body$ language plpgsql;
update "anv".myuser set deleted = false where deleted is null or (select "anv".removeDuplicateEmailTrackers()) is not null;

update "anv".corpemailtracker set counter = (select max(counter) from "anv".corpemailtracker) + 1  where id =(select id from "anv".corpemailtracker where counter is not null order by id desc limit 1);


