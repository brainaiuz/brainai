insert into region (countryid, code, name) values ((select id from country where name = 'Russia'), 'TATARSTAN', 'Tatarstan');
