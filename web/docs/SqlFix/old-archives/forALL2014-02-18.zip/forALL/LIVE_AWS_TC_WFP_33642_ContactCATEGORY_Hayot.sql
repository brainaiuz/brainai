update "anv".contactcategory set foldertype = 111 where foldertype = 5;
update "anv".contactcategory set foldertype = 5 where foldertype = 6;
--select * from "anv".contactcategory order by id;
delete from "anv".crmcontact_contactcategory where crmcontact_id in (select id from "anv".crmcontact where contacttype = 5 and deleted is not true);
insert into "anv".crmcontact_contactcategory(crmcontact_id, categories_id) select id, (select id from "anv".contactcategory where foldertype = 5) from "anv".crmcontact where contacttype = 5 and deleted is not true;
