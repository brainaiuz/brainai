INSERT INTO permission(code, context, name, sorder, ismainmenu, parent) VALUES ('GANTTCHART_EDIT_PERMISSION', 'PM', 'GanttChart edit permission', 1, false, (SELECT id from permission  where code ='PM_PROJECT_GANTT_CHART'));

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'DR', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'PMOFPR', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'BMOFPR', 'ALLOW');

--for zero
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'DR', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'PMOFPR', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('GANTTCHART_EDIT_PERMISSION', 'BMOFPR', 'ALLOW');