update "35231".reference set parentid = (select id from "35231".reference where code='_CASE_REASON') where parentid = (select id from "35231".reference where code='_CASE_ORIGIN') and relative is not null;
insert into "35231".reference (code, name,parentid,sorder) values('FAX','Fax',(select id from "35231".reference where code='_CASE_ORIGIN'),1);
insert into "35231".reference (code, name,parentid,sorder) values('IN_PERSON','In-Person',(select id from "35231".reference where code='_CASE_ORIGIN'),1);
