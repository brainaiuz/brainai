
-- Schema Update dan kiyin urilsin!!!

update "anv".wfp_page set pagelayout_website_id = website_id;
update "anv".wfp_page set siteLayout_websiteID = website_id;

update "anv".wfp_page_block set block_website_id = website_id;
update "anv".wfp_page_block set page_website_id = website_id;

update "anv".wfp_page_layout_block set block_website_id = website_id;
update "anv".wfp_page_layout_block set layout_website_id = website_id;

update "anv".wfp_website_layout_block set block_website_id = website_id;
update "anv".wfp_website_layout_block set websiteLayout_websiteID = website_id;

update "anv".wfp_website_layout_holders set websiteLayout_websiteID = website_id;

update "anv".wfp_website_menu set page_website_id = website_id;

update "anv".wfp_website_template set websiteLayout_websiteID = website_id;

update "anv".companypdftemplate pdftemplate set customEntity_websiteID =(select customentity.websiteid from "anv".wfp_custom_entities customentity where customentity.external_guid=pdftemplate.customentity_guid);
