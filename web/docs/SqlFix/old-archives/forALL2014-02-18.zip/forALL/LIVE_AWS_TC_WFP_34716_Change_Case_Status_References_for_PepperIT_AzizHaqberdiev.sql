update "27241".reference set deleted = false where id = 355 and code = 'CS_CLOSED';
update "27241".reference set deleted = false, sorder = 3, name = 'Waiting for customer' where id = 524 and code = 'REPLIED';
update "27241".reference set deleted = false, sorder = 2, name = 'Waiting for PepperIT' where id = 525 and code = 'WAITING_FOR_REPLY';
update "27241".reference set deleted = false, name = 'New' where id = 527 and code = 'NEW';

update "27241".crmcase set status = 525 where id in (select id from "27241".crmcase where status = 980);
update "27241".crmcase set status = 524 where id in (select id from "27241".crmcase where status = 981);
update "27241".crmcase set status = 527 where id in (select id from "27241".crmcase where status = 1156);

update "27241".reference set deleted = true where id = 980;
update "27241".reference set deleted = true where id = 981;
update "27241".reference set deleted = true where id = 1156;
