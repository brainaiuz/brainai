INSERT INTO permission(code, context, name, sorder, ismainmenu, parent) VALUES ('HRMS_SEE_ALL_DEPARTMENT_LIST', 'HRMS', 'HRMS see all department list', 1, false, (SELECT id from permission  where code ='HRMS_DEPARTMENT'));


insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('HRMS_SEE_ALL_DEPARTMENT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('HRMS_SEE_ALL_DEPARTMENT_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('HRMS_SEE_ALL_DEPARTMENT_LIST', 'DR', 'ALLOW');


--for zero

insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('HRMS_SEE_ALL_DEPARTMENT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('HRMS_SEE_ALL_DEPARTMENT_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('HRMS_SEE_ALL_DEPARTMENT_LIST', 'DR', 'ALLOW');