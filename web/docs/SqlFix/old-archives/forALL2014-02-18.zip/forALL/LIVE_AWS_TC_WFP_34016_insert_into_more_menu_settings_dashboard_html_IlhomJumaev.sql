
insert into "anv".moreMenuSettings (actionName,enabled,linkName) values ('Dashboard.html', true, 'Dashboard.html');