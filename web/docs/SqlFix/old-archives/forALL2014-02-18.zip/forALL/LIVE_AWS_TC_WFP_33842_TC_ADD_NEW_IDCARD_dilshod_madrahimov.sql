INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('WIRE LINE AND RIGGER BANKSMAN',6,'/tc/images/12-1.png','/tc/images/12-2.png');

