
-- schema update dan keyin uriladi

insert into "anv".converted_items(quote_id, invoice_id)  select converted_item_id, id from "anv".invoice where converted_item_id is not null and deleted is not true;