  --first
UPDATE "35231".REFERENCE SET deleted = true where parentid = (select id from "1".reference where code='_CASE_REASON');

  --second

insert into "35231".reference (name,parentid,sorder,relative) values('Appointments',(select id from "35231".reference where code='_CASE_REASON'),1,(select array_to_string(array_agg(id),',')  from "35231".reference where code in ('CUSTOM_SERVICE','PATIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('Directions',(select id from "35231".reference where code='_CASE_REASON'),2,(select id  from "35231".reference where code in ('CUSTOM_SERVICE')));
insert into "35231".reference (name,parentid,sorder,relative) values('Complaints',(select id from "35231".reference where code='_CASE_REASON'),3,(select array_to_string(array_agg(id),',')  from "35231".reference where code in ('CUSTOM_SERVICE','PHLEBOTOMY','LOGISTICS','SUPPLIES','SALES_CASE_TYPE','HR_CASE_TYPE')));
insert into "35231".reference (name,parentid,sorder,relative) values('Pricing',(select id from "35231".reference where code='_CASE_REASON'),4, (select  array_to_string(array_agg(id),',')  from "35231".reference where code in ('CUSTOM_SERVICE','PATIENT_BILLING','CLIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('Statements',(select id from "35231".reference where code='_CASE_REASON'),5,(select id  from "35231".reference where code in ('CLIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('Error Processing',(select id from "35231".reference where code='_CASE_REASON'),6,(select id  from "35231".reference where code in ('CLIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('Payments',(select id from "35231".reference where code='_CASE_REASON'),7,(select  array_to_string(array_agg(id),',')  from "35231".reference where code in ('CLIENT_BILLING','PATIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('General Inquiries',(select id from "35231".reference where code='_CASE_REASON'),8,(select id  from "35231".reference where code in ('CLIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('Refunds',(select id from "35231".reference where code='_CASE_REASON'),9,(select id  from "35231".reference where code in ('PATIENT_BILLING')));
insert into "35231".reference (name,parentid,sorder,relative) values('eMail',(select id from "35231".reference where code='_CASE_REASON'),10,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('eLab',(select id from "35231".reference where code='_CASE_REASON'),11,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('New Accounts',(select id from "35231".reference where code='_CASE_REASON'),12,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Harvest',(select id from "35231".reference where code='_CASE_REASON'),13,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('TimeClock Plus',(select id from "35231".reference where code='_CASE_REASON'),14,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('EMR Interfacing',(select id from "35231".reference where code='_CASE_REASON'),15,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Result Delivery',(select id from "35231".reference where code='_CASE_REASON'),16,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Printing',(select id from "35231".reference where code='_CASE_REASON'),17,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Faxing',(select id from "35231".reference where code='_CASE_REASON'),18,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Label Printing',(select id from "35231".reference where code='_CASE_REASON'),19,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('General',(select id from "35231".reference where code='_CASE_REASON'),20,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Training',(select id from "35231".reference where code='_CASE_REASON'),21,(select  array_to_string(array_agg(id),',')  from "35231".reference where code in ('IT_SUPPORT','LAB_SUPPORT','PHLEBOTOMY','SALES_CASE_TYPE','HR_CASE_TYPE')));
insert into "35231".reference (name,parentid,sorder,relative) values('Computer Management',(select id from "35231".reference where code='_CASE_REASON'),22,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('New Installations',(select id from "35231".reference where code='_CASE_REASON'),23,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Internet',(select id from "35231".reference where code='_CASE_REASON'),24,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Office Issues',(select id from "35231".reference where code='_CASE_REASON'),25,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Networking',(select id from "35231".reference where code='_CASE_REASON'),26,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Lab Instruments',(select id from "35231".reference where code='_CASE_REASON'),27,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('LIS Issues',(select id from "35231".reference where code='_CASE_REASON'),28,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Door Access',(select id from "35231".reference where code='_CASE_REASON'),29,(select id  from "35231".reference where code in ('IT_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Security',(select id from "35231".reference where code='_CASE_REASON'),30,(select id  from "35231".reference where code in ('IT_SUPPORT')));


insert into "35231".reference (name,parentid,sorder,relative) values('Add-on',(select id from "35231".reference where code='_CASE_REASON'),31,(select id  from "35231".reference where code in ('LAB_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Test Questions',(select id from "35231".reference where code='_CASE_REASON'),32,(select id  from "35231".reference where code in ('LAB_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Lab Results',(select id from "35231".reference where code='_CASE_REASON'),33,(select id  from "35231".reference where code in ('LAB_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('Test Requirements',(select id from "35231".reference where code='_CASE_REASON'),34,(select id  from "35231".reference where code in ('LAB_SUPPORT')));
insert into "35231".reference (name,parentid,sorder,relative) values('General Support',(select id from "35231".reference where code='_CASE_REASON'),35,(select id  from "35231".reference where code in ('LAB_SUPPORT')));

insert into "35231".reference (name,parentid,sorder,relative) values('Pickups',(select id from "35231".reference where code='_CASE_REASON'),36,(select id  from "35231".reference where code in ('LOGISTICS')));
insert into "35231".reference (name,parentid,sorder,relative) values('Deliveries',(select id from "35231".reference where code='_CASE_REASON'),37,(select id  from "35231".reference where code in ('LOGISTICS')));
insert into "35231".reference (name,parentid,sorder,relative) values('Accidents',(select id from "35231".reference where code='_CASE_REASON'),39,(select id  from "35231".reference where code in ('LOGISTICS')));
insert into "35231".reference (name,parentid,sorder,relative) values('Incidents',(select id from "35231".reference where code='_CASE_REASON'),40,(select id  from "35231".reference where code in ('LOGISTICS')));

insert into "35231".reference (name,parentid,sorder,relative) values('Request',(select id from "35231".reference where code='_CASE_REASON'),41,(select id  from "35231".reference where code in ('SUPPLIES')));
insert into "35231".reference (name,parentid,sorder,relative) values('Preparation',(select id from "35231".reference where code='_CASE_REASON'),42,(select id  from "35231".reference where code in ('SUPPLIES')));
insert into "35231".reference (name,parentid,sorder,relative) values('Delivery',(select id from "35231".reference where code='_CASE_REASON'),43,(select id  from "35231".reference where code in ('SUPPLIES')));
insert into "35231".reference (name,parentid,sorder,relative) values('Shipping',(select id from "35231".reference where code='_CASE_REASON'),44,(select id  from "35231".reference where code in ('SUPPLIES')));

insert into "35231".reference (name,parentid,sorder,relative) values('Assignment',(select id from "35231".reference where code='_CASE_REASON'),45,(select id  from "35231".reference where code in ('PHLEBOTOMY')));
insert into "35231".reference (name,parentid,sorder,relative) values('Collection Problem',(select id from "35231".reference where code='_CASE_REASON'),46,(select id  from "35231".reference where code in ('PHLEBOTOMY')));
insert into "35231".reference (name,parentid,sorder,relative) values('Staffing',(select id from "35231".reference where code='_CASE_REASON'),47,(select id  from "35231".reference where code in ('PHLEBOTOMY')));

insert into "35231".reference (name,parentid,sorder,relative) values('New Business',(select id from "35231".reference where code='_CASE_REASON'),49,(select id  from "35231".reference where code in ('SALES_CASE_TYPE')));
insert into "35231".reference (name,parentid,sorder,relative) values('Follow-Up',(select id from "35231".reference where code='_CASE_REASON'),50,(select id  from "35231".reference where code in ('SALES_CASE_TYPE')));

insert into "35231".reference (name,parentid,sorder,relative) values('New Employees',(select id from "35231".reference where code='_CASE_REASON'),51,(select id  from "35231".reference where code in ('HR_CASE_TYPE')));
insert into "35231".reference (name,parentid,sorder,relative) values('Termination',(select id from "35231".reference where code='_CASE_REASON'),52,(select id  from "35231".reference where code in ('HR_CASE_TYPE')));
insert into "35231".reference (name,parentid,sorder,relative) values('Other',(select id from "35231".reference where code='_CASE_REASON'),53 , (select  array_to_string(array_agg(id),',')  from "35231".reference where code in ('CUSTOM_SERVICE','PATIENT_BILLING','CLIENT_BILLING','IT_SUPPORT','LAB_SUPPORT','LOGISTICS' ,'SUPPLIES','PHLEBOTOMY','SALES_CASE_TYPE','HR_CASE_TYPE')));