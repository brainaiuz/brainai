--schemaUpdatedan kn urilsin
update "anv".coursePrice set stopFee=0;
update "anv".scheduledcourse set stopFee=0;
