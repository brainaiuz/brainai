
--for public data
insert into myupdatetype(code, description, parentid) values('USER_EMPLOYEE_TERMINATE', 'Records when user terminated employee', (select id from myupdatetype where code='USER'));
