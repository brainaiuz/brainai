

--for exlibris and needed companies -- OR so'ralgan company ga apply qilinadi!!!

insert into "COMPANY_ID".genericSettings (key, value) values ('ENABLE_EXLIB_PERCENTAGE_OF_EMPLOYEES_IN_THE_PROJECT_WORKLOAD', 'YES');
insert into "COMPANY_ID".genericSettings (key, value) values ('ENABLE_EXLIB_PROJECT_EMPLOYEE_UPDATES_HISTORY', 'YES');