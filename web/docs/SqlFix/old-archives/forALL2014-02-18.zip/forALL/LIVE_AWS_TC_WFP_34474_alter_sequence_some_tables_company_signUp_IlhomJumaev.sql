
--for all schemas -- in create schema

update updater set id = 1 where (SELECT setval('"anv".trustee_id_seq', (SELECT max(id) FROM "anv".trustee)) is not null); 

update updater set id = 1 where (SELECT setval('"anv".trusteegroup_id_seq', (SELECT max(id) FROM "anv".trusteegroup)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".relationship_id_seq', (SELECT max(id) FROM "anv".relationship)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".taskpermission_id_seq', (SELECT max(id) FROM "anv".taskpermission)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".taskpolicy_id_seq', (SELECT max(id) FROM "anv".taskpolicy)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".folderpermission_id_seq', (SELECT max(id) FROM "anv".folderpermission)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".folderpolicy_id_seq', (SELECT max(id) FROM "anv".folderpolicy)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".contactpermission_id_seq', (SELECT max(id) FROM "anv".contactpermission)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".contactpolicy_id_seq', (SELECT max(id) FROM "anv".contactpolicy)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".assessmenttemplate_id_seq', (SELECT max(id) FROM "anv".assessmenttemplate)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".skillgroup_id_seq', (SELECT max(id) FROM "anv".skillgroup)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".skill_id_seq', (SELECT max(id) FROM "anv".skill)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".assessmenttemplateskill_id_seq', (SELECT max(id) FROM "anv".assessmenttemplateskill)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".paymentmethod_id_seq', (SELECT max(id) FROM "anv".paymentmethod)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".companyemailnotificationsettings_id_seq', (SELECT max(id) FROM "anv".companyemailnotificationsettings)) is not null); 

update updater set id = 1 where (SELECT setval('"anv".category_id_seq', (SELECT max(id) FROM "anv".category)) is not null); 
update updater set id = 1 where (SELECT setval('"anv".role_id_seq', (SELECT max(id) FROM "anv".role)) is not null); 