--for zero schema!!!

--after apply  - 1
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION "0".candidateFormReferenceForExist() RETURNS integer AS $$
BEGIN
	IF EXISTS (SELECT * FROM "0".reference WHERE (code = 'CANDIDATE_FORM' or code = 'Candidate Form') AND parentid = (select id from "0".reference where code = '_WEB_FORM') )
	THEN
	ELSE
       insert into "0".reference(code, name, description, parentid, sorder, id )
       values(
        'CANDIDATE_FORM',
        'Candidate Form',
        'for Candidate Form',
        (select id from "0".reference where code = '_WEB_FORM'), 4,
        (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference))) );
	END IF;
	RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;
------------------------------------------------------------------------------------------------------------------------
--after apply  - 2
update "0".myuser set deleted = false where deleted is null and (select "0".candidateFormReferenceForExist()) is not null;
------------------------------------------------------------------------------------------------------------------------
--and         - 3
 --DROP FUNCTION "0".candidateFormReferenceForExist();

------------------------------------------------------------------------------------------------------------------------
--after   - 4
update "0".reference set name='Candidate Form' where id= (select id from "0".reference where name='CANDIDATE_FORM');
update "0".reference set code='CANDIDATE_FORM' where id= (select id from "0".reference where code='Candidate Form');

------------------------------------------------------------------------------------------------------------------------

--for all schemas!!!

--after apply  - 1
------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION "anv".candidateFormReferenceForExist() RETURNS integer AS $$
BEGIN
	IF EXISTS (SELECT * FROM "anv".reference WHERE (code = 'CANDIDATE_FORM' or code = 'Candidate Form') AND parentid = (select id from "anv".reference where code = '_WEB_FORM') )
	THEN
	ELSE
       insert into "anv".reference(code, name, description, parentid, sorder, id )
       values(
        'CANDIDATE_FORM',
        'Candidate Form',
        'for Candidate Form',
        (select id from "anv".reference where code = '_WEB_FORM'), 4,
        (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference))) );
	END IF;
	RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;
------------------------------------------------------------------------------------------------------------------------
--after apply  - 2
update "anv".myuser set deleted = false where deleted is null and (select "anv".candidateFormReferenceForExist()) is not null;
------------------------------------------------------------------------------------------------------------------------
--and         - 3
 --DROP FUNCTION "anv".candidateFormReferenceForExist();

------------------------------------------------------------------------------------------------------------------------
--after   - 4
update "anv".reference set name='Candidate Form' where id= (select id from "anv".reference where name='CANDIDATE_FORM');
update "anv".reference set code='CANDIDATE_FORM' where id= (select id from "anv".reference where code='Candidate Form');

------------------------------------------------------------------------------------------------------------------------