/*Public Schema uchun*/
INSERT INTO accounttemplate(code, codestring, key, name, accounttypeid) VALUES('2302','2302',2302,'Income Tax Payable', (select id from accounttype where code='LIABILITY'));

/*Company schemalar uchun*/
INSERT INTO "anv".account(accountcode, codestring, key, name, accounttypeid) VALUES(2302,'2302',2302,'Income Tax Payable', (select id from accounttype where code='LIABILITY'));