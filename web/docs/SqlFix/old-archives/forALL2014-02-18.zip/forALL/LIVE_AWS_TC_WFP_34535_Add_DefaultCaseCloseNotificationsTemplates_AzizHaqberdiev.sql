INSERT INTO "anv"."emailtemplate"(deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, messagehtml, name, sendemail, subject, categoryid, fromusername, customentityaction, activitytext, entitytype, toemailquery, code, locale)
VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Dear ${userto},</p>

        <p>Please be informed that "${changeduser}" has closed the following case.</p>

        <table width="370" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
            <tr>
                <td width="368" valign="top">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="368" valign="top">
                                <table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%"
                                       style="vertical-align:top;">
                                    <tr>
                                        <td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
                     font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;"
                                            colspan="2">
                                            Case Details
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Case Number:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${casenumber}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Company:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${crmaccount}
                                        </td>
                                    </tr>
                                    <tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Case Subject:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${subject}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Reported by:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${reportedby}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Reported Date:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${reporteddate}
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p>Click
            <a href="{$caselink}">here</a>
            or copy and paste following link below:
        </p>

        <p>* If you are not able to click on the link, you can instead copy and paste the following address in to your
            web browser:
        </p>

        <p style="border-bottom: 1px solid #cccccc">&nbsp;</p>
        <p>
            <span style="color: #0033FF">$HOST/Crm.html?link=$link</span>
        </p>
        ${description}', 'Default Case Close Notification', null, 'CRM Case Closed Notification [$casenumber]',
          (SELECT min(id) FROM "anv".reference r WHERE code = 'CASE_CLOSE_NOTIFICATION_CATEGORY'),
          null, null, null, null, null, 'DEFAULT_CASE_CLOSE_NOTIFICATION_CATEGORY', 'en');


INSERT INTO "anv"."emailtemplate"(deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, messagehtml, name, sendemail, subject, categoryid, fromusername, customentityaction, activitytext, entitytype, toemailquery, code, locale)
VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Dear ${userto},</p>

        <p>Please be informed that "${changeduser}" has $status the reported case.</p>

        <table width="370" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
            <tr>
                <td width="368" valign="top">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                            <td width="368" valign="top">
                                <table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%"
                                       style="vertical-align:top;">
                                    <tr>
                                        <td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
                     font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;"
                                            colspan="2">
                                            Case Details
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Company:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${crmaccount}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Case Subject:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${subject}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Case Number:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${casenumber}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Reported Date:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${reporteddate}
                                        </td>
                                    </tr>
                                    <tr>
                                        <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                     font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                                            Note:
                                        </td>
                                        <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                     font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                                            ${casenote}
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p style="border-bottom: 1px solid #cccccc">&nbsp;</p>
        ${description}', 'Default Case Close Notification (to reporter)', null, 'CRM Case Closed Notification [$casenumber]',
          (SELECT min(id) FROM "anv".reference r WHERE code = 'CASE_CLOSE_NOTIFICATION_CATEGORY_FOR_REPORTER'),
          null, null, null, null, null, 'DEFAULT_CASE_CLOSE_NOTIFICATION_CATEGORY_FOR_REPORTER', 'en');

