--for public schema
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'ACCOUNTING', 'Build Assembly', 8, false, (select id from permission where code='ACCOUNTING_PRODUCT_LIST'));


--for zero schema
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'DR', 'ALLOW');
insert into "0".rolepermission ("permissioncode", "rolecode", "access") VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'ACCOUNTANT', 'ALLOW');


--for all schemas
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'DR', 'ALLOW');
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('ACCOUNTING_BUILD_ASSEMBLY', 'ACCOUNTANT', 'ALLOW');