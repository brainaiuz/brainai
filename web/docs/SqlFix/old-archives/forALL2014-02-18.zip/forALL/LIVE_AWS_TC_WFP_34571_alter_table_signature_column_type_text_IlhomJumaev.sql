---for zero schema

alter table "0".signature alter column signature type text;

--for all schemas

alter table "anv".signature alter column signature type text;