--for public schema
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_TIMESHEET_APPROVERS', 'PM', 'Timesheet approvers', 1, false, (select id from permission where code='PM_TIMESHEET'));


--for zero schema
--for timesheet approvers
insert into "0".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'ADMIN');
insert into "0".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'DR');
insert into "0".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'PMOFPR');
insert into "0".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'BMOFPR');


--for all schemas
--for timesheet approvers
insert into "anv".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'ADMIN');
insert into "anv".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'DR');
insert into "anv".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'PMOFPR');
insert into "anv".rolepermission ("permissioncode", "rolecode") VALUES ('PM_TIMESHEET_APPROVERS', 'BMOFPR');
