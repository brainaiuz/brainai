INSERT INTO "anv".userfilter (isdefault, filterid, userid)  select isdefaultfilter, id, userid from "anv".facetfilter;

ALTER TABLE  "anv".facetfilter  DROP  COLUMN isdefaultfilter;
ALTER TABLE  "anv".facetfilter  DROP  COLUMN userid;


//for zero

ALTER TABLE  "0".facetfilter  DROP  COLUMN isdefaultfilter;
ALTER TABLE  "0".facetfilter  DROP  COLUMN userid;

//Permissions

INSERT INTO permission(code, context, "name", sorder, ismainmenu, iscore) VALUES ('ADD_SYSTEM_FILTER', 'CRM', 'Add system facet filter', 1, false, true);

INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "access") VALUES('ADD_SYSTEM_FILTER','ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES('ADD_SYSTEM_FILTER','ADMIN', 'ALLOW');
