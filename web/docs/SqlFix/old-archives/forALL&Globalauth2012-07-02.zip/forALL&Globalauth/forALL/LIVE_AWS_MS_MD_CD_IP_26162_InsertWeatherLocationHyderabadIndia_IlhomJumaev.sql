--apply to public schema
INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Hyderabad, India', 'INXX0057', 112);