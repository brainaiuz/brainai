--Hammasini bitta-bitta yurgiz

ALTER TABLE  "anv".crmAccount DROP COLUMN lastUpdateTime;

ALTER TABLE "anv".crmAccount rename column lastUpdatedDate to lastUpdateTime ;

update "anv".crmAccount set sasuuLastUpdatedTime=lastUpdateTime;


ALTER TABLE "anv".item drop column lastUpdateTime ;

ALTER TABLE "anv".item rename column lastUpdatedDate to lastUpdateTime ;

update "anv".item set sasuuLastUpdateddate=lastUpdateTime;




