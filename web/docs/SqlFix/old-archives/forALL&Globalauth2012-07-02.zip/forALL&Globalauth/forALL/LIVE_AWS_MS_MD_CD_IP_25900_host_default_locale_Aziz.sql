--Run for Globalauth database before starting Tomcat
ALTER TABLE hostbasedsetting ADD COLUMN defaultLocale character varying(255);
update hostbasedsetting set defaultLocale = 'en';
update hostbasedsetting set defaultLocale = 'ru' where hostname like '%workforcetrack.ru%';
update hostbasedsetting set defaultLocale = 'es' where hostname like '%smebu.com%';