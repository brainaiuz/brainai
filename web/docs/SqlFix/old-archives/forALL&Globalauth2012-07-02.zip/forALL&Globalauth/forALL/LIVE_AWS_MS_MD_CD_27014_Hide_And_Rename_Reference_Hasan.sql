<--Sxema updatedan keyin-->

update "anv".reference set shared='false' where code in('_TASK_DIFFICULTY', '_TASK_WEIGHT', '_MANAGEMENT_EXPERIENCE',
 '_PROJECT_LEADERSHIP_EXPERIENCE', '_INCIDENT_EMPLOYEE_TYPE', 'SUPPORTER', 'PARTICIPANT', 'ASSESSMENT_STATUS',
 '_SICK_STATUS', '_REASON', 'MESSAGE_STATUS', 'INVOICING_PERIOD', '_TASK_PRIORITY', '_UPLOAD_TYPE', '_LOGO_TYPE',
 '_SICK_TYPE','_COLLABORATOR_TYPE', '_ASSESSMENT_TYPE', '_HOLIDAY_REPEAT', '_BUG_STATUS', '_PERIOD_TYPE',
 '_SERVICE_TYPE', 'INSTANT_NOTIFICATION', 'TSREPORT_NOTIFICATION', '_PAYMENT_STATUS', '_ALERT_TYPE', '_CLIENT_TYPE_2',
 '_TIME_SHEET_ENTRY_STATUS', '_TIME_SHEET_APPROVAL_SESSION_STATUS', '_ATTACHMENT_TYPE', 'TAX_PERIOD', '_GOAL_CATEGORY',
 '_CRM_TASK_PRIORITY', '_CRM_TASK_STATUS', '_RECURRING_PERIOD', '_MESSAGE_STATUSES', '_MAIL_LIST_STATUSES', 'Send_Lead_Message_Status',
 '_LEAD_CUSTOM_FIELD1', '_LEAD_CUSTOM_FIELD2', 'INVOICEPAYMENT_STATUS', 'EMP_PAYROLL_SETTINGS_HISTORY_STATUS', 'EMP_PAYROLL_SETTINGS_METHODOFCHANGE',
 'PENSION_SCHEME_TYPE', 'PAYSLIP_STATUS', '_EMAIL_TEMPLATE_CATEGORY', '_RESOURCE_TYPE', '_BANK_ACCOUNT_TYPE',
 'EMAIL_FILTERS', 'EMAIL_TYPES', 'BUG_LABEL', 'SMS_TYPE', 'MESSAGE_CENTER_EMAIL_ATTACHMENT_TYPES', 'SMS_SERVICES',
 '_PERMISSION', 'SLA_RESPONSE_TIME', '_WEB_FORM', '_TIMETRACK_STATUS', '_EMPLOYEE_GRADE', '_PROJECT_LEADERSHIP_EXPERIENCE',
 'USER_ALERT_TYPE', 'REPORT_PERIOD', '_BUG_PRIORITY', '_SEND_LEAD_MESSAGE_STATUS', '_ATM_NEWS_CATEGORIES','OPPORTUNITY',
 'SLA_RESPONSE_TIME', 'POS_STATUS', 'REPORT_DAY', 'RELATED_TO_ISSUE') and parentid is null;

 update "anv".reference set name = 'Incident level' where name = '_INCIDENT_LEVEL';
 update "anv".reference set name = 'Leave request type' where name = '_LEAVE_REQUEST_TYPE';
 update "anv".reference set name = 'Company workarea' where name = '_COMPANY_WORKAREA';
 update "anv".reference set name = 'Issue status' where name = '_ISSUE_STATUS';
 update "anv".reference set name = 'Task priority' where name = '_TASK_PRIORITY';
 update "anv".reference set name = 'Company industry' where name = 'Industries';
 update "anv".reference set name = 'Task status' where code = '_TASK_STATUS';
 update "anv".reference set name = 'Product type' where code = '_PRODUCT_TYPE';
 update "anv".reference set name = 'Expense status' where code = 'EXPENSE_STATUS';
 update "anv".reference set name = 'Issue status' where code = '_ISSUE_STATUS';
 update "anv".reference set name = 'Issue priority' where code = '_ISSUE_PRIORITY';
 update "anv".reference set name = 'Lead status' where code = '_LEAD_STATUS';
 update "anv".reference set name = 'Lead source' where code = '_LEAD_SOURCE';
 update "anv".reference set name = 'Lead rating' where code = '_LEAD_RATING';
 update "anv".reference set name = 'Case priority' where code = '_CASE_PRIORITY';
 update "anv".reference set name = 'Case status' where code = '_CASE_STATUS';
 update "anv".reference set name = 'Case origin' where code = '_CASE_ORIGIN';
 update "anv".reference set name = 'Case type' where code = '_CASE_TYPE';
 update "anv".reference set name = 'Solution status' where code = '_SOLUTION_STATUS';
 update "anv".reference set name = 'Campaign type' where code = '_CAMPAIGN_TYPE';
 update "anv".reference set name = 'Campaign status' where code = '_CAMPAIGN_STATUS';
 update "anv".reference set name = 'Opportunity stage' where code = '_OPPORTUNITY_STAGE';
 update "anv".reference set name = 'Employment mode' where code = '_EMPLOYMENT_MODE';
 update "anv".reference set name = 'Marital status' where code = '_MARTIAL_STATUS';
 update "anv".reference set name = 'Opportunity type' where code = '_OPPORTUNITY_TYPE';
 update "anv".reference set name = 'CRM Account type' where code = '_CRM_ACCOUNT_TYPE';
 update "anv".reference set name = 'Ownership' where code = '_OWNERSHIP';
 update "anv".reference set name = 'Case reason' where code = '_CASE_REASON';
 update "anv".reference set name = 'type' where code = 'WEEK_MONTH';
 update "anv".reference set name = 'Employment mode' where code = 'TIME_TYPES';
 update "anv".reference set name = 'Job type' where code = 'REG_TEMP';
 update "anv".reference set name = 'SLA priority' where code = 'SLA_PRIORITY';
 update "anv".reference set name = 'SLA type' where code = 'SLA_TYPE';
 update "anv".reference set name = 'SLA reason' where code = 'SLA_REASON';
 update "anv".reference set name = 'Invoice custom type' where code = 'INVOICE_CUSTOM_TYPE';
 update "anv".reference set name = 'Incident status' where code = '_INCIDENT_STATUS';
 update "anv".reference set name = 'Ivoice status' where code = 'INVOICE_STATUS';
 update "anv".reference set name = 'Tax basis' where code = 'TAX_BASIS';
 update "anv".reference set description = 'Company industry' where code = '_NETWORK_CATEGORIES';