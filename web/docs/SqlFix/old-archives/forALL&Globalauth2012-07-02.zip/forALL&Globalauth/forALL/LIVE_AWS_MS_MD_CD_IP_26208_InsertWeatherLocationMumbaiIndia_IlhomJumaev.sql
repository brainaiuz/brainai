--apply to public schema

INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Mumbai, India', 'INXX0087', 112);
INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Navi Mumbai, India', 'INXX0382', 112);