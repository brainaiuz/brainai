--Public schema
--PM SECTION
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_COST', 'PM', 'Project Cost Details', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_BUDGET_SHEET', 'PM', 'Budget Sheet', 11, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_EMPLOYEE_RATE_HISTORY', 'PM', 'Employee Rate History', 12, false);