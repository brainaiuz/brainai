//schema update dan kyin

update "anv".role set isdeleted = false;