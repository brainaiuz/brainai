/*Bu patch faqat bir marta publicga patch qilinadi*/

/*1.*/
DELETE FROM defaultlayout where formid='BOOKINGITEMS';

/*2.*/
INSERT INTO defaultlayout(formid,layout) VALUES('BOOKINGITEMS','
<div class="productcontent">
    <div class="contentScroll">
        <table cellspacing="0" cellpadding="0" class="bindContent">
            <tr>
                <td class="mainBar">
                    <div class="invoice-block">

                        <fieldset class="slideDown-content group labelLine" style="display:block !important">
                            <div class="halfSet-1 left">

                                <div class="row">
                                    $$label:name$$
                                    <div class="field">
                                        $$input:name$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:number$$
                                    <div class="field">
                                        $$input:number$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:category$$
                                    <div class="field">
                                        $$input:category$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:status$$
                                    <div class="field">
                                        $$input:status$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:description$$
                                    <div class="field">
                                        $$input:description$$
                                    </div>
                                </div>

                                <div class="row">
                                <div class="gwt-HTML"> </div>
                                        <div class="field">
                                           <div class="lineBtnSet c buttonIcons" >
                                               $$input:savebutton$$
                                               $$input:cancelbutton$$
                                           </div>
                                        </div>
                                </div>

                            </div>
                        </fieldset>


                    </div>
                </td>

                <td>
                    <div class="row">
                        $$label:reservationHistory$$
                        <div class="field">
                          $$input:reservationHistory$$
                        </div>
                    </div>
                </td>

            </tr>
        </table>
    </div>
</div>
');



/*Bu patch faqat bir marta publicga patch qilinadi*/

/*1.*/
DELETE FROM defaultlayout where formid='BOOKINGITEMSRESERVATION';

/*2.*/
INSERT INTO defaultlayout(formid,layout) VALUES('BOOKINGITEMSRESERVATION','
<div class="productcontent">
    <div class="contentScroll">
        <table cellspacing="0" cellpadding="0" class="bindContent">
            <tr>
                <td class="mainBar">
                    <div class="invoice-block">

                        <fieldset class="slideDown-content group labelLine" style="display:block !important">
                            <div class="halfSet-1 left">

                                <div class="row">
                                    $$label:reservedBy$$
                                    <div class="field">
                                        $$input:reservedBy$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:category$$
                                    <div class="field">
                                        $$input:category$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:bookingItem$$
                                    <div class="field">
                                        $$input:bookingItem$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:fromDate$$
                                    <div class="field">
                                        $$input:fromDate$$
                                    </div>
                                </div>

                                <div class="row">
                                    $$label:toDate$$
                                    <div class="field">
                                        $$input:toDate$$
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="field">
                                        $$input:addLink$$
                                    </div>
                                </div>

                            </div>
                        </fieldset>

                        <div class="lineBtnSet c buttonIcons" >
                            $$input:savebutton$$
                            $$input:cancelbutton$$
                        </div>
                    </div>
                </td>
                <td>
                    <div class="row">
                        $$label:reservationHistory$$
                        <div class="field">
                          $$input:reservationHistory$$
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</div>
');