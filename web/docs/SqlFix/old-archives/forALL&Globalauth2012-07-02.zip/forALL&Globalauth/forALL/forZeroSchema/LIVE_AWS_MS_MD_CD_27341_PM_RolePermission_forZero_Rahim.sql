
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_SALES_QUOTE', 'CREATOR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_INVOICE', 'CREATOR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL', 'CREATOR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_COMPOSE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EMAIL_TRASH', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASK_EMAIL_TRASH', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
