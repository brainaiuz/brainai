--Rahim akadan so'rab ur
delete from "0".reporting where id not in(select  max(id) from "0".reporting group by code);

ALTER TABLE "0".reporting ADD CONSTRAINT reporting_code_unique UNIQUE (code);

-- Schema update dan keyin urilsa maqsadga muvofiq bo`lardi :)
delete from rolereporttemplate;
insert into rolereporttemplate(role,reporttemplatecode) select r.code,rp.code from "1".role r, reporttemplate rp where rp.iscustom is not true;

insert into rolereporttemplate(role,companyid,reporttemplatecode)  select r.code, rp.companyid,rp.code from (select c.companyid,code  from reporttemplate rp inner join companyreporttemplates c on rp.id=c.reporttemplateid where rp.iscustom is true) rp, "1".role r;