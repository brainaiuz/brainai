--Schema Updatedan avval
ALTER TABLE "0".myuser_role DROP CONSTRAINT IF EXISTS fkf052883e16f4ef93;
ALTER TABLE "0".bmt_approval_workflow DROP CONSTRAINT IF EXISTS fk3294750578dc773a;
--Public schemaga 
ALTER TABLE role RENAME TO role_old;

--Schema updatedan keyin. 
--Bu patchni run qilgandan keyin, yana bir bor schema update qilib yuborish kerak.
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (1, NULL, 'Director', 'DR');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (2, NULL, 'Department Leader', 'TL');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (3, NULL, 'Project Manager', 'PM');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (4, NULL, 'HR Manager', 'HR');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (5, NULL, 'Administrator', 'ADMIN');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (6, NULL, 'Member', 'MEM');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (7, NULL, 'Client', 'CLIENT');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (8, NULL, 'One-off', 'ONE_OFF');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (9, NULL, 'Accountant', 'ACCOUNTANT');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (10, NULL, 'Sales Manager', 'SALESMAN');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (11, NULL, 'Customer Service Representative', 'CUSTOMER_SERVICE_REPRESENTATIVE');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (12, NULL, 'Sales Person', 'SALESPERSON');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (13, NULL, 'Admin (location)', 'ADMIN_LOCATION');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (14, NULL, 'Calendar Editor', 'CALENDAR_EDITOR');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (15, NULL, 'Calendar Viewer', 'CALENDAR_VIEWER');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (16, NULL, 'Chat Expert', 'CHAT_EXPERT');
INSERT INTO "0"."role" ("id", "description", "name", "code") VALUES (17, NULL, 'Timesheet Editor', 'TIMESHEET_EDITOR');
