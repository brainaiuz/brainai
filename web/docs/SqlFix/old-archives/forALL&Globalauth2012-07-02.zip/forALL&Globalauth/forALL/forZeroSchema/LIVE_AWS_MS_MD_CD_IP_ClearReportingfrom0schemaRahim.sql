delete from "0".dashlet;
delete from "0".reportingemployee;
delete from "0".reporting;
delete from "0".chart;