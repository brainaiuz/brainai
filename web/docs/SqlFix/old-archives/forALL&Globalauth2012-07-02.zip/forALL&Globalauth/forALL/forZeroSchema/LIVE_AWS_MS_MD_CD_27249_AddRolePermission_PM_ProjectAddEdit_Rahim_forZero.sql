--PM_PROJECT_ADD
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ADD', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ADD', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ADD', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ADD', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ADD', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ADD', 'PM', (SELECT id from "0".reference where code='ALLOW') );

--Private Schema
--PM_PROJECT_EDIT
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EDIT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EDIT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EDIT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EDIT', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EDIT', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EDIT', 'CREATOR', (SELECT id from "0".reference where code='ALLOW') );