 --add_permission_HRMS_FAXRIDDIN dan kiyin yurguzilsin Faxriddin--

-------------------------------------------- HRMS TAB -------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SECTION_TAB', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SECTION_TAB', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SECTION_TAB', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SECTION_TAB', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SECTION_TAB', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'HR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'DR', (SELECT id from "0".reference where code='ALLOW') );

--------------------------------------------EMPLOYEE PROFILE TAB -----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE_SUMMARY', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_INCIDENT_LIST', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'TL', (SELECT id from "0".reference where code='ALLOW') );

--------------------------------------------EMPLOYEE GOAL MANAGEMENT TAB-----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT_TAB', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

--------------------------------------------------------PERFORMANCE APPRAISALS TAB -----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_APPRAISALS_TAB', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_360_REVIEW', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SIMPLE_APPRAISALS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPRAISALS_ARCHIVE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

-----------------------------------------------------PERFORMANCE ATTENDANCE TRACKING TAB -----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING_TAB', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_HOME', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MY_ATTENDANCE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_REPORT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_REPORT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_REPORT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_REPORT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_LIVE_STATUS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_LIVE_STATUS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_LIVE_STATUS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_LIVE_STATUS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPROVE_LIVE_STATUS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_APPROVE_LIVE_STATUS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

--------------------------------------------HRMS EMPLOYEE LIST ACTIONS -----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_PROFILE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROFILE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROFILE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROFILE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROFILE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROFILE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROFILE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL_WEIGHTS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL_WEIGHTS', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_REMOVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_REMOVE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVATE_DEACTIVATE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVATE_DEACTIVATE', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES_EXPORT_TO_PDF', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES_EXPORT_TO_PDF', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES_EXPORT_TO_PDF', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES_EXPORT_TO_PDF', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES_EXPORT_TO_PDF', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEES_EXPORT_TO_PDF', 'TL', (SELECT id from "0".reference where code='ALLOW') );


--------------------------------------------HRMS DEPARTMENT LIST ACTIONS -----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPARTMENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPARTMENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPARTMENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPARTMENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_SUMMARY', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPARTMENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPARTMENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPARTMENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPARTMENT', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_REMOVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_NOTES', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_NOTES', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_NOTES', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_NOTES', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENTS_EXPORT_TO_PDF', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENTS_EXPORT_TO_PDF', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENTS_EXPORT_TO_PDF', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENTS_EXPORT_TO_PDF', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENTS_EXPORT_TO_PDF', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENTS_EXPORT_TO_PDF', 'TL', (SELECT id from "0".reference where code='ALLOW') );

-------------------------------------------------HRMS LOCATION LIST ACTIONS -------------------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_LOCATION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_LOCATION', 'DR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_LOCATION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_LOCATION', 'DR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_LOCATION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_LOCATION', 'DR', (SELECT id from "0".reference where code='ALLOW') );

--------------------------------------------PM EMPLOYEE LIST ACTIONS -----------------------------------------------------------------------
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_SUMMARY', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_EDIT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_EDIT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_EDIT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_EDIT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_EDIT', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_REMOVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_REMOVE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_REMOVE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_REMOVE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_REMOVE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

