--PM_DEPARTMENT_EDIT
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'TL', (SELECT id from "0".reference where code='ALLOW') );

--PM_DEPARTMENT_NOTES
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'CLIENT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_NOTES', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

--PM_DEPARTMENT_REMOVE
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_REMOVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );

--PM_DEPARTMENT_PDF
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'CLIENT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_PDF', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

--PM_DEPARTMENT_ADD
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_ADD', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_ADD', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_ADD', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_ADD', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
