insert into "0".reference(code, name) values('_PERMISSION', 'Permission');
insert into "0".reference(code, name, sorder, parentid) values('ALLOW', 'Allow', 1, (select id from "0".reference where code='_PERMISSION'));
insert into "0".reference(code, name, sorder, parentid) values('DENY', 'Deny', 2, (select id from "0".reference where code='_PERMISSION'));