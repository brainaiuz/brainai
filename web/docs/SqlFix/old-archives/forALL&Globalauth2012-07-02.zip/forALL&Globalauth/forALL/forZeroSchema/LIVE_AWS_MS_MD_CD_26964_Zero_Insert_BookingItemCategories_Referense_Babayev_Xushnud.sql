
UPDATE "anv".reference SET code='ROOM_CATEGORY', name='Room' where code='BIG_MEETING_ROOM';
UPDATE "anv".reference SET code='VEHICLE_CATEGORY', name='Vehicle' where code='SMAL_MEETING_ROOM';
insert into "anv".reference(code, name, sorder, parentid) values('COMPUTER_CATEGORY', 'Computer', 3, (select id from "anv".reference where code='_BOOKING_ITEM_CATEGORY'));

