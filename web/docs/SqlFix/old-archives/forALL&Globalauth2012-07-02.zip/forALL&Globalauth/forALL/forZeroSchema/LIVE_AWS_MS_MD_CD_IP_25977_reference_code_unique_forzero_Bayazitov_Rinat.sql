UPDATE "0".reference SET code = 'SMS_TYPE' WHERE code = 'SMS TYPE';

UPDATE "0".reference SET code = 'LR_TYPE_SICK_LEAVE' WHERE code = 'SICK_LEAVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "0".reference SET code = 'LR_TYPE_ANNUAL_LEAVE' WHERE code = 'ANNUAL_LEAVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "0".reference SET code = 'LR_TYPE_STUDY_LEAVE' WHERE code = 'STUDY_LEAVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "0".reference SET code = 'LR_TYPE_LATE' WHERE code = 'LATE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_LEAVE_REQUEST_TYPE');
UPDATE "0".reference SET code = 'LR_TYPE_SPECIAL' WHERE code = 'SPECIAL'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_LEAVE_REQUEST_TYPE');

UPDATE "0".reference SET code = 'REASON_TYPE_SICK_LEAVE' WHERE code = 'SICK_LEAVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_REASON');
UPDATE "0".reference SET code = 'REASON_TYPE_ANNUAL_LEAVE' WHERE code = 'ANNUAL_LEAVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_REASON');
UPDATE "0".reference SET code = 'REASON_TYPE_STUDY_LEAVE' WHERE code = 'STUDY_LEAVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_REASON');
UPDATE "0".reference SET code = 'REASON_TYPE_OTHER' WHERE code = 'OTHER'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_REASON');

UPDATE "0".reference SET code = 'MESSAGE_STATUS_PENDING' WHERE code = 'PENDING'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'MESSAGE_STATUS');
UPDATE "0".reference SET code = 'MESSAGE_STATUS_IN_PROGRESS' WHERE code = 'IN_PROGRESS'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'MESSAGE_STATUS');

UPDATE "0".reference SET code = 'ME_3_YEARS' WHERE code = '3_YEARS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_4_YEARS' WHERE code = '4_YEARS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_2_YEARS' WHERE code = '2_YEARS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_1_YEAR' WHERE code = '1_YEAR'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_LESS_THAN_1_YEAR' WHERE code = 'LESS_THAN_1_YEAR'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_MORE_THAN_5_YEARS' WHERE code = 'MORE_THAN_5_YEARS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_5_YEARS' WHERE code = '5_YEARS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');
UPDATE "0".reference SET code = 'ME_NO_EXPERIENCE' WHERE code = 'NO_EXPERIENCE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MANAGEMENT_EXPERIENCE');

UPDATE "0".reference SET code = 'EX_LESS_THAN_1_YEAR' WHERE code = 'LESS_THAN_1_YEAR'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_EXPERIENCE');

UPDATE "0".reference SET code = 'CS_INACTIVE' WHERE code = 'INACTIVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "0".reference SET code = 'CS_ACTIVE' WHERE code = 'ACTIVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CAMPAIGN_STATUS');

UPDATE "0".reference SET code = 'CT_ADVERTISEMENT' WHERE code = 'ADVERTISEMENT'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "0".reference SET code = 'CT_PUBLIC_RELATIONS' WHERE code = 'PUBLIC_RELATIONS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "0".reference SET code = 'CT_TRADE_SHOW' WHERE code = 'TRADE_SHOW'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "0".reference SET code = 'CT_EMAIL' WHERE code = 'EMAIL'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CAMPAIGN_TYPE');

UPDATE "0".reference SET code = 'BS_UNDER_INVESTIGATION' WHERE code = 'UNDER_INVESTIGATION'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_STATUS');
UPDATE "0".reference SET code = 'BS_NEW' WHERE code = 'NEW'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_STATUS');
UPDATE "0".reference SET code = 'BS_RESOLVED' WHERE code = 'RESOLVED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_STATUS');
UPDATE "0".reference SET code = 'BS_IN_PROGRESS' WHERE code = 'IN_PROGRESS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_STATUS');

UPDATE "0".reference SET code = 'MS_SENT' WHERE code = 'SENT'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MESSAGE_STATUSES');
UPDATE "0".reference SET code = 'MS_DRAFT' WHERE code = 'DRAFT'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MESSAGE_STATUSES');
UPDATE "0".reference SET code = 'MS_IN_PROGRESS' WHERE code = 'IN_PROGRESS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MESSAGE_STATUSES');

UPDATE "0".reference SET code = 'BP_HIGH' WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_PRIORITY');
UPDATE "0".reference SET code = 'BP_MEDIUM' WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_PRIORITY');
UPDATE "0".reference SET code = 'BP_LOW' WHERE code = 'LOW'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_PRIORITY');
UPDATE "0".reference SET code = 'BP_CRITICAL' WHERE code = 'CRITICAL'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_BUG_PRIORITY');

UPDATE "0".reference SET code = 'IS_HIGH' WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_ISSUE_PRIORITY');
UPDATE "0".reference SET code = 'IS_MEDIUM' WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_ISSUE_PRIORITY');
UPDATE "0".reference SET code = 'IS_LOW' WHERE code = 'LOW'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_ISSUE_PRIORITY');

UPDATE "0".reference SET code = 'CP_HIGH' WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CASE_PRIORITY');
UPDATE "0".reference SET code = 'CP_MEDIUM' WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CASE_PRIORITY');
UPDATE "0".reference SET code = 'CP_LOW' WHERE code = 'LOW'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CASE_PRIORITY');

UPDATE "0".reference SET code = 'IL_HIGH' WHERE code = 'HIGH'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_INCIDENT_LEVEL');
UPDATE "0".reference SET code = 'IL_MEDIUM' WHERE code = 'MEDIUM'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_INCIDENT_LEVEL');
UPDATE "0".reference SET code = 'IL_LOW' WHERE code = 'LOW'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_INCIDENT_LEVEL');

UPDATE "0".reference SET code = 'IS_RESOLVED' WHERE code = 'RESOLVED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_INCIDENT_STATUS');

UPDATE "0".reference SET code = 'CRM_PARTNER' WHERE code = 'PARTNER'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CRM_ACCOUNT_TYPE');

UPDATE "0".reference SET code = 'CR_PARTNER' WHERE code = 'PARTNER'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'CONTACT_RELATIONS');

UPDATE "0".reference SET code = 'CT_CLIENT' WHERE code = 'CLIENT'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_COLLABORATOR_TYPE');
UPDATE "0".reference SET code = 'CT_MANAGER' WHERE code = 'MANAGER'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_COLLABORATOR_TYPE');

UPDATE "0".reference SET code = 'HR_YEARLY' WHERE code = 'YEARLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_HOLIDAY_REPEAT');
UPDATE "0".reference SET code = 'HR_WEEKLY' WHERE code = 'WEEKLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_HOLIDAY_REPEAT');
UPDATE "0".reference SET code = 'HR_MONTHLY' WHERE code = 'MONTHLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_HOLIDAY_REPEAT');

UPDATE "0".reference SET code = 'SS_DRAFT' WHERE code = 'DRAFT'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_SOLUTION_STATUS');
UPDATE "0".reference SET code = 'SS_REVIEWED' WHERE code = 'REVIEWED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_SOLUTION_STATUS');
UPDATE "0".reference SET code = 'SS_DUPLICATE' WHERE code = 'DUPLICATE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_SOLUTION_STATUS');

UPDATE "0".reference SET code = 'SMS_SERVICE_CLICKATELL' WHERE name = 'Clickatell'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'SMS_SERVICES');
UPDATE "0".reference SET code = 'SMS_SERVICE_MVAAYOO' WHERE name = 'mVaayoo'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'SMS_SERVICES');

UPDATE "0".reference SET code = 'IP_QUARTERLY' WHERE code = 'QUARTERLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'INVOICING_PERIOD');
UPDATE "0".reference SET code = 'IP_WEEKLY' WHERE code = 'WEEKLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'INVOICING_PERIOD');
UPDATE "0".reference SET code = 'IP_MONTHLY' WHERE code = 'MONTHLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'INVOICING_PERIOD');

UPDATE "0".reference SET code = 'CT2_SUPPLIER' WHERE code = 'SUPPLIER'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CLIENT_TYPE_2');

UPDATE "0".reference SET code = 'ST_LEAD' WHERE code = 'LEAD'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'SMS_TYPE');
UPDATE "0".reference SET code = 'ST_CONTACT' WHERE code = 'CONTACT'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'SMS_TYPE');

UPDATE "0".reference SET code = 'RP_WEEKLY' WHERE code = 'WEEKLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'REPORT_PERIOD');
UPDATE "0".reference SET code = 'RP_MONTHLY' WHERE code = 'MONTHLY'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'REPORT_PERIOD');

UPDATE "0".reference SET code = 'ET_DRAFT' WHERE code = 'DRAFT'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'EMAIL_TYPES');

UPDATE "0".reference SET code = 'PST_OTHER' WHERE code = 'OTHER'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'PENSION_SCHEME_TYPE');

UPDATE "0".reference SET code = 'CS_ON_HOLD' WHERE code = 'ON_HOLD'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CASE_STATUS');
UPDATE "0".reference SET code = 'CS_CLOSED' WHERE code = 'CLOSED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CASE_STATUS');

UPDATE "0".reference SET code = 'PS_DRAFT' WHERE code = 'DRAFT'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'PAYSLIP_STATUS');

UPDATE "0".reference SET code = 'ST_PAID' WHERE code = 'PAID'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_SICK_TYPE');

UPDATE "0".reference SET code = 'IN_DISABLE' WHERE code = 'Disable'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'INSTANT_NOTIFICATION');

UPDATE "0".reference SET code = 'MLS_ACTIVE' WHERE code = 'ACTIVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_MAIL_LIST_STATUSES');

UPDATE "0".reference SET code = 'LRT_ACTIVE' WHERE code = 'ACTIVE'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_LEAD_RATING');

UPDATE "0".reference SET code = 'SS_APPROVED' WHERE code = 'APPROVED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_SICK_STATUS');

UPDATE "0".reference SET code = 'CW_OTHER' WHERE code = 'OTHER'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_COMPANY_WORKAREA');

UPDATE "0".reference SET code = 'OW_OTHER' WHERE code = 'OTHER'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_OWNERSHIP');

UPDATE "0".reference SET code = 'CTS_IN_PROGRESS' WHERE code = 'IN_PROGRESS'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CRM_TASK_STATUS');
UPDATE "0".reference SET code = 'CTS_COMPLETED' WHERE code = 'COMPLETED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CRM_TASK_STATUS');
UPDATE "0".reference SET code = 'CTS_NOT_STARTED' WHERE code = 'NOT_STARTED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_CRM_TASK_STATUS');

UPDATE "0".reference SET code = 'PS_COMPLETED' WHERE code = 'COMPLETED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_PROJECT_STATUS');
UPDATE "0".reference SET code = 'PS_NOT_STARTED' WHERE code = 'NOT_STARTED'
AND parentid = (SELECT id FROM "0".reference WHERE code = '_PROJECT_STATUS');

UPDATE "0".reference SET code = 'IS_REVERSED' WHERE code = 'REVERSED'
AND parentid = (SELECT id FROM "0".reference WHERE code = 'INVOICEPAYMENT_STATUS');

ALTER TABLE "0".reference ADD CONSTRAINT unique_reference_code UNIQUE(code);