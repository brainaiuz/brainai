!--schema update dan kyin-->
update "0".role set isentityspecific =false

<!-- ketidan buni urish kerak-->

insert into "0".role (code,name,issystem,isentityspecific) values('PMOFPR','PMofPR',true,true);
insert into "0".role (code,name,issystem,isentityspecific) values('DLOFPR','DLofPR',true,true);
insert into "0".role (code,name,issystem,isentityspecific) values('BMOFPR','BMofPR',true,true);

// oxirgi o`zgartirish
//AWS GA URDIM (RAHIM)
update "0".role set sorder=10 where code='ADMIN';
update "0".role set sorder=20 where code='DR';
update "0".role set sorder=30 where code='HR';
update "0".role set sorder=40 where code='ACCOUNTANT';
update "0".role set sorder=50 where code='ADMIN_LOCATION';
update "0".role set sorder=60 where code='SALESMAN';
update "0".role set sorder=70 where code='CUSTOMER_SERVICE_REPRESENTATIVE';
update "0".role set sorder=80 where code='SALESPERSON';
update "0".role set sorder=90 where code='TL';
update "0".role set sorder=100 where code='PM';
update "0".role set sorder=110 where code='MEM';
update "0".role set sorder=120 where code='CALENDAR_EDITOR';
update "0".role set sorder=130 where code='CALENDAR_VIEWER';
update "0".role set sorder=140 where code='TIMESHEET_EDITOR';
update "0".role set sorder=150 where code='PMOFPR';
update "0".role set sorder=160 where code='DLOFPR';
update "0".role set sorder=170 where code='BMOFPR';
update "0".role set sorder=180 where code='CLIENT';
update "0".role set sorder=190 where code='ONE_OFF';
update "0".role set sorder=200 where code='CHAT_EXPERT';