UPDATE "0".reference SET code='ROOM_CATEGORY', name='Room' where code='BIG_MEETING_ROOM';
UPDATE "0".reference SET code='VEHICLE_CATEGORY', name='Vehicle' where code='SMAL_MEETING_ROOM';
insert into "0".reference(code, name, sorder, parentid) values('COMPUTER_CATEGORY', 'Computer', 3, (select id from "0".reference where code='_BOOKING_ITEM_CATEGORY'));


