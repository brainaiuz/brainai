--Run for Globalauth database before starting Tomcat
ALTER TABLE hostbasedsetting ADD COLUMN paypalAccount character varying(255);
update hostbasedsetting set paypalAccount = 'sales@workforcetrack.com' where isliveenv = true;
update hostbasedsetting set paypalAccount = 'sheral_1228381642_biz@gmail.com' where isliveenv is null or isliveenv = false;
update hostbasedsetting set paypalAccount = 'paypal.soluntia.sa@soluntia.com' where hostname like '%smebu.com';