--Bu patclani xamma patchladan keyin urilsin
delete  from "28492".rolepermission where  permissioncode='PM_TASKS_REMOVE' or permissioncode='CRM_TASKS_REMOVE'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_REMOVE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_REMOVE', 'PM', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_REMOVE', 'BMOFPR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_REMOVE', 'CREATOR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_REMOVE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_REMOVE', 'PM', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_REMOVE', 'PMOFPR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_REMOVE', 'CREATOR', (SELECT id from "28492".reference where code='ALLOW') );


delete  from "28492".rolepermission where  permissioncode='PM_TASKS_ADD' or permissioncode='CRM_TASKS_ADD'
delete  from "24021".rolepermission where  permissioncode='PM_TASKS_ADD' or permissioncode='CRM_TASKS_ADD';
delete  from "24763".rolepermission where  permissioncode='PM_TASKS_ADD' or permissioncode='CRM_TASKS_ADD';
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'ADMIN', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'TL', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'DR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'HR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'ACCOUNTANT', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'ADMIN_LOCATION', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'SALESMAN', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'SALESPERSON', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'PM', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'MEM', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'PMOFPR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'DLOFPR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'BMOFPR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'CREATOR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'ADMIN', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'TL', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'DR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'HR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'ACCOUNTANT', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'ADMIN_LOCATION', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'SALESMAN', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'SALESPERSON', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'PM', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'MEM', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'PMOFPR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'DLOFPR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'BMOFPR', (SELECT id from 22026.reference where code='ALLOW') );
insert into 22026.rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ADD', 'CREATOR', (SELECT id from 22026.reference where code='ALLOW') );



delete  from "28492".rolepermission where  permissioncode='HRMS_POSITION'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'PM', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION', 'TL', (SELECT id from "28492".reference where code='ALLOW') );


delete  from "28492".rolepermission where  permissioncode='HRMS_LOCATION'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'PM', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LOCATION', 'TL', (SELECT id from "28492".reference where code='ALLOW') );


delete  from "22542".rolepermission where  permissioncode='HRMS_SALARY_GRADE'
delete  from "25507".rolepermission where  permissioncode='HRMS_SALARY_GRADE'
delete  from "26338".rolepermission where  permissioncode='HRMS_SALARY_GRADE'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "25507".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "26338".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );


delete  from "28492".rolepermission where  permissioncode='HRMS_PROFILE_NOTE' or permissioncode='PM_EMPLOYEE_NOTE'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROFILE_NOTE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROFILE_NOTE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROFILE_NOTE', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_NOTE', 'TL', (SELECT id from "28492".reference where code='ALLOW') );

delete  from "8687".rolepermission where  permissioncode='HRMS_ADD_NEW_LOCATION'
delete  from "28492".rolepermission where  permissioncode='HRMS_ADD_NEW_LOCATION'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_LOCATION', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );

Delete from "21252".rolepermission where permissioncode = 'PM_PROJECT_BUDGET_SHEET' and rolecode != 'ADMIN';
Delete from "21252".rolepermission where permissioncode = 'PM_PROJECT_ADD' and rolecode != 'ADMIN';
Delete from "28492".rolepermission where permissioncode = 'PM_PROJECT_ADD' and rolecode = 'PM';

delete from "21252".rolepermission where permissioncode = 'PM_EMPLOYEE_ACTIVATE_DEACTIVATE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ACTIVATE_DEACTIVATE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode = 'HRMS_EXPORT_TO_PDF' and rolecode='PM';
delete from "28492".rolepermission where permissioncode = 'HRMS_EXPORT_TO_PDF' and rolecode='MEM';

delete from "28492".rolepermission where permissioncode = 'HRMS_ADD_NEW_EMPLOYEE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );

insert into "24763".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_GANTT_CHART', 'CLIENT', (SELECT id from "24763".reference where code='ALLOW'));

delete from "28492".rolepermission where permissioncode = 'HRMS_SECTION' and rolecode='PM';

delete from "28492".rolepermission where permissioncode = 'HRMS_ATTENDANCE_TRACKING_TAB';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EMPLOYEE', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode = 'HRMS_GOAL_MANAGEMENT';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_MANAGEMENT', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode = 'HRMS_CURENT_EMPLOYEE_PROFILE_TAB';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CURENT_EMPLOYEE_PROFILE_TAB', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode = 'HRMS_SECTION';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SECTION', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'PMOFPR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'DLOFPR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'BMOFPR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'CREATOR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'PMOFPR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'DLOFPR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'BMOFPR';
Delete from "22026".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'CREATOR';

Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'PMOFPR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'DLOFPR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'BMOFPR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_ORDER' and rolecode = 'CREATOR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'PMOFPR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'DLOFPR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'BMOFPR';
Delete from "24021".rolepermission where permissioncode = 'PM_PROJECT_PURCHASE_INVOICE' and rolecode = 'CREATOR';

delete from "28492".rolepermission where permissioncode='HRMS_DOCUMENT'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DOCUMENT', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );


insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TALENT_PROFILE', 'DR', (SELECT id from "28492".reference where code='DENY') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_LIVE_REQUEST', 'AUDITOR', (SELECT id from "28492".reference where code='DENY') );

delete from "28492".rolepermission where permissioncode='HRMS_TEMPLATES'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_TEMPLATES', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_COMPETENCES'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPETENCES', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_PERFORMANCE_NOTE'
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

insert into "8032".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_REPORT', 'MEM', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_REPORT', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_LIVE_STATUS', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ATTENDANCE_TRACKING', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SALARY_GRADE', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_GOAL_WEIGHTS' and rolecode='TL';
delete from "28492".rolepermission where permissioncode='HRMS_EMPLOYEE_PROFILE' and rolecode='PM';

 Delete from "28492".rolepermission where permissioncode = 'PM_CUSTOMER_EDIT' and rolecode != 'ADMIN';
Delete from "28492".rolepermission where permissioncode = 'ACCOUNTING_CUSTOMER_EDIT' and rolecode != 'ADMIN';

Delete from "28492".rolepermission where permissioncode = 'ACCOUNTING_CUSTOMER_SUMMARY' and rolecode = 'MEM';
Delete from "28492".rolepermission where permissioncode = 'ACCOUNTING_CUSTOMER_SUMMARY' and rolecode = 'CLIENT';

Delete from "28492".rolepermission where permissioncode = 'PM_CUSTOMER_CLIENT_NOTES' and rolecode = 'MEM';
Delete from "28492".rolepermission where permissioncode = 'PM_CUSTOMER_CLIENT_NOTES' and rolecode = 'CLIENT';













