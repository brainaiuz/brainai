
UPDATE backendManagement bm SET hostName = (SELECT host FROM companySystemSettings WHERE companyid = bm.company_id);

