-- Bu patchni Backend.html > Add New > Add Custom Form > Activity(Event) View ni tanlab Edit> Save Qilish kerak


-- DELETE FROM defaultlayout where formid='ACTIVITY_FORM';
-- INSERT INTO defaultlayout(formid,layout) VALUES('ACTIVITY_FORM','


<div class="contentBar" style="padding:0 10px;">
    <div id="click1" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('click1');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:EVENT_INFORMATION$$</h3>

        <fieldset class="slideDown-content group labelLine">
            <div class="halfSet-1 left">
                <div class="row">$$label:SUBJECT$$<div class="field">$$input:SUBJECT$$</div></div>
                <div class="row">$$label:WHEN$$<div class="field">$$input:WHEN$$</div></div>
                <div class="row">$$label:WHERE$$<div class="field">$$input:WHEN$$</div></div>
                <div class="row">$$label:CREATED_BY$$<div class="field">$$input:CREATED_BY$$</div></div>
                <div class="row">$$label:CREATED_DATE$$<div class="field">$$input:CREATED_DATE$$</div></div>
                <div class="row">$$label:GUESTS$$<div class="field">$$input:GUESTS$$</div></div>
            </div>

            <div class="halfSet-1 left">
                <div class="row">$$label:DESCRIPTION$$<div class="field">$$input:DESCRIPTION$$</div></div>
                <div class="row">$$label:UPDATED_BY$$<div class="field">$$input:UPDATED_BY$$</div></div>
                <div class="row">$$label:UPDATED_DATE$$<div class="field">$$input:UPDATED_DATE$$</div></div>
            </div>
        </fieldset>

    </div>


    <div id="sharedWith" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('sharedWith');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:SHARED_WITH$$</h3>
        <fieldset class="slideDown-content group nobrd">
            <div class="halfSet-1 left">
                $$input:SHARED_WITH$$
            </div>
        </fieldset>
    </div>

    <div id="sharedWith" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('reservation');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:RESERVATION$$</h3>
        <fieldset class="slideDown-content group nobrd">
            <div class="halfSet-1 left">
                $$input:RESERVATION$$
            </div>
        </fieldset>
    </div>

    <div id="links" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('links');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:LINKS$$</h3>
        <fieldset class="slideDown-content group nobrd">
            <div class="halfSet-1 left">
                $$input:LINKS$$
            </div>
        </fieldset>
    </div>

    <div id="attachments" class="slideDown-box expand group">
        <h3 onclick="var myclick=document.getElementById('attachments');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:ATTACHMENTS$$</h3>
        <fieldset class="slideDown-content group nobrd">
            <div class="halfSet-1 left">
                $$input:ATTACHMENTS$$
            </div>
        </fieldset>
    </div>

</div>


-- ');