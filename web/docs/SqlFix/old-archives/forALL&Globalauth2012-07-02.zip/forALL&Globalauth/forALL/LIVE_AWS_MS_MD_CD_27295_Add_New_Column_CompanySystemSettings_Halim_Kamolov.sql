--After schema update
update companySystemSettings set copyNewEmployeesToProjectTasks='false';
update companySystemSettings set copyNewEmployeesToProjectTasks='true' where companyid in(25608,3465,8687);