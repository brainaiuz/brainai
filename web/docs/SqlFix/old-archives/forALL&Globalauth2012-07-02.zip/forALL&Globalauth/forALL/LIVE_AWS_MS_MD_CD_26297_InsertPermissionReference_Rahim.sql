insert into "anv".reference(code, name) values('_PERMISSION', 'Permission');
insert into "anv".reference(code, name, sorder, parentid) values('ALLOW', 'Allow', 1, (select id from "anv".reference where code='_PERMISSION'));
insert into "anv".reference(code, name, sorder, parentid) values('DENY', 'Deny', 2, (select id from "anv".reference where code='_PERMISSION'));