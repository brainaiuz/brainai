/*Bu patch faqat bir marta publicga patch qilinadi*/

/*1.*/
DELETE FROM defaultlayout where formid='MEETINGMINUTES';

/*2.*/
INSERT INTO defaultlayout(formid,layout) VALUES('MEETINGMINUTES','
   <div class="productcontent">
<div class="contentScroll">
<table cellspacing="0" cellpadding="0" class="bindContent">
<tr>

<td class="mainBar">
    <div class="invoice-block">
        <fieldset class="slideDown-content group labelLine" style="display:block !important">
            <div class="halfSet-1 left">
                <div class="row">

                    $$label:title$$
                    <div class="field">
                        $$input:title$$
                    </div>
                </div>
                <div class="row">
                    $$label:meetingid$$
                    <div class="field">
                        $$input:meetingid$$
                    </div>
                </div>
                <div class="row">

                    $$label:calledby$$
                    <div class="field">
                        $$input:calledby$$
                    </div>
                </div>

                <div class="row">
                    $$label:startdate$$
                    <div class="field">
                        $$input:startdate$$
                    </div>
                </div>

                <div class="row">
                    $$label:enddate$$
                    <div class="field">
                        $$input:enddate$$
                    </div>
                </div>

                <div class="row">
                    $$label:location$$
                    <div class="field">
                        $$input:location$$
                    </div>
                </div>
                <div class="row">

                    $$label:meetingtype$$
                    <div class="field">
                        $$input:meetingtype$$
                    </div>
                </div>
            </div>
            <div class="halfSet-1 left">
                <div class="row">
                    $$label:attendees$$
                    <div class="field">
                        $$input:attendees$$
                    </div>
                </div>

                <div class="row">
                    $$label:absent$$
                    <div class="field">
                        $$input:absent$$
                    </div>
                </div>
            </div>
        </fieldset>
        <fieldset class="slideDown-content group labelLine" style="display:block !important">
            <div class="halfSet-1 left">
                <div class="row">

                    $$label:purpose$$
                    <div class="field">
                        $$input:purpose$$
                    </div>
                </div>
            </div>
        </fieldset>

        <fieldset class="slideDown-content group labelLine" style="display:block !important">
            <div class="halfSet-1 left">
                <div class="row">
                    <!-- $$input:addagendalink$$-->
                    <div class="field">
                        $$input:agendapanel$$
                    </div>
                </div>
            </div>
        </fieldset>
        <fieldset class="slideDown-content group labelLine" style="display:block !important">
            <div class="halfSet-1 left">
                <div class="row">

                    $$label:preparedby$$
                    <div class="field">
                        $$input:preparedby$$
                    </div>
                </div>
            </div>
        </fieldset>

        <div class="lineBtnSet c buttonIcons" >
                 $$input:savebutton$$
                 $$input:closebutton$$
	     </div>

    </div>

<td class="sidebar">
    <div class="inv-OptBar">
        <div class="optBarBlock image-upload">
            $$label:attachments$$
            $$input:attachments$$
            $$input:uploadbutton$$
        </div>
        <div class="optBarBlock storefront">
            $$label:notes$$
            $$input:notes$$
            $$input:addnotes$$
        </div>

        <div class="optBarBlock invoice-customfields">

        </div>
    </div>
</td>

</tr>
</table>
</div>
</div>
');