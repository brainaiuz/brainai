/*1.*/
DELETE FROM defaultlayout where formid='PERSONAL_GOAL_FORM';
/*Bu patch faqat bir marta publicga patch qilinadi*/
INSERT INTO defaultlayout(formid,title,addform,editform,viewform,layout) VALUES ('PERSONAL_GOAL_FORM','Personal Goal Add/Edit and View ',true,true ,true,'<div class="contentBar" style="padding:0 10px;padding-top:3px;">
<div id="click1" class="slideDown-box  group expand">
    <h3 onclick="var myclick=document.getElementById('click1');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:GOAL_DETAILS$$</h3>

    <fieldset class="slideDown-content group labelLine">
        <div class="halfSet-1 left">
			<div class="row">
                $$label:GOAL_PERSONAL_ASSINESS$$
                <div class="field">
                    $$input:GOAL_PERSONAL_ASSINESS$$
                </div>
            </div>
            <div class="row">
                $$label:GOAL_TITLE$$
                <div class="field">
                    $$input:GOAL_TITLE$$
                </div>
            </div>

            <div class="row">
                $$label:GOAL_DESCIRIPTION$$
                <div class="field">
                    $$input:GOAL_DESCIRIPTION$$
                </div>
            </div>

            <div class="row">
                $$label:GOAL_START_DATE$$
                <div class="field">$$input:GOAL_START_DATE$$</div>
            </div>

            <div class="row">
                $$label:GOAL_TO_DATE$$
                <div class="field">
                    $$input:GOAL_TO_DATE$$
                </div>
            </div>
        </div>

        <div class="halfSet-1 left">
            <div class="row">
                $$label:GOAL_ACTION_STEPS$$
                <div class="field">
                    $$input:GOAL_ACTION_STEPS$$
                </div>
            </div>

            <div class="row">
                $$label:GOAL_SCORE$$
                <div class="field">
                    $$input:GOAL_SCORE$$
                </div>
            </div>

            <div class="row">
                $$label:GOAL_PROGRESS$$
                <div class="field">$$input:GOAL_PROGRESS$$</div>
            </div>

            <div class="row">
                $$label:GOAL_STATUS$$
                <div class="field">
                    $$input:GOAL_STATUS$$
                </div>
            </div>
			<div class="row">
                $$label:GOAL_WEIGHT$$
                <div class="field">
                    $$input:GOAL_WEIGHT$$
                </div>
            </div>
        </div>
    </fieldset>

</div>

<div id="click2" class="slideDown-box expand group">
    <h3 onclick="var myclick=document.getElementById('click2');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:ATTACHMENTS$$</h3>
    <fieldset class="slideDown-content group nobrd">
        <div class="data-grid" >
            $$input:ATTACHMENTS$$
        </div>
    </fieldset>

</div>
<div id="click3" class="slideDown-box expand group">
    <h3 onclick="var myclick=document.getElementById('click3');if(myclick &amp;&amp; myclick.className);{var cls=myclick.className;if(cls.indexOf('expand')>=0){cls=cls.replace('expand','');}else{cls+=' expand';}myclick.className=cls;}" class="slideDown-title">$$label:CRM_NOTE$$</h3>

    <fieldset class="slideDown-content group nobrd">
        <div class="halfSet-1 left">
            $$input:CRM_NOTE$$
        </div>
    </fieldset>
</div>
</div>');