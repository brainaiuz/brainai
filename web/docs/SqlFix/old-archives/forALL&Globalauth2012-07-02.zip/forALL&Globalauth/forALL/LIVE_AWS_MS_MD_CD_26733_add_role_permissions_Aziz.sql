--Bu patchni 26535_add_permissions_Aziz.sql dan keyin qilish kerak

--PM_TASKS_LIST open for all
--PM_ISSUE_LIST open for all
--PM_TIMESHEET - hidden for client
--PM_TIMESHEET_APPROVAL - open to admin, pm, dr
--PM_PROJECT_LIST - open for all
--PM_CUSTOMER_LIST - open for ADMIN, DR, PM
--PM_EMPLOYEE_LIST - open for ADMIN, DR, ADMIN_LOCATION, PM, TL
--PM_DEPARTMENT_LIST - ADMIN, DR, PM, TL, MEM
--PM_LOCATION_LIST - ADMIN, DR

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'ONE_OFF', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'CALENDAR_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'CALENDAR_VIEWER', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'CHAT_EXPERT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_LIST', 'TIMESHEET_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );

--

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'ONE_OFF', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'CALENDAR_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'CALENDAR_VIEWER', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'CHAT_EXPERT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_LIST', 'TIMESHEET_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );

--

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'CALENDAR_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'CALENDAR_VIEWER', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'CHAT_EXPERT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET', 'TIMESHEET_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );

--

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET_APPROVAL', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET_APPROVAL', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET_APPROVAL', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET_APPROVAL', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TIMESHEET_APPROVAL', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );

--

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'ONE_OFF', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'CALENDAR_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'CALENDAR_VIEWER', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'CHAT_EXPERT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_LIST', 'TIMESHEET_EDITOR', (SELECT id from "anv".reference where code='ALLOW') );


--
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );


--

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_LIST', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );

--

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_LIST', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );

--
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
