/*public schema */
update bugreport set status = 'UNDER_INVESTIGATION' where status='UNDER INVESTIGATION';