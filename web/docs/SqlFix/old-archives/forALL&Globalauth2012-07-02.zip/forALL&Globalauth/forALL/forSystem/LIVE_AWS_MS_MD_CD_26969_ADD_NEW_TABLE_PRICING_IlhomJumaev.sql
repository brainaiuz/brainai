CREATE TABLE pricing
(
  id serial NOT NULL,
  hostName character varying(255),
  userCount integer,
  price numeric(11, 2),
  CONSTRAINT pricing_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE pricing OWNER TO wftauth;

-- insert query for APP.KPI.COM
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 1, 39.99); --per 1 user to 39.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 2, 29.99); --per 2 user to 29.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 3, 24.99); --per 3 user to 24.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 4, 19.99); --per 4 user to 19.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 5, 17.99); --per 5 user to 17.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 6, 17.49); --per 6 user to 17.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 7, 16.99); --per 7 user to 16.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 8, 16.49); --per 8 user to 16.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 9, 15.99); --per 9 user to 15.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 10, 15.49); --per 10 user to 15.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 11, 14.99); --per 11 user to 14.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 12, 14.49); --per 12 user to 14.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 13, 13.99); --per 13 user to 13.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 14, 13.49); --per 14 user to 13.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 15, 12.99); --per 15 user to 12.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 16, 12.49); --per 16 user to 12.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 17, 11.99); --per 17 user to 11.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 18, 11.49); --per 18 user to 11.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 19, 10.99); --per 19 user to 10.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 20, 10.49); --per 20 user to 10.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 21, 9.99); --per 21 user to 9.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 22, 9.49); --per 22 user to 9.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 23, 8.99); --per 23 user to 8.99$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 24, 8.49); --per 24 user to 8.49$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 25, 8.25); --per 25 user to 8.25$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 26, 8.25); --per 26 user to 8.25$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 27, 8.25); --per 27 user to 8.25$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 28, 8.25); --per 28 user to 8.25$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 29, 8.25); --per 29 user to 8.25$
insert into pricing (hostName, userCount, price) VALUES('app.kpi.com', 30, 8.25); --per 30 user to 8.25$


-- insert query for app.smebu.com
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 1, 10.21); --per 1 user to 10.21$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 2, 10.21); --per 2 user to 10.21$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 3, 10.21); --per 3 user to 10.21$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 4, 10.21); --per 4 user to 10.21$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 5, 10.21); --per 5 user to 10.21$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 6, 10.00); --per 6 user to 10.00$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 7, 10.00); --per 7 user to 10.00$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 8, 10.00); --per 8 user to 10.00$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 9, 10.00); --per 9 user to 10.00$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 10, 9.80); --per 10 user to 9.80$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 11, 9.80); --per 11 user to 9.80$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 12, 9.80); --per 12 user to 9.80$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 13, 9.80); --per 13 user to 9.80$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 14, 9.80); --per 14 user to 9.80$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 15, 9.60); --per 15 user to 9.60$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 16, 9.60); --per 16 user to 9.60$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 17, 9.60); --per 17 user to 9.60$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 18, 9.60); --per 18 user to 9.60$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 19, 9.60); --per 19 user to 9.60$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 20, 9.40); --per 20 user to 9.40$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 21, 9.40); --per 21 user to 9.40$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 22, 9.40); --per 22 user to 9.40$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 23, 9.40); --per 23 user to 9.40$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 24, 9.40); --per 24 user to 9.40$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 25, 9.20); --per 25 user to 9.20$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 26, 9.20); --per 26 user to 9.20$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 27, 9.20); --per 27 user to 9.20$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 28, 9.20); --per 28 user to 9.20$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 29, 9.20); --per 29 user to 9.20$
insert into pricing (hostName, userCount, price) VALUES('app.smebu.com', 30, 9.20); --per 30 user to 9.20$