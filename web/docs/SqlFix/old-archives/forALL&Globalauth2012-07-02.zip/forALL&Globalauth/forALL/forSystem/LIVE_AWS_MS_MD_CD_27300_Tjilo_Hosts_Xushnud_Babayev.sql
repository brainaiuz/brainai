-- Bu Patch globalauth DB ga bir marta yurgizildi: White Labeling www.tjilo.com
-- For APP.TJELO.COM host

INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid, facebooksecret,
            googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm, googlesignaturekey,
            hostname, imagemagickpath, isliveenv, linkedinapikey, linkedinsecret,
            liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported, defaultlocale, paypalaccount, vat)
    VALUES ('62.252.53.33', '/usr/share/tomcat6/webapps/projects/app.workforcetrack.com/ROOT/', null, null,null,
            null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAPPTjilo.jks', 'app.tjilo.com', null, '6P2yUb4jYCDJ0hwLbxtifyER',
            'app.tjilo.com', null, true, null, null,
            '00000000440C63D8', 'fYS0mvi4LdbjeFCZSJSb8hJqVvEIp2w0', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solrpaid.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'Tjilo.com', '/customisation/tjilo.com/images/tjilo_logo.png', 'tjilo.com', 'support@tjilo.com',
            'Tjilo-info', '+31 30 8200 262', 'Emmalaan 21, Utrecht, Netherlands', '/customisation/tjilo.com/images/tjilo_logo.png', 'Tjilo.com', 'tjilomail.properties',
            'Tjilo.com', true, 'en', 'sales@workforcetrack.com', 0.20 );


-- For AWS.TJELO.COM host
INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid, facebooksecret,
            googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm, googlesignaturekey,
            hostname, imagemagickpath, isliveenv, linkedinapikey, linkedinsecret,
            liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported, defaultlocale, paypalaccount, vat)
    VALUES ('62.252.53.33', '/usr/share/tomcat6/webapps/projects/aws.workforcetrack.com/ROOT/', null, null,null,
            null, null,
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSTjilo.jks', 'aws.tjilo.com', null, 'QTi1BtRUcrDabd0O_4VLhnJl',
            'aws.tjilo.com', null, false, null, null,
            '00000000400C9EB5', '0gHOxbO9aDELShmFrHtzErKY5lFHWRuL', '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solrpaid.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'Tjilo.com', '/customisation/tjilo.com/images/tjilo_logo.png', 'tjilo.com', 'support@tjilo.com',
            'Tjilo-info', '+31 30 8200 262', 'Emmalaan 21, Utrecht, Netherlands', '/customisation/tjilo.com/images/tjilo_logo.png', 'Tjilo.com', 'tjilomail.properties',
            'Tjilo.com', false, 'en', 'sales@workforcetrack.com', 0.20);




