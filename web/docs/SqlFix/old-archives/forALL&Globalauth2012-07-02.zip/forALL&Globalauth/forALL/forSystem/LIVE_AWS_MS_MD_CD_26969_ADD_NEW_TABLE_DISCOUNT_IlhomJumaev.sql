CREATE TABLE discount
(
  id serial NOT NULL,
  hostName character varying(255),
  oneMonth numeric(11, 2),
  threeMonth numeric(11, 2),
  sixMonth numeric(11, 2),
  twentyMonth numeric(11, 2),
  CONSTRAINT discount_pkey PRIMARY KEY (id),
  CONSTRAINT discount_hostName_key UNIQUE (hostName)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE discount OWNER TO wftauth;

--- insert query
insert into discount (hostName, oneMonth, threeMonth, sixMonth, twentyMonth) VALUES('app.kpi.com', 0.00, 0.15, 0.25, 0.30);--//FOR APP.KPI.COM HOST --> (1 month - not discount), 3 month - 15%, 6 month - 25%, 12 month - 30%;
insert into discount (hostName, oneMonth, threeMonth, sixMonth, twentyMonth) VALUES('app.smebu.com', 0.00, 0.02, 0.04, 0.06);--//FOR app.smebu.com HOST --> (1 month - not discount), 3 month - 2%, 6 month - 4%, 12 month - 6%;