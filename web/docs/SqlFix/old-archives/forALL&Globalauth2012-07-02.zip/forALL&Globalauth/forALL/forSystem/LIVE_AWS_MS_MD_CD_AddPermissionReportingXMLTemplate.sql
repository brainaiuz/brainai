
//TO`LQIN MAN AWS GA APPLY QILDIM BU PATCHNI, SIZ YURGIZMANG
insert into rolereporttemplate(reporttemplatecode,role) select r.code,rl.code from reporttemplate r ,"1".role rl where rl.code is not null and r.isCustom is not true