
ALTER TABLE hostbasedsetting ADD COLUMN VAT numeric(11, 2);


-- update query
update hostbasedsetting set VAT = 0.20 where hostname like ('%app.kpi.com%');
update hostbasedsetting set VAT = 0.18 where hostname like ('%smebu.com%');
