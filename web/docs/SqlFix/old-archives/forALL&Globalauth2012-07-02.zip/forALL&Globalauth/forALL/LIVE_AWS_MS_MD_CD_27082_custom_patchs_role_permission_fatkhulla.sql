--Xamma patchlani ohirida buni qilish kk. ketma ketlikda urilsin!!!!   bu lani xammasini companyid isini yozib ketganman.

delete from "7619".rolepermission where permissioncode='PM_TASKS_BUDGET'
insert into "7619".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ADMIN', (SELECT id from "7619".reference where code='ALLOW') );
insert into "7619".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'DR', (SELECT id from "7619".reference where code='ALLOW') );
insert into "7619".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ACCOUNTANT', (SELECT id from "7619".reference where code='ALLOW') );


delete from "21252".rolepermission where permissioncode='PM_TASKS_BUDGET'
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ADMIN', (SELECT id from "21252".reference where code='ALLOW') );
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'DR', (SELECT id from "21252".reference where code='ALLOW') );
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ACCOUNTANT', (SELECT id from "21252".reference where code='ALLOW') );

delete from "21252".rolepermission where permissioncode='PM_PROJECT_COST'
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_COST', 'ADMIN', (SELECT id from "21252".reference where code='ALLOW') );

delete from "21252".rolepermission where permissioncode='PM_TASKS_VIEW_PROJECT_COST'
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_VIEW_PROJECT_COST', 'ADMIN', (SELECT id from "21252".reference where code='ALLOW') );

delete from "21252".rolepermission where permissioncode='PM_PROJECT_BUDGET_SHEET'
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_BUDGET_SHEET', 'ADMIN', (SELECT id from "21252".reference where code='ALLOW') );

delete from "21252".rolepermission where permissioncode='PM_EMPLOYEE_RATE_HISTORY'
insert into "21252".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE_HISTORY', 'ADMIN', (SELECT id from "21252".reference where code='ALLOW') );


delete from "24021".rolepermission where permissioncode='PM_TASKS_BUDGET'
insert into "24021".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ADMIN', (SELECT id from "24021".reference where code='ALLOW') );
insert into "24021".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'DR', (SELECT id from "24021".reference where code='ALLOW') );
insert into "24021".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ACCOUNTANT', (SELECT id from "24021".reference where code='ALLOW') );


delete from "24763".rolepermission where permissioncode='PM_TASKS_ADD' and rolecode='CLIENT';
delete from "24763".rolepermission where permissioncode='PM_TASKS_ADD_MULTI' and rolecode='CLIENT';


delete from "24763".rolepermission where permissioncode='PM_DEPARTMENT_EDIT';
insert into "24021".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'ADMIN', (SELECT id from "24021".reference where code='ALLOW') );
insert into "24021".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'DR', (SELECT id from "24021".reference where code='ALLOW') );


