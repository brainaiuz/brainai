<!--schema update dan sung -->

update companysystemsettings set ispermissionmanagement=false;