<--Add_New_Reference_Goal_Score_Hasan.sql shu patchdi urgandan keyin uriladi-->



UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE1') where weight=1;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE2') where weight=2;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE3') where weight=3;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE4') where weight=4;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE5') where weight=5;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE6') where weight=6;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE7') where weight=7;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE8') where weight=8;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE9') where weight=9;
UPDATE "anv".goal set weight = (select id from "anv".reference where code='_GOAL_SCORE10') where weight=10;