
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_BUDGET', 'PM', 'Task Budget', 10, false);