update hostbasedsetting set
    googleappsconsumerkey='app.smebu.com',
    googlesignaturekey='uXF50bWC315o6vy2hcuReyXz',
    googleappsconsumersecret=null,
    googlemarketplacerealm=null,
    imagemagickpath=null,
    isliveenv=true
where hostname='app.smebu.com';