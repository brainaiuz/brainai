--PUBLIC SCHEMA
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_CUSTOMER_EDIT', 'PM', 'Customer Edit', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_CUSTOMER_CLIENT_NOTES', 'PM', 'Client Notes', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_CUSTOMER_REMOVE_CLIENT', 'PM', 'Remove Client', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_CUSTOMER_ADD_CLIENT', 'PM', 'Remove Client', 10, false);

--PRIVATE
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_EDIT', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_EDIT', 'PM', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_CLIENT_NOTES', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_CLIENT_NOTES', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_CLIENT_NOTES', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_CLIENT_NOTES', 'PM', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_ADD_CLIENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_ADD_CLIENT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_ADD_CLIENT', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_ADD_CLIENT', 'PM', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CUSTOMER_REMOVE_CLIENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
