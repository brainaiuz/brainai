drop function if exists "anv".createCrmFolders();
create or replace function "anv".createCrmFolders() returns integer as $body$
BEGIN
    if (select count(id) from "anv".folder where foldertype = 40 and parent_id = (select id from "anv".folder where type = 1 and foldertype = 14)) = 0
    then
        INSERT INTO "anv".folder(foldertype, name, parent_id, creationdate, modificationdate, deleted, version, createdby_id, owner_id, modifiedby_id, type)
        VALUES(40, 'Mass Mail Attachments', (select id from "anv".folder where type=1 and foldertype=14),'2011-05-05 12:00:00', '2011-05-05 12:00:00', false, 1, (select creatorid from company where id = anv),(select creatorid from company where id = anv), (select creatorid from company where id = anv), 1);
        RAISE NOTICE '>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>%|Mass Mail Attachments Created',anv;
    end if;
    return null;
    end;
$body$ language plpgsql;

update "anv".myuser set deleted = false where deleted is null or (select "anv".createCrmFolders()) is not null;