--PM_LOCATION_EDIT
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );

--PM_LOCATION_REMOVE
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_REMOVE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );

--PM_LOCATION_ADD
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_LOCATION_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );

