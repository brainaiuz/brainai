--PM_PROJECT_COST
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_COST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_COST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_COST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_COST', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_COST', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
--PM_PROJECT_BUDGET_SHEET
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_BUDGET_SHEET', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_BUDGET_SHEET', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_BUDGET_SHEET', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_BUDGET_SHEET', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_BUDGET_SHEET', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
--PM_EMPLOYEE_RATE_HISTORY
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE_HISTORY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE_HISTORY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE_HISTORY', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE_HISTORY', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE_HISTORY', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );