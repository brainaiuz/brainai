alter table reporttemplate alter column code type varchar(255);

update reporttemplate set code =upper(name);

update "0".reporting r2 set viewcode = (select code from reporttemplate t where t.id=r2.xmltemplateid);

update "anv".reporting r2 set viewcode = (select code from reporttemplate t where t.id=r2.xmltemplateid);