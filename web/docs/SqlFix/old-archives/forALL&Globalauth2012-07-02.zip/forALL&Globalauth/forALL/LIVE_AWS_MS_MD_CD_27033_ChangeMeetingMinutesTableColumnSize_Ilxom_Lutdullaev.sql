alter table "anv".meetingminutes alter column purpose type varchar(10000);
update "anv".meetingminutes set lastUpdateTime = now() where lastUpdateTime is null;