--Rahim akadan so'rab ur (so`rab o`tirmang og`a :) )
delete from "anv".reporting where id not in(select  max(id) from "anv".reporting group by code);

ALTER TABLE "anv".reporting ADD CONSTRAINT reporting_code_unique UNIQUE (code);