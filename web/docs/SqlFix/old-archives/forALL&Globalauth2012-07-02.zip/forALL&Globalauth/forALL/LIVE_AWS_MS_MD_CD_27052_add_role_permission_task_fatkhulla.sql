<--Task budget
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_BUDGET', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
