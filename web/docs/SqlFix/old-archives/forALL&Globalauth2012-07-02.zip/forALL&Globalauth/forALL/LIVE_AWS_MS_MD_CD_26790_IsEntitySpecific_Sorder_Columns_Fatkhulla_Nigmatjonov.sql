!--schema update dan kyin-->
update "anv".role set isentityspecific =false;

<!-- ketidan buni urish kerak-->

insert into "anv".role (code,name,issystem,isentityspecific,isdeleted) values('PMOFPR','PMofPR',true,true,false);
insert into "anv".role (code,name,issystem,isentityspecific,isdeleted) values('DLOFPR','DLofPR',true,true,false);
insert into "anv".role (code,name,issystem,isentityspecific,isdeleted) values('BMOFPR','BMofPR',true,true,false);
 <!-- ketidan buni urish kerak-->
 ///oxirgi o`zgartirish
 //AWS GA URDIM (RAHIM)
update "anv".role set sorder=10 where code='ADMIN';
update "anv".role set sorder=20 where code='DR';
update "anv".role set sorder=30 where code='HR';
update "anv".role set sorder=40 where code='ACCOUNTANT';
update "anv".role set sorder=50 where code='ADMIN_LOCATION';
update "anv".role set sorder=60 where code='SALESMAN';
update "anv".role set sorder=70 where code='CUSTOMER_SERVICE_REPRESENTATIVE';
update "anv".role set sorder=80 where code='SALESPERSON';
update "anv".role set sorder=90 where code='TL';
update "anv".role set sorder=100 where code='PM';
update "anv".role set sorder=110 where code='MEM';
update "anv".role set sorder=120 where code='CALENDAR_EDITOR';
update "anv".role set sorder=130 where code='CALENDAR_VIEWER';
update "anv".role set sorder=140 where code='TIMESHEET_EDITOR';
update "anv".role set sorder=150 where code='PMOFPR';
update "anv".role set sorder=160 where code='DLOFPR';
update "anv".role set sorder=170 where code='BMOFPR';
update "anv".role set sorder=180 where code='CLIENT';
update "anv".role set sorder=190 where code='ONE_OFF';
update "anv".role set sorder=200 where code='CHAT_EXPERT';