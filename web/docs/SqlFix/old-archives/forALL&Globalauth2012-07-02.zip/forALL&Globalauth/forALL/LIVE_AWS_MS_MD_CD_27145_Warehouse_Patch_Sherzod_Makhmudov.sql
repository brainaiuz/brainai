/*Bu patchlar schema updatedan keyin qilinadi*/

update "anv".productwarehouselocation set warehouseid=(select warehouseid from "anv".warehouselocation where id=locationid) where locationid is not null;
update "anv".item_stock set warehouseid = (select warehouseid from "anv".warehouselocation where id in (select locationid from "anv".productwarehouselocation where id = product_locationid)) where product_locationid is not null;

update "anv".quoteitem set warehouseid=(select warehouseid from "anv".warehouselocation where id=warehouselocationid) where warehouselocationid is not null;
update "anv".invoiceitem set warehouseid=(select warehouseid from "anv".warehouselocation where id=warehouselocationid) where warehouselocationid is not null;
update "anv".invoiceitem set warehouseid = (select id from "anv".warehouse where isDefaultWarehouse = true order by id desc limit 1) where warehouseid is null;
update "anv".adjustment_item set warehouseid = (select id from "anv".warehouse where isDefaultWarehouse = true order by id desc limit 1) where warehouseid is null;