UPDATE hostbasedsetting SET  productname='kpi.com', logoimage='/customisation/kpi.com/images/kpilogo.png', pdflogo='/customisation/kpi.com/images/kpilogo.png' WHERE productname='KPI'
