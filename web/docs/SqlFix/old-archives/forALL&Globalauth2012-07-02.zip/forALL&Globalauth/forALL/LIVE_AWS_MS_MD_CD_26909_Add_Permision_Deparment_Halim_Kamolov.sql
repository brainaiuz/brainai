INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_EDIT', 'PM', 'Department edit', 23, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_NOTES', 'PM', 'Department notes', 24, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_REMOVE', 'PM', 'Department remove', 25, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_PDF', 'PM', 'Department pdf version', 26, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_ADD', 'PM', 'Department add', 27, false);