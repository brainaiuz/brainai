alter table "anv".crmcase drop constraint "fk3db1522e614d63f4";
alter table "anv".crmcase drop constraint "fk3db1522e7bf99aa1";