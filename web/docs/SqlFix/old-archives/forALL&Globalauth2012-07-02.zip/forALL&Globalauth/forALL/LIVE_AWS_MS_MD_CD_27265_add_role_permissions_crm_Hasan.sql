--Sales tab permission--
--Public.  Birinchi uriladi--
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SALES_TAB', 'CRM', 'CRM Sales tab', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_LEADS_LIST', 'CRM', 'Leads List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_OPPORTUNITIES_LIST', 'CRM', 'Opportunities List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_LIST', 'CRM', 'Accounts List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CONTACTS_LIST', 'CRM', 'Contacts List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CAMPAIGNS_LIST', 'CRM', 'Campaigns List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_LIST', 'CRM', 'Tasks List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACTIVITIES_LIST', 'CRM', 'Activities List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_WEB_FORMS_LIST', 'CRM', 'Web Forms List', 1, false);


--Private.  Ikkinchi--
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SALES_TAB', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SALES_TAB', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SALES_TAB', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SALES_TAB', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SALES_TAB', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_LEADS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_LEADS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_LEADS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_LEADS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_LEADS_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_OPPORTUNITIES_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_OPPORTUNITIES_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_OPPORTUNITIES_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_OPPORTUNITIES_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_OPPORTUNITIES_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CONTACTS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CONTACTS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CONTACTS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CONTACTS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CONTACTS_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CAMPAIGNS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CAMPAIGNS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CAMPAIGNS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CAMPAIGNS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CAMPAIGNS_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACTIVITIES_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACTIVITIES_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACTIVITIES_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACTIVITIES_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACTIVITIES_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_WEB_FORMS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_WEB_FORMS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_WEB_FORMS_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_WEB_FORMS_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_WEB_FORMS_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );




