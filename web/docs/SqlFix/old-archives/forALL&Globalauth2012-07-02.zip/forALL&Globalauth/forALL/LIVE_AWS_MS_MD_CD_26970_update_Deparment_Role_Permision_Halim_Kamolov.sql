delete from "anv".rolepermission where permissioncode='PM_DEPARTMENT_EDIT';

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_DEPARTMENT_EDIT', 'TL', (SELECT id from "anv".reference where code='ALLOW') );