<---Birinchi->
insert into "anv".reference (code,  name, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE', 'Goal score', 'f', 't', 'f');

<--Ikkinchi-->
insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE1', '1', 1, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE2', '2', 2, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE3', '3', 3, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE4', '4', 4, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE5', '5', 5, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE6', '6', 6, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE7', '7', 7, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE8', '8', 8, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE9', '9', 9, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');

insert into "anv".reference (code, name, sorder, parentid, isremovable, issystemreference, deleted)
values ('_GOAL_SCORE10', '10', 10, (SELECT id from "anv".reference where code='_GOAL_SCORE'),'f', 't', 'f');