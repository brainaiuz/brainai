UPDATE "anv".reference SET sorder = '1' WHERE code = 'CT_ADVERTISEMENT'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '2' WHERE code = 'BANNER_ADS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '3' WHERE code = 'CONFERENCE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '4' WHERE code = 'DIRECT_MAIL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '5' WHERE code = 'CT_EMAIL'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '6' WHERE code = 'PARTNERS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '7' WHERE code = 'CT_PUBLIC_RELATIONS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '8' WHERE code = 'REFERRAL_PROGRAM'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '9' WHERE code = 'TELEMARKETING'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '10' WHERE code = 'CT_TRADE_SHOW'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '11' WHERE code = 'WEBINAR'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');
UPDATE "anv".reference SET sorder = '12' WHERE code = 'OTHERS'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_TYPE');

UPDATE "anv".reference SET sorder = '1' WHERE code = 'PLANNING'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "anv".reference SET sorder = '2' WHERE code = 'CS_ACTIVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "anv".reference SET sorder = '3' WHERE code = 'CS_INACTIVE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');
UPDATE "anv".reference SET sorder = '4' WHERE code = 'COMPLATE'
AND parentid = (SELECT id FROM "anv".reference WHERE code = '_CAMPAIGN_STATUS');