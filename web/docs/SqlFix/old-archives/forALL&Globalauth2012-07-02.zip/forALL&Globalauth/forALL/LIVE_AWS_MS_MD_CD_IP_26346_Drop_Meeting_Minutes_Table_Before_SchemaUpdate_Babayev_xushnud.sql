drop table if exists "anv".meetingattendees;
drop table if exists "anv".agendadiscussion;
drop table if exists "anv".agendatopic;
drop table if exists "anv".meetingminutes;