INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_MEMBERS_INVOLVED', 'PM', 'Members involved', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_COMMENTS', 'PM', 'Task comments', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_EMAILS', 'PM', 'Task emails', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_COMPOSE', 'PM', 'Task compose', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_CASE', 'PM', 'Task case', 10, false);



