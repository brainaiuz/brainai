--PUBLIC SCHEMA
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_PURCHASE_ORDER', 'PM', 'Project Purchase Order', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_PURCHASE_INVOICE', 'PM', 'Project Purchase Invoice', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_EXPENSE_CLAIMS', 'PM', 'Project Expense Claims', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_CASE', 'PM', 'Project Case', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_CASE_ADD_NEW', 'PM', 'Case Add', 10, false);

--PRIVATE
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_ORDER', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_ORDER', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_ORDER', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_ORDER', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_ORDER', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_ORDER', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_INVOICE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_INVOICE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_INVOICE', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_INVOICE', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_INVOICE', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_PURCHASE_INVOICE', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EXPENSE_CLAIMS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EXPENSE_CLAIMS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EXPENSE_CLAIMS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EXPENSE_CLAIMS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EXPENSE_CLAIMS', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_EXPENSE_CLAIMS', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_CASE', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_CASE_ADD_NEW', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
