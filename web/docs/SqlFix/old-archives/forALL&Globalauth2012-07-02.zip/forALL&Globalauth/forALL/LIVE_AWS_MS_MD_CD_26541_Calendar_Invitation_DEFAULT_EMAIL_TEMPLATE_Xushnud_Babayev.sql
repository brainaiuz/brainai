update "anv".myuser set deleted = false where deleted is not true and (select setval('"anv".emailtemplate_id_seq',(select max(id) from "anv".emailtemplate))) is null;

insert into "anv".reference (code, name, parentid) VALUES ('CALENDAR_INVITATION_TO_GUESTS_ADD_CATEGORY', 'Calendar Invitation to guests Add', 509);

INSERT INTO "anv"."emailtemplate"(deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, messagehtml, name, sendemail, subject, categoryid, fromusername, customentityaction, activitytext, entitytype, toemailquery, customentityid, code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Dear ${USER},</p>
          <p>Please be informed that you have been invited to ${EVENT_NAME}</p>
          <p>${UPDATED} Event details:</p>
          <div style="background-color:lightblue; width:100%;">
              <p>Title: ${EVENT_NAME}</p>
              <p>Description: ${DESCRIPTION}</p>
              <p>When: ${DATE}</p>
          </div>
          <p>Where: ${WHERE}</p>
          <p>Organizer: ${CREATOR_NAME}</p>
          <p>Shared with: ${SHARED_WITH}</p>
          <p>Guests:${GUESTS}</p>
          <p>
            <b>Going?</b>
            - <a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&cid=${COMPANY_ID}&id=${EVENT_ID}&email=${GUESTSEMAIL}&answer=Accepted"> Yes </a>
            - <a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&cid=${COMPANY_ID}&id=${EVENT_ID}&email=${GUESTSEMAIL}&answer=Tentatively"> Maybe </a>
            - <a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&cid=${COMPANY_ID}&id=${EVENT_ID}&email=${GUESTSEMAIL}&answer=Declined"> No </a>
          </p>', 'Default Add Calendar invitation to guests', null, 'Event Invitation: ${EVENT_NAME} ${DATE}',
          (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_INVITATION_TO_GUESTS_ADD_CATEGORY'),
          null, null, null, null, null, null, 'DEFAULT_CALENDAR_INVITATION_TO_GUESTS_ADD_CATEGORY', 'en');




insert into "anv".reference (code, name, parentid) VALUES ('CALENDAR_INVITATION_TO_GUESTS_EDIT_CATEGORY', 'Calendar Invitation to guests Edit', 509);

INSERT INTO "anv"."emailtemplate"(deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, messagehtml, name, sendemail, subject, categoryid, fromusername, customentityaction, activitytext, entitytype, toemailquery, customentityid, code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Dear ${USER},</p>
          <p>Please be informed that ${CREATOR_NAME} updated this event.</p>
          <p>${UPDATED} Event details:</p>
          <div style="background-color:lightblue; width:100%;">
              <p>Title: ${EVENT_NAME}</p>
              <p>Description: ${DESCRIPTION}</p>
              <p>When: ${DATE}</p>
          </div>
          <p>Where: ${WHERE}</p>
          <p>Organizer: ${CREATOR_NAME}</p>
          <p>Shared with: ${SHARED_WITH}</p>
          <p>Guests: ${GUESTS}</p>
          <p>
            <b>Going?</b>
            - <a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&cid=${COMPANY_ID}&id=${EVENT_ID}&email=${GUESTSEMAIL}&answer=Accepted"> Yes </a>
            - <a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&cid=${COMPANY_ID}&id=${EVENT_ID}&email=${GUESTSEMAIL}&answer=Tentatively"> Maybe </a>
            - <a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&cid=${COMPANY_ID}&id=${EVENT_ID}&email=${GUESTSEMAIL}&answer=Declined"> No </a>
          </p>', 'Default Edit Calendar invitation to guests', null, 'Updated Invitation: ${EVENT_NAME} ${DATE}',
          (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_INVITATION_TO_GUESTS_EDIT_CATEGORY'),
          null, null, null, null, null, null, 'DEFAULT_CALENDAR_INVITATION_TO_GUESTS_EDIT_CATEGORY', 'en');




insert into "anv".reference (code, name, parentid) VALUES ('CALENDAR_INVITATION_TO_GUESTS_DELETE_CATEGORY', 'Calendar Invitation to guests Delete', 509);

INSERT INTO "anv"."emailtemplate"(deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, messagehtml, name, sendemail, subject, categoryid, fromusername, customentityaction, activitytext, entitytype, toemailquery, customentityid, code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Dear ${USER},</p>
          <p>Please, be informed ${CREATOR_NAME} has <b>deleted</b> the following event that you have been invited:</p>
          <p>${UPDATED} Event details:</p>
          <div style="background-color:lightblue; width:100%;">
              <p>Title: ${EVENT_NAME}</p>
              <p>Description: ${DESCRIPTION}</p>
              <p>When: ${DATE}</p>
          </div>
          <p>Where: ${WHERE}</p>
          <p>Organizer: ${CREATOR_NAME}</p>
          <p>Shared with: ${SHARED_WITH}</p>', 'Default Delete Calendar invitation to guests', null, 'Canceled Event: ${EVENT_NAME}',
          (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_INVITATION_TO_GUESTS_DELETE_CATEGORY'),
          null, null, null, null, null, null, 'DEFAULT_CALENDAR_INVITATION_TO_GUESTS_DELETE_CATEGORY','en');

