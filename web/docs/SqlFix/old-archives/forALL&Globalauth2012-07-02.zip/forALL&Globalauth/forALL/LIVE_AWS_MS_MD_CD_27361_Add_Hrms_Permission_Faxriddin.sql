


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_SUMMARY', 'PM', 'PM Department Summary', 20, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PROFILE_NOTE', 'PM', 'PM Department Summary', 20, false);

