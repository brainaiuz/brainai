--Public.  Birinchi uriladi--
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_MESSAGE_IN_DRAFT_LIST', 'CRM', 'CRM Add New Message in Draft List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_MESSAGE_SUMMARY', 'CRM', 'CRM Message Summary', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_MESSAGE_EDIT', 'CRM', 'CRM Message Edit', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_MESSAGE_REMOVE', 'CRM', 'CRM Message Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_NEW_MESSAGE_IN_SENT_MESSAGE', 'CRM', 'CRM New Message in Sent Message', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_VIEW_SUMMARY_IN_SENT_MESSAGE', 'CRM', 'CRM View Summary in Sent Message', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TRACK_MESSAGES_IN_SENT_MESSAGE', 'CRM', 'CRM Track Messages in Sent Message', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE', 'CRM', 'CRM Update Statistic in Sent Message', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_MESSAGE_IN_SENT_MESSAGE', 'CRM', 'CRM Edit Message in Sent Message', 1, false);



--Private.  Ikkinchi--
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ADD_NEW_MESSAGE_IN_DRAFT_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ADD_NEW_MESSAGE_IN_DRAFT_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ADD_NEW_MESSAGE_IN_DRAFT_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ADD_NEW_MESSAGE_IN_DRAFT_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ADD_NEW_MESSAGE_IN_DRAFT_LIST', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_SUMMARY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_SUMMARY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_SUMMARY', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_SUMMARY', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_SUMMARY', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_EDIT', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_EDIT', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_EDIT', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_REMOVE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_REMOVE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_REMOVE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_REMOVE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_MESSAGE_REMOVE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_NEW_MESSAGE_IN_SENT_MESSAGE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_NEW_MESSAGE_IN_SENT_MESSAGE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_NEW_MESSAGE_IN_SENT_MESSAGE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_NEW_MESSAGE_IN_SENT_MESSAGE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_NEW_MESSAGE_IN_SENT_MESSAGE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_VIEW_SUMMARY_IN_SENT_MESSAGE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_VIEW_SUMMARY_IN_SENT_MESSAGE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_VIEW_SUMMARY_IN_SENT_MESSAGE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_VIEW_SUMMARY_IN_SENT_MESSAGE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_VIEW_SUMMARY_IN_SENT_MESSAGE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TRACK_MESSAGES_IN_SENT_MESSAGE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TRACK_MESSAGES_IN_SENT_MESSAGE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TRACK_MESSAGES_IN_SENT_MESSAGE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TRACK_MESSAGES_IN_SENT_MESSAGE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TRACK_MESSAGES_IN_SENT_MESSAGE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_EDIT_MESSAGE_IN_SENT_MESSAGE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_EDIT_MESSAGE_IN_SENT_MESSAGE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_EDIT_MESSAGE_IN_SENT_MESSAGE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_EDIT_MESSAGE_IN_SENT_MESSAGE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_EDIT_MESSAGE_IN_SENT_MESSAGE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );
