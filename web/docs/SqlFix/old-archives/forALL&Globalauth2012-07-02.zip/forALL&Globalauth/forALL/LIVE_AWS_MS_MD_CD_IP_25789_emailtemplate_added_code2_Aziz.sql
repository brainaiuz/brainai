update "anv".emailtemplate set code = null;
update "anv".emailtemplate set code = upper(replace(replace(replace(replace(replace(name, '-', '_'), ')', '_'), '(', '_'), ' ', '_'), '__', '_')) where iscompanyemailtemplate='DEFAULT_EMAIL_TEMPLATE';
update "anv".emailtemplate set locale = null;
update "anv".emailtemplate set locale = 'en' where iscompanyemailtemplate='DEFAULT_EMAIL_TEMPLATE';