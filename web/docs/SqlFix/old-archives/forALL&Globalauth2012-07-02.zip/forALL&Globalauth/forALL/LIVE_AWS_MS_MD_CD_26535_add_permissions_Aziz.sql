--Public schema, schema updatedan keyin
-- WORKSPACE
-- PM
-- HRMS
-- CRM
-- ACCOUNTING
-- PAYROLL
-- DOCUMENTS
-- DASHBOARD
-- MYACCOUNT
-- SETTINGS
-- REPORTING

--Public schema
TRUNCATE permission CASCADE;

--PM SECTION
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_LIST', 'PM', 'Task List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_ISSUE_LIST', 'PM', 'Issue List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TIMESHEET', 'PM', 'Timesheet', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TIMESHEET_APPROVAL', 'PM', 'Timesheet Approval', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_PROJECT_LIST', 'PM', 'Project List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_CUSTOMER_LIST', 'PM', 'Customer Center', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_EMPLOYEE_LIST', 'PM', 'Employee List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_DEPARTMENT_LIST', 'PM', 'Department List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_LOCATION_LIST', 'PM', 'Location List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_ADD', 'PM', 'Adding new tasks', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_ADD_MULTI', 'PM', 'Adding multiple tasks', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_EDIT', 'PM', 'Editing tasks', 3, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_REMOVE', 'PM', 'Removing tasks', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_DOCUMENTS', 'PM', 'Documents', 5, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_NOTES', 'PM', 'Notes', 6, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_PDF_EXCEL_EXPORT', 'PM', 'Pdf/excel export', 7, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_TIMER', 'PM', 'Timer', 8, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_TASKS_VIEW_PROJECT_COST', 'PM', 'View Task costs', 9, false);

--MAIN MENUS
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('WORKSPACE_MAIN_MENU', 'WORKSPACE', 'Workspace', 1, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_MAIN_MENU', 'PM', 'Project Management', 2, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_MAIN_MENU', 'HRMS', 'HRMS', 3, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_MAIN_MENU', 'CRM', 'CRM', 4, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MAIN_MENU', 'ACCOUNTING', 'Accounting', 5, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_MAIN_MENU', 'PAYROLL', 'Payroll', 6, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('DOCUMENTS_MAIN_MENU', 'DOCUMENTS', 'Documents', 7, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('DASHBOARD_MAIN_MENU', 'DASHBOARD', 'Dashboard', 8, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('MYACCOUNT_MAIN_MENU', 'MYACCOUNT', 'My Account', 9, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_MAIN_MENU', 'SETTINGS', 'Settings', 10, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('REPORTING_MAIN_MENU', 'REPORTING', 'Reporting', 11, true);


