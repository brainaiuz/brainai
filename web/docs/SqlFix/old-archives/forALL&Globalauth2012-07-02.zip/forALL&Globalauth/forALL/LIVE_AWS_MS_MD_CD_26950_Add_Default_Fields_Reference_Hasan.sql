update "anv".reference set isSystemreference = true;
update "anv".reference set isRemovable = false;
