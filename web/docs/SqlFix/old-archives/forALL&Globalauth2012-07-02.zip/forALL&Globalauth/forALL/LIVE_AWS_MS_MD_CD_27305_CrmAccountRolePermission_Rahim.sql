--PUBLIC SCHEMA
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNT_ADD', 'PM', 'Add New Account', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SUPPLIER_ADD', 'PM', 'Add New Supplier', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CLIENT_ADD', 'PM', 'Add New Client', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_CONVERT', 'PM', 'Account Convert', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_MERGE', 'PM', 'Account Merge', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'PM', 'Account Merge', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_DELETE', 'PM', 'Account Merge', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_ACTIVITY_ADD', 'PM', 'Add Activity', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_EDIT', 'PM', 'Edit Account', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'PM', 'Send Sales Quote', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACCOUNTS_SEND_SALES_INVOICE', 'PM', 'Send Sales Invoice', 10, false);

--PRIVATE
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNT_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNT_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNT_ADD', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNT_ADD', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNT_ADD', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNT_ADD', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SUPPLIER_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SUPPLIER_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SUPPLIER_ADD', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SUPPLIER_ADD', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SUPPLIER_ADD', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_SUPPLIER_ADD', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CLIENT_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CLIENT_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CLIENT_ADD', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CLIENT_ADD', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CLIENT_ADD', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_CLIENT_ADD', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_CONVERT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_CONVERT', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_CONVERT', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_CONVERT', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_MERGE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_MERGE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_MERGE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_MERGE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_MERGE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_MERGE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DETECT_DUBLICATES', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DELETE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DELETE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DELETE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DELETE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_DELETE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_ACTIVITY_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_ACTIVITY_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_ACTIVITY_ADD', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_ACTIVITY_ADD', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_ACTIVITY_ADD', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_ACTIVITY_ADD', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_EDIT', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_EDIT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_EDIT', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_EDIT', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_QUOTE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_INVOICE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_INVOICE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_INVOICE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_INVOICE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_ACCOUNTS_SEND_SALES_INVOICE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );
