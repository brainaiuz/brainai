insert into "anv".role (code,name, issystem,isdeleted,isentityspecific, sorder) values('CREATOR','Creator',true,false,true,21);
update "anv".role set code='PMOFPR' where code='PMOFRP';

<!--PM_ISSUE_ADD-->
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_ADD', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );

 <!--PM_ISSUE_REMOVE-->
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_REMOVE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_REMOVE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_REMOVE', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_REMOVE', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_REMOVE', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_REMOVE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );


<!--PM_ISSUE_EDIT-->
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ISSUE_EDIT', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );
