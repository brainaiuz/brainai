-- run after schema update
update companySystemSettings set isShowBookingItems = false;