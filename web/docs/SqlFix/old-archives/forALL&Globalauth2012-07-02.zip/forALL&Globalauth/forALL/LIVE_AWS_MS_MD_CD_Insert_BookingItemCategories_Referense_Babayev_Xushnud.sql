insert into "anv".reference(code, name) values('_BOOKING_ITEM_CATEGORY', 'Booking Item Category');

insert into "anv".reference(code, name, sorder, parentid)
values('BIG_MEETING_ROOM', 'Big Meeting Room', 1, (select id from "anv".reference where code='_BOOKING_ITEM_CATEGORY'));

insert into "anv".reference(code, name, sorder, parentid)
values('SMAL_MEETING_ROOM', 'Smal Meeting Room', 2, (select id from "anv".reference where code='_BOOKING_ITEM_CATEGORY'));