INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_ISSUE_ADD', 'PM', 'Adding new issue', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_ISSUE_REMOVE', 'PM', 'Remove issue', 11, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_ISSUE_EDIT', 'PM', 'Edit issue', 12, false);
