/*Accounting Main Menu*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_GETTING_STARTED_MENU', 'ACCOUNTING', 'Getting Started Menu', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNTING_MENU', 'ACCOUNTING', 'Accounting Menu', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_WAREHOUSE_MENU', 'ACCOUNTING', 'Warehouse Menu', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REPORTS_MENU', 'ACCOUNTING', 'Reports Menu', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_STOREFRONT_MENU', 'ACCOUNTING', 'Storefront Menu', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SETTINGS_MENU', 'ACCOUNTING', 'Settings Menu', 1, false);

/*Accounting*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_QUOTE_LIST', 'ACCOUNTING', 'Sales Quote List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_QUOTE_ADD', 'ACCOUNTING', 'Sales Quote Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_QUOTE_EDIT', 'ACCOUNTING', 'Sales Quote Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_QUOTE_DELETE', 'ACCOUNTING', 'Sales Quote Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_QUOTE_SUMMARY', 'ACCOUNTING', 'Sales Quote Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_QUOTE_COPY', 'ACCOUNTING', 'Sales Quote Copy', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_ORDER_LIST', 'ACCOUNTING', 'Sales Order List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_ORDER_ADD', 'ACCOUNTING', 'Sales Order Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_ORDER_DELETE', 'ACCOUNTING', 'Sales Order Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_ORDER_SUMMARY', 'ACCOUNTING', 'Sales Order Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_ORDER_PICKLIST', 'ACCOUNTING', 'Sales Order Pick List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_ORDER_COPYTOPO', 'ACCOUNTING', 'Sales Order Copy To PO', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_LIST', 'ACCOUNTING', 'Sales Invoice List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_ADD', 'ACCOUNTING', 'Sales Invoice Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_EDIT', 'ACCOUNTING', 'Sales Invoice Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_DELETE', 'ACCOUNTING', 'Sales Invoice Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_VOID', 'ACCOUNTING', 'Sales Invoice Void', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_SUMMARY', 'ACCOUNTING', 'Sales Invoice Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_CREDIT_NOTE_ADD', 'ACCOUNTING', 'Credit Note Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_COPY', 'ACCOUNTING', 'Sales Invoice Copy', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SALES_INVOICE_COPYTOPO', 'ACCOUNTING', 'Sales Invoice Copy To PO', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECEIVE_PAYMENT', 'ACCOUNTING', 'Receive Payment', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PREPAYMENT_ADD', 'ACCOUNTING', 'Add Prepayment', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CUSTOMER_PROJECT_BALANCE', 'ACCOUNTING', 'Customer Project Balance', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECURRING_INVOICE_LIST', 'ACCOUNTING', 'Recurring Invoice List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECURRING_INVOICE_ADD', 'ACCOUNTING', 'Recurring Invoice Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECURRING_INVOICE_EDIT', 'ACCOUNTING', 'Recurring Invoice Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECURRING_INVOICE_DELETE', 'ACCOUNTING', 'Recurring Invoice Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECURRING_INVOICE_SUMMARY', 'ACCOUNTING', 'Recurring Invoice Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RECURRING_INVOICE_COPY', 'ACCOUNTING', 'Recurring Invoice Copy', 1, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CUSTOMER_LIST', 'ACCOUNTING', 'Customer List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CUSTOMER_ADD', 'ACCOUNTING', 'Customer Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CUSTOMER_EDIT', 'ACCOUNTING', 'Customer Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CUSTOMER_DELETE', 'ACCOUNTING', 'Customer Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CUSTOMER_SUMMARY', 'ACCOUNTING', 'Customer Summary', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_ORDER_LIST', 'ACCOUNTING', 'Purchase Order List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_ORDER_ADD', 'ACCOUNTING', 'Purchase Order Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_ORDER_EDIT', 'ACCOUNTING', 'Purchase Order Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_ORDER_DELETE', 'ACCOUNTING', 'Purchase Order Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_ORDER_SUMMARY', 'ACCOUNTING', 'Purchase Order Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_ORDER_COPY', 'ACCOUNTING', 'Purchase Order Copy', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_LIST', 'ACCOUNTING', 'Purchase Invoice List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_ADD', 'ACCOUNTING', 'Purchase Invoice Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_EDIT', 'ACCOUNTING', 'Purchase Invoice Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_DELETE', 'ACCOUNTING', 'Purchase Invoice Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_VOID', 'ACCOUNTING', 'Purchase Invoice Void', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_SUMMARY', 'ACCOUNTING', 'Purchase Invoice Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_CREDIT_NOTE_ADD', 'ACCOUNTING', 'Credit Note Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PURCHASE_INVOICE_COPY', 'ACCOUNTING', 'Purchase Invoice Copy', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PAY_BILL', 'ACCOUNTING', 'Pay Bill', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SUPPLIER_LIST', 'ACCOUNTING', 'Supplier List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SUPPLIER_ADD', 'ACCOUNTING', 'Supplier Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SUPPLIER_EDIT', 'ACCOUNTING', 'Supplier Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SUPPLIER_DELETE', 'ACCOUNTING', 'Supplier Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SUPPLIER_SUMMARY', 'ACCOUNTING', 'Supplier Summary', 1, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_FIXED_ASSET_LIST', 'ACCOUNTING', 'Fixed Asset List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_FIXED_ASSET_ADD', 'ACCOUNTING', 'Fixed Asset Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_FIXED_ASSET_EDIT', 'ACCOUNTING', 'Fixed Asset Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_FIXED_ASSET_DELETE', 'ACCOUNTING', 'Fixed Asset Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_FIXED_ASSET_DEPRECIATION_UPDATE', 'ACCOUNTING', 'Update Depreciation', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_LIST', 'ACCOUNTING', 'Product List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_ADD', 'ACCOUNTING', 'Product Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_GROUP_ADD', 'ACCOUNTING', 'Product Group Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_EDIT', 'ACCOUNTING', 'Product Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_DELETE', 'ACCOUNTING', 'Product Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_SUMMARY', 'ACCOUNTING', 'Product Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_VARIATION_ADD', 'ACCOUNTING', 'Variation Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_VARIATION_DELETE', 'ACCOUNTING', 'Variation Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_STOCK_ADJUSTMENT', 'ACCOUNTING', 'Stock Adjustment', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_STOCK_TRANSFER', 'ACCOUNTING', 'Stock Transfer', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_EXPENSE_REPORT_LIST', 'ACCOUNTING', 'Expense Claims List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_EXPENSE_REPORT_ADD', 'ACCOUNTING', 'Expense Claims Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_EXPENSE_REPORT_EDIT', 'ACCOUNTING', 'Expense Claims Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_EXPENSE_REPORT_DELETE', 'ACCOUNTING', 'Expense Claims Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_EXPENSE_REPORT_VOID', 'ACCOUNTING', 'Expense Claims Void', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_EXPENSE_REPORT_SUMMARY', 'ACCOUNTING', 'Expense Claims Summary', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CHECK_LIST', 'ACCOUNTING', 'Check List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_LIST', 'ACCOUNTING', 'Bank Account List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_ADD', 'ACCOUNTING', 'Bank Account Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_EDIT', 'ACCOUNTING', 'Bank Account Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_DELETE', 'ACCOUNTING', 'Bank Account Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_SPEND', 'ACCOUNTING', 'Spend Money', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_RECEIVE', 'ACCOUNTING', 'Receive Money', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_TRANSFER', 'ACCOUNTING', 'Transfer Money', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_TRANSACTION_IMPORT', 'ACCOUNTING', 'Import Transactions', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_ACCOUNT_TRANSACTIONS', 'ACCOUNTING', 'Account Transactions', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BANK_STATEMENT', 'ACCOUNTING', 'Bank Statements', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_LIST', 'ACCOUNTING', 'Chart Of Account List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_ADD', 'ACCOUNTING', 'Chart Of Account Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_EDIT', 'ACCOUNTING', 'Chart Of Account Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_DELETE', 'ACCOUNTING', 'Chart Of Account Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_SUMMARY', 'ACCOUNTING', 'Chart Of Account Summary', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RESERVATION_LIST', 'ACCOUNTING', 'Reservation List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RESERVATION_ADD', 'ACCOUNTING', 'Reservation Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_RESERVATION_EDIT', 'ACCOUNTING', 'Reservation Edit', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MANUAL_JOURNAL_LIST', 'ACCOUNTING', 'Manual Journal List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MANUAL_JOURNAL_ADD', 'ACCOUNTING', 'Manual Journal Add', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MANUAL_JOURNAL_EDIT', 'ACCOUNTING', 'Manual Journal Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MANUAL_JOURNAL_DELETE', 'ACCOUNTING', 'Manual Journal Delete', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MANUAL_JOURNAL_VOID', 'ACCOUNTING', 'Manual Journal Void', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_MANUAL_JOURNAL_SUMMARY', 'ACCOUNTING', 'Manual Journal Summary', 1, false);

/*Warehouse*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_WAREHOUSE_LIST', 'ACCOUNTING', 'Warehouse List', 1, false);

/*Reports*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BUDGET_SHEET', 'ACCOUNTING', 'Budget Sheet', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_JOURNAL_REPORT', 'ACCOUNTING', 'Journal Report', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_TRIAL_BALANCE', 'ACCOUNTING', 'Trial Balance', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PROFIT_AND_LOSS', 'ACCOUNTING', 'Profit And Loss', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BALANCE_SHEET', 'ACCOUNTING', 'Balance Sheet', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_TRANSACTIONS', 'ACCOUNTING', 'Account Transactions', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_VAT_RETURN', 'ACCOUNTING', 'Vat Return Report', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_VAT_RETURNS_LIST', 'ACCOUNTING', 'Vat Return Report List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_STOCK_VALUATION', 'ACCOUNTING', 'Stock Valuation', 1, false);

/*Settings*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_INVOICE_SETTINGS', 'ACCOUNTING', 'Invoice Settings', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_FINANCIAL_SETTINGS', 'ACCOUNTING', 'Financial Settings', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_ACCOUNT_NUMBERING', 'ACCOUNTING', 'Account Numbering', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_CONVERSION_BALANCE', 'ACCOUNTING', 'Conversion Balance', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_NUMBERING_SETTINGS', 'ACCOUNTING', 'Numbering Settings', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_TAX_RATES_LIST', 'ACCOUNTING', 'Tax Rates', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRICE_LEVELS_LIST', 'ACCOUNTING', 'Price Levels', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_DISCOUNTS_LIST', 'ACCOUNTING', 'Discounts', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_UNIT_MEASUREMENTS_LIST', 'ACCOUNTING', 'Measurements', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_PRODUCT_CATEGORIES_LIST', 'ACCOUNTING', 'Product Categories', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_BRANDS_LIST', 'ACCOUNTING', 'Brands', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SHIPPING_METHODS_LIST', 'ACCOUNTING', 'Shipping Methods', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_INVOICE_TEMPLATES_LIST', 'ACCOUNTING', 'Invoice Templates', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_SAASU_INTEGRATION_SETTINGS', 'ACCOUNTING', 'Saasu Integration', 1, false);
