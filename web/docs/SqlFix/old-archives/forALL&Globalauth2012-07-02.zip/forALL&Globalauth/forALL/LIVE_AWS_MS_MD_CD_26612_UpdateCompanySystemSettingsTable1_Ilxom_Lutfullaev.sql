-- run after schema update
update companySystemSettings set isChangeTasksProject = false;