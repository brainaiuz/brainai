INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_ADD', 'CRM', 'Task Add', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_ADD_MULTI', 'CRM', 'Task Multi Add', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_EDIT', 'CRM', 'Task Edit', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_DOCUMENTS', 'CRM', 'Task Documents', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_NOTES', 'CRM', 'Task Notes', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_REMOVE', 'CRM', 'Task Remove', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_PDF_EXCEL_EXPORT', 'CRM', 'Task Remove', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_TIMER', 'CRM', 'Task Timer', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_TASKS_COMPOSE', 'CRM', 'Task Compose', 10, false);






