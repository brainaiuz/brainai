-- you should execute this patch for public schema before using reporting tool filter options

--current date
DROP FUNCTION IF EXISTS currentDate();
CREATE OR REPLACE FUNCTION currentDate()
RETURNS date AS
$$
  SELECT (current_date)::date
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

DROP FUNCTION IF EXISTS currentYearFirstDay();
CREATE OR REPLACE FUNCTION currentYearFirstDay()
RETURNS date AS
$$
  SELECT (date_trunc('YEAR', current_date))::date
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

-- year
DROP FUNCTION IF EXISTS currentYearLastDay();
CREATE OR REPLACE FUNCTION currentYearLastDay() --done
RETURNS date AS
$$
  SELECT (date_trunc('YEAR', current_date) + INTERVAL '1 YEAR - 1 DAY')::date;
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

--quertar
DROP FUNCTION IF EXISTS currentQuarterLastDay();
CREATE OR REPLACE FUNCTION currentQuarterLastDay() --done
RETURNS date AS
$$
  SELECT (date_trunc('QUARTER', current_date) + INTERVAL '4 MONTH - 1 DAY')::date;
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

DROP FUNCTION IF EXISTS currentQuarterFirstDay();
CREATE OR REPLACE FUNCTION currentQuarterFirstDay()
RETURNS date AS
$$
  SELECT (date_trunc('QUARTER', current_date))::date
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

--month
DROP FUNCTION IF EXISTS currentMonthLastDay();
CREATE OR REPLACE FUNCTION currentMonthLastDay() --done
RETURNS date AS
$$
  SELECT (date_trunc('MONTH', current_date) + INTERVAL '1 MONTH - 1 DAY')::date;
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

DROP FUNCTION IF EXISTS currentMonthFirstDay();
CREATE OR REPLACE FUNCTION currentMonthFirstDay()
RETURNS date AS
$$
  SELECT (date_trunc('MONTH', current_date))::date
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

--month
DROP FUNCTION IF EXISTS currentMonthLastDay();
CREATE OR REPLACE FUNCTION currentMonthLastDay() --done
RETURNS date AS
$$
  SELECT (date_trunc('MONTH', current_date) + INTERVAL '1 MONTH - 1 DAY')::date;
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

--week
DROP FUNCTION IF EXISTS currentWeekFirstDay();
CREATE OR REPLACE FUNCTION currentWeekFirstDay() --done
RETURNS date AS
$$
  SELECT (date_trunc('WEEK', current_date))::date;
$$ LANGUAGE 'sql' IMMUTABLE STRICT;

DROP FUNCTION IF EXISTS currentWeekLastDay();
CREATE OR REPLACE FUNCTION currentWeekLastDay() --done
RETURNS date AS
$$
  SELECT (date_trunc('WEEK', current_date) + INTERVAL '1 WEEK - 1 DAY')::date;
$$ LANGUAGE 'sql' IMMUTABLE STRICT;