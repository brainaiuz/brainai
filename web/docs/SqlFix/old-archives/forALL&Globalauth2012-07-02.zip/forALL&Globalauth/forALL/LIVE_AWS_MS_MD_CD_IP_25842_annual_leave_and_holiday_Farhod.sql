--run it after schema update
INSERT INTO "anv".annualleave(allowanceyear, annualallowanceminutes, employeeid)
SELECT 2009, (SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN endtime - starttime ELSE 0 END)/ SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN 1 ELSE 0 END)) * COALESCE(e.annualallowance, 0), e.id
FROM "anv".employee e
LEFT JOIN "anv".timeslot t ON t.id = e.timeslotid
LEFT JOIN "anv".timeslotitem ti ON ti.timeslotid = t.id
GROUP BY e.id, e.annualallowance;

INSERT INTO "anv".annualleave(allowanceyear, annualallowanceminutes, employeeid)
SELECT 2010, (SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN endtime - starttime ELSE 0 END)/ SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN 1 ELSE 0 END)) * COALESCE(e.annualallowance, 0), e.id
FROM "anv".employee e
LEFT JOIN "anv".timeslot t ON t.id = e.timeslotid
LEFT JOIN "anv".timeslotitem ti ON ti.timeslotid = t.id
GROUP BY e.id, e.annualallowance;

INSERT INTO "anv".annualleave(allowanceyear, annualallowanceminutes, employeeid)
SELECT 2011, (SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN endtime - starttime ELSE 0 END)/ SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN 1 ELSE 0 END)) * COALESCE(e.annualallowance, 0), e.id
FROM "anv".employee e
LEFT JOIN "anv".timeslot t ON t.id = e.timeslotid
LEFT JOIN "anv".timeslotitem ti ON ti.timeslotid = t.id
GROUP BY e.id, e.annualallowance;

INSERT INTO "anv".annualleave(allowanceyear, annualallowanceminutes, employeeid)
SELECT 2012, (SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN endtime - starttime ELSE 0 END)/ SUM(CASE WHEN ti.starttime <> 0 and ti.endtime <> 0 THEN 1 ELSE 0 END)) * COALESCE(e.annualallowance, 0), e.id
FROM "anv".employee e
LEFT JOIN "anv".timeslot t ON t.id = e.timeslotid
LEFT JOIN "anv".timeslotitem ti ON ti.timeslotid = t.id
GROUP BY e.id, e.annualallowance;


UPDATE "anv".holiday SET dayoff = true;