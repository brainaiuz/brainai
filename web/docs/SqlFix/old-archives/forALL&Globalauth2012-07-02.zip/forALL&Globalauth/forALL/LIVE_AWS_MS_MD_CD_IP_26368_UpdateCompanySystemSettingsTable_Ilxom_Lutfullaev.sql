-- run after schema update
update companySystemSettings set isShowMeetingMinutes = false;