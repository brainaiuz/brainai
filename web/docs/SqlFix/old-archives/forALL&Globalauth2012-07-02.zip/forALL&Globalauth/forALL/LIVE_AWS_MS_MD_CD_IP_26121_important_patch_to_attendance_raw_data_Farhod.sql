--To'lqin bu patchni app ga urgan paytda app.kpi.com/import/patch ni ishlatgandan keyin urish kerak
--AWS da esa xozir ursa ham bo'ladi
UPDATE "anv".attendancerawdata SET timesheet = t.s
FROM (SELECT employeeid e, d.id d, SUM(COALESCE(timespent, 0)) s FROM "anv".timesheet
LEFT JOIN datejoin d ON timesheet.date = d.from_date
WHERE statusid = 269
GROUP BY e, d
ORDER BY d.id) as t
WHERE t.e = employeeid and t.d = dateid;

UPDATE "anv".attendancerawdata SET timesheetPending = t.s
FROM (SELECT employeeid e, d.id d, SUM(COALESCE(timespent, 0)) s FROM "anv".timesheet
LEFT JOIN datejoin d ON timesheet.date = d.from_date
WHERE statusid is null
GROUP BY e, d
ORDER BY d.id) as t
WHERE t.e = employeeid and t.d = dateid;