-- BU patch awsda ham app ga ham urildi
update "anv".reference set sorder='1' where parentid=(select id from "anv".reference where code='_PROJECT_STATUS') and code='PS_NOT_STARTED';
update "anv".reference set sorder='2' where parentid=(select id from "anv".reference where code='_PROJECT_STATUS') and code='ONGOING';
update "anv".reference set sorder='3' where parentid=(select id from "anv".reference where code='_PROJECT_STATUS') and code='PS_COMPLETED';
update "anv".reference set sorder='4' where parentid=(select id from "anv".reference where code='_PROJECT_STATUS') and code='ALL';