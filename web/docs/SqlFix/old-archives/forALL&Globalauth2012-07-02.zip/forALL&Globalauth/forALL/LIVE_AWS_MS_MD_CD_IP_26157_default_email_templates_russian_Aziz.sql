INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale) 
VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname}  ${lastname}  ,</p> <p>Эта счет-фактура с  ${startdate} по ${duedate} .
Пожалуйста рассмотрите прикрепленную счет-фактуру .</p> <p>Спасибо за Ваш бизнес, если у Вас возникнут вопросы,пожалуйста свяжитесь со мной  <b><u> ${email} </u></b>
если у Вас возникнут вопросы относительно счета.</p><p >С Уважением</br>Бухгалтерия</br><b> ${companyname} </b></p>', 'Шаблон по умолчанию для Счет фактуры', null, 'Счет фактура', (SELECT min(id) FROM "anv".reference r WHERE code = 'SALES_INVOICE_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_INVOICE', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемы (ая) ${firstname}  ${lastname},</p> <p>Это предложение о продаже с ${startdate}
                  по ${duedate}. Пожалуйста рассмотрите предложение о продаже .Для справки PDFдокумент.</p>
                  ${hasaccesslink}
                 <p>Спасибо за Ваш бизнес, если у вас возникнут вопросы, пожалуйста свяжитесь со мной <b><u> ${email}
                 </u></b> Если у вас возникунт вопросы относительно предложения.</p><p>С Уважением,</br>Бухгалтерия,</br><b> ${companyname} </b></p>', 'Шаблон по умолчанию для Предложения о продаже', null, 'Предложение о продаже', (SELECT min(id) FROM "anv".reference r WHERE code = 'SALES_QUOTE_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_QUOTE', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname}  ${lastname},</p> <p>
               Эот заказ на поставку от ${startdate}
                 для компании ${companyname}. Пожалуйста рассмотрите прилагаему форму PDF для  ознокомления.Если Вы согласны с условиями заказа, пожалуйста отправьте нам Ваш счет
                с прикрепленным текущим заказом</p> <p>Пожалуйста свяжитесь с нами<b><u> ${name}
                </u></b> at <b><u> ${email} </u></b> если у Вас возникнут вопросы.</p>
                <p>С Уважением,</br> ${name} </br><b> ${companyname} </b></p>', 'Шаблон по умолчанию для заказа на поставку', null, 'Заказ на поставку', (SELECT min(id) FROM "anv".reference r WHERE code = 'PURCHASE_ORDER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_ORDER', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname}  ${lastname},</p> <p>
                Это подтверждение Вашего платежа полученный на${startdate}
               на счет No.: ${number} Прилагается квитанция об оплате.</p> <p>
               Спасибо за Ваш бизнес, если у Вас возникнут вопросы пожалуйста свяжитесь со мной <b><u> ${email}
                </u></b> Если у вас возникли вопросы по данному счету .</p>
                <p>С Уважением,</br>Бухгалтерия,</br><b> ${companyname} </b></p>', 'Шаблон по умолчанию для квитанции', null, 'Квитанция для счет-фактуры', (SELECT min(id) FROM "anv".reference r WHERE code = 'RECEIPT_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_RECEIPT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${approverfirstname}  ${approverlastname},</p><br>
             <p>Настоящим уведомляю Вас, что  ${reporterfirstname} ${reporterlastname} , был отправлен отчет  расходах 
             от WorkforceTrack.ru  ${resubmitdate}.
              This report was originally declined by you on $(declinedate). Представлено повторно отчет о расходах:</p>
              <p>Название: ${reporttitle}<br/>
              Период: ${startdate} &mdash; ${enddate}<br/>
             Дата: ${expenseamount}</p>
              <p>Прилагиется также PDF верссия отчета о расходах.</p>
              <p>Здесь <a href="${host}/Accounting.html?link=${link}&user=${userurl}" title="Обзор отчета о расходах" target="_blank">here</a>
              рассмотрите очет о расходах, также Вы можете утвердить либо отклонить.</p>
              <p>Как только Вы отклоните или утвердите отчет ${reporterfirstname} ${reporterlastname} к Вам будет направлено письмо по электронной почте о статусе.</p>
              <p><font color="red">* </font>Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера::<br/>
              ${host}/Accounting.html?link=${link}&user=${userurl}</p>', 'Шаблон по умолчанию для отчета о расходах', null, 'Отчет о расходах', (SELECT min(id) FROM "anv".reference r WHERE code = 'EXPENSE_CLAIM_CATEGORY_SUBMIT'), null, null, null, null, null, null, 'DEFAULT_EXPENSE_CLAIM_SUBMIT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${approverfirstname}  ${approverlastname},</p><br>
             <p>Настоящим уведомляю Вас, что  ${reporterfirstname} ${reporterlastname} , был отправлен отчет  расходах 
             от WorkforceTrack.ru  ${resubmitdate}.
              This report was originally declined by you on $(declinedate). Представлено повторно отчет о расходах:</p>
              <p>Название: ${reporttitle}<br/>
              Период: ${startdate} &mdash; ${enddate}<br/>
             Дата: ${expenseamount}</p>
              <p>Прилагается также PDF версия отчета о расходах.</p>
              <p>Здесь <a href="${host}/Accounting.html?link=${link}&user=${userurl}" title="Обзор отчета о расходах" target="_blank">here</a>
              рассмотрите очет о расходах, также Вы можете утвердить либо отклонить.</p>
              <p>Как только Вы отклоните или утвердите отчет ${reporterfirstname} ${reporterlastname} к Вам будет направлено письмо по электронной почте о статусе.</p>
              <p><font color="red">* </font>Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера::<br/>
              ${host}/Accounting.html?link=${link}&user=${userurl}</p>', 'Шаблон по умолчанию для повторного отправления отчета о расходах', null, 'Повторный отчет о расходах', (SELECT min(id) FROM "anv".reference r WHERE code = 'EXPENSE_CLAIM_CATEGORY_RESUBMIT'), null, null, null, null, null, null, 'DEFAULT_EXPENSE_CLAIM_RESUBMIT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${reportername},</p>
              <p>Это подтверждение,что мы получили Ваше письмо и свяжемся с Вами как можно скорее.
              Данное сообщение было автоматически сгенерировано, когда был создан запрос в службу поддержки/ обслуживания:</p>
              <p>&quot;${casesubject}&quot;, a summary of which appears below.</p>
              <p>Your ticket has been assigned an ID of [#${casenumber}].<br/>
              Если Вы хотите сделать дополнительные комментарии или сообщить какую либо информацию о кейсе. который был открыт для Вас,
              пожалуйста ответьте на это письмо и убедитесь </p>
              <p>[#${casenumber}]</p>
              <p>появляется в строке темы каждого сообщения электронной почты. Этот ID будет использоваться для отслеживания каждого сообщения, связанные с текущими случаями.</p>
              <p>Спасибо,<br/>
              ${repliercompany}<br/>
              ${replieremail}</p>
              <p>Для спарвки была отправлена копия кейса.</p>', 'Шаблон по умолчанию для автоответа кейса', null, 'Ваше сообщение для ${repliercompany} было получено', (SELECT min(id) FROM "anv".reference r WHERE code = 'CASE_AUTO_RESPONSE_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CASE_AUTO_RESPONSE', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', 'Уважаемый (ая) ${username}, Ваши Google контакты и синхронизация с Workforcetrack контактами закончена','Шаблон по умолчанию для синхронизации Google контактов', null, 'Синхронизация с Google контактами закончена', (SELECT min(id) FROM "anv".reference r WHERE code = 'GOOGLE_CONTACT_SYNC_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_GOOGLE_CONTACT_SYNCHRONIZATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${username},</p>
        <p>Сообщаем Вам,что Вы доавили предложение;${name}&quot; событие в свой календарный.</p>
        <p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: ${location}</p>
        <p>${sharedemployees}</p>
        ${guests}
        <p>Здесь <a href="${url}">here</a>для обзора событий календаря.<br/>
        * Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера
        <span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию для добавления события в календарь', null, 'Добавить в календарь извещение о событие: ${name}', (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_EVENT_ADD_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CALENDAR_ADD_EVENT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${username},</p>
        <p>Сообщаем Вам, что были совершенны следующие события<b>обновлено:</b></p>
        <p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Название: ${name}</p>
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: $WHERE</p>
        ${sharedemployees}
        ${guests}
        <p>Здесь <a href="${url}">here</a> для обзора событий календаря.<br/>
        *Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:
        <span style="color: #0033FF">${url}</span></p> ', 'Шаблон по умолчанию для редактирования события в календаре', null, 'Событие ${name} обновлено в календаре', (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_EVENT_EDIT_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CALENDAR_EDIT_EVENT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${username},</p>
        <p>Сообщаем Вам, что были совершенны следующие события <b>удалено:</b></p>
        <p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Название: ${name}</p>
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: ${location}</p>
          ${sharedemployees}', 'Шаблон по умолчанию: Событие было удалено из календаря', null, 'Событие ${name} было удалено из календаря', (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_EVENT_DELETE_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CALENDAR_DELETE_EVENT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${username},</p>
        <p>Пожалуйста, обратите внимание${creator} были <b>updated</b> совершены следующие события, которые стали общими для Вас :</b></p>
        <p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Название: ${name}</p>
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: ${location}</p>
        ${sharedemployees}
        ${guests}
        <p>Здесь <a href="${url}">here</a> для обзора событий Вашего календаря .<br/>
        * Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:
        <span style="color: #0033FF">${url}</span></p>"
<p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Название: ${name}</p>
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: ${location}</p>
        <p>Здесь<a href="${url}">here</a> для обзора событий Вашего календаря .<br/>
        * Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:
        <span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Поделится событием в календаре', null, 'С Вами поделились событием : ${name}', (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_EVENT_SHARE_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CALENDAR_SHARE_EVENT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${username},</p>
        <p>Пожалуйста, обратите внимание${creator} были <b>updated</b> совершены следующие события, которые стали общими для Вас :</b></p>
        <p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Название: ${name}</p>
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: ${location}</p>
        ${sharedemployees}
        ${guests}
        <p>Здесь <a href="${url}">here</a> для обзора событий Вашего календаря .<br/>
        * Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:
        <span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Cобытие было обновлено в календаре', null, 'Cобытие было обновлено в календаре', (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_EVENT_SHARE_EDIT_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CALENDAR_UPDATE_EVENT', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p><b>Детали событий:</b></p>
        <div style="background-color:lightblue; width:100%;">
        <p>Название: ${name}</p>
        <p>Описание: ${description}</p>
        <p>Когда: ${when}</p>
        </div>
        <p>Где: ${location}</p>
        <p>Здесь<a href="${url}">here</a> для обзора событий Вашего календаря .<br/>
        * Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:
        <span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Добавить напоминание о событии в календаре', null, 'Напоминание о добавлении события', (SELECT min(id) FROM "anv".reference r WHERE code = 'CALENDAR_EVENT_REMINDER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CALENDAR_ADD_EVENT_REMINDER', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname},</p>
<p>Пожалуйста обратите внимание, что ${creator} Вас назначели ${taskname}на задачу ${date}.</p>
<table width="705" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
  <tr>
    <td width="368" valign="top">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="368" valign="top">
            <table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%" style="vertical-align:top;">
                <tr>
                    <td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
                    font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
                       Резюме задачи</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Название задачи:</td>
                    <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${taskname}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Описание:</td>
                    <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${description}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Приоритет:</td>
                    <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${proirity}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Статус:</td>
                    <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${status}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="132" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        % Завершено:</td>
                    <td width="236" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${completed}</td>
                </tr>
            </table>
        </td>
      </tr>
    </table>
    </td>
    <td width="9">&nbsp;</td>
    <td width="328" valign="top">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="70" width="328" valign="top">
            <table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
                <tr>
                    <td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
                    font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
                        Дополнительные детали</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                       Разработчик:</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${creator}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Проект:</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${projectname}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Клиент:</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${clientname}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Назначен(ый):</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${assignees}</td>
                </tr>
                <tr><td height="9"></td></tr>
            </table>
        </td>
      </tr>
      <tr>
          <td height="89" width="328" valign="top">
            <table cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" width="100%">
                <td height="19" bgcolor="#ffffff" valign="top" colspan="2">&nbsp;</td>
                <tr>
                    <td height="20" bgcolor="#1c5b94" valign="middle" style="color:rgb(255,255,255);
                    font-size:12px;font-weight:bolder;padding-left:5px;text-align:left;font-family:Verdana,Arial,Helvetica,sans-serif;" colspan="2">
                        Даты</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Дата начало:</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${startdate}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Дата завершения:</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${duedate}</td>
                </tr>
                <tr>
                    <td height="17" bgcolor="#dce5ea" width="117" valign="top" style="color:rgb(0,0,0);
                    font-size:11px; padding-left:5px;text-align:left;font-weight:bold;font-family:Verdana,sans-serif;">
                        Предполагаемое время:</td>
                    <td width="211" valign="top" bgcolor="#dce5ea" style="color:rgb(0,0,0);
                    font-size:11px;padding-left:1px;text-align:left;font-weight:normal;font-family:Verdana,sans-serif;">
                         ${estimatedtime}</td>
                </tr>
                <tr><td height="9"></td></tr>
            </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
            ##<p>Проект : ${projectname} <br /> Назначен(ый): ${assignees}</p>
            <p>Здесь <a href="${url}" Название="Обзор задачи">здесь</a>для просмотра задачи</p>
            <p>*Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузераr: </p>
            <p><span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Вам назначена задача', null, 'Вам назначена задача', (SELECT min(id) FROM "anv".reference r WHERE code = 'TASK_ASSIGN_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_ASSIGN_TO_TASK', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname},</p>
             <p>Сообщаем Вам что,задачи предшественник - ${completed} к ${taskname} отмечен как завершен${date}.</p>
             <p>Название задачи: ${taskname}<br /> Проектt: ${projectname}<br />  Assignee(s): ${assignees}</p>
             <p>Здесь <a href="${url}" title="View task" target="_blank">here</a>
            для обзора задачи</p><p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера: </p>
             <p><span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию о завершении задачи предшественника', null, 'Задача предшественник была завершена', (SELECT min(id) FROM "anv".reference r WHERE code = 'TASK_COMPLETED_PREDECESSOR_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_PREDECESSOR_TASK_HAS_BEEN_COMPLETED', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname},</p>
            <p>Пожалуйста обратите внимание  ${creator} зарегистрированный ${projectname} в проекте ${date}.<br />
           Детали проекта находятся ниже:</p><p>Упраление проектами: ${managername}<br />
            <p>Здесь<a href="${url}" title="View project">here</a>  для просмотра проекта</p>
            <p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера: </p>
            <p><span style="color: #0033FF">${url}</span></p>
            <p>${productName} служба технической поддержки <br />
            ${companyInfo}', 'Шаблон по умолчанию: Добавление проекта', null, 'Был добавлен проект', (SELECT min(id) FROM "anv".reference r WHERE code = 'PROJECT_ADD_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_PROJECT_ADD_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)  ${firstname} ${lastname},</p>
            <p>Пожалуйста обратите внимание ${creator} Вас добавили в качестве участника  ${projectname} в проект ${date}.</p>
            <p>Детали проекта находятся ниже:</p><p>Управление проектами: ${managername}<br />
            <p>Здесь<a href="${url}" title="View project">here</a>
         для просмотра проекта</p>
            <p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера: </p>
            <p><span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Вас добавили в проект'
, null, 'Вас добавили в проект', (SELECT min(id) FROM "anv".reference r WHERE code = 'PROJECT_ASSIGN_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_PROJECT_ASSIGN_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${firstname} ${lastname},</p><p>Пожалуйста обратите внимание ${creator} Вас назначели ассистентом менеджера ${projectname} в проект ${date}.</p>
            <p>Здесь<a href="${url}" title="View project" target="_blank">here</a>
            для просмотра проектаt</p><p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера: </p>
            <p><span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Назначен менеджер проекта', null, 'Назначен менеджер проекта', (SELECT min(id) FROM "anv".reference r WHERE code = 'PROJECT_MANAGER_ASSIGN_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_PROJECT_MANAGER_ASSIGN_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${firstname} ${lastname},</p><p>Пожалуйста обратите внимание ${creator} Вас назначели ассистентом менеджера ${projectname} в проект ${date}.</p>
            <p>Здесь<a href="${url}" title="View project" target="_blank">here</a>
            для просмотра проектаt</p><p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера: </p>
            <p><span style="color: #0033FF">${url}</span></p>', 'Шаблон по умолчанию: Назначен ассистент менеджера', null, 'Был назначен ассистент менеджера', (SELECT min(id) FROM "anv".reference r WHERE code = 'BACKUP_MANAGER_ASSIGN_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_BACKUP_MANAGER_ASSIGN_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname}, </p>
            <p>Мы рады сообщить Вам ${managername} была создана учетная запись клиенту 
            ${productName} (<a href="${loginpagelink}"> ${loginpagelink} </a>)</p>
            <p>${productName} это новый улучшенный интерактивный инструмент для бизнеса, позволяет проводить следующие  задачи с меньшими усилиями и более полным контролем: Управление проектами и задачами, Управление персоналом
             Оценка деятельности, Отслеживание времени и инструмент сотрудничества.
            </p>
            <p>
            Вы можете получить доступ ${productName}, который является на веб-основе, а также просмотреть Ваши проекты оценить производительность и развитие.
             просматривать счета, задавать вопросы, а также получать уведомления и отчеты о ходе развития проекта
             Так как на  веб-основе, легко получить доступ в любое время и помогает Вашему проекту быть самым лучшем.
            </p>
            <p>Наша служба поддержки готова отвечать на ваши звонки и помочь Вам в любое время.</P>
            <p>Для того, чтобы активировать свою учетную запись, пожалуйста <a href="${activationlink}">здесь</a>
            (или скопируйте / вставить следующий адрес в адресную строку браузера: ${activationlink} )</p>

            <p> Благодарим Вас за проявленный интерес к нашему продукту .Мы рады работать с Вами и помоготь Вам
             улучшать потенциал   ${productName}. </p>
            <p><br />
            ${productName} support team<br />
            ${companyInfo}', 'Шаблон по умолчанию: Активирован клиент(новый пользователь)', null, 'Был активирован клиент (новый пользователь)', (SELECT min(id) FROM "anv".reference r WHERE code = 'CLIENT_ACTIVATION_NEW_USER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CLIENT_ACTIVATION_NEW_USER_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${firstname} ${lastname}, </p>
            <p>Мы рады сообщить Вам что, ${managername} была создана учетная запись клиенту
            ${productName} (<a href="${loginpagelink}"> ${loginpagelink}</a>)</p>
            <p>
            Вы можете войти в свой новый аккаунт с тем же именем пользователя и паролем имеющиеся в системе
            </p>
            <p>
            Вы можете получить доступ${productName}, который является на веб-основе, а также просмотреть Ваши проекты производительность и развитие,
            просматривать счета, задавать интересующиеся  вопросы, а также получать уведомления и отчеты о ходе развития проекта.
           Так как на  веб-основе, легко получить доступ в любое время и помогает Вашему проекту стать лучшим
            <p>Наша служба поддержки готова отвечать на ваши звонки и помочь Вам в любое время.</p>

            <p> Благодарим Вас за интерес к нашей продукции. Мы будем рады работать с Вами и помогать
            Вам улучшит потенциал${productName}. </p>
            <p><br />
            ${productName} служба технической поддержки<br />
            ${companyinfo}', 'Шаблон по умолчанию: Клиент активирован (существующий пользователь)', null, 'Клиент был активирован (существующий пользователь)', (SELECT min(id) FROM "anv".reference r WHERE code = 'CLIENT_ACTIVATION_EXISTING_USER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CLIENT_ACTIVATION_EXISTING_USER_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname}</a><br />
            <p>Мы рады Вам сообщить, что ${managername} была созданна учетная запись специально для Вас${productName} (${loginpagelink}).</p>
            <p>Для того, чтобы активировать свою учетную запись, пожалуйста <a href="${activationlink}">здесь</a><br />
            (или скопируйте / вставить и перейдите к следующей ссылке в вашем браузере: ${activationlink} </p>

            <p>Спасибо за ваш интерес к нашей системе.</p>
            <p>${productName}  служба технической поддержки <br />
            ${companyInfo}', 'Шаблон по умолчанию: Сотрудник активирован (новый)', null, 'Был активирован новый сотрудник', (SELECT min(id) FROM "anv".reference r WHERE code = 'EMPLOYEE_ACTIVATION_NEW_USER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_EMPLOYEE_ACTIVATION_NEW_USER_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname}, </p>
          <p>Мы рады вам сообщить, что $admin.firstName ${managername} была создана учетная запись для Вас
            at ${productName} (${loginpagelink}).</p>
            <p>
            Вы можете войти в свой новый аккаунт с тем же именем пользователя и паролем существующий в системе.
            </p>
            <p>Спасибо за ваш интерес к нашей системе.</p>
            <p>${productName}служба технической поддержки <br />
            ${companyInfo}', 'Шаблон по умолчанию: Сотрудник активирован	(существующий)', null, 'Сотрудник был активирован (существующий пользователь)', (SELECT min(id) FROM "anv".reference r WHERE code = 'EMPLOYEE_ACTIVATION_EXISTING_USER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_EMPLOYEE_ACTIVATION_EXISTING_USER_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая)${firstname} ${lastname}</p><br/>
            <p>Мы рады сообщить Вам, что${activationlink}Вы были активированны.</p>
            <p>Ваше имя пользователя ${username}.</p>
            <p>Ваш пароль ${password}.</p>
            <p>Чтобы получить доступ к вашей учетной записи, пожалуйста <a href="${loginpagelink}">здесь</a><br/>
            (или скопируйте и передите к следующей ссылке в вашем браузере: ${loginpagelink}</p>
            <p>Спасибо за Ваш интерес к нашей системе t.</p>
            <p>${productName} служба технической подджержки <br />
            ${companyInfo}', 'Шаблон по умолчанию: Подтверждение учетной записи', null, 'Учетная запись пользователя подтверждена', (SELECT min(id) FROM "anv".reference r WHERE code = 'USER_ACCOUNT_CONFIRMATION_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_USER_ACCOUNT_CONFIRMATION_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname},</p><br/>
            <p>${productName} account for ${companyname} has been created, and your personal account details are as follows:</p>
            <p>Логин: ${username}<br />  Пароль: ${password}</p>
            <p>${firstname}, Пожалуйста храните ,эту информацию если у Вас возникнут вопросы пожалуйста обратитесь к нам.</p>
            <p>Чтобы получить доступ к вашей учетной записи, пожалуйста <a href="${loginpagelink}">щелкните здесь</a><br/>
            (или скопируйте и передите к следующей ссылке в вашем браузере: ${loginpagelink}</p>
            <p>${productName} служба технической поддержки <br />
            ${companyInfo}', 'Шаблон по умолчанию: Сотрудник активирован менеджером', null, 'Сотрудник был активирован менеджером', (SELECT min(id) FROM "anv".reference r WHERE code = 'EMPLOYEE_ACTIVATED_BY_MANAGER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_EMPLOYEE_ACTIVATED_BY_MANAGER_NOTIFICATION', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname}  ${lastname},</p>
<p>Пожалуйста обратите внимание что  ${name} представленно предложение о продаже от Workforcetrack ${startdate}</p>
<p>${hasaccesslink}</p>
<p>После того как Вы утвердите или отклоните предложение о продаже ${name} к Вам будет направлено письмо по электронной почте о Вашем статусе.</p>
                <p>Спасибо,<br/> ${name} <br/><b> ${companyname} </b></p>', 'Шаблон по умолчанию предложение о продаже для менеджера', null, 'Предложение о продаже', (SELECT min(id) FROM "anv".reference r WHERE code = 'SALES_QUOTE_MANAGER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_SALES_QUOTE_FOR_MANAGER', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемый (ая) ${firstname} ${lastname} ,</p>
<p>Эта кредитовая авиза выдается на ${startdate} fдля компании ${companyname}.
Пожалуйста рассмотрите прилагаемый PDF документ для сведения .</p>
<p>Пожалуйста, свяжитесь с ${name} по ${email} если у Вас возникнут вопросы.</p>
<p>С Уважением,</br>Бухгалтерия,</br><b> ${companyname} </b></p>"
<p>Уважаемый (ая) ${receiverFullName},</p>
            <p>Информируем Вас,сто Ваш администратор <strong>${creatorFullName}</strong> добавил ${requestType} для ${employeeFullName}.</p>
            <p><strong>Детали запроса:</strong><br/>
               Причина: ${reason}<br/>
               Описание: ${description}<br/>
               Дата: от ${startdate} to ${enddate}</p>
            <p><a href="${link}"><span style="color:blue">щелкните здесь для просмотра${requestType}</span></a>*</p>
            <p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:</p>
            <p><span style="color: #0033FF">${link}</span></p>', 'Шаблон по умолчанию: Кредитовая авиза', null, 'Кредитовая авиза', (SELECT min(id) FROM "anv".reference r WHERE code = 'CREDIT_NOTE_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_CREDIT_NOTE', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемые (ая) ${receiverFullName},</p>
            <p>Информируем Вас, что <strong>${creatorFullName}</strong> добавил ${requestType}.</p>
            <p><strong>Детали запроса:</strong><br/>
               Причина: ${reason}<br/>
               Описание: ${description}<br/>
             Дата: от ${startdate} to ${enddate}</p>
            <p><a href="${link}"><span style="color:blue">щелкните здесь для просмотра ${requestType}</span></a>*</p>
            <p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:</p>
            <p><span style="color: #0033FF">${link}</span></p>', 'Шаблон по умолчанию: Добавить запрос на отпуск  (для утверждения)', null, 'Был добавлен запрос на отпуск (на утверждение)', (SELECT min(id) FROM "anv".reference r WHERE code = 'ADD_LEAVE_REQUEST_SEND_TO_ADMIN_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_ADD_LEAVE_REQUEST_BY_ADMIN_TO_APPROVER_', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемые (ая) ${receiverFullName},</p>
            <p>Информируем Вас, что <strong>${creatorFullName}</strong> добавил ${requestType}.</p>
            <p><strong>Детали запроса:</strong><br/>
               Причина: ${reason}<br/>
               Описание: ${description}<br/>
             Дата: от ${startdate} to ${enddate}</p>
            <p><a href="${link}"><span style="color:blue">щелкните здесь для просмотра ${requestType}</span></a>*</p>
            <p>* Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:</p>
            <p><span style="color: #0033FF">${link}</span></p>', 'Шаблон по умолчанию: Добавить запрос на отпуск (утвердителю)', null, 'Добавить запрос на отпуск (утвердителю)', (SELECT min(id) FROM "anv".reference r WHERE code = 'ADD_LEAVE_REQUEST_SEND_TO_APPROVER_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_ADD_LEAVE_REQUEST_NOTIFICATION_TO_APPROVER_', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемы (ая)${receiverFullName},</p>
            <p>Информируем Вас,что <strong>${creatorFullName}</strong> добавил ${requestType}.</p>
            Было ${requestType} подтверждено ${managerFullName} в ${confirmdate}
            <p><strong>Детали запроса:</strong><br/>
              Причина: ${reason}<br/>
               Описание: ${description}<br/>
            Дата: от ${startdate} to ${enddate}</p>
            <p><a href="${link}"><span style="color:blue">щелкните здесь для просмотра ${requestType}</span></a>*</p>
            <p>*Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:</p>
            <p><span style="color: #0033FF">${link}</span></p>', 'Шаблон по умолчанию: Запрос на отпуск на подтверждения (руководителю)', null, 'Был отправлен запрос на отпуск для подтверждения', (SELECT min(id) FROM "anv".reference r WHERE code = 'LEAVE_REQUEST_CONFIRMED_SEND_TO_DR_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_LEAVE_REQUEST_CONFIRMATION_NOTIFICATION_TO_DIRECTOR_', 'ru');
INSERT INTO "anv"."emailtemplate"(
             deleted, fromemail, fromuserid, iscompanyemailtemplate, isdefault, 
            messagehtml, name, sendemail, subject, categoryid, fromusername, 
            customentityaction, activitytext, entitytype, toemailquery, customentityid, 
            code, locale)
 VALUES ('f', null, '-1', 'DEFAULT_EMAIL_TEMPLATE', 't', '<p>Уважаемые (ая) ${employeeFullName},</p>
            <p>Информируем Вас,что ${creatorFullName} ${status} Ваш ${requestType}.</p>
            <p><strong>Детали запроса:</strong><br/>
              Причина : ${reason}<br/>
               Описание: ${description}<br/>
               Дата: от ${startdate} to ${enddate}</p>
            <p><a href="${link}"><span style="color:blue">щелкните здесь для просмотра${requestType}</span></a>*</p>
            <p>*Если у Вас не получается перейти по ссылке, то Вы можете скопировать данную ссылку и вставить ее в адресную строку Вашего браузера:</p>
            <p><span style="color: #0033FF">${link}</span></p>', 'Шаблон по умолчанию: Обзор запроса на отпуск по умолчанию (для сотрудников)', null, 'Уведомление о потдверждении запроса на отпуск', (SELECT min(id) FROM "anv".reference r WHERE code = 'EMPLOYEE_RESPONSE_LEAVE_REQUEST_CATEGORY'), null, null, null, null, null, null, 'DEFAULT_LEAVE_REQUEST_REVIEW_NOTIFICATION_TO_EMPLOYEE_', 'ru');
