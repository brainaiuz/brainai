ALTER TABLE "anv"."role" ALTER COLUMN id SET DEFAULT nextval('"anv".role_id_seq'::regclass);
Alter sequence "anv".role_id_seq restart 20;
