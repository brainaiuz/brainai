
-- bu patch //companyID = 28492, Company Name: ITS DEPARTMENT - PROJECT MANAGEMENT & COLLABORATION PORTAL  ga apply qilinadi

	insert into "28492".role (id, name, code, isSystem, isEntitySpecific) values (24,'Projects Director', 'PROJECTS_DIRECTOR', false, false);
	insert into "28492".role (id, name, code, isSystem, isEntitySpecific) values (25,'Auditor', 'AUDITOR', false, false);