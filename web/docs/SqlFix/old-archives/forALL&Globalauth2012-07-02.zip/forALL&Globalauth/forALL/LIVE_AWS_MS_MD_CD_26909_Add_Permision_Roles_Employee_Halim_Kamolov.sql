--PM_EMPLOYEE_ADD
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_ADD', 'TL', (SELECT id from "anv".reference where code='ALLOW') );