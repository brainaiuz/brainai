insert into "anv".reference(code, name, parentid, sorder, issystemreference, isremovable) values('SLA_PRIORITY', 'Sla Priority', null, 0, true, false);
insert into "anv".reference(code, name, parentid, sorder, issystemreference, isremovable) values('SLA_TYPE', 'Sla Type', null, 0, true, false);
insert into "anv".reference(code, name, parentid, sorder, issystemreference, isremovable) values('SLA_REASON', 'Sla Reason', null, 0, true, false);
insert into "anv".reference(code, name, parentid, sorder, issystemreference, isremovable) values('SLA_RESPONSE_TIME', 'Sla Response Time', null, 0, true, false);

insert into "anv".reference(code, name, parentid, sorder, issystemreference, isremovable, description) values
        ('SLA_PRIORITY_HIGH', 'High', (select id from "anv".reference where code = 'SLA_PRIORITY'), 0, false, true, ''),
        ('SLA_PRIORITY_MEDIUM', 'Medium', (select id from "anv".reference where code = 'SLA_PRIORITY'), 1, false, true, ''),
        ('SLA_PRIORITY_LOW', 'Low', (select id from "anv".reference where code = 'SLA_PRIORITY'), 2, false, true, ''),
        ('SLA_TYPE_INQUIRY', 'Inquiry', (select id from "anv".reference where code = 'SLA_TYPE'), 0, false, true, ''),
        ('SLA_TYPE_QUESTION', 'Question', (select id from "anv".reference where code = 'SLA_TYPE'), 1, false, true, ''),
        ('SLA_REASON_TRAINING', 'Lack Of Training', (select id from "anv".reference where code = 'SLA_REASON'), 0, false, true, ''),
        ('SLA_REASON_KNOWLEDGE', 'Lack Of knowledge', (select id from "anv".reference where code = 'SLA_REASON'), 1, false, true, ''),
        ('SLA_RESPONSE_TIME_01', '1 hour(s)', (select id from "anv".reference where code = 'SLA_RESPONSE_TIME'), 0, false, true, '60'),
        ('SLA_RESPONSE_TIME_12', '12 hour(s)', (select id from "anv".reference where code = 'SLA_RESPONSE_TIME'), 1, false, true, '720'),
        ('SLA_RESPONSE_TIME_24', '24 hour(s)', (select id from "anv".reference where code = 'SLA_RESPONSE_TIME'), 2, false, true, '1440'),
        ('SLA_RESPONSE_TIME_48', '48 hour(s)', (select id from "anv".reference where code = 'SLA_RESPONSE_TIME'), 3, false, true, '2880');