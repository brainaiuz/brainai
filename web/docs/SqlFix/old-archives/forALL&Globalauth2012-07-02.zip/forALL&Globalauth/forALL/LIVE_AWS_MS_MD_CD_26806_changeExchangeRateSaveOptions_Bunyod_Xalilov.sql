--for invoice
ALTER TABLE "anv".invoice ALTER exchangerate TYPE numeric(20,10);
--for quote
ALTER TABLE "anv".quote ALTER exchangerate TYPE numeric(20,10);