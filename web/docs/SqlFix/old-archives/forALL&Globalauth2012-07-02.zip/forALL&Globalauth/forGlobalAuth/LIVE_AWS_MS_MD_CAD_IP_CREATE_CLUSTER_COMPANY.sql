﻿CREATE OR REPLACE FUNCTION insertClusterCompany(cluster_domain text,company_id integer, domainname text) RETURNS void AS $$
DECLARE cluster_id integer;
DECLARE cc_id integer;
BEGIN
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
cc_id = (SELECT id FROM clustercompany WHERE companyid=company_id);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,googleappdomain) VALUES (cluster_id, company_id,domainname);
END IF;
ELSE
--cc_id not be null
INSERT INTO "cluster"("domain") VALUES (cluster_domain);
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,domainname) VALUES (cluster_id, company_id,domainname);
END IF;
END IF;

END;
$$ LANGUAGE 'plpgsql' VOLATILE;
Sherali Pirnafasov is busy.
Sent at 10:52 PM on Sunday
abdulaziz: CREATE OR REPLACE FUNCTION insertClusterCompany(cluster_domain text,company_id integer, domainname text) RETURNS void AS $$
DECLARE cluster_id integer;
DECLARE cc_id integer;
BEGIN
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
cc_id = (SELECT id FROM clustercompany WHERE companyid=company_id);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,googleappdomain) VALUES (cluster_id, company_id,domainname);
END IF;
ELSE
--cc_id not be null
INSERT INTO "cluster"("domain") VALUES (cluster_domain);
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,googleappdomain) VALUES (cluster_id, company_id,domainname);
END IF;
END IF;

END;
$$ LANGUAGE 'plpgsql' VOLATILE;
Sent at 11:19 PM on Sunday
abdulaziz: CREATE OR REPLACE FUNCTION insertClusterCompany(cluster_domain text,company_id integer, domainname text) RETURNS void AS $$
DECLARE cluster_id integer;
DECLARE cc_id integer;
BEGIN
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
cc_id = (SELECT id FROM clustercompany WHERE companyid=company_id);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,googleappdomain) VALUES (cluster_id, company_id,domainname);
END IF;
ELSE
--cc_id not be null
INSERT INTO "cluster"("domain") VALUES (cluster_domain);
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,googleappdomain) VALUES (cluster_id, company_id,domainname);
END IF;
END IF;

END;
$$ LANGUAGE 'plpgsql' VOLATILE;
Sent at 11:26 PM on Sunday
Sherali: RAISE NOTICE 'delete FROM vatefiling where companyid in (%);',cid;
Sent at 11:31 PM on Sunday
Sherali: CREATE OR REPLACE FUNCTION insertclustercompany(cluster_domain text, company_id integer, domainname text)
RETURNS void AS
$BODY$
DECLARE cluster_id integer;
DECLARE cc_id integer;
BEGIN
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
cc_id = (SELECT id FROM clustercompany WHERE companyid=company_id);

IF cc_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,googleappdomain) VALUES (cluster_id, company_id,domainname);
END IF;
ELSE
INSERT INTO "cluster"("domain") VALUES (cluster_domain);
cluster_id = (SELECT id FROM cluster WHERE domain=cluster_domain);
IF cluster_id IS NOT NULL
THEN
UPDATE clustercompany set clusterid = cluster_id WHERE id=cc_id;
ELSE
INSERT INTO clustercompany(clusterid, companyid,domainname) VALUES (cluster_id, company_id,domainname);
END IF;
END IF;

END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
ALTER FUNCTION insertclustercompany(text, integer, text) OWNER TO wftauth;