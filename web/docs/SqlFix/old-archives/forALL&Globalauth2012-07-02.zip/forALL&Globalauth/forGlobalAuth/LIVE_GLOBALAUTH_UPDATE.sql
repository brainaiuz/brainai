﻿CREATE OR REPLACE FUNCTION saveUserAuthenticationData(u_name text,u_password text,u_email text,u_id integer,u_companyid integer) RETURNS integer AS $$
DECLARE cc_id integer; ua_id integer; uc_id integer; returnvalue integer;
BEGIN	
	returnvalue = 0;	
	--select clustercompanyid
	RAISE NOTICE 'u_companyid =%',u_companyid;	
	cc_id = (SELECT id FROM clustercompany WHERE companyid=u_companyid);
	RAISE NOTICE 'cc_id =%',cc_id;
	IF cc_id IS NOT NULL
	  THEN 
		--select userauthid
		RAISE NOTICE 'u_name =%',u_name;
		ua_id = (SELECT id FROM userauth WHERE username=u_name); 
		RAISE NOTICE 'ua_id =%',ua_id;
		IF ua_id IS NOT NULL
		THEN
			--update userauth
			UPDATE userauth SET password=u_password WHERE id=ua_id;
			--select usercompanyid
			uc_id = (SELECT id FROM usercompany WHERE authid=ua_id AND clustercompanyid=cc_id AND userid=u_id);
			IF uc_id IS NULL
			THEN
				--create usercompany			
				INSERT INTO usercompany(userid, authid, email, clustercompanyid) VALUES (u_id, ua_id, u_email, cc_id);
			ELSE 
				UPDATE usercompany SET email=u_email WHERE id=uc_id;
			END IF;
			returnvalue = 1;
		ELSE
			--create userauth
			INSERT INTO userauth("password", username) VALUES (u_password, u_name);
			--select userauthid
			ua_id = (SELECT id FROM userauth WHERE username=u_name);
			--create usercompany
			INSERT INTO usercompany(userid, authid, email, clustercompanyid) VALUES (u_id, ua_id, u_email, cc_id);
			returnvalue = 1;
		END IF;
	ELSE 
	--cc_id not be null
	END IF;

	RETURN returnvalue;
	    
END;
$$ LANGUAGE 'plpgsql' VOLATILE;