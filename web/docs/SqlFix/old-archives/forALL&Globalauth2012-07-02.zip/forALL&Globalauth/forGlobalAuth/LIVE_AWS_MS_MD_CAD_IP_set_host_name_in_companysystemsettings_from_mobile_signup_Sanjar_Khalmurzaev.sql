UPDATE companysystemsettings
 SET host = 'app.kpi.com'
 WHERE (companysignedupfrom = 'SIGNED_UP_FROM_ANDROID' OR companysignedupfrom = 'SIGNED_UP_FROM_IPHONE');