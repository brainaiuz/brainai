CREATE SEQUENCE googlegadgetauth_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE googlegadgetauth_id_seq OWNER TO wftauth;


CREATE TABLE googlegadgetauth
(
  id serial NOT NULL,
  opensocialid character varying(255),
  token character varying(255),
  userauthid integer,
  CONSTRAINT googlegadgetauth_pkey PRIMARY KEY (id),
  CONSTRAINT fka1dd96edf4f77f31 FOREIGN KEY (userauthid)
      REFERENCES userauth (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT googlegadgetauth_opensocialid_key UNIQUE (opensocialid),
  CONSTRAINT googlegadgetauth_token_key UNIQUE (token)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE googlegadgetauth OWNER TO wfmtest;
