﻿SELECT c.id as clusterID, c.domain as clusterDomain, userID, cc.companyid
FROM userAuth ua
INNER JOIN userCompany uc on ua.id = uc.authid
INNER JOIN clustercompany cc on cc.id = uc.clustercompanyid
INNER JOIN cluster c on c.id = cc.clusterid
WHERE ua.username ='' AND ua.password='' 
ORDER BY uc.id

SELECT c.id as clusterID, c.domain as clusterDomain, userID, cc.companyid
FROM userCompany as uc
INNER JOIN clustercompany cc on cc.id = uc.clustercompanyid
INNER JOIN cluster c on c.id = cc.clusterid
WHERE uc.userId=1 AND cc.companyid=1;
