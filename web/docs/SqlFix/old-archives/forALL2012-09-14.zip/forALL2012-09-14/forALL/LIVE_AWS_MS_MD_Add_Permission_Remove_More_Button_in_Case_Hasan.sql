INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'CRM', 'Crm', 1, false);

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'CUSTOMER_SERVICE_MANAGER', (SELECT id from "anv".reference where code='ALLOW') );



insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_REMOVE_IN_MORE_BUTTON_CASE', 'CUSTOMER_SERVICE_MANAGER', (SELECT id from "0".reference where code='ALLOW') );
