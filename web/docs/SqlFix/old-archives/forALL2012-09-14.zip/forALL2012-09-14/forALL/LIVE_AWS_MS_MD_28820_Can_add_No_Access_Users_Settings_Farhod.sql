
INSERT INTO "anv".reference(code,  name, isremovable, issystemreference, deleted, shared)
VALUES ('_EMPLOYEE_STATUS',  'Employee Status', FALSE, TRUE, FALSE, TRUE);

INSERT INTO "anv".reference(code,  name, sorder, parentid, isremovable, issystemreference, deleted, shared)
VALUES ('ACTIVE_EMPLOYEE',  'Active', 1, (SELECT id FROM "anv".REFERENCE WHERE CODE = '_EMPLOYEE_STATUS'), FALSE, TRUE, FALSE, TRUE);

INSERT INTO "anv".reference(code,  name, sorder, parentid, isremovable, issystemreference, deleted, shared)
VALUES ('INACTIVE_EMPLOYEE',  'Inactive', 2, (SELECT id FROM "anv".REFERENCE WHERE CODE = '_EMPLOYEE_STATUS'), FALSE, TRUE, FALSE, TRUE);

INSERT INTO "anv".reference(code,  name, sorder, parentid, isremovable, issystemreference, deleted, shared)
VALUES ('PENDING_EMPLOYEE',  'Pending', 3, (SELECT id FROM "anv".REFERENCE WHERE CODE = '_EMPLOYEE_STATUS'), FALSE, TRUE, FALSE, TRUE);

INSERT INTO "anv".reference(code,  name, sorder, parentid, isremovable, issystemreference, deleted, shared)
VALUES ('NO_ACCESS_EMPLOYEE',  'No Access', 4, (SELECT id FROM "anv".REFERENCE WHERE CODE = '_EMPLOYEE_STATUS'), FALSE, TRUE, FALSE, TRUE);

INSERT INTO "anv".reference(code,  name, sorder, parentid, isremovable, issystemreference, deleted, shared)
VALUES ('RESIGNED_EMPLOYEE',  'Resigned', 5, (SELECT id FROM "anv".REFERENCE WHERE CODE = '_EMPLOYEE_STATUS'), FALSE, TRUE, FALSE, TRUE);

UPDATE "anv".myuser SET accountstatusid = (SELECT id FROM "anv".reference where code = 'ACTIVE_EMPLOYEE') WHERE active = true;
UPDATE "anv".myuser SET accountstatusid = (SELECT id FROM "anv".reference where code = 'INACTIVE_EMPLOYEE') WHERE active = null or active = false;
