

insert into "anv".role (code,description,name,issystem,isdeleted,isentityspecific,sorder)  values('CUSTOMER_SERVICE_MANAGER', '','Customer Service Manager', true, false, false, 210);