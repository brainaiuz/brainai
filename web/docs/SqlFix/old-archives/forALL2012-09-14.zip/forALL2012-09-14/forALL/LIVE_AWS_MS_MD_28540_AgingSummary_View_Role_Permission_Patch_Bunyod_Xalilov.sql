/*Public schema uchun*/
INSERT INTO permission(code,"name",context,ismainmenu) VALUES('ACCOUNTING_AGING_SUMMARY','Aging Summary','ACCOUNTING',false);

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_AGING_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_AGING_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_AGING_SUMMARY', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

/*Company schemalari uchun*/
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_AGING_SUMMARY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_AGING_SUMMARY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_AGING_SUMMARY', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );