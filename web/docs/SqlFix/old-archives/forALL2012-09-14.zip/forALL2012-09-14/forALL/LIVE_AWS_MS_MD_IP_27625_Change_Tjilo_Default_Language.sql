UPDATE hostbasedsetting SET  defaultlocale='nl' WHERE hostname like('%tjilo.com%');
