

delete from "anv".rolepermission where permissioncode='HRMS_RECRUITMENT' and rolecode <> 'HR' and rolecode <>'DR' and rolecode <> 'ADMIN';


delete from "0".rolepermission where permissioncode='HRMS_RECRUITMENT' and rolecode <> 'HR' and rolecode <>'DR' and rolecode <> 'ADMIN';