
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYMENT_DEDUCATION_LIST', 'PAYROLL', 'Payment/Deduction', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYMENT_DEDUCATION_ADD', 'PAYROLL', 'New Payment', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYMENT_DEDUCATION_VIEW', 'PAYROLL', 'Payment Summary View', 2, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYSLIP_LIST', 'PAYROLL', 'Payslip List', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYSLIP_ADD', 'PAYROLL', 'New Payslip', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYSLIP_EDIT', 'PAYROLL', 'Edit Payslip', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYSLIP_PDF', 'PAYROLL', 'PDF', 3, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYSLIP_PROCESS_PAYRUN', 'PAYROLL', 'Process Payrun', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_PAYSLIP_ROLLBACK_P11', 'PAYROLL', 'Rollback P11', 5, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_FORMS_REPORT', 'PAYROLL', 'Forms/Reports', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_FORMS_REPORT_TAX_CODE_CHANGES', 'PAYROLL', 'Tax Code Changes', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_FORMS_REPORT_NI_CATEGORY_CHANGES', 'PAYROLL', 'NI Category Changes', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_FORMS_REPORT_P32_FORM', 'PAYROLL', 'P32 Form', 3, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_FORMS_REPORT_EFILES_P35', 'PAYROLL', 'Efiles P35', 4, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS', 'PAYROLL', 'Payroll Settings', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_EMPLOYER_SETTINGS', 'PAYROLL', 'Employer Settings ', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_PENSION_PROVIDERS', 'PAYROLL', 'Pension Providers', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_PENSION_SCHEMES', 'PAYROLL', 'Pension Schemes', 3, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_PAYE_TAX_BAND', 'PAYROLL', 'PAYE Tax Band', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_NI_BANDS_AND_RATES', 'PAYROLL', 'NI Bands and Rates', 5, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_STUDENT_LOAN', 'PAYROLL', 'Student Loan', 6, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_PAYMENT_CATEGORIES', 'PAYROLL', 'Payment Categories', 7, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES', 'PAYROLL', 'Deduction Categories', 8, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_SETTINGS_PROCESS_PAYRUN', 'PAYROLL', 'Process Payrun', 9, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_LIST', 'PAYROLL', 'Employees', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_ADD', 'PAYROLL', 'New Employees', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_PAYROLL_SETTINGS', 'PAYROLL', 'Payroll Settings', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_RECURRING_PAYMENT_DEDUCATION_SETTINGS', 'PAYROLL', 'Recurring Payment/Deduction Settings', 3, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_BANK_DETAILS', 'PAYROLL', 'Bank Details', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_PAYSLIPS', 'PAYROLL', 'Payslips', 5, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_ATTACHMENT_ARRESMENT_ORDERS', 'PAYROLL', 'Attachment/Arrestment Orders', 6, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_P11_FORM', 'PAYROLL', 'P11 Form', 7, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_P45_FORM', 'PAYROLL', 'P45 Form', 8, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_P60_FORM', 'PAYROLL', 'P60 Form', 9, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EMPLOYEES_P14_FORM', 'PAYROLL', 'P14 Form', 10, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PAYROLL_EFILE_TO_HRMS', 'PAYROLL', 'Efile to HMRC', 1, false);