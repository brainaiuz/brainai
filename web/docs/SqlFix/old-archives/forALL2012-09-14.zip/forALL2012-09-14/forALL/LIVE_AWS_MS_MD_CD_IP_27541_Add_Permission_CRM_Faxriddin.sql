
--Crm Section

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_OPPORTUNITIES', 'CRM', 'CRM Add New Opportunity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SUMMARY_OPPORTUNITIES', 'CRM', 'CRM Summary Opportunity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CONVERT_OPPORTUNITIES', 'CRM', 'CRM Convert Opportunity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_OPPORTUNITIES', 'CRM', 'CRM Edit Opportunity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_OPPORTUNITIES', 'CRM', 'CRM Remove Opportunity', 4, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_CASE', 'CRM', 'CRM Remove Case', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CHANGE_STATUS_CASE', 'CRM', 'CRM Change Status Case', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CHANGE_PRIORITY_CASE', 'CRM', 'CRM Change Priority Case', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CHANGE_ASSIGNEE_CASE', 'CRM', 'CRM Change Assignee Case ', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CLOSE_CASE', 'CRM', 'CRM Close Case', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CONVERT_TO_CASE', 'CRM', 'CRM Convert To Case', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CREATE_TASK_CASE', 'CRM', 'CRM Create Task Case', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_CASE', 'CRM', 'CRM Edit Case', 4, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_CAMPAIGN', 'CRM', 'CRM Add New Campaign', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SUMMARY_CAMPAIGN', 'CRM', 'CRM Summary Campaign', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_CAMPAIGN', 'CRM', 'CRM Edit Campaign', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_CAMPAIGN', 'CRM', 'CRM Remove Campaign', 4, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_ACTIVITY_EVENT', 'CRM', 'CRM Add New Event', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_ACTIVITY_LOG_A_CALL', 'CRM', 'CRM Add New Log a Call', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SUMMARY_ACTIVITY', 'CRM', 'CRM Summary Activity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_ACTIVITY', 'CRM', 'CRM Edit Activity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_ACTIVITY', 'CRM', 'CRM Remove Activity', 4, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_WEB_FORM', 'CRM', 'CRM Add New Web Form', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SUMMARY_WEB_FORM', 'CRM', 'CRM Summary Web Form', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_WEB_FORM', 'CRM', 'CRM Edit Web Form', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_WEB_FORM', 'CRM', 'CRM Remove Web Form', 4, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_CONTACT', 'CRM', 'CRM Add New Contact', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_CATEGORY', 'CRM', 'CRM Add New Category', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_NEW_MAILING_LIST', 'CRM', 'CRM Add New Category', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_COPY_TO_CATEGORY', 'CRM', 'CRM Copy To Category', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_MOVE_TO_CATEGORY', 'CRM', 'CRM Move To Category', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ADD_SUBSCRIPTIONS', 'CRM', 'CRM Add Subscription', 4, true);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_FROM_CATEGORY', 'CRM', 'CRM remove From Category', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_REMOVE_CONTACT', 'CRM', 'CRM Remove Category', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_ACTIVATE_DEACTIVATE_CONTACT', 'CRM', 'CRM Activate/Deactivate Contact', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_CONTACT', 'CRM', 'CRM Edit Contact', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_EDIT_SUBSCRIPTION', 'CRM', 'CRM Edit Subscription', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SEND_SALES_INVOICE', 'CRM', 'CRM Send Sales Invoice', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SEND_SALES_QUOTE', 'CRM', 'CRM Send Sales Quote', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CONTACT_LOOK_UP', 'CRM', 'CRM Contact Look Up', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_CONTACT_ADD_ACTIVITY', 'CRM', 'CRM Add Activity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_SUMMARY_CONTACT', 'CRM', 'CRM Summary Contact', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('CRM_NOTE_CONTACT', 'CRM', 'CRM Contact Note', 4, false);