
--for zero schema
update "0".reference set name = 'Saved as draft' where code = 'PLACEMENT_STATUS_SAVE_AS_DRAFT';


--for all schemas
update "anv".reference set name = 'Saved as draft' where code = 'PLACEMENT_STATUS_SAVE_AS_DRAFT';