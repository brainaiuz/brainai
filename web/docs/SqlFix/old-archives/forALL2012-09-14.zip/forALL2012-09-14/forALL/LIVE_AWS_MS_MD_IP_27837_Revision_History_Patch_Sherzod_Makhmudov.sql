update "anv".invoice set updater_id=creator_id where updater_id is null;
update "anv".quote set updater_id=creator_id where updater_id is null;
