update "anv".manualjournal set deleted=false where deleted is null;
update "anv".manualjournal mj set status = (select status from "anv".transaction where id=mj.transactionid) where mj.status is null;
update "anv".transaction set deleted=true where dtype='EdsManualTransaction' and status='DRAFT';