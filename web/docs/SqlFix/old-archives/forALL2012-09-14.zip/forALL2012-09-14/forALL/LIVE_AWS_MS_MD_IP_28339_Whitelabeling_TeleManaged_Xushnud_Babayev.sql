-- APP HOST

INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,
            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported, defaultlocale, paypalaccount,
            vat, freetrialdays)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAPPTelemanaged.jks', 'app.telemanaged.com', null,
            'HNmVA9DthuqOaA6OLcAsbVRr', 'app.telemanaged.com', null, TRUE, null,
            null, '00000000440CEB17', 'jugrdWIqavFsHfLUDTXatx9c3IuE9oSr', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'telemanaged.com', '/customisation/telemanaged.com/images/logo.png', 'telemanaged.com', 'support@telemanaged.com',
            'telemanaged', '323-977-TELE', '917 N LA JOLLA AVE, W HOLLYWOOD, CA 90046', '/customisation/telemanaged.com/images/logo.png', 'TELE-TEAM (info@telemanaged.com)', 'telemanagedmail.properties',
            'Telemanaged INC', false, 'en', 'sales@workforcetrack.com',
            0.20, 7);


-- AWS HOST
INSERT INTO hostbasedsetting(
            chatdomain, emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleauthsubprivatekeypath, googleconsumerkey, googlemarketplacerealm,
            googlesignaturekey, hostname, imagemagickpath, isliveenv, linkedinapikey,
            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            uploadresourcedirpath, productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported, defaultlocale, paypalaccount,
            vat, freetrialdays)
    VALUES (
            '62.252.53.33', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
            null, null, null,
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT/WEB-INF/jks/GoogleAuthSubPrivateKeyAWSTelemanaged.jks', 'aws.telemanaged.com', null,
            '7clGbaQLFlkJz8pOVISrHCoP', 'aws.telemanaged.com', null, false, null,
            null, '00000000440CEB18', 'QJdw9YRrZYzNERxc-HFfwS2vyfYXFhah', '/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            '/usr/local/tomcat/projects/gwt.workforcetrack.com/wfmuploads/', 'telemanaged.com', '/customisation/telemanaged.com/images/logo.png', 'telemanaged.com', 'support@telemanaged.com',
            'telemanaged', '323-977-TELE', '917 N LA JOLLA AVE, W HOLLYWOOD, CA 90046', '/customisation/telemanaged.com/images/logo.png', 'TELE-TEAM (info@telemanaged.com)', 'telemanagedmail.properties',
            'Telemanaged INC', false, 'en', 'sales@workforcetrack.com',
            0.20, 7);

