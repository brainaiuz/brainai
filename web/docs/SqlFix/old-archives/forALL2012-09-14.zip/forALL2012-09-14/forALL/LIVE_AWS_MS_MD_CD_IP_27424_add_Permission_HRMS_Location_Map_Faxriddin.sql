

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_MAP_LOCATION', 'HRMS', 'Hrms Location Map List', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_POSITION', 'HRMS', 'Hrms Add New Postion ', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_POSITION_SUMMARRY', 'HRMS', 'Hrms Position Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_POSITION_EDIT', 'HRMS', 'Hrms Position Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_POSITION_REMOVE', 'HRMS', 'Hrms Position Remove', 1, false);


INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_GRADE', 'HRMS', 'Hrms Add New Grade', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_GRADE_SUMMARY', 'HRMS', 'Hrms Grade Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_GRADE', 'HRMS', 'Hrms Edit Grade', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_GRADE_REMOVE', 'HRMS', 'Hrms Remove Grade', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_EXPENSE_CLAIM', 'HRMS', 'Hrms Add New Expense Claim', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_VIEW_EXPENSE_CLAIM', 'HRMS', 'Hrms View Expense Claim', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_PERSONAL_GOALS', 'HRMS', 'Hrms Add New Personal GoalL', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_DEPARTMENT_GOAL', 'HRMS', 'Hrms Add New Department Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_PROJECT_GOAL', 'HRMS', 'Hrms Add New Project Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_BUSINESS_GOALS', 'HRMS', 'Hrms Add New Business Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_COMPANY_GOALS', 'HRMS', 'Hrms Add New Company Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_GOAL_SUMMARY', 'HRMS', 'Hrms Goal Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_GOAL', 'HRMS', 'Hrms Edit Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_GOAL_REMOVE', 'HRMS', 'Hrms Goal Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_INCIDENT', 'HRMS', 'Hrms Add New Incident', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_SUMMARY_INCIDENT', 'HRMS', 'Hrms Summary Incident', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_INCIDENT', 'HRMS', 'Hrms Edit Incident', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_PERSONAL_GOALS', 'HRMS', 'Hrms New  Personal Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PERSONAL_GOAL_SUMMARY', 'HRMS', 'Hrms New  Personal Goal Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_PERSONAL_GOAL', 'HRMS', 'Hrms New  Personal Goal Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NOTES_PERSONAL_GOAL', 'HRMS', 'Hrms New  Personal Goal Note', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PERSONAL_GOAL_REMOVE', 'HRMS', 'Hrms New  Personal Goal Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_DEPARTMENT_GOALS', 'HRMS', 'Hrms New Department Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'HRMS', 'Hrms Department Goal Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_DEPARTMENT_GOAL', 'HRMS', 'Hrms Department Goal Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NOTES_DEPARTMENT_GOAL', 'HRMS', 'Hrms Department Goal Note', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_DEPARTMENT_GOAL_REMOVE', 'HRMS', 'Hrms Department Goal Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_PROJECT_GOALS', 'HRMS', 'Hrms New Project Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PROJECT_GOAL_SUMMARY', 'HRMS', 'Hrms Project Goal Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_PROJECT_GOAL', 'HRMS', 'Hrms Project Goal Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NOTES_PROJECT_GOAL', 'HRMS', 'Hrms Project Goal Note', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PROJECT_GOAL_REMOVE', 'HRMS', 'Hrms Project Goal Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_BUSINESS_GOALS', 'HRMS', 'Hrms New Business Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_BUSINESS_GOAL_SUMMARY', 'HRMS', 'Hrms Business Goal Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_BUSINESS_GOAL', 'HRMS', 'Hrms Business Goal Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NOTES_BUSINESS_GOAL', 'HRMS', 'Hrms Business Goal Note', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_BUSINESS_GOAL_REMOVE', 'HRMS', 'Hrms Business Goal Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_COMPANY_GOALS', 'HRMS', 'Hrms New Company Goal', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_COMPANY_GOAL_SUMMARY', 'HRMS', 'Hrms Company Goal Summary', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_COMPANY_GOAL', 'HRMS', 'Hrms Company Goal Edit', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NOTES_COMPANY_GOAL', 'HRMS', 'Hrms Company Goal Note', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_COMPANY_GOAL_REMOVE', 'HRMS', 'Hrms Company Goal Remove', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_APPRAISALS', 'HRMS', 'Hrms New Appraisals', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_EMPLOYEE_360_APPRAISALS', 'HRMS', 'Hrms New Employee 360 appraisals', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NEW_APPRAISALS_TEMPLATES', 'HRMS', 'Hrms New Appraisals Templates', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_TEMPLATED', 'HRMS', 'Hrms Edit Appraisals Templates', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_REMOVE_TEMPLATED', 'HRMS', 'Hrms Remove Appraisals Templates', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_COMPETENCES', 'HRMS', 'Hrms Add New Competences', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_REMOVE_COMPETENCES', 'HRMS', 'Hrms Remove Competences', 1, false);

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_PERFORMANCE_NOTE', 'HRMS', 'Hrms Remove Competences', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PERFORMANCE_NOTE_SUMMERY', 'HRMS', 'Hrms Remove Competences', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_PERFORMANCE_NOTE', 'HRMS', 'Hrms Remove Competences', 1, false);

