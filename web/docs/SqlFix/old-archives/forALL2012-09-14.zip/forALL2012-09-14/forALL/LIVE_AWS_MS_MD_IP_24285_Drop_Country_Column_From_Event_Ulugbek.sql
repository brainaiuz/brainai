--apply before schema update
alter table "anv".event drop column country;