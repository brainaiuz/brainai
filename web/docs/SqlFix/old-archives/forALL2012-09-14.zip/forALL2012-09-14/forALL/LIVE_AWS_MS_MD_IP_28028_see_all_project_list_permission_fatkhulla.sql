INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_SEE_ALL_PROJECTS', 'PM', 'See all project list', 10, false);
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_SEE_ALL_PROJECTS', 'PROJECTS_DIRECTOR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_SEE_ALL_PROJECTS', 'DR', (SELECT id from "0".reference where code='ALLOW') );


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_SEE_ALL_PROJECTS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
