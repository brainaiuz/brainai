/*Bu public schemaga 1 marta uriladi*/

INSERT INTO addonsettings("key","name",imageurl) VALUES('MULTIWAREHOUSE_ENABLED','Multiple Warehouse','multiwarehouse.jpg');
INSERT INTO addonsettings("key","name",imageurl) VALUES('PRODUCT_SERIAL_ENABLED','Serial Number Track','serialnumbertrack.jpg');
INSERT INTO addonsettings("key","name",imageurl) VALUES('LANDED_COST','Landed Cost','landedcost.jpg');