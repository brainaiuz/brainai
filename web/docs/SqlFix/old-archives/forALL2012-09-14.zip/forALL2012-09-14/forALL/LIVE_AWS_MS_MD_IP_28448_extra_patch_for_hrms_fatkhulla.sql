delete from "0".rolepermission  where permissioncode='HRMS_EDIT_PROFILE' and (rolecode='ADMIN_LOCATION' or rolecode='PM' or rolecode='DLOFPR');


delete from "anv".rolepermission  where permissioncode='HRMS_EDIT_PROFILE' and (rolecode='ADMIN_LOCATION' or rolecode='PM' or rolecode='DLOFPR');