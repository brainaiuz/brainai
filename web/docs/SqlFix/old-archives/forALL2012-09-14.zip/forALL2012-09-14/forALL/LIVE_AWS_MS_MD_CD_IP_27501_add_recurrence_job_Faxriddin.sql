--Project number uchun urilmasa numbering settings null pointer tawedi

select setval('recurrencejob_id_seq', (select max(id) from recurrencejob));
insert into recurrencejob (name) values ('Restart project number');