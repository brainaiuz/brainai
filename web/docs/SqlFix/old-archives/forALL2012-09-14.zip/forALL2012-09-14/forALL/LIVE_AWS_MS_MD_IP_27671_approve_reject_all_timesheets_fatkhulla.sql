INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'PM', 'Approve reject all timesheets', 10, false);

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT_ALL_TIMESHEETS', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
