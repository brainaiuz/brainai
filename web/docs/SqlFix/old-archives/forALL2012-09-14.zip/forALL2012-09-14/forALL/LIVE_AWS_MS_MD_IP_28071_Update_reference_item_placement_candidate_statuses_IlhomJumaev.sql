
--for zero schemas

--placement status
update "0".reference set isSystemReference = true where code = '_PLACEMENT_STATUS';
update "0".reference set isSystemReference = true where parentid = (select id from "0".reference where code = '_PLACEMENT_STATUS' and parentid is null);
--candidate status
update "0".reference set isSystemReference = true where code = '_CANDIDATE_STATUS';
update "0".reference set isSystemReference = true where parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
--candidate source
update "0".reference set isSystemReference = true where code = '_CANDIDATE_SOURCE';
update "0".reference set isSystemReference = true where parentid = (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null);
--


--for all schemas

--placement status
update "anv".reference set isSystemReference = true where code = '_PLACEMENT_STATUS';
update "anv".reference set isSystemReference = true where parentid = (select id from "anv".reference where code = '_PLACEMENT_STATUS' and parentid is null);
--candidate status
update "anv".reference set isSystemReference = true where code = '_CANDIDATE_STATUS';
update "anv".reference set isSystemReference = true where parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
--candidate source
update "anv".reference set isSystemReference = true where code = '_CANDIDATE_SOURCE';
update "anv".reference set isSystemReference = true where parentid = (select id from "anv".reference where code = '_CANDIDATE_SOURCE' and parentid is null);
--