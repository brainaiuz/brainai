
--for all schemas

update "anv".TimeSheet set timeSpent = 0 where timeSpent is null;