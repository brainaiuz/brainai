--for all schema

insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','PM', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','HR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','MEM', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','SALESMAN', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','SALESPERSON', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW'));
