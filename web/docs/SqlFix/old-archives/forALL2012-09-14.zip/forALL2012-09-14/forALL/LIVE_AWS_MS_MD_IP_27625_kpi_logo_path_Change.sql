UPDATE hostbasedsetting SET  logoimage='/customisation/kpi.com/images/kpilogo.png', pdflogo='/customisation/kpi.com/images/kpilogo.png' WHERE productname='kpi.com';


