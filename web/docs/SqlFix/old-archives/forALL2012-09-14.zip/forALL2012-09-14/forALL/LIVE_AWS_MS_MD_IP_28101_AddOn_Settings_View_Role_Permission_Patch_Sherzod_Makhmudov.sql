/*Public schema uchun*/
INSERT INTO permission(code,"name",context,ismainmenu) VALUES('ACCOUNTING_ADD_ON_SETTINGS','Accounting Add-ons','ACCOUNTING',false);

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_ADD_ON_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_ADD_ON_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_ADD_ON_SETTINGS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

/*Company schemalari uchun*/
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_ADD_ON_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_ADD_ON_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_ADD_ON_SETTINGS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );