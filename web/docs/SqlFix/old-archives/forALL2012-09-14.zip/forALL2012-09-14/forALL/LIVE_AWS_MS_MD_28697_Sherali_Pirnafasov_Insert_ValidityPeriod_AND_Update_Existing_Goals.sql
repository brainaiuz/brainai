CREATE OR REPLACE FUNCTION "anv".insertValidityPeriod()
  RETURNS void AS $BODY$
DECLARE  cop record;
DECLARE s1 text;
    BEGIN
        FOR cop in (select m.timezone from "anv".myuser m where m.active=true and m.timezone is not null order by m.id limit 1)
        LOOP
        if(substr(cop.timezone,0,5)='GMT+')
        then
          s1 = 'GMT-' || substr(cop.timezone,5);
          else
          s1 = 'GMT+' || substr(cop.timezone,5);
        end if;
        if ((select count(vp.id) from "anv".validity_period vp) <1)
        then
            INSERT INTO "anv".validity_period(deleted, name, description, fromdate, todate,periodType) VALUES (false, 'Goal(2010-01-01 - 2010-12-31)','Goal(2010-01-01 - 2010-12-31)', TIMESTAMP '2010-01-01 00:00:00' AT TIME ZONE s1,  TIMESTAMP '2010-12-31 23:59:59' AT TIME ZONE s1,(select id from "anv".reference where code='VALIDITY_PERIOD_GOAL'));
            INSERT INTO "anv".validity_period(deleted, name, description, fromdate, todate,periodType) VALUES (false, 'Goal(2011-01-01 - 2011-12-31)','Goal(2011-01-01 - 2011-12-31)', TIMESTAMP '2011-01-01 00:00:00' AT TIME ZONE s1,  TIMESTAMP '2011-12-31 23:59:59' AT TIME ZONE s1,(select id from "anv".reference where code='VALIDITY_PERIOD_GOAL'));
            INSERT INTO "anv".validity_period(deleted, name, description, fromdate, todate,periodType) VALUES (false, 'Goal(2012-01-01 - 2013-12-31)','Goal(2012-01-01 - 2012-12-31)', TIMESTAMP '2012-01-01 00:00:00' AT TIME ZONE s1,  TIMESTAMP '2012-12-31 23:59:59' AT TIME ZONE s1,(select id from "anv".reference where code='VALIDITY_PERIOD_GOAL'));
            INSERT INTO "anv".validity_period(deleted, name, description, fromdate, todate,periodType) VALUES (false, 'Appraisal(2012-01-01 - 2012-12-31)','Appraisal(2012-01-01 - 2012-12-31)', TIMESTAMP '2012-01-01 00:00:00' AT TIME ZONE s1, TIMESTAMP '2012-12-31 23:59:59' AT TIME ZONE s1,(select id from "anv".reference where code='VALIDITY_PERIOD_APPRAISAL'));
        end if;
        END LOOP;
    END;
$BODY$
LANGUAGE plpgsql VOLATILE
COST 100;
ALTER FUNCTION "anv".insertValidityPeriod() OWNER TO wfmtest;

--- second step
update "anv".myuser set deleted = false where deleted is not true and (select "anv".insertValidityPeriod()) is null;

---third step
DROP FUNCTION "anv".insertValidityPeriod();

--For Financial Year
INSERT INTO "anv".validity_period(deleted, name, description, fromdate, todate,periodType) VALUES (false, '2012-01-01 - 2012-12-31','2012-01-01 - 2012-12-31', '2012-01-01 00:00:00', '2012-12-31 23:59:59',(select id from "anv".reference where code='VALIDITY_PERIOD_APPRAISAL_GOAL'));

--update existing goals
update "anv".goal as  g set period_id=(select v.id from "anv".validity_period as v where g.fromDate between v.fromDate and v.toDate limit 1) where period_id is null and fromDate is not null;
update "anv".goal set score_calculation_id=(select r.id from "anv".reference as r where r.code='MAXIMIZE') where score_calculation_id is null;
