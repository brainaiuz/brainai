
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER','All purchase order related updates',null) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_ADD','Records when user has add purchase order',(select id from myupdatetype where code='PURCHASE_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_EDIT','Records when user has edited purchase order',(select id from myupdatetype where code='PURCHASE_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_DELETE','Records when user has deleted purchase order',(select id from myupdatetype where code='PURCHASE_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_SEND_TO_CLIENT','Records when user has sent purchase order to client',(select id from myupdatetype where code='PURCHASE_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_APPROVE','Records when client has approved purchase order',(select id from myupdatetype where code='PURCHASE_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_RECEIVED','Records when user has received for purchase order',(select id from myupdatetype where code='PURCHASE_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_ORDER_PARTIAL_RECEIVED','Records when user has partial received for purchase order',(select id from myupdatetype where code='PURCHASE_ORDER')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE','All purchase invoice related updates',null) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_ADD','Records when user has add purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_EDIT','Records when user has edited purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_DELETE','Records when user has deleted purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_APPROVE','Records when user has approved purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_ADD_CREDIT_NOTE','Records when user has add credit purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_PAYMENT_VOID','Records when user has payment void  purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_PAYMENT_DELETE','Records when user has payment delete purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_PAYMENT_PAY','Records when user has payment Pay purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PURCHASE_INVOICE_REFUND','Records when user has payment refund purchase invoice',(select id from myupdatetype where code='PURCHASE_INVOICE')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_INVOICE_PAYMENT_VOID','Records when user has payment void  sales invoice',(select id from myupdatetype where code='SALES_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_INVOICE_PAYMENT_DELETE','Records when user has payment delete sales invoice',(select id from myupdatetype where code='SALES_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_INVOICE_ADD_CREDIT_NOTE','Records when user has add credit sales invoice',(select id from myupdatetype where code='SALES_INVOICE')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_INVOICE_REFUND','Records when user has add refund sales invoice',(select id from myupdatetype where code='SALES_INVOICE')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_ORDER','All sales order related updates',null) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_ORDER_ADD','Records when user has add sales order',(select id from myupdatetype where code='SALES_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_ORDER_EDIT','Records when user has edited sales order',(select id from myupdatetype where code='SALES_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_ORDER_DELETE','Records when user has deleted sales order',(select id from myupdatetype where code='SALES_ORDER')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('SALES_ORDER_PICKLIST','Records when user has add picklist',(select id from myupdatetype where code='SALES_ORDER')) ;


insert into myupdatetype ("code", "description", "parentid") VALUES ('PRODUCT','All product related updates',null) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PRODUCT_ADD','Records when user has add product',(select id from myupdatetype where code='PRODUCT')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PRODUCT_EDIT','Records when user has edited product',(select id from myupdatetype where code='PRODUCT')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('PRODUCT_DELETE','Records when user has deleted product',(select id from myupdatetype where code='PRODUCT')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('FIXED_ASSET','All fixed asset related updates',null) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('FIXED_ASSET_ADD','Records when user has add fixed asset',(select id from myupdatetype where code='FIXED_ASSET')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('FIXED_ASSET_EDIT','Records when user has edited fixed asset',(select id from myupdatetype where code='FIXED_ASSET')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('FIXED_ASSET_DELETE','Records when user has deleted fixed asset',(select id from myupdatetype where code='FIXED_ASSET')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('FIXED_ASSET_DISPOSE','Records when user has deleted fixed asset',(select id from myupdatetype where code='FIXED_ASSET')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('CHECK','All check related updates',null) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('CHECK_ADD','Records when user has add check',(select id from myupdatetype where code='CHECK')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('CHECK_EDIT','Records when user has edited check',(select id from myupdatetype where code='CHECK')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('CHECK_DELETE','Records when user has deleted check',(select id from myupdatetype where code='CHECK')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('BANK_ACCOUNT','All bank account related updates',null) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('BANK_ACCOUNT_ADD','Records when user has add bank account',(select id from myupdatetype where code='BANK_ACCOUNT')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('BANK_ACCOUNT_EDIT','Records when user has edited bank account',(select id from myupdatetype where code='BANK_ACCOUNT')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('BANK_ACCOUNT_DELETE','Records when user has deleted bank account',(select id from myupdatetype where code='BANK_ACCOUNT')) ;

insert into myupdatetype ("code", "description", "parentid") VALUES ('CHART_OF_ACCOUNT','All chart of account related updates',null) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('CHART_OF_ACCOUNT_ADD','Records when user has add chart of account',(select id from myupdatetype where code='CHART_OF_ACCOUNT')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('CHART_OF_ACCOUNT_EDIT','Records when user has edited chart of account',(select id from myupdatetype where code='CHART_OF_ACCOUNT')) ;
insert into myupdatetype ("code", "description", "parentid") VALUES ('CHART_OF_ACCOUNT_DELETE','Records when user has deleted chart of account',(select id from myupdatetype where code='CHART_OF_ACCOUNT')) ;




