                                                --Bu patchlar xamma patchlardan keyin urilsin --
------------------------------------------------------------------------------------------------------------------------------------------

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ADD', 'AUDITOR', (SELECT id from "28492".reference where code='DENY') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_INCIDENT';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_POSITION';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_POSITION', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_POSITION', 'DR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_POSITION_SUMMARRY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION_SUMMARRY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION_SUMMARRY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION_SUMMARRY', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION_SUMMARRY', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_POSITION_SUMMARRY', 'PM', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_GRADE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_GRADE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_GRADE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_GRADE_SUMMARY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GRADE_SUMMARY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GRADE_SUMMARY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GRADE_SUMMARY', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_GRADE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GRADE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GRADE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_EXPENSE_CLAIM', 'AUDITOR', (SELECT id from "28492".reference where code='DENY') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_VIEW_EXPENSE_CLAIM', 'PM', (SELECT id from "28492".reference where code='DENY') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_PERSONAL_GOALS', 'AUDITOR', (SELECT id from "28492".reference where code='DENY') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_PROJECT_GOAL', 'PM', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_PROJECT_GOAL', 'TL', (SELECT id from "28492".reference where code='DENY') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_GOAL';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_GOAL', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_GOAL_REMOVE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_REMOVE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_REMOVE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_REMOVE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_GOAL_REMOVE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_INCIDENT';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_INCIDENT';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_INCIDENT', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_INCIDENT', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_INCIDENT', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_INCIDENT', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_PERSONAL_GOALS';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_PROJECT_GOALS';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'PM', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_BUSINESS_GOALS';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BUSINESS_GOALS', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BUSINESS_GOALS', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BUSINESS_GOALS', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BUSINESS_GOALS', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BUSINESS_GOALS', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOAL_SUMMARY', 'PM', (SELECT id from "28492".reference where code='DENY') );

delete from "28492".rolepermission where permissioncode='HRMS_DEPARTMENT_GOAL_SUMMARY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPARTMENT_GOAL_SUMMARY', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_PROJECT_GOAL_SUMMARY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_SUMMARY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_SUMMARY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_SUMMARY', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_SUMMARY', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_SUMMARY', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_BUSINESS_GOAL_SUMMARY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOAL_SUMMARY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOAL_SUMMARY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOAL_SUMMARY', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOAL_SUMMARY', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOAL_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_BUSINESS_GOAL_SUMMARY', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_PERSONAL_GOAL';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERSONAL_GOAL', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERSONAL_GOAL', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERSONAL_GOAL', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERSONAL_GOAL', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERSONAL_GOAL', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPARTMENT_GOAL', 'PM', (SELECT id from "28492".reference where code='DENY') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_PROJECT_GOAL';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROJECT_GOAL', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROJECT_GOAL', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROJECT_GOAL', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROJECT_GOAL', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PROJECT_GOAL', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_NOTES_PERSONAL_GOAL';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PERSONAL_GOAL', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PERSONAL_GOAL', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PERSONAL_GOAL', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PERSONAL_GOAL', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PERSONAL_GOAL', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_NOTES_PROJECT_GOAL';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PROJECT_GOAL', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PROJECT_GOAL', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PROJECT_GOAL', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PROJECT_GOAL', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_PROJECT_GOAL', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_PERSONAL_GOAL_REMOVE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOAL_REMOVE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOAL_REMOVE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOAL_REMOVE', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOAL_REMOVE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERSONAL_GOAL_REMOVE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_PROJECT_GOAL_REMOVE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_REMOVE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_REMOVE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_REMOVE', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_REMOVE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PROJECT_GOAL_REMOVE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_COMPANY_GOAL_SUMMARY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_SUMMARY', 'SALESMAN', (SELECT id from "28492".reference where code='ALLOW') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_COMPANY_GOAL', 'PM', (SELECT id from "28492".reference where code='DENY') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_COMPANY_GOAL', 'TL', (SELECT id from "28492".reference where code='DENY') );

insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_COMPANY_GOAL', 'PM', (SELECT id from "28492".reference where code='DENY') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTES_COMPANY_GOAL', 'TL', (SELECT id from "28492".reference where code='DENY') );

delete from "28492".rolepermission where permissioncode='HRMS_COMPANY_GOAL_REMOVE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_REMOVE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_REMOVE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_COMPANY_GOAL_REMOVE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_NEW_APPRAISALS_TEMPLATES';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'HR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_NEW_EMPLOYEE_360_APPRAISALS';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_EMPLOYEE_360_APPRAISALS', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_EMPLOYEE_360_APPRAISALS', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_EMPLOYEE_360_APPRAISALS', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_EMPLOYEE_360_APPRAISALS', 'HR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_NEW_APPRAISALS_TEMPLATES';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NEW_APPRAISALS_TEMPLATES', 'HR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_TEMPLATED';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_TEMPLATED', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_TEMPLATED', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_TEMPLATED', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_TEMPLATED', 'HR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_COMPETENCES';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_COMPETENCES', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_COMPETENCES', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_COMPETENCES', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_COMPETENCES', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_COMPETENCES', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_COMPETENCES', 'AUDITOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_REMOVE_COMPETENCES';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_COMPETENCES', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_COMPETENCES', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_COMPETENCES', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_COMPETENCES', 'HR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_ADD_NEW_PERFORMANCE_NOTE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERFORMANCE_NOTE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERFORMANCE_NOTE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERFORMANCE_NOTE', 'TL', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_PERFORMANCE_NOTE_SUMMERY';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE_SUMMERY', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE_SUMMERY', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE_SUMMERY', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE_SUMMERY', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PERFORMANCE_NOTE_SUMMERY', 'TL', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission where permissioncode='HRMS_EDIT_PERFORMANCE_NOTE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERFORMANCE_NOTE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_PERFORMANCE_NOTE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "8687".rolepermission where permissioncode='CRM_ADD_NEW_MAILING_LIST';

delete from "28201".rolepermission where permissioncode='PM_ASSIGN_TASK_TO_MEMBER';
insert into "28201".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_TASK_TO_MEMBER', 'SALESPERSON', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28201".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_TASK_TO_MEMBER', 'SALESMAN', (SELECT id from "28492".reference where code='ALLOW') );

