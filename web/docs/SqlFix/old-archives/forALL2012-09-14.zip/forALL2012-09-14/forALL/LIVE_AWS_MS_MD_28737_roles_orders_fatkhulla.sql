update  "anv".role set sorder=10 where code='PMOFPR';
update  "anv".role set sorder=11 where code='BMOFPR';
update  "anv".role set sorder=12 where code='DLOFPR';
update  "anv".role set sorder=13 where code='MEM';
update  "anv".role set sorder=14 where code='CREATOR';
update  "anv".role set sorder=15 where code='CLIENT';


update  "0".role set sorder=10 where code='PMOFPR';
update  "0".role set sorder=11 where code='BMOFPR';
update  "0".role set sorder=12 where code='DLOFPR';
update  "0".role set sorder=13 where code='MEM';
update  "0".role set sorder=14 where code='CREATOR';
update  "0".role set sorder=15 where code='CLIENT';
