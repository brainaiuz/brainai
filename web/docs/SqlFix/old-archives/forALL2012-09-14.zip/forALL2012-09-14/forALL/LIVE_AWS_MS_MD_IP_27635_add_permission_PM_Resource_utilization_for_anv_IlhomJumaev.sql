
--first step

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_RESOURCE_UTILIZATION_LIST', 'PM', 'Resource Utilization', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_RESOURCE_UTILIZATION_EDITABLE', 'PM', 'Resource Utilization editable', 1, false);


--second step

--for all schema

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );



insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
