INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ANNUAL_ALLOWANCE', 'HRMS', 'Annual Allowance', 4, false);
--for zero
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );


--for private
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
