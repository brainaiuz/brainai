insert into "anv".reference(name, code, parentid, sorder) values ('Placement Statuses', '_PLACEMENT_STATUS', null, 0);
insert into "anv".reference(name, code, parentid, sorder) values
('Save as draft', 'PLACEMENT_STATUS_SAVE_AS_DRAFT', (select id from "anv".reference where code = '_PLACEMENT_STATUS' and parentid is null), 1),
('Approved', 'PLACEMENT_STATUS_APPROVED', (select id from "anv".reference where code = '_PLACEMENT_STATUS' and parentid is null), 2),
('Hired', 'PLACEMENT_STATUS_HIRED', (select id from "anv".reference where code = '_PLACEMENT_STATUS' and parentid is null), 11);