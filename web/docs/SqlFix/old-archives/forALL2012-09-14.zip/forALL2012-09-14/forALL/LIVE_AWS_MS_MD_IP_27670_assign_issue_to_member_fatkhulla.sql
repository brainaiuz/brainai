INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('PM_ASSIGN_ISSUE_TO_MEMBER', 'PM', 'Assign issue to member', 4, false);

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW') );
