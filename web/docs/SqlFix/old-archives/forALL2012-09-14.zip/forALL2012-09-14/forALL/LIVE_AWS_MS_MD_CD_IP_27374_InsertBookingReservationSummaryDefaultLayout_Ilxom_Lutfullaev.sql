insert into defaultlayout (formid, layout, title, viewform, active) values('BOOKINGITEMSRESERVATION', '<div class="bothSect">
	<fieldset class="group sect labelLine">
		<div class="left" style="margin-left: 10px; margin-top: 3px;">
			<div class="row">
				$$label:reservedBy$$
				<div class="field">
					$$input:reservedBy$$
				</div>
			</div>

			<div class="row">
				$$label:category$$
				<div class="field">
					$$input:category$$
				</div>
			</div>

			<div class="row">
				$$label:bookingItem$$
				<div class="field">
					$$input:bookingItem$$
				</div>
			</div>

			<div class="row">
				$$label:fromDate$$
				<div class="field">
					$$input:fromDate$$
				</div>
			</div>

			<div class="row">
				$$label:toDate$$
				<div class="field">
					$$input:toDate$$
				</div>
			</div>
			<div class="row">
				$$label:addLink$$
				<div class="field" style = "margin-left: -10px;">
					$$input:addLink$$
				</div>
			</div>

			<div class="row">
				<div class="field">
					$$input:cancelbutton$$
				</div>
			</div>
		</div>
	</fieldset>
</div>', 'Booking Reservation View', true, true);