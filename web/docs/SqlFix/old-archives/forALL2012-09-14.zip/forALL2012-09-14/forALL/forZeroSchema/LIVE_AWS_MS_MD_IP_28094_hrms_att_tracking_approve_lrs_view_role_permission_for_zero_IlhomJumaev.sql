--for zero schema

insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','PM', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','HR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','MEM', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','SALESMAN', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','SALESPERSON', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission (permissioncode,rolecode,priviledgeid) values ('HRMS_APPROVE_LIVE_STATUS','ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW'));
