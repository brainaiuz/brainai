--for zero schema

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_LIST', 'MEM', (SELECT id from "0".reference where code='ALLOW') );


--for zero schema

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_RESOURCE_UTILIZATION_EDITABLE', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );


