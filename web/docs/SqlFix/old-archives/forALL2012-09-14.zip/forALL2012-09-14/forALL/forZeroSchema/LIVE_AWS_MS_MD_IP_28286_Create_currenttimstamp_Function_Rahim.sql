-- DROP FUNCTION currenttimstamp();

CREATE OR REPLACE FUNCTION currenttimstamp()
RETURNS timestamp with time zone AS
$BODY$
SELECT (current_timestamp)::timestamp with time zone
$BODY$
LANGUAGE sql IMMUTABLE STRICT
COST 100;
ALTER FUNCTION currenttimstamp() OWNER TO postgres;