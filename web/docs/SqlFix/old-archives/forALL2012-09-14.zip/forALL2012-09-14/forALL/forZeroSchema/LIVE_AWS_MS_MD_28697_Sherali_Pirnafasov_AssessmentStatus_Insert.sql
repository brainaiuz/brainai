--update "0".reference set code='APPROVED', name ='Approved',description='Approved' where code ='APPROVED_BY_MANAGER';
insert into "0".reference(code, name, description, parentid) values('REJECTED', 'Rejected', 'Rejected', (select id from "0".reference where code='ASSESSMENT_STATUS'));
insert into "0".reference(code, name, description, parentid) values('APPROVED_BY_HR', 'Approved by HR', 'Approved by HR', (select id from "0".reference where code='ASSESSMENT_STATUS'));
insert into "0".reference(code, name, description, parentid) values('APPROVED_BY_MANAGER', 'Approved by Manager', 'Approved by Manager', (select id from "0".reference where code='ASSESSMENT_STATUS'));

insert into "0".reference(code, name, description, parentid) values('REVIEWED_BY_EMPLOYEE', 'Reviewed by Employee', 'Reviewed by Employee', (select id from "0".reference where code='ASSESSMENT_STATUS'));
update "0".reference set code='REVIEWED_BY_MANAGER', name ='Reviewed by Manager',description='Reviewed by Manager' where code ='REVIEWED';
