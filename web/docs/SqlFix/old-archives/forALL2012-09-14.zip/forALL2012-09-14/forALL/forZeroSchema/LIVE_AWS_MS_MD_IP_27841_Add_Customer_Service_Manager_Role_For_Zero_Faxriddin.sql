

insert into "0".role (id,code,description,name,issystem,isdeleted,isentityspecific,sorder)  values(26,'CUSTOMER_SERVICE_MANAGER', '','Customer Service Manager', true, false, false, 210);