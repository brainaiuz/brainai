<-- bu patchni urishdan oldin 28010_settings_role_permission_fatkhulla_nigmatjonov.sql  ni urvorin
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );


insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );


insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );

