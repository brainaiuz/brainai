insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'PMOFPR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'BMOFPR', (SELECT id from "0".reference where code='ALLOW') );
