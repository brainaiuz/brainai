INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_COMPANY_SETTINGS', 'SETTINGS', 'Company Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_ACCOUNTING_SETTINGS', 'SETTINGS', 'Accounting Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_RECURRENCE_SETTINGS', 'SETTINGS', 'Recurrence Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_PROFILE_SETTINGS', 'SETTINGS', 'Profile Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_USER_CREDENTIALS', 'SETTINGS', 'User Credentials', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_EMAIL_SETTINGS', 'SETTINGS', 'Email Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'SETTINGS', 'Project Management Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_HRMS_SETTINGS', 'SETTINGS', 'HRMS Settings', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_CRM_SETTINGS', 'SETTINGS', 'CRM Settings', 10, false);



insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_COMPANY_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_ACCOUNTING_SETTINGS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_RECURRENCE_SETTINGS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROFILE_SETTINGS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_USER_CREDENTIALS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_EMAIL_SETTINGS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_PROJECT_MANAGEMENT_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_HRMS_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_CRM_SETTINGS', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );

