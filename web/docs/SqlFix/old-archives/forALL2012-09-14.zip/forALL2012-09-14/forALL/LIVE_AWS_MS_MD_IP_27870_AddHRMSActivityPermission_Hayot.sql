INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_ACTIVITY_EVENT', 'HRMS', 'HRMS Add New Event', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_ACTIVITY_LOG_A_CALL', 'HRMS', 'HRMS Add New Log a Call', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_SUMMARY_ACTIVITY', 'HRMS', 'HRMS Summary Activity', 3, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EDIT_ACTIVITY', 'HRMS', 'HRMS Edit Activity', 4, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_REMOVE_ACTIVITY', 'HRMS', 'HRMS Remove Activity', 5, false);

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_ACTIVITY_EVENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_ACTIVITY_LOG_A_CALL', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SUMMARY_ACTIVITY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_ACTIVITY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_ACTIVITY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_ACTIVITY_EVENT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_ACTIVITY_LOG_A_CALL', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SUMMARY_ACTIVITY', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_ACTIVITY', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_ACTIVITY', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
