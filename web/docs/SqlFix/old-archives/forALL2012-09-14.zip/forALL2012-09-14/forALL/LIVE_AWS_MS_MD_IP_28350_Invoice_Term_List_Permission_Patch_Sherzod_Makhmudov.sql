/*1.Public schemaga*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_TERMS_LIST', 'ACCOUNTING', 'Invoice Terms List', null, false);

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_TERMS_LIST', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_TERMS_LIST', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_TERMS_LIST', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

/*3.Hamma company schemalarga*/
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_TERMS_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_TERMS_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_TERMS_LIST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );