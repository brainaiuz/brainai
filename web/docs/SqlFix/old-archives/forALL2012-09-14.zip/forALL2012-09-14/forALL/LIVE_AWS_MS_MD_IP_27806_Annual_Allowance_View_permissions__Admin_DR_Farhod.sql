--for zero
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'DR', (SELECT id from "0".reference where code='ALLOW') );

--for private
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ANNUAL_ALLOWANCE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );