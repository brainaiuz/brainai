--for zero schema

ALTER TABLE "0".crmcontact DROP COLUMN placementid;


--for all schemas
ALTER TABLE "anv".crmcontact DROP COLUMN if exists placementid;