
--for public schema
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'HRMS', 'Match to vacancies', 10, false);



--for zero schema
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'CREATOR', (SELECT id from "0".reference where code='ALLOW') );



--for all schemas
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_MATCH_TO_VACANCY', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );