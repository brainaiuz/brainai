--birinchi buni
UPDATE "anv".attendancerawdata SET timesheetPending = t.s
FROM (SELECT employeeid e, d.id d, SUM(COALESCE(timespent, 0)) s FROM "anv".timesheet
LEFT JOIN datejoin d ON timesheet.date = d.from_date
WHERE statusid is null
GROUP BY e, d
ORDER BY d.id) as t
WHERE t.e = employeeid and t.d = dateid;

UPDATE "anv".attendancerawdata SET timesheet = t.s
FROM (SELECT employeeid e, d.id d, SUM(COALESCE(timespent, 0)) s FROM "anv".timesheet
LEFT JOIN datejoin d ON timesheet.date = d.from_date
WHERE statusid = 269
GROUP BY e, d
ORDER BY d.id) as t
WHERE t.e = employeeid and t.d = dateid;

--keyin buni
UPDATE "anv".attendancerawdata SET timesheetPending = 0 where timesheetPending < 0;

