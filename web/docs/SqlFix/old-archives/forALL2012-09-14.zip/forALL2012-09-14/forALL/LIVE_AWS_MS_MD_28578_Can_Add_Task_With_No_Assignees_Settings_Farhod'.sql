INSERT INTO "anv".genericsettings(key, value) values('CAN_ADD_NO_ACCESS_USERS', 'NO');
INSERT INTO "anv".genericsettings(key, value) values('CAN_ADD_TASKS_WITH_NO_ASSIGNEES', 'NO');
UPDATE "27007".genericsettings SET value = 'YES' where key = 'CAN_ADD_TASKS_WITH_NO_ASSIGNEES';
UPDATE "31733".genericsettings SET value = 'YES' where key = 'CAN_ADD_TASKS_WITH_NO_ASSIGNEES';