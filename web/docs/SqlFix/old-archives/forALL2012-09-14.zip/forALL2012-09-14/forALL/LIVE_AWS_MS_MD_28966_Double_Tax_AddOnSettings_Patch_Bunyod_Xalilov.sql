/*Bu public schemaga 1 marta uriladi*/

INSERT INTO addonsettings("key","name",imageurl) VALUES('DOUBLE_TAX','Double Tax','doubleTax.png');