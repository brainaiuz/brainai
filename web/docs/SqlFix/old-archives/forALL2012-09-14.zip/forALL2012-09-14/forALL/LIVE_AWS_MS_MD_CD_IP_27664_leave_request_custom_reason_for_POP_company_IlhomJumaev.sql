
--for the POP Company  -- companyID = 20458

insert into "30458".reference(code, name, parentid) VALUES ('PERSONAL_REQUEST_LEAVE', 'Personal Leave Request', (select id from "30458".reference where code='_REASON'));