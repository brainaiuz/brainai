insert into "anv".reference(name, code, parentid, sorder) values('Candidate Sources', '_CANDIDATE_SOURCE', null, 0),('Candidate Statuses', '_CANDIDATE_STATUS', null, 0);
insert into "anv".reference(name, code, parentid, sorder) values
('Internal', 'CANDIDATE_SOURCE_INTERNAL', (select id from "anv".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 1),
('Imported', 'CANDIDATE_SOURCE_IMPORTED', (select id from "anv".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 2),
('API', 'CANDIDATE_SOURCE_API', (select id from "anv".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 3),
('Google Import', 'CANDIDATE_SOURCE_GOOGLE_IMPORT', (select id from "anv".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 4),
('Web', 'CANDIDATE_SOURCE_WEB', (select id from "anv".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 5),
('New', 'CANDIDATE_STATUS_NEW', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 1),
('Matched', 'CANDIDATE_STATUS_MATCHED', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 2),
('Interview', 'CANDIDATE_STATUS_INTERVIEW', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 3),
('On Hold', 'CANDIDATE_STATUS_ON_HOLD', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 4),
('Rejected', 'CANDIDATE_STATUS_REJECTED', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 5),
('Offer Made', 'CANDIDATE_STATUS_OFFER_MADE', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 6),
('Placed', 'CANDIDATE_STATUS_PLACED', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 7),
('Offer Declined', 'CANDIDATE_STATUS_OFFER_DECLINED', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 8),
('Offer Withdrawn', 'CANDIDATE_STATUS_OFFER_WITHDRAWN', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 9),
('Hired', 'CANDIDATE_STATUS_HIRED', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 10),
('Unqualified', 'CANDIDATE_STATUS_UNQUALIFIED', (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null), 11);