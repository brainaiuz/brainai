
update permission set context='HRMS', name='Hrms employee notes view' where code ='HRMS_PROFILE_NOTE';