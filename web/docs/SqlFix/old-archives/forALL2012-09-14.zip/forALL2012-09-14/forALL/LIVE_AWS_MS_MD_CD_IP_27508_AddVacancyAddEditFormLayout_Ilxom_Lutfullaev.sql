delete from defaultlayout where formid = 'VACANCYADDEDIT';
insert into defaultlayout (formid, layout, title, addform, editform, active) values('VACANCYADDEDIT', '<div class="bothSect">
	<fieldset class="group sect labelLine">
		<div>
			<div class="row">
				$$label:vacancyid$$
				<div class="field">
					$$input:vacancyid$$
				</div>
			</div>

			<div class="row">
				$$label:managers$$
				<div class="field">
					$$input:managers$$
				</div>
			</div>

			<div class="row">
				$$label:positions$$
				<div class="field">
					$$input:positions$$
				</div>
			</div>

			<div class="row">
				$$label:locations$$
				<div class="field">
					$$input:locations$$
				</div>
			</div>

			<div class="row">
				$$label:jobtitle$$
				<div class="field">
					$$input:jobtitle$$
				</div>
			</div>

			<div class="row">
				$$label:description$$
				<div class="field">
					$$input:description$$
				</div>
			</div>

			<div class="row">
				$$label:startdate$$
				<div class="field">
					$$input:startdate$$
				</div>
			</div>

			<div class="row">
				$$label:enddate$$
				<div class="field">
					$$input:enddate$$
				</div>
			</div>

			<div class="row">
				$$label:statuses$$
				<div class="field">
					$$input:statuses$$
				</div>
			</div>

			<div class="row">
				$$label:vacantplacecount$$
				<div class="field">
					$$input:vacantplacecount$$
				</div>
			</div>

			<div class="row">
				$$label:jobtype$$
				<div class="field">
					$$input:jobtype$$
				</div>
			</div>

			<div class="row">
				$$label:jobfamily$$
				<div class="field">
					$$input:jobfamily$$
				</div>
			</div>

			<div class="row">
				$$label:responsibilities$$
				<div class="field">
					$$input:responsibilities$$
				</div>
			</div>

			<div class="row">
				$$label:requireddegree$$
				<div class="field">
					$$input:requireddegree$$
				</div>
			</div>

			<div class="row">
				$$label:attachments$$
				<div class="field">
					$$input:attachments$$
				</div>
			</div>

			<div class="gwt-HTML"></div>
			<div class="row">
				<div class="gwt-HTML"></div>
				<div class="field">
					$$input:savebutton$$
					$$input:closebutton$$
				</div>
			</div>
		</div>
	</fieldset>
</div>', 'Add/Edit Vacancy View', true, true, true);