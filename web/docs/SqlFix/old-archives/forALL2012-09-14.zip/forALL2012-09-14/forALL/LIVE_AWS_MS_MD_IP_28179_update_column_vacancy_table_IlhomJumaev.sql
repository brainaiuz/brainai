--schema update dan keyin apply qilinadi!!!!

--for zero schema
update "0".vacancy set deleted = false;

--for all schemas
update "anv".vacancy set deleted = false;