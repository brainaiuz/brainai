--Globalauth, only for live
update userauth set domainname = '|app.kpi.com||login.victechweb.com|' where domainname = '|login.victechweb.com|';
update userauth set domainname = '|app.kpi.com||projects.spritelab.dk|' where domainname = '|projects.spritelab.dk|';