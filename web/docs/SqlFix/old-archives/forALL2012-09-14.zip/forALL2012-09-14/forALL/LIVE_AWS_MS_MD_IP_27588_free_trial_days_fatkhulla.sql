ALTER TABLE hostbasedsetting ADD COLUMN freetrialdays integer;
UPDATE hostbasedsetting SET freetrialdays = 7;
ALTER TABLE hostbasedsetting ALTER COLUMN freetrialdays SET NOT NULL;