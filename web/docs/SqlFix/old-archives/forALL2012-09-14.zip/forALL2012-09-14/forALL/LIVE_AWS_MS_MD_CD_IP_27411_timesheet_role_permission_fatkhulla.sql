insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_APPROVE_REJECT', 'BMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
