insert into "anv".reference(code, name, description) values('_BONUS_SETTINGS_STATUS', 'Bonus Settings Status', 'Bonus Settings Status');
insert into "anv".reference(code, name, description, parentid) values('BONUS_SETTINGS_SUBMIT_FOR_APPROVE', 'Submit for Approve', 'Submit for Approve', (select id from "anv".reference where code='_BONUS_SETTINGS_STATUS'));
insert into "anv".reference(code, name, description, parentid) values('BONUS_SETTINGS_APPROVED', 'Approved', 'Approved', (select id from "anv".reference where code='_BONUS_SETTINGS_STATUS'));
insert into "anv".reference(code, name, description, parentid) values('BONUS_SETTINGS_REJECTED', 'Rejected', 'Rejected', (select id from "anv".reference where code='_BONUS_SETTINGS_STATUS'));
insert into "anv".reference(code, name, description, parentid) values('BONUS_SETTINGS_DRAFT', 'Draft', 'Draft', (select id from "anv".reference where code='_BONUS_SETTINGS_STATUS'));

update "anv".bonus_settings set status_id=(select id from "anv".reference where code='BONUS_SETTINGS_APPROVED') where status_id is null;