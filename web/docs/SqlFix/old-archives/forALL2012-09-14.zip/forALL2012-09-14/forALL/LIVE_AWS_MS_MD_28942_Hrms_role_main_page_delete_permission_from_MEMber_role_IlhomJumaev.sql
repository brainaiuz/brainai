--for zero schema

delete from "0".rolepermission where permissioncode = 'HRMS_SECTION_TAB' and rolecode='MEM';


--for all schemas

delete from "anv".rolepermission where permissioncode = 'HRMS_SECTION_TAB' and rolecode='MEM';