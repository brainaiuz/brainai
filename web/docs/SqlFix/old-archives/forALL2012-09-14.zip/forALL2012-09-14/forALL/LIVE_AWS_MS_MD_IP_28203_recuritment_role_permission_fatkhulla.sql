INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_VACANCY_LIST_VIEW', 'HRMS', 'Vacancies', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_CANDIDATE_LIST_VIEW', 'HRMS', 'Candidates', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_SHORT_LIST_VIEW', 'HRMS', 'Short-list', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ACTIVITIES_VIEW', 'HRMS', 'Activities', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_PLACEMENT_LIST_VIEW', 'HRMS', 'Placements', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_CHANGE_STATUS_VACANCY', 'HRMS', 'Change Status Vacancy', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_PLACEMENT', 'HRMS', 'Add Placement', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_HIRE_PLACEMENT', 'HRMS', 'Hire Placement', 10, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_TO_SHORT_LIST', 'HRMS', 'Add to short list', 10, false);


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_VACANCY_LIST_VIEW', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_VACANCY_LIST_VIEW', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_VACANCY_LIST_VIEW', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_VACANCY_LIST_VIEW', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_VACANCY_LIST_VIEW', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_LIST_VIEW', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_LIST_VIEW', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_LIST_VIEW', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_LIST_VIEW', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CANDIDATE_LIST_VIEW', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SHORT_LIST_VIEW', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SHORT_LIST_VIEW', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SHORT_LIST_VIEW', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SHORT_LIST_VIEW', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_SHORT_LIST_VIEW', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVITIES_VIEW', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVITIES_VIEW', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVITIES_VIEW', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVITIES_VIEW', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ACTIVITIES_VIEW', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PLACEMENT_LIST_VIEW', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PLACEMENT_LIST_VIEW', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PLACEMENT_LIST_VIEW', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PLACEMENT_LIST_VIEW', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_PLACEMENT_LIST_VIEW', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CHANGE_STATUS_VACANCY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CHANGE_STATUS_VACANCY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_CHANGE_STATUS_VACANCY', 'HR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_PLACEMENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_PLACEMENT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_HIRE_PLACEMENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_HIRE_PLACEMENT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_TO_SHORT_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_TO_SHORT_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_TO_SHORT_LIST', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_TO_SHORT_LIST', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_TO_SHORT_LIST', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
