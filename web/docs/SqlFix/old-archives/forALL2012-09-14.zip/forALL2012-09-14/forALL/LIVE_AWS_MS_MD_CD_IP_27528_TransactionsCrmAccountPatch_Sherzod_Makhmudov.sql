update "anv".invoice set iscreditnote=true where id in (select id from "anv".saleinvoice where iscreditnote=true);
update "anv".invoice set iscreditnote=true where id in (select id from "anv".purchaseinvoice where iscreditnote=true);

update "anv".transaction t set clientid=(select client_id from "anv".saleinvoice where id=t.invoiceid) where t.clientid is null and t.invoiceid is not null and t.invoiceid in (select id from "anv".saleinvoice);
update "anv".transaction t set supplierid=(select supplier_id from "anv".purchaseinvoice where id=t.invoiceid) where t.supplierid is null and t.invoiceid is not null and t.invoiceid in (select id from "anv".purchaseinvoice);


update "anv".transaction t set clientid=(select client_id from "anv".saleinvoice where id=(select invoiceid from "anv".invoicepayments where id = t.invoicepaymentid)) where t.clientid is null and t.invoicepaymentid is not null and t.invoicepaymentid in (select id from "anv".invoicepayments where invoiceid in (select id from "anv".saleinvoice));

update "anv".transaction t set supplierid=(select supplier_id from "anv".purchaseinvoice where id=(select invoiceid from "anv".invoicepayments where id = t.invoicepaymentid)) where t.supplierid is null and t.invoicepaymentid is not null and t.invoicepaymentid in (select id from "anv".invoicepayments where invoiceid in (select id from "anv".purchaseinvoice));

update "anv".transaction t set clientid=(select crmaccountid from "anv".invoicepayments where id = t.invoicepaymentid) where t.clientid is null and t.invoicepaymentid is not null and t.invoicepaymentid in (select id from "anv".invoicepayments where crmaccountid is not null);

update "anv".transaction t set invoiceid = (select invoiceid from "anv".transaction where id=t.reversalid), invoicepaymentid = (select invoicepaymentid from "anv".transaction where id=t.reversalid),
clientid = (select clientid from "anv".transaction where id=t.reversalid), supplierid = (select supplierid from "anv".transaction where id=t.reversalid) where reversalid is not null;

update "anv".transaction t set clientid=(select customerSupplierID from "anv".customerPayment where id = t.customersupplierpaymentid) where t.customersupplierpaymentid is not null and t.customersupplierpaymentid in (select id from "anv".customerPayment where type=1);
update "anv".transaction t set supplierid=(select customerSupplierID from "anv".customerPayment where id = t.customersupplierpaymentid) where t.customersupplierpaymentid is not null and t.customersupplierpaymentid in (select id from "anv".customerPayment where type=2);