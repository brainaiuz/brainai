
--IT's FOR AWS DB
delete from pricing_package where hostname='aws.activira.com';

insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_MINI',97,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_SMALL',199,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_STANDART',379,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_SILVER',924,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_ENTERPRISE2',1749,0,0,0,0);

insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_MINI_ANNUAL',999,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_SMALL_ANNUAL',1999,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_STANDART_ANNUAL',3799,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_SILVER_ANNUAL',9299,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('aws.activira.com','PP_ENTERPRISE2_ANNUAL',17990,0,0,0,0);

--IT's FOR APP DB
delete from pricing_package where hostname='app.activira.com';
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_MINI',97,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_SMALL',199,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_STANDART',379,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_SILVER',924,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_ENTERPRISE2',1749,0,0,0,0);

insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_MINI_ANNUAL',999,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_SMALL_ANNUAL',1999,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_STANDART_ANNUAL',3799,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_SILVER_ANNUAL',9299,0,0,0,0);
insert into pricing_package (hostname,packagename,price,min_one_month,min_three_month, min_six_month,max_twenty_month) values('app.activira.com','PP_ENTERPRISE2_ANNUAL',17990,0,0,0,0);