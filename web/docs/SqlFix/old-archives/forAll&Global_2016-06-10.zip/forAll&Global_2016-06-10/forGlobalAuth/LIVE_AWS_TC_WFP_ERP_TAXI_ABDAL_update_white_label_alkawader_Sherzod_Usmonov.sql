/* for aws */
update hostbasedsetting set paypalaccount = 'nabil@labbaik.com' where hostname = 'aws.alkawader.com' or hostname like '%alkawader%';
update hostbasedsetting set freetrialdays = 14 where hostname = 'aws.alkawader.com' or hostname like '%alkawader%';
/* for app */
update hostbasedsetting set paypalaccount = 'nabil@labbaik.com' where hostname = 'apps.alkawader.com' or hostname like '%alkawader%';
update hostbasedsetting set freetrialdays = 14 where hostname = 'apps.alkawader.com' or hostname like '%alkawader%';