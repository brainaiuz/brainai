ALTER TABLE clustercompany ADD COLUMN gadgetenabled boolean DEFAULT true;
ALTER TABLE googlegadgetauth DROP COLUMN isenable;