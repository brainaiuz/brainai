update hostbasedsetting set productname = 'Alfursanrecruitment' where hostname = 'aws.alfursanrecruitment.ae' and helphost = 'aws.alfursanrecruitment.ae';
update hostbasedsetting set productname = 'Alfursanrecruitment' where hostname = 'login.alfursanrecruitment.ae' and helphost = 'login.alfursanrecruitment.ae';
