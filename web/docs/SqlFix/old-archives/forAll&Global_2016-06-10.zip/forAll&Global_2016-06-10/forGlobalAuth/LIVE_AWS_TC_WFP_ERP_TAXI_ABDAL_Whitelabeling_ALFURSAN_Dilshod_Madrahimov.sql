-- aws.alfursanrecruitment.ae
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,
            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'aws.alfursanrecruitment.ae',
            null, 'aws.alfursanrecruitment.ae', TRUE, null,
            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            null, null, 'aws.alfursanrecruitment.ae', null,
            null, null, null, null, null, null,
            null, false, 'en',
            null, null, 14, 'workforce', null,
            null, null, null
    );


  ----- app.alfursanrecruitment.ae

  INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,
            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'app.alfursanrecruitment.ae',
            null, 'aws.alfursanrecruitment.ae', TRUE, null,
            null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            null, null, 'app.alfursanrecruitment.ae', null,
            null, null, null, null, null, null,
            null, false, 'en',
            null, null, 14, 'workforce', null,
            null, null, null
    );
