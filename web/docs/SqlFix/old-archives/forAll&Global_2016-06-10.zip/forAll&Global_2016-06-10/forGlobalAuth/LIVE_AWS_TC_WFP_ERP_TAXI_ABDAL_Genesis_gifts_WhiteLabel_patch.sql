-- app.genesis-gifts.com
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,
            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'app.genesis-gifts.com',
            null, 'app.genesis-gifts.com', TRUE, null,
            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            null, null, 'genesis-gifts.com', null,
            null, null, null, null, null, null,
            null, false, 'en',
            null, null, 14, 'workforce', null,
            null, null, null
    );

-- aws.genesis-gifts.com
INSERT INTO hostbasedsetting(
            emlfiledirectory, facebookapikey, facebookappid,
            facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
            googleconsumerkey,
            googlesignaturekey, hostname, isliveenv, linkedinapikey,
            linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
            productname, logoimage, helphost, email,
            skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
            productcompanyname, issslsupported,  defaultlocale,
            paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
            wikiurl, recaptcha_pubkey, recaptcha_privkey, massmailparamsfilename)
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT', null, null,
            null, null, null,
            'aws.genesis-gifts.com',
            null, 'aws.genesis-gifts.com', TRUE, null,
            null, null, null,'/mnt/webapps/projects/aws.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
            null, null, 'genesis-gifts.com', null,
            null, null, null, null, null, 'genesisgiftsmail.properties',
            null, false, 'en',
            null, null, 14, 'workforce', null,
            null, null, null, 'genesisgiftsmassmailler.properties'
    );

