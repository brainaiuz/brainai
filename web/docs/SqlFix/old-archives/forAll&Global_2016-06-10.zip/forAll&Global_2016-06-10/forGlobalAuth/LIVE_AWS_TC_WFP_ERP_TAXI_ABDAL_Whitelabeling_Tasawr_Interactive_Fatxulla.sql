-- aws.activira.com
INSERT INTO hostbasedsetting(
            emlfiledirectory,  hostname, isliveenv, solrurl, productname, helphost, email,
            skype, phone, address, pdflogo, mailparamsfilename,
            productcompanyname,  defaultlocale,
            paypalaccount,  freetrialdays, defaulttheme, currencycode
           )
    VALUES (
            '/mnt/webapps/projects/aws.workforcetrack.com/ROOT','aws.activira.com', TRUE,'http://solr2.workforcetrack.com:8080/solr/',
            'Activira ERP', 'aws.activira.com', 'support@activira.com', 'ActiviraERP', '+966 (56) 404-4240', '4363 Prince Muhammad Ibn Abdulaziz Rd, Al Olaya, Riyadh 12331 - 6734, KSA.',
            '/customisation/kpi.com/images/kpilogo.png', 'activiraemail.properties', 'Tasawr Interactive', 'en','billing@activira.com', 7, 'workforce', 'USD'
    );


  ----- app.activira.com

INSERT INTO hostbasedsetting(
            emlfiledirectory,  hostname, isliveenv, solrurl, productname, helphost, email,
            skype, phone, address, pdflogo, mailparamsfilename,
            productcompanyname,  defaultlocale,
            paypalaccount,  freetrialdays, defaulttheme, currencycode
           )
    VALUES (
            '/mnt/webapps/projects/app.workforcetrack.com/ROOT','app.activira.com', TRUE,'http://solr2.workforcetrack.com:8080/solr/',
            'Activira ERP', 'app.activira.com', 'support@activira.com', 'ActiviraERP', '+966 (56) 404-4240', '4363 Prince Muhammad Ibn Abdulaziz Rd, Al Olaya, Riyadh 12331 - 6734, KSA.',
            '/customisation/kpi.com/images/kpilogo.png', 'activiraemail.properties', 'Tasawr Interactive', 'en','billing@activira.com', 7, 'workforce', 'USD'
    );
