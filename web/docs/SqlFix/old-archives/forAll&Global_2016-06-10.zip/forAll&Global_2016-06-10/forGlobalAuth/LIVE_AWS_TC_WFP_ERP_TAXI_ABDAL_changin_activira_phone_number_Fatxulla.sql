--FOR AWS
update hostbasedsetting set phone='+966 (56) 777-7663 Ext: 810' where hostname='aws.activira.com';

--FOR APP
update hostbasedsetting set phone='+966 (56) 777-7663 Ext: 810' where hostname='app.activira.com';