update hostbasedsetting set productname = 'Genesis' where hostname = 'app.genesis-gifts.com';
update hostbasedsetting set productname = 'Genesis' where hostname = 'aws.genesis-gifts.com';