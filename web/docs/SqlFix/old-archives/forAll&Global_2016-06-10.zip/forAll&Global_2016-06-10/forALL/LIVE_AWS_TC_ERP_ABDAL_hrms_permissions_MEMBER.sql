--schema anv
delete from "anv".rolepermission where permissioncode='HRMS_MAIN_SECTION' and rolecode='MEM';
delete from "anv".rolepermission where permissioncode='HRMS_COMPANY_NEWS_ADD' and rolecode='MEM';
delete from "anv".rolepermission where permissioncode='HRMS_COMPANY_NEWS_EDIT' and rolecode='MEM';

delete from "anv".rolepermission where permissioncode='HRMS_SECTION_TAB' and rolecode='MEM';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SECTION_TAB', 'MEM', 'ALLOW');

delete from "anv".rolepermission where permissioncode='HRMS_COMPANY_NEWS' and rolecode='MEM';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'MEM', 'ALLOW');





--for zero schema
delete from "0".rolepermission where permissioncode='HRMS_MAIN_SECTION' and rolecode='MEM';
delete from "0".rolepermission where permissioncode='HRMS_COMPANY_NEWS_ADD' and rolecode='MEM';
delete from "0".rolepermission where permissioncode='HRMS_COMPANY_NEWS_EDIT' and rolecode='MEM';

delete from "0".rolepermission where permissioncode='HRMS_SECTION_TAB' and rolecode='MEM';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SECTION_TAB', 'MEM', 'ALLOW');

delete from "0".rolepermission where permissioncode='HRMS_COMPANY_NEWS' and rolecode='MEM';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COMPANY_NEWS', 'MEM', 'ALLOW');