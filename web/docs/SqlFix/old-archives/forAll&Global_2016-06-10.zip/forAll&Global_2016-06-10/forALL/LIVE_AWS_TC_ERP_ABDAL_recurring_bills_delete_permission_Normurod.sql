----for the public schema ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECURRING_BILL_DELETE', 'ACCOUNTING', 'Delete Recurring Bill', 5, false, (select id from permission where code='ACCOUNTING_RECURRING_BILL_LIST'), false, 'RECURRING_BILLS');

----for the zero schema ----
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_DELETE', 'ACCOUNTANT', 'ALLOW');

----for the anv schema ----
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_DELETE', 'ACCOUNTANT', 'ALLOW');