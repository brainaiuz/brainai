--SQL patch for all companies using multi currency (by invoice)
insert into "anv".exchangecurrency (deleted,currencyid)
select false,b.currency from (
	select ec.currencyid as currency from "anv".exchangecurrency ec where ec.deleted is false or ec.deleted is null
	order by ec.currencyid
) as a
full join (
	select distinct i.currency_id as currency from "anv".invoice i
		where (i.deleted is false or i.deleted is null) and i.currency_id not in 	(
			select fs.currency_id from company c
			join financialsettings fs on fs.id=c.financialsettingsid
			where c.id=anv)
	order by i.currency_id
) as b on b.currency=a.currency
where a.currency is null;
