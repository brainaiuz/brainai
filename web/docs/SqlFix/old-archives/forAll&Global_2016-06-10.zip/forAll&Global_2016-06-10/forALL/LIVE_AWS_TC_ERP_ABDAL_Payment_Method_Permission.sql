insert into permission(code, context, name,  ismainmenu, parent, iscore, modulecode)
		values('ACCOUNTING_PAYMENT_METHOD_LIST', 'ACCOUNTING', 'Payment Method List', false,
		(select id from permission where code = '"ACCOUNTING_SETTINGS_MENU"'), false, 'ACCOUNTING_MODULE');

insert into permission(code, context, name, ismainmenu, parent, iscore, modulecode)
values ('ACCOUNTING_PAYMENT_METHOD_ADD', 'ACCOUNTING', 'Payment Method Add', false,
(select id from permission where code = 'ACCOUNTING_PAYMENT_METHOD_LIST'), false, 'ACCOUNTING_MODULE');

  insert into permission(code, context, name, ismainmenu, parent, iscore, modulecode)
      values ('ACCOUNTING_PAYMENT_METHOD_EDIT', 'ACCOUNTING', 'Payment Method Add', false,
      (select id from permission where code = 'ACCOUNTING_PAYMENT_METHOD_LIST'), false, 'ACCOUNTING_MODULE');

  insert into permission(code, context, name, ismainmenu, parent, iscore, modulecode)
  values ('ACCOUNTING_PAYMENT_METHOD_DELETE', 'ACCOUNTING', 'Payment Method Add', false,
      (select id from permission where code = 'ACCOUNTING_PAYMENT_METHOD_LIST'), false, 'ACCOUNTING_MODULE');

	insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_LIST', 'ADMIN', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_LIST', 'DR', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_LIST', 'ACCOUNTANT', 'ALLOW');

  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_ADD', 'ADMIN', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_ADD', 'DR', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_ADD', 'ACCOUNTANT', 'ALLOW');

  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_EDIT', 'ADMIN', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_EDIT', 'DR', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_EDIT', 'ACCOUNTANT', 'ALLOW');

  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_DELETE', 'ADMIN', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_DELETE', 'DR', 'ALLOW');
  insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_DELETE', 'ACCOUNTANT', 'ALLOW');

  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_LIST', 'ADMIN', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_LIST', 'DR', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_LIST', 'ACCOUNTANT', 'ALLOW');

  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_ADD', 'ADMIN', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_ADD', 'DR', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_ADD', 'ACCOUNTANT', 'ALLOW');

  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_EDIT', 'ADMIN', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_EDIT', 'DR', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_EDIT', 'ACCOUNTANT', 'ALLOW');

  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_DELETE', 'ADMIN', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_DELETE', 'DR', 'ALLOW');
  insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAYMENT_METHOD_DELETE', 'ACCOUNTANT', 'ALLOW');