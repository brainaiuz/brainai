
insert into weather_locations ("location", "location_id", "country_id") values('As Sulaymaniyah','SAXX0009',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Bahrahh','SAXX0010',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Jeddah/Abdul Aziz','SAXX0011',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Jiddah','SAXX0012',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Mecca','SAXX0013',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Medina','SAXX0009',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Qara','SAXX0015',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Rabigh','SAXX0016',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Riyadh/Khaled','SAXX0018',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Sakakah','SAXX0019',(select id from country where code='SA'));

insert into weather_locations ("location", "location_id", "country_id") values('Zahran','SAXX0021',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Turaif','SAXX0022',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Arar','SAXX0023',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Guriat','SAXX0024',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Rafha','SAXX0025',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Al Qaysumah','SAXX0026',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Tabuk','SAXX0027',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Hail','SAXX0028',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Wejh','SAXX0029',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Gassim','SAXX0030',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Al Ahsa','SAXX0031',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Yenbo','SAXX0032',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Taif','SAXX0033',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Wadi Al Dawasser Airport','SAXX0034',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Bisha','SAXX0035',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Abha','SAXX0036',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Khamis Mushait','SAXX0037',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Najran','SAXX0038',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Sharurah','SAXX0039',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Gizan','SAXX0040',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Al Aqiq','SAXX0041',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Ad Dawadimi','SAXX0042',(select id from country where code='SA'));
insert into weather_locations ("location", "location_id", "country_id") values('Hafar+Al-Batin','SAXX0043',(select id from country where code='SA'));




insert into weather_locations ("location", "location_id", "country_id") values('Al Aqabah','JOXX0001',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Amman','JOXX0002',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Az Zarqa’','JOXX0003',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Madaba','JOXX0004',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Sahab','JOXX0005',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Zuwayza','JOXX0006',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Queen Alia Airport','JOXX0007',(select id from country where code='JO'));
insert into weather_locations ("location", "location_id", "country_id") values('Safi','JOXX0008',(select id from country where code='JO'));


insert into weather_locations ("location", "location_id", "country_id") values('As Sib','MUXX0001',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Matrah','MUXX0002',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Muscat','MUXX0003',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Khassab','MUXX0004',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Buraimi','MUXX0005',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Sohar Majis','MUXX0006',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Fahud','MUXX0007',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Sur','MUXX0008',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Masirah','MUXX0009',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Marmul','MUXX0010',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Thumrait','MUXX0011',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Salalah','MUXX0012',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Adam','MUXX0013',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Qairoon Hairiti','MUXX0014',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Al Rustaq','MUXX0015',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Ibra','MUXX0016',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Haima','MUXX0017',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Nizwa','MUXX0018',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Samail','MUXX0019',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Bahla','MUXX0020',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Saiq','MUXX0021',(select id from country where code='OM'));
insert into weather_locations ("location", "location_id", "country_id") values('Taqah','MUXX0022',(select id from country where code='OM'));


insert into weather_locations ("location", "location_id", "country_id") values('Ash Shuwayfat','LEXX0001',(select id from country where code='LB'));
insert into weather_locations ("location", "location_id", "country_id") values('Babda','LEXX0002',(select id from country where code='LB'));
insert into weather_locations ("location", "location_id", "country_id") values('Beirut','LEXX0003',(select id from country where code='LB'));
insert into weather_locations ("location", "location_id", "country_id") values('Furn ash Shubbak','LEXX0004',(select id from country where code='LB'));
insert into weather_locations ("location", "location_id", "country_id") values('Juniyah','LEXX0005',(select id from country where code='LB'));
insert into weather_locations ("location", "location_id", "country_id") values('Houche-Al-Oumara','LEXX0006',(select id from country where code='LB'));
insert into weather_locations ("location", "location_id", "country_id") values('Tripoli','LEXX0007',(select id from country where code='LB'));

