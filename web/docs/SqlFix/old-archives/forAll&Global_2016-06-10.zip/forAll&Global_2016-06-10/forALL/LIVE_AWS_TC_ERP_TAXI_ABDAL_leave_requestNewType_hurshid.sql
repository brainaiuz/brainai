---new reason type Other Leave

insert into "anv".reference (code, deleted, isremovable, issystemreference, name, shared, sorder, iscustombutton, parentid)
values ('LR_TYPE_OTHER_LEAVE', false, false, true, 'Other', true, (select sorder+1 from "anv".reference where code='LR_TYPE_UNAUTHORIZED_LEAVE'), false, (select id from "anv".reference where code='_LEAVE_REQUEST_TYPE'));


insert into "0".reference (code, deleted, isremovable, issystemreference, name, shared, sorder, iscustombutton, parentid)
values ('LR_TYPE_OTHER_LEAVE', false, false, true, 'Other', true, (select sorder+1 from "0".reference where code='LR_TYPE_UNAUTHORIZED_LEAVE'), false, (select id from "0".reference where code='_LEAVE_REQUEST_TYPE'));


update "anv".sickrequest set reason=(select id from "anv".reference where code='LR_TYPE_OTHER_LEAVE') where otherreason is not null and reason is null;