

--Schema updatedan OLDIN urilsin, Faqat awsga, appga kerak emas


alter table "anv".benefit drop column allowance;