
-- after schema update
update "anv".cashadvance set category_id=(
	select id from "anv".category c
		where c.code='CASH_ADVANCE'
	) where deleted is not true;

-- after schema update
update "anv".category set iscashadvance=true where code='CASH_ADVANCE';
