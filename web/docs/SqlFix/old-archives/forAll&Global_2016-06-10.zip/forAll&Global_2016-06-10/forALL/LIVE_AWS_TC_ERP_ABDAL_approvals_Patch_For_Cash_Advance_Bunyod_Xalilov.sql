DROP function if EXISTS "anv".createDefaultApproversForCashAdvance();
CREATE OR replace function "anv".createDefaultApproversForCashAdvance()
  returns INTEGER AS
  $body$
DECLARE
    approverID INTEGER;
    approvedWorkflowID INTEGER;
    rejectedWorkflowID INTEGER;
    cashAdvance_approver_id INTEGER;
    ca record;

    BEGIN
            --create approver item in "anv".approvers table
            insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'CASH_ADVANCE', true, 1, 3) RETURNING id INTO approverID;
            --create approvers_role rows.!!!!!!!!!
            insert into "anv".approver_roles(approver_id, role_id) (select approverID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
            --create workflows for approval1
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_CASH_ADVANCE', false) RETURNING id into approvedWorkflowID;
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_CASH_ADVANCE', false) RETURNING id INTO rejectedWorkflowID;
            --set workflowids to the approver
            update "anv".approvers set workflow=approvedWorkflowID, rejected_workflow=rejectedWorkflowID where id=approverID;
            --create approvers for every "anv".cashadvance
            FOR ca IN (SELECT * FROM "anv".cashadvance)
            LOOP
                INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
                values (1, 'CASH_ADVANCE', ca.id, false, 5, 6,approvedWorkflowID, rejectedWorkflowID,ca.approver_id,ca.status_id) RETURNING id INTO cashAdvance_approver_id;
                -- update current cashAdvance with new approver item.
                update "anv".cashadvance a set currentapprover=cashAdvance_approver_id, prevapprover=cashAdvance_approver_id, overallstatus=a.status_id where id = ca.id;
            END LOOP;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".createDefaultApproversForCashAdvance() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".createDefaultApproversForCashAdvance()) IS NOT NULL;