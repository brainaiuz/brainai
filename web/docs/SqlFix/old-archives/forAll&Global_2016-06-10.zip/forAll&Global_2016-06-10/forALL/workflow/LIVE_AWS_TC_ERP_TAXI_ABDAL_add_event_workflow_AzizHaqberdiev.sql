delete from "model"  where formid = 'ACTIVITY_FORM';
delete from "modelfield"  where form_id = 'ACTIVITY_FORM';
delete from "0".reference  where code = '_WORKFLOW_MODULE_ACTIVITY';
insert into "0".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_ACTIVITY', 'Event', (select max(sorder) from "0".reference where parentid = (select id from "0".reference where code = '_WORKFLOW_MODULE')),
(select id from "0".reference where code = '_WORKFLOW_MODULE'));

insert into model(active,formID, title,viewname) values(true,'ACTIVITY_FORM', 'Event Form', 'Activity');
insert into modelfield(form_ID,       field_ID,    sorder,  isCustomField,  defaultValue,    widget,      source,  type,   usableByWorkflow) values
                      ('ACTIVITY_FORM',  'SUBJECT',       1,       false,           '',     'TextBox',     null,  'Text',        true),
                      ('ACTIVITY_FORM',  'START_DATE',    2,       false,           '',    'DatePicker',   null,  'Date',        true),
                      ('ACTIVITY_FORM',  'END_DATE',      3,       false,           '',    'DatePicker',   null,  'Date',        true),
                      ('ACTIVITY_FORM',  'DESCRIPTION',   4,       false,           '',     'TextArea',    null,  'Text',        true),
                      ('ACTIVITY_FORM',  'LOCATION',      5,       false,           '',     'TextBox',     null,  'Text',        true);


delete from "anv"."model"  where formid = 'ACTIVITY_FORM';
delete from "anv"."modelfield"  where form_id = 'ACTIVITY_FORM';

delete from "anv".reference  where code = '_WORKFLOW_MODULE_ACTIVITY';
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_ACTIVITY', 'Event', (select max(sorder) from "anv".reference where parentid = (select id from "anv".reference where code = '_WORKFLOW_MODULE')),
(select id from "anv".reference where code = '_WORKFLOW_MODULE'));

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('ACTIVITY_FORM', 'Activity')) IS NOT NULL;
