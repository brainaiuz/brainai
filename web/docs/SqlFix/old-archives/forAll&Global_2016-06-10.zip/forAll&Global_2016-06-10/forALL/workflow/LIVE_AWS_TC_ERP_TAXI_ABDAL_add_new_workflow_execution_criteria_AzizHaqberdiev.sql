insert into "0".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_RESCHEDULE', 
'RESCHEDULE(Executes the rule when CS student(s) are rescheduled)', 6, (select id from "0".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
insert into "anv".reference(code, name, sorder, parentid) values('_WORKFLOW_EXECUTION_CRITERIA_RESCHEDULE',
'RESCHEDULE(Executes the rule when CS student(s) are rescheduled)', 6, (select id from "anv".reference where code = '_WORKFLOW_EXECUTION_CRITERIA' limit 1));
