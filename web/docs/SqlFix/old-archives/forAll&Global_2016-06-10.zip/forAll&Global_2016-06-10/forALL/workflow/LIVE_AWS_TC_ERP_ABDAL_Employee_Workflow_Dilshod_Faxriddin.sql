
--
------ public -------
--set employee fields usable by workflow
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'FIRST_NAME';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'LAST_NAME';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'MIDDLE_NAME';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMAIL';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PHONE';

update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'GENDER';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'NATIONALITY';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'MARTIAL_STATUS';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_STATUS';

update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMPLOYEE_CODE';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'DEPARTMENT';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SUPERVISOR';
update modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'WAGE_RATE';
update modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'CLIENT_CHARGE_RATE';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMPLOYMENT_MODE';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SALARY_GRADE';
update modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SALARY_AMOUNT';
update modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'QUALIFICATION';

update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PASSPORT_NUMBER';
update modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PASSPORT_ISSUE_DATE';
update modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PASSPORT_EXPIRY_DATE';
update modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'YEAR_LEAVE_DURATION';
update modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'YEAR_LEAVE_HOUR_DURATION';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'INSURANCE_NUMBER';
update modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'INSURANCE_EXPIRY_DATE';

update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'VISA_NUMBER';
update modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'VISA_ISSUE_DATE';
update modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'VISA_EXPIRATION_DATE';


-- set source reference

update modelfield set source='REFERENCE@_MARTIAL_STATUS' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'MARTIAL_STATUS';
update modelfield set source='REFERENCE@Q_QUALIFICATION' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'QUALIFICATION';
update modelfield set source='REFERENCE@_EMPLOYMENT_MODE' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMPLOYMENT_MODE';
update modelfield set source='REFERENCE@_EMPLOYEE_STATUS' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_STATUS';

update modelfield set source='HRMS@_DEPARTMENT' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'DEPARTMENT';
update modelfield set source='HRMS@_SUPERVISOR' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SUPERVISOR';


----- All --------

update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'FIRST_NAME';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'LAST_NAME';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'MIDDLE_NAME';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMAIL';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PHONE';

update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'GENDER';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'NATIONALITY';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'MARTIAL_STATUS';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_STATUS';

update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMPLOYEE_CODE';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'DEPARTMENT';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SUPERVISOR';
update "anv".modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'WAGE_RATE';
update "anv".modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'CLIENT_CHARGE_RATE';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMPLOYMENT_MODE';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SALARY_GRADE';
update "anv".modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SALARY_AMOUNT';
update "anv".modelfield set usableByWorkflow = true,type='text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'QUALIFICATION';

update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PASSPORT_NUMBER';
update "anv".modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PASSPORT_ISSUE_DATE';
update "anv".modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PASSPORT_EXPIRY_DATE';
update "anv".modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'YEAR_LEAVE_DURATION';
update "anv".modelfield set usableByWorkflow = true,type='Number' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'YEAR_LEAVE_HOUR_DURATION';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'INSURANCE_NUMBER';
update "anv".modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'INSURANCE_EXPIRY_DATE';

update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'VISA_NUMBER';
update "anv".modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'VISA_ISSUE_DATE';
update "anv".modelfield set usableByWorkflow = true,type='Date' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'VISA_EXPIRATION_DATE';


-- set source reference

update "anv".modelfield set source='REFERENCE@_MARTIAL_STATUS' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'MARTIAL_STATUS';
update "anv".modelfield set source='REFERENCE@Q_QUALIFICATION' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'QUALIFICATION';
update "anv".modelfield set source='REFERENCE@_EMPLOYMENT_MODE' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'EMPLOYMENT_MODE';
update "anv".modelfield set source='REFERENCE@_EMPLOYEE_STATUS' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_STATUS';

update "anv".modelfield set source='HRMS@_DEPARTMENT' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'DEPARTMENT';
update "anv".modelfield set source='HRMS@_SUPERVISOR' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SUPERVISOR';