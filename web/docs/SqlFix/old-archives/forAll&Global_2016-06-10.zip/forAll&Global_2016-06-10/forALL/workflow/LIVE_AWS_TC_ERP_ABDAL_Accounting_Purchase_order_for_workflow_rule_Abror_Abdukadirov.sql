--SchemaUpdate dan kiyin urilsin

insert into "anv".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_PURCHASEORDER', false, true, 'Purchase Order', true, 7, (select id from "anv".reference where code='_WORKFLOW_MODULE'), true);

insert into "0".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_PURCHASEORDER', false, true, 'Purchase Order', true, 7, (select id from "0".reference where code='_WORKFLOW_MODULE'), true);


insert into model(active, formid, title, viewname) values(true, 'PURCHASEORDER_FORM', 'Purchase Order Form', 'Purchase Order');

insert into modelfield(form_ID, 				     field_ID,	 							sorder, widget , 				source, 													   usableByWorkflow, 	type, 		disableUpdate) values
											('PURCHASEORDER_FORM', 'SUPPLIER', 							1,			'DropDown', 		'ACCOUNTING@PURCHASE_ORDER_SUPPLIER',true,							'Text',	  false),
											('PURCHASEORDER_FORM', 'PROJECT',  							2,			'DropDown',  		'ACCOUNTING@PURCHASE_ORDER_PROJECT', true,							'Text',	  true),
											('PURCHASEORDER_FORM', 'INVOICE_DATE',					3,			'DatePicker', 	null,  														   true,							'Date',	  true),
											('PURCHASEORDER_FORM', 'DUE_DATE', 							4,			'DatePicker', 	null,															   true,							'Date',	  true),
											('PURCHASEORDER_FORM', 'REFERENCE', 						5,			'TextBox', 			null,	 														 	 true,							'Text',	  true),
											('PURCHASEORDER_FORM', 'PO_NUMBER', 						6,			'TextBox', 			null,	 														 	 true,							'Text',	  true),
											('PURCHASEORDER_FORM', 'SUB_TOTAL',   					7, 			'TextBox', 			null, 														 	 true,							'Number', true),
											('PURCHASEORDER_FORM', 'TOTAL',									8, 			'TextBox', 			null, 														 	 true,							'Number', true),
											('PURCHASEORDER_FORM', 'TOTAL_INVOICE_CURRENCY',9,			'TextBox', 			null,															 	 true,							'Number', true),
											('PURCHASEORDER_FORM', 'TOTAL_DISCOUNT',				10,			'TextBox', 			null,															 	 true,							'Number', true),
											('PURCHASEORDER_FORM', 'SHIPPING_TERMS',				11,			'TextBox', 			null,															 	 true,							'Text',	  true),
											('PURCHASEORDER_FORM', 'PAYMENT_TERMS',					12,			'TextBox', 			null,															 	 true,							'Text',	  true),
											('PURCHASEORDER_FORM', 'PAYMENT_TYPE',					13,			'DropDown',			'ACCOUNTING@SALE_QUOTE_SHIP_VIA',    true,							'Text',	  true),
											('PURCHASEORDER_FORM', 'STATUS', 		  					14,			'DropDown',			'ACCOUNTING@PURCHASE_ORDER_STATUS',	 true,							'Text', 	true),
											('PURCHASEORDER_FORM', 'SALE_QUOTE',  					14,			'DropDown',			'ACCOUNTING@PURCHASE_ORDER_SALE_QUOTE',true,						'Text', 	true);


