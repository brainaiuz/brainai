delete from modelfield where form_id = 'ACTIVITY_FORM' and field_id = 'CRETOR';
insert into modelfield(form_ID,           field_ID,    sorder,  isCustomField,  defaultValue,    widget,          source,       type,   usableByWorkflow) values
                      ('ACTIVITY_FORM',  'CREATOR',        6,       false,           '',      'LOOKUP',    'CRM@EMPLOYEE',  'text',        true);


delete from "anv".modelfield where form_id = 'ACTIVITY_FORM' and field_id = 'CRETOR';
insert into "anv".modelfield(form_ID,           field_ID,    sorder,  isCustomField,  defaultValue,    widget,          source,       type,   usableByWorkflow) values
                      ('ACTIVITY_FORM',  'CREATOR',        6,       false,           '',      'LOOKUP',    'CRM@EMPLOYEE',  'text',        true);
