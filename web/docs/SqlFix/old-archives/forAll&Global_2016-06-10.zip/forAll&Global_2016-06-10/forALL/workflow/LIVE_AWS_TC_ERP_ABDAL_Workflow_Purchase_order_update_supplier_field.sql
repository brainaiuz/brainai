update modelfield set disableUpdate = true where form_ID = 'PURCHASEORDER_FORM'
                                          and field_ID = 'SUPPLIER'
                                          and source = 'ACCOUNTING@PURCHASE_ORDER_SUPPLIER';