delete from "model"  where formid = 'CS_STUDENT_FORM';
delete from "0".reference  where code = '_WORKFLOW_MODULE_CS_STUDENT';
insert into "0".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CS_STUDENT', 'CS Student', (select max(sorder) from "0".reference where parentid = (select id from "0".reference where code = '_WORKFLOW_MODULE')),
(select id from "0".reference where code = '_WORKFLOW_MODULE'));

insert into model(active,formID, title,viewname) values(true,'CS_STUDENT_FORM', 'CS Student Form', 'CS Student');

delete from "anv"."model"  where formid = 'CS_STUDENT_FORM';

delete from "anv".reference  where code = '_WORKFLOW_MODULE_CS_STUDENT';
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CS_STUDENT', 'CS Student', (select max(sorder) from "anv".reference where parentid = (select id from "anv".reference where code = '_WORKFLOW_MODULE')),
(select id from "anv".reference where code = '_WORKFLOW_MODULE'));

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('CS_STUDENT_FORM', 'CS Student')) IS NOT NULL;
