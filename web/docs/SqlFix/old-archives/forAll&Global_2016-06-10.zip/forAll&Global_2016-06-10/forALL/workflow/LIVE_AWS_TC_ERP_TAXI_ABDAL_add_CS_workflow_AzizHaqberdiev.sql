delete from "model"  where formid = 'SCHEDULED_COURSE_FORM';
delete from "modelfield"  where form_id = 'SCHEDULED_COURSE_FORM';
delete from "0".reference  where code = '_WORKFLOW_MODULE_SCHEDULED_COURSE';
insert into "0".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_SCHEDULED_COURSE', 'Course Schedule', (select max(sorder) from "0".reference where parentid = (select id from "0".reference where code = '_WORKFLOW_MODULE')),
(select id from "0".reference where code = '_WORKFLOW_MODULE'));

insert into model(active,formID, title,viewname) values(true,'SCHEDULED_COURSE_FORM', 'Course Schedule Form', 'Course Schedule');
insert into modelfield(       form_ID,           field_ID,           sorder,  isCustomField,  defaultValue,    widget,           source,        type,   usableByWorkflow) values
                      ('SCHEDULED_COURSE_FORM',  'LOCATION',             1,       false,           '',        'DropDown',     'TC@LOCATION',   'Text',        true),
                      ('SCHEDULED_COURSE_FORM',  'COURSE',               2,       false,           '',        'DropDown',     'TC@COURSE',     'Text',        true),
                      ('SCHEDULED_COURSE_FORM',  'LANGUAGE',             3,       false,           '',        'DropDown',     'TC@LANGUAGE',   'Text',        true),
                      ('SCHEDULED_COURSE_FORM',  'START_DATE',           4,       false,           '',        'DatePicker',       null,        'Date',        true),
                      ('SCHEDULED_COURSE_FORM',  'INSTRUCTOR',           5,       false,           '',        'DropDown',     'TC@INSTRUCTOR', 'Text',        true),
                      ('SCHEDULED_COURSE_FORM',  'ASSESSOR',             6,       false,           '',        'DropDown',     'TC@ASSESSOR',   'Text',        true),
                      ('SCHEDULED_COURSE_FORM',  'NUMBER_OF_SEATS',      7,       false,           '',        'TextBox',          null,       'Number',       true),
                      ('SCHEDULED_COURSE_FORM',  'NUMBER',               8,       false,           '',        'TextBox',          null,        'Text',        true);


delete from "anv"."model"  where formid = 'SCHEDULED_COURSE_FORM';
delete from "anv"."modelfield"  where form_id = 'SCHEDULED_COURSE_FORM';

delete from "anv".reference  where code = '_WORKFLOW_MODULE_SCHEDULED_COURSE';
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_SCHEDULED_COURSE', 'Course Schedule', (select max(sorder) from "anv".reference where parentid = (select id from "anv".reference where code = '_WORKFLOW_MODULE')),
(select id from "anv".reference where code = '_WORKFLOW_MODULE'));

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('SCHEDULED_COURSE_FORM', 'Course Schedule')) IS NOT NULL;
