--invitation templatelani attributelari


---||||ZERO SCHEMAGA
update "0".emailtemplate set messageHtml = replace(messageHtml, '${username}', '${creator}'), subject = replace(subject, '${username}', '${creator}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${USER}', '${creator}'), subject = replace(subject, '${USER}', '${creator}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${EVENT_NAME}', '${subject}'), subject = replace(subject, '${EVENT_NAME}', '${subject}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${SUBJECT}', '${subject}'), subject = replace(subject, '${SUBJECT}', '${subject}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${DESCRIPTION}', '${description}'), subject = replace(subject, '${DESCRIPTION}', '${description}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${WHERE}', '${location}'), subject = replace(subject, '${WHERE}', '${location}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${DATE}', '${when}'), subject = replace(subject, '${DATE}', '${when}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${CREATOR_NAME}', '${creator}'), subject = replace(subject, '${CREATOR_NAME}', '${creator}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${SHARED_WITH}', '${sharedemployees}'), subject = replace(subject, '${SHARED_WITH}', '${sharedemployees}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${GUESTS}', '${guests}'), subject = replace(subject, '${GUESTS}', '${guests}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${GUESTSEMAIL}', '${guests_emails}'), subject = replace(subject, '${GUESTSEMAIL}', '${guests_emails}')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');
update "0".emailtemplate set messageHtml = replace(messageHtml, '${UPDATED}', 'Updated'), subject = replace(subject, '${UPDATED}', 'Updated')
where module_id = (select id from "0".reference where code = 'ET_EVENT_MODULE');


delete from "0".workflow_alerts where workflow in (select id from "0".workflowRule where module = '_WORKFLOW_MODULE_ACTIVITY');
delete from "0".workflow_condition where workflow in (select id from "0".workflowRule where module = '_WORKFLOW_MODULE_ACTIVITY');
delete from "0".workflowrule where module = '_WORKFLOW_MODULE_ACTIVITY';

--yangi create buganda ishlaydigan shared va guestlarga ketadigan notificationlar
insert into "0".workflowrule (executioncriteria, module, name, status)
values ('_WORKFLOW_EXECUTION_CRITERIA_CREATE', '_WORKFLOW_MODULE_ACTIVITY', 'Default Calendar add event', '_WORKFLOW_STATUS_ACTIVE');
--Creatorga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${creator_email}', 'Calendar Add Event Notification: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar add event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Dear ${creator},</p>

<p>Please be informed that you have added &quot;${subject}&quot; event to your calendar.</p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>${sharedemployees}</p>
${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--shared employeelarga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${shared_employee_emails}', 'Calendar Share Event Notification: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar add event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed ${creator} has <b>shared</b> the following event to you:</p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees} ${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--guestlarga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${guests_emails}', 'Event Invitation: ${subject} ${start_date}', (select id from "0".workflowRule where name = 'Default Calendar add event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please be informed that you have been invited to ${subject}</p>

<p>Added Event details:</p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>Organizer: ${creator}</p>

<p>Shared with: ${sharedemployees}</p>

<p>Guests:${guests}</p>

<p><b>Going?</b> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Accepted"> Yes </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Tentatively"> Maybe </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Declined"> No </a></p>');

--edit buganda ishlaydigan shared va guestlarga ketadigan notificationlar
insert into "0".workflowrule (executioncriteria, module, name, status)
values ('_WORKFLOW_EXECUTION_CRITERIA_EDIT', '_WORKFLOW_MODULE_ACTIVITY', 'Default Calendar edit event', '_WORKFLOW_STATUS_ACTIVE');
--Creatorga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${creator_email}', 'Calendar Update Event Notification: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar edit event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Dear ${creator},</p>

<p>Please, be informed that the following event has been <b>updated:</b></p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees} ${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--shared employeelarga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${shared_employee_emails}', 'Calendar Update Event Notification: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar edit event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed ${creator} has <b>updated</b> the following event that was shared to you:</p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees} ${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--guestlarga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${guests_emails}', 'Updated Invitation: ${subject} ${start_date}', (select id from "0".workflowRule where name = 'Default Calendar edit event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please be informed that ${creator} updated this event.</p>

<p>Updated Event details:</p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>Organizer: ${creator}</p>

<p>Shared with: ${sharedemployees}</p>

<p>Guests: ${guests}</p>

<p><b>Going?</b> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Accepted"> Yes </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Tentatively"> Maybe </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Declined"> No </a></p>');

--delete buganda ishlaydigan shared va guestlarga ketadigan notificationlar
insert into "0".workflowrule (executioncriteria, module, name, status)
values ('_WORKFLOW_EXECUTION_CRITERIA_REMOVE', '_WORKFLOW_MODULE_ACTIVITY', 'Default Calendar delete event', '_WORKFLOW_STATUS_INACTIVE');
--Creatorga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${creator_email}', 'Calendar Delete Event Notification: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar delete event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Dear ${creator},</p>

<p>Please, be informed that the following event has been <b>deleted:</b></p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees}');
--shared employeelarga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${shared_employee_emails}', 'Calendar Delete Event Notification: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar delete event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed that the following event has been <b>deleted:</b></p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees}');
--guestlarga
insert into "0".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${guests_emails}', 'Canceled Event: ${subject}', (select id from "0".workflowRule where name = 'Default Calendar delete event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed ${creator} has <b>deleted</b> the following event that you have been invited:</p>

<p>Deleted Event details:</p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>Organizer: ${creator}</p>

<p>Shared with: ${sharedemployees}</p>');


---|||PRIVATE SCHEMAGA
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${username}', '${creator}'), subject = replace(subject, '${username}', '${creator}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${USER}', '${creator}'), subject = replace(subject, '${USER}', '${creator}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${EVENT_NAME}', '${subject}'), subject = replace(subject, '${EVENT_NAME}', '${subject}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${SUBJECT}', '${subject}'), subject = replace(subject, '${SUBJECT}', '${subject}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${DESCRIPTION}', '${description}'), subject = replace(subject, '${DESCRIPTION}', '${description}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${WHERE}', '${location}'), subject = replace(subject, '${WHERE}', '${location}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${DATE}', '${when}'), subject = replace(subject, '${DATE}', '${when}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${CREATOR_NAME}', '${creator}'), subject = replace(subject, '${CREATOR_NAME}', '${creator}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${SHARED_WITH}', '${sharedemployees}'), subject = replace(subject, '${SHARED_WITH}', '${sharedemployees}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${GUESTS}', '${guests}'), subject = replace(subject, '${GUESTS}', '${guests}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${GUESTSEMAIL}', '${guests_emails}'), subject = replace(subject, '${GUESTSEMAIL}', '${guests_emails}')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');
update "anv".emailtemplate set messageHtml = replace(messageHtml, '${UPDATED}', 'Updated'), subject = replace(subject, '${UPDATED}', 'Updated')
where module_id = (select id from "anv".reference where code = 'ET_EVENT_MODULE');


delete from "anv".workflow_alerts where workflow in (select id from "anv".workflowRule where module = '_WORKFLOW_MODULE_ACTIVITY');
delete from "anv".workflow_condition where workflow in (select id from "anv".workflowRule where module = '_WORKFLOW_MODULE_ACTIVITY');
delete from "anv".workflowrule where module = '_WORKFLOW_MODULE_ACTIVITY';

--yangi create buganda ishlaydigan shared va guestlarga ketadigan notificationlar
insert into "anv".workflowrule (executioncriteria, module, name, status)
values ('_WORKFLOW_EXECUTION_CRITERIA_CREATE', '_WORKFLOW_MODULE_ACTIVITY', 'Default Calendar add event', '_WORKFLOW_STATUS_ACTIVE');
--Creatorga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${creator_email}', 'Calendar Add Event Notification: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar add event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Dear ${creator},</p>

<p>Please be informed that you have added &quot;${subject}&quot; event to your calendar.</p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>${sharedemployees}</p>
${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--shared employeelarga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${shared_employee_emails}', 'Calendar Share Event Notification: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar add event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed ${creator} has <b>shared</b> the following event to you:</p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees} ${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--guestlarga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${guests_emails}', 'Event Invitation: ${subject} ${start_date}', (select id from "anv".workflowRule where name = 'Default Calendar add event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please be informed that you have been invited to ${subject}</p>

<p>Added Event details:</p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>Organizer: ${creator}</p>

<p>Shared with: ${sharedemployees}</p>

<p>Guests:${guests}</p>

<p><b>Going?</b> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Accepted"> Yes </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Tentatively"> Maybe </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Declined"> No </a></p>');

--edit buganda ishlaydigan shared va guestlarga ketadigan notificationlar
insert into "anv".workflowrule (executioncriteria, module, name, status)
values ('_WORKFLOW_EXECUTION_CRITERIA_EDIT', '_WORKFLOW_MODULE_ACTIVITY', 'Default Calendar edit event', '_WORKFLOW_STATUS_ACTIVE');
--Creatorga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${creator_email}', 'Calendar Update Event Notification: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar edit event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Dear ${creator},</p>

<p>Please, be informed that the following event has been <b>updated:</b></p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees} ${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--shared employeelarga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${shared_employee_emails}', 'Calendar Update Event Notification: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar edit event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed ${creator} has <b>updated</b> the following event that was shared to you:</p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees} ${guests}

<p>Click <a href="${event_link}">here</a> to view your event details on calendar.<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser: <span style="color: #0033FF">${event_link}</span></p>');
--guestlarga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${guests_emails}', 'Updated Invitation: ${subject} ${start_date}', (select id from "anv".workflowRule where name = 'Default Calendar edit event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please be informed that ${creator} updated this event.</p>

<p>Updated Event details:</p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>Organizer: ${creator}</p>

<p>Shared with: ${sharedemployees}</p>

<p>Guests: ${guests}</p>

<p><b>Going?</b> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Accepted"> Yes </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Tentatively"> Maybe </a> -
<a href="${HOST}/eventGuest.html?dtype=${DATABASE_TYPE}&amp;cid=${COMPANY_ID}&amp;id=${EVENT_ID}&amp;email=${guests_emails}&amp;answer=Declined"> No </a></p>');

--delete buganda ishlaydigan shared va guestlarga ketadigan notificationlar
insert into "anv".workflowrule (executioncriteria, module, name, status)
values ('_WORKFLOW_EXECUTION_CRITERIA_REMOVE', '_WORKFLOW_MODULE_ACTIVITY', 'Default Calendar delete event', '_WORKFLOW_STATUS_INACTIVE');
--Creatorga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${creator_email}', 'Calendar Delete Event Notification: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar delete event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Dear ${creator},</p>

<p>Please, be informed that the following event has been <b>deleted:</b></p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees}');
--shared employeelarga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${shared_employee_emails}', 'Calendar Delete Event Notification: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar delete event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed that the following event has been <b>deleted:</b></p>

<p><b>Event details:</b></p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>
${sharedemployees}');
--guestlarga
insert into "anv".workflow_alerts (recepient, subject, workflow, workflowactionstarttime, workflowactionstarttimegranularity, workflowactionstarttimeunit, isworkflowactiontimebased, fromuserid, content)
values ('${guests_emails}', 'Canceled Event: ${subject}', (select id from "anv".workflowRule where name = 'Default Calendar delete event'), 'TRIGGER_TIME', 'MINUTES', 0, false, -1,
'<p>Please, be informed ${creator} has <b>deleted</b> the following event that you have been invited:</p>

<p>Deleted Event details:</p>

<div style="background-color:lightblue; width:100%;">
<p>Title: ${subject}</p>

<p>Description: ${description}</p>

<p>When: ${when}</p>
</div>

<p>Where: ${location}</p>

<p>Organizer: ${creator}</p>

<p>Shared with: ${sharedemployees}</p>');

