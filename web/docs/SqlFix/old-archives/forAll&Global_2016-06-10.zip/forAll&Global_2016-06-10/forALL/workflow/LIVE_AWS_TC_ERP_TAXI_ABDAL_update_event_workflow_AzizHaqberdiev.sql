update model set title = 'Activity Form', viewName = 'Activity' where formid = 'ACTIVITY_FORM';
update "anv".model set title = 'Activity Form', viewName = 'Activity' where formid = 'ACTIVITY_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('ACTIVITY_FORM', 'Activity')) IS NOT NULL;