
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
   ('ACCOUNTING_CURRENCY_RATES_LIST', 'ACCOUNTING', 'Currency Rates', 16, false, (select id from permission where code='ACCOUNTING_SETTINGS_MENU'), false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATES_LIST', 'PM', 'ALLOW');


