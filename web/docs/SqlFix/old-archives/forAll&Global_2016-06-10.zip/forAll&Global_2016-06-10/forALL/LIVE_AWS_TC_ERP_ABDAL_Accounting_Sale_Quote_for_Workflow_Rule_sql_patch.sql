--SchemaUpdate dan kiyin urilsin

insert into "anv".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_SALEQUOTE', false, true, 'Sales Quote', true, 6, (select id from "anv".reference where code='_WORKFLOW_MODULE'), true);

insert into "0".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_SALEQUOTE', false, true, 'Sales Quote', true, 6, (select id from "0".reference where code='_WORKFLOW_MODULE'), true);


insert into model(active, formid, title, viewname) values(true, 'SALEQUOTE_FORM', 'Sales Quat Form', 'Sales Quote');

insert into modelfield(form_ID, 				 field_ID, 	 							sorder, widget , 				source, 													 usableByWorkflow, 	type, 		disableUpdate) values
											('SALEQUOTE_FORM', 'CUSTOMER', 							1,			'DropDown', 		'ACCOUNTING@SALE_QUOTE_CUSTOMER',  true,								'Text',	true),
											('SALEQUOTE_FORM', 'PROJECT',  							2,			'DropDown',  		'ACCOUNTING@SALE_QUOTE_PROJECT',   true,								'Text',	true),
											('SALEQUOTE_FORM', 'INVOICE_DATE',					3,			'DatePicker', 	null,  														 true,								'Date',	true),
											('SALEQUOTE_FORM', 'DUE_DATE', 							4,			'DatePicker', 	null,															 true,								'Date',	true),
											('SALEQUOTE_FORM', 'MANAGER', 							5,			'DropDown', 		'ACCOUNTING@SALE_QUOTE_MANAGER',	 true,								'Text',	false),
											('SALEQUOTE_FORM', 'REFERENCE', 						6,			'TextBox', 			null,	 														 true,								'Text',	true),
											('SALEQUOTE_FORM', 'PO_NUMBER', 						7,			'TextBox', 			null,	 														 true,								'Text',	true),
											('SALEQUOTE_FORM', 'SHIP_VIA', 							8,			'DropDown', 		'ACCOUNTING@SALE_QUOTE_SHIP_VIA',	 true,								'Text',	false),
											('SALEQUOTE_FORM', 'SUB_TOTAL',   					9, 			'TextBox', 			null, 														 true, 								'Number',true),
											('SALEQUOTE_FORM', 'TOTAL',									10, 		'TextBox', 			null, 														 true, 								'Number',true),
											('SALEQUOTE_FORM', 'TOTAL_INVOICE_CURRENCY',11,			'TextBox', 			null,															 true, 								'Number',true),
											('SALEQUOTE_FORM', 'TOTAL_DISCOUNT',				12,			'TextBox', 			null,															 true, 								'Number',true),
											('SALEQUOTE_FORM', 'STATUS',								13, 		'DropDown', 		'ACCOUNTING@SALE_QUOTE_STATUS',	   true, 								'Text',	true);

