-- schema anv
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('_VACANCY_TYPE', '',  '_VACANCY_TYPE', null,null );
INSERT INTO "anv".reference( code, description, name, sorder, parentid) VALUES ('VACANCY_YEARLY_VACATION', '', 'Yearly vacation', 1, (select id from "anv".reference where code = '_VACANCY_TYPE' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_END_OF_CONTRACT_VACATION', '',  'End of contract vacation', 2, (select id from "anv".reference where code = '_VACANCY_TYPE' limit 1) );

INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('_VACANCY_RELIGION', '',  '_VACANCY_RELIGION', null,null );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_JUDAISM', '',  'Judaism', 1, (select id from "anv".reference where code = '_VACANCY_RELIGION' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_CHRISTIANITY', '',  'Christianity', 2, (select id from "anv".reference where code = '_VACANCY_RELIGION' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_ISLAM', '',  'Islam', 3, (select id from "anv".reference where code = '_VACANCY_RELIGION' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_OTHER', '',  'Other', 4, (select id from "anv".reference where code = '_VACANCY_RELIGION' limit 1) );





-- for schema 0
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('_VACANCY_TYPE', '',  '_VACANCY_TYPE', null,null );
INSERT INTO "0".reference( code, description, name, sorder, parentid) VALUES ('VACANCY_YEARLY_VACATION', '', 'Yearly vacation', 1, (select id from "0".reference where code = '_VACANCY_TYPE' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_END_OF_CONTRACT_VACATION', '',  'End of contract vacation', 2, (select id from "0".reference where code = '_VACANCY_TYPE' limit 1) );

INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('_VACANCY_RELIGION', '',  '_VACANCY_RELIGION', null,null );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_JUDAISM', '',  'Judaism', 1, (select id from "0".reference where code = '_VACANCY_RELIGION' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_CHRISTIANITY', '',  'Christianity', 2, (select id from "0".reference where code = '_VACANCY_RELIGION' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_ISLAM', '',  'Islam', 3, (select id from "0".reference where code = '_VACANCY_RELIGION' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('VACANCY_RELIGION_OTHER', '',  'Other', 4, (select id from "0".reference where code = '_VACANCY_RELIGION' limit 1) );
