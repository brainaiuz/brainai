
-- For Public

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'ACCOUNTING', 'Supplier Credit List', 18, false, (select id from permission where code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'ACCOUNTING', 'Supplier Credit Add', 1, false, (select id from permission where code='ACCOUNTING_SUPPLIER_CREDIT_LIST'), false, 'ACCOUNTING_MODULE');


-- For Zero Schema
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'ACCOUNTANT', 'ALLOW');


-- For All Schemas

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_CREDIT_ADD', 'ACCOUNTANT', 'ALLOW');


