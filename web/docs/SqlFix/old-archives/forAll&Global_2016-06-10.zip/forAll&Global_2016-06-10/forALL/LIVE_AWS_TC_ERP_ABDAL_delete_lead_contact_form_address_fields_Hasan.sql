----------- Only Private Schema---------------

DELETE FROM "anv".modelfield  where (select count(*) from "anv".modelfield where form_id='LEAD_FORM')<=6 and form_id='LEAD_FORM';
DELETE FROM "anv".modelfield  where (select count(*) from "anv".modelfield where form_id='CONTACT_FORM')<=6 and form_id='CONTACT_FORM';