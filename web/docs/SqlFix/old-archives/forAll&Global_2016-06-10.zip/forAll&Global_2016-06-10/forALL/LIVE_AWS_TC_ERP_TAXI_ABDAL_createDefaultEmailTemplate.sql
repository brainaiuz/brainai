INSERT INTO "anv".emailtemplate(deleted, fromuserid, fromusername, iscompanyemailtemplate, isdefault, messagehtml, name, subject, categoryid, module_id)
    VALUES (false, -1, 'Current User', 'COMPANY_EMAIL_TEMPLATE', true, 'Please be informed ${leftdays} left to &quot;${remindertype}&quot; of following employees:<br />
&nbsp;
<table border="1" cellpadding="1" cellspacing="1" height="2502" width="704">
	<tbody>
		<tr>
			<td style="width: 264px;"><span style="font-size:18px;">Employee:</span></td>
			<td style="width: 280px;"><span style="font-size:18px;">Department:</span></td>
			<td style="width: 140px;"><span style="font-size:18px;">Date:</span></td>
		</tr>
		<tr>
			<td style="width: 264px;">Avazbek Nuriddinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Contego Fraud Solutions Limited </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Zafar Sultonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Contego Fraud Solutions Limited</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Feruza Atabaeva</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Nazokat Tokhirova</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Oybek Bekmirzayev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Tohir Arifjanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Abror Abdukadirov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Murad Satimov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Otabek Kasimov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Surayyo Karimova</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Azizbek Bekturdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farhad Haydarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Timur Urmanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Internet Shop</td>
			<td style="width: 280px;"><span style="font-size:12px;">E-sales</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Damir Asamatdinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fozil Ergashev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shohin Tagaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Vasila Ismatullaeva</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javohir Fayzullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Stanislav Matsko</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Timur Mirzahmetov</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Valentina Sayapina</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Usmon Rakhimjanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Human Resources</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Asilbek Ashirov</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahtiyor Mirzarahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farhod Otaboev</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Haqberdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Khalmukhamedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Saidakhmedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziza Israilova</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahrom Abdullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bekzod Mirahmedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bunyod Xalilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilshod Madrahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilshodbek Tadjiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fahriddin Taslimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farruh Atabaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fatkhulla Nigmatjonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hasan Xo&#39;janazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hayot Rahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hurshid Djuraev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Ilhom Jumaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Ilhom Lutfullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Iskandar Ashurov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Lochin Shodiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Mardon Shonazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Munir Yamaletdinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Navruz Musulmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Normurod Buriyev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Olimkhon Eshonkhujaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Qahhor Abdijalilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Rahimjon Turdiyev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanatbek Egamberdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanjar Israilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Mamasharipov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Mahmudov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Usmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">To&#39;lqin Navro&#39;zov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Valeriya Tsoy</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aliakbar Navruzov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Andrey Kan</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Azam Mamatmurodov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahrom Turgunov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Behzod Shermatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bekhzod Tillakhonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bobur Hakimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Usmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farrukh Khamidov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Project Managers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javlon Shametov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Project Managers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Artem Pankratov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Sales </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilafruz Shamsiddinova</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Sales </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Anvar Musamukhamedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Artem Abdurakhmanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Axror Yodgorov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Jahongir Madaminov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Jakhongir Makhkamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javokhir Mamadiyarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Mirzohid Akbarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Murodjon Normatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Nugzar Gaguliya</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanjar Khalmurzaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sardor Asatillaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sarvar Fayzulaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shahobiddin Imamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Pirnafasov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Turdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Umid Axmedjonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Umidbek Karimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Zafar Nazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Muhiddin Hasanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">PhotoShop </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Inna Yakovleva</td>
			<td style="width: 280px;"><span style="font-size:12px;">RFP Connect </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shuhrat Pulatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">RFP Connect </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Abror Hasanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Sales/Marketing</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Doniyor Makhkamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Sales/Marketing</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Pavel Zinin</td>
			<td style="width: 283px;"><span style="font-size:12px;">Sysadmins </span></td>
			<td style="width: 137px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Yuri Reynsberg</td>
			<td style="width: 283px;"><span style="font-size:12px;">Sysadmins</span></td>
			<td style="width: 137px;">&nbsp;</td>
		</tr>
	</tbody>
</table>
&nbsp;

<div id="s3gt_translate_tooltip" is_mini="true" style="left: 297px; top: 1997px;">&nbsp;</div>
<link href="chrome://s3gt/skin/s3gt_tooltip.css" rel="stylesheet" type="text/css" />',
'Passport Expiry Date', 'Passport Expiry reminder',
(select r.id from "anv".reference r where (r.code) = '_HR_REMINDERS_CATEGORY' and r.deleted = false),
(select r.id from "anv".reference r where (r.code) = '_SYSTEM_REMINDERS_MODULE' and r.deleted = false));


INSERT INTO "anv".emailtemplate(deleted, fromuserid, fromusername, iscompanyemailtemplate, isdefault, messagehtml, name, subject, categoryid, module_id)
    VALUES (false, -1, 'Current User', 'COMPANY_EMAIL_TEMPLATE', true, 'Please be informed ${leftdays} left to &quot;${remindertype}&quot; of following employees:<br />
&nbsp;
<table border="1" cellpadding="1" cellspacing="1" height="2502" width="704">
	<tbody>
		<tr>
			<td style="width: 264px;"><span style="font-size:18px;">Employee:</span></td>
			<td style="width: 280px;"><span style="font-size:18px;">Department:</span></td>
			<td style="width: 140px;"><span style="font-size:18px;">Date:</span></td>
		</tr>
		<tr>
			<td style="width: 264px;">Avazbek Nuriddinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Contego Fraud Solutions Limited </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Zafar Sultonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Contego Fraud Solutions Limited</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Feruza Atabaeva</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Nazokat Tokhirova</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Oybek Bekmirzayev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Tohir Arifjanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Abror Abdukadirov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Murad Satimov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Otabek Kasimov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Surayyo Karimova</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Azizbek Bekturdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farhad Haydarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Timur Urmanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Internet Shop</td>
			<td style="width: 280px;"><span style="font-size:12px;">E-sales</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Damir Asamatdinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fozil Ergashev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shohin Tagaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Vasila Ismatullaeva</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javohir Fayzullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Stanislav Matsko</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Timur Mirzahmetov</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Valentina Sayapina</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Usmon Rakhimjanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Human Resources</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Asilbek Ashirov</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahtiyor Mirzarahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farhod Otaboev</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Haqberdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Khalmukhamedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Saidakhmedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziza Israilova</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahrom Abdullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bekzod Mirahmedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bunyod Xalilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilshod Madrahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilshodbek Tadjiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fahriddin Taslimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farruh Atabaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fatkhulla Nigmatjonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hasan Xo&#39;janazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hayot Rahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hurshid Djuraev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Ilhom Jumaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Ilhom Lutfullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Iskandar Ashurov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Lochin Shodiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Mardon Shonazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Munir Yamaletdinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Navruz Musulmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Normurod Buriyev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Olimkhon Eshonkhujaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Qahhor Abdijalilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Rahimjon Turdiyev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanatbek Egamberdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanjar Israilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Mamasharipov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Mahmudov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Usmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">To&#39;lqin Navro&#39;zov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Valeriya Tsoy</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aliakbar Navruzov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Andrey Kan</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Azam Mamatmurodov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahrom Turgunov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Behzod Shermatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bekhzod Tillakhonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bobur Hakimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Usmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farrukh Khamidov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Project Managers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javlon Shametov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Project Managers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Artem Pankratov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Sales </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilafruz Shamsiddinova</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Sales </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Anvar Musamukhamedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Artem Abdurakhmanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Axror Yodgorov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Jahongir Madaminov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Jakhongir Makhkamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javokhir Mamadiyarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Mirzohid Akbarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Murodjon Normatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Nugzar Gaguliya</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanjar Khalmurzaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sardor Asatillaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sarvar Fayzulaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shahobiddin Imamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Pirnafasov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Turdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Umid Axmedjonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Umidbek Karimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Zafar Nazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Muhiddin Hasanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">PhotoShop </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Inna Yakovleva</td>
			<td style="width: 280px;"><span style="font-size:12px;">RFP Connect </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shuhrat Pulatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">RFP Connect </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Abror Hasanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Sales/Marketing</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Doniyor Makhkamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Sales/Marketing</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Pavel Zinin</td>
			<td style="width: 283px;"><span style="font-size:12px;">Sysadmins </span></td>
			<td style="width: 137px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Yuri Reynsberg</td>
			<td style="width: 283px;"><span style="font-size:12px;">Sysadmins</span></td>
			<td style="width: 137px;">&nbsp;</td>
		</tr>
	</tbody>
</table>
&nbsp;

<div id="s3gt_translate_tooltip" is_mini="true" style="left: 297px; top: 1997px;">&nbsp;</div>
<link href="chrome://s3gt/skin/s3gt_tooltip.css" rel="stylesheet" type="text/css" />',
'Visa expiration date', 'Visa expiration reminder',
(select r.id from "anv".reference r where (r.code) = '_HR_REMINDERS_CATEGORY' and r.deleted = false),
(select r.id from "anv".reference r where (r.code) = '_SYSTEM_REMINDERS_MODULE' and r.deleted = false));


INSERT INTO "anv".emailtemplate(deleted, fromuserid, fromusername, iscompanyemailtemplate, isdefault, messagehtml, name, subject, categoryid, module_id)
    VALUES (false, -1, 'Current User', 'COMPANY_EMAIL_TEMPLATE', true, 'Please be informed ${leftdays} left to &quot;${remindertype}&quot; of following employees:<br />
&nbsp;
<table border="1" cellpadding="1" cellspacing="1" height="2502" width="704">
	<tbody>
		<tr>
			<td style="width: 264px;"><span style="font-size:18px;">Employee:</span></td>
			<td style="width: 280px;"><span style="font-size:18px;">Department:</span></td>
			<td style="width: 140px;"><span style="font-size:18px;">Date:</span></td>
		</tr>
		<tr>
			<td style="width: 264px;">Avazbek Nuriddinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Contego Fraud Solutions Limited </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Zafar Sultonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Contego Fraud Solutions Limited</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Feruza Atabaeva</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Nazokat Tokhirova</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Oybek Bekmirzayev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Tohir Arifjanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Data Entry</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Abror Abdukadirov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Murad Satimov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Otabek Kasimov</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Surayyo Karimova</td>
			<td style="width: 280px;">Dental</td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Azizbek Bekturdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farhad Haydarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Timur Urmanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Designers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Internet Shop</td>
			<td style="width: 280px;"><span style="font-size:12px;">E-sales</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Damir Asamatdinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fozil Ergashev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shohin Tagaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Vasila Ismatullaeva</td>
			<td style="width: 280px;"><span style="font-size:12px;">Finnet Technologies Pvt. Ltd.</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javohir Fayzullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Stanislav Matsko</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Timur Mirzahmetov</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Valentina Sayapina</td>
			<td style="width: 280px;"><span style="font-size:12px;">HTML Coders (Верстальщики)</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Usmon Rakhimjanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Human Resources</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Asilbek Ashirov</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahtiyor Mirzarahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farhod Otaboev</td>
			<td style="width: 280px;"><span style="font-size:12px;">&nbsp;IPD </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Haqberdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Khalmukhamedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziz Saidakhmedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aziza Israilova</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahrom Abdullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bekzod Mirahmedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bunyod Xalilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilshod Madrahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilshodbek Tadjiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fahriddin Taslimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farruh Atabaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Fatkhulla Nigmatjonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hasan Xo&#39;janazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hayot Rahimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Hurshid Djuraev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Ilhom Jumaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Ilhom Lutfullaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Iskandar Ashurov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Lochin Shodiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Mardon Shonazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Munir Yamaletdinov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Navruz Musulmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Normurod Buriyev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Olimkhon Eshonkhujaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Qahhor Abdijalilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Rahimjon Turdiyev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanatbek Egamberdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanjar Israilov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Mamasharipov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Mahmudov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Usmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">To&#39;lqin Navro&#39;zov</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Valeriya Tsoy</td>
			<td style="width: 280px;"><span style="font-size:12px;">KPI</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Aliakbar Navruzov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Andrey Kan</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Azam Mamatmurodov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bahrom Turgunov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Behzod Shermatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bekhzod Tillakhonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Bobur Hakimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherzod Usmonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Developers </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Farrukh Khamidov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Project Managers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javlon Shametov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Project Managers</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Artem Pankratov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Sales </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Dilafruz Shamsiddinova</td>
			<td style="width: 280px;"><span style="font-size:12px;">Local Sales </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Anvar Musamukhamedov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Artem Abdurakhmanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Axror Yodgorov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Jahongir Madaminov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Jakhongir Makhkamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Javokhir Mamadiyarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Mirzohid Akbarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Murodjon Normatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Nugzar Gaguliya</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sanjar Khalmurzaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sardor Asatillaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sarvar Fayzulaev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shahobiddin Imamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Pirnafasov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Sherali Turdiev</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Umid Axmedjonov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Umidbek Karimov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Zafar Nazarov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Mobile Team </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Muhiddin Hasanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">PhotoShop </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Inna Yakovleva</td>
			<td style="width: 280px;"><span style="font-size:12px;">RFP Connect </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Shuhrat Pulatov</td>
			<td style="width: 280px;"><span style="font-size:12px;">RFP Connect </span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Abror Hasanov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Sales/Marketing</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Doniyor Makhkamov</td>
			<td style="width: 280px;"><span style="font-size:12px;">Sales/Marketing</span></td>
			<td style="width: 140px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Pavel Zinin</td>
			<td style="width: 283px;"><span style="font-size:12px;">Sysadmins </span></td>
			<td style="width: 137px;">&nbsp;</td>
		</tr>
		<tr>
			<td style="width: 264px;">Yuri Reynsberg</td>
			<td style="width: 283px;"><span style="font-size:12px;">Sysadmins</span></td>
			<td style="width: 137px;">&nbsp;</td>
		</tr>
	</tbody>
</table>
&nbsp;

<div id="s3gt_translate_tooltip" is_mini="true" style="left: 297px; top: 1997px;">&nbsp;</div>
<link href="chrome://s3gt/skin/s3gt_tooltip.css" rel="stylesheet" type="text/css" />',
'Insurance expiry date', 'Insurance expiry reminder',
(select r.id from "anv".reference r where (r.code) = '_HR_REMINDERS_CATEGORY' and r.deleted = false),
(select r.id from "anv".reference r where (r.code) = '_SYSTEM_REMINDERS_MODULE' and r.deleted = false));

