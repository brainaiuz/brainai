insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'PM', 'f', 'Pdf/excel export', '26', (select id from permission where code='PM_PROJECT_LIST'), 'PM');
------*****------------
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'ADMIN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'DR', 'ALLOW');
------*****-----------
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'ADMIN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('PM_PROJECT_LIST_PDF_EXCEL_EXPORT', 'DR', 'ALLOW');