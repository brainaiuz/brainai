
delete from "0".reference where code='EXPENSE_CLOSED' and parentid=(select id from "0".reference where code='EXPENSE_STATUS' limit 1);


insert into "0".reference(code, name, issystemreference, sorder, parentid) values('EXPENSE_CLOSED', 'EXPENSE_CLOSED', true, 3, (select id from "0".reference where code='EXPENSE_STATUS' limit 1));
