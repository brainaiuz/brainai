
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
('HRMS_MANAGER_SELF_SERVICE_VIEW', 'HRMS', 'Manager Self Service View', '2', 'false',
    (select id from permission where code='HRMS_CURENT_EMPLOYEE_PROFILE_TAB'), 'false', 'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_MANAGER_SELF_SERVICE_VIEW', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_MANAGER_SELF_SERVICE_VIEW', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_MANAGER_SELF_SERVICE_VIEW', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_MANAGER_SELF_SERVICE_VIEW', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_MANAGER_SELF_SERVICE_VIEW', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_MANAGER_SELF_SERVICE_VIEW', 'HR', 'ALLOW');

UPDATE permission set sorder=3 where code='HRMS_EMPLOYEE_PROFILE_SUMMARY';
