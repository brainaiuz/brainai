
//Contract_Add_Edit_View_Permission_Faxriddin_Taslimov.sql dan kiyin urilsin

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_ADD_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_ADD_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_ADD_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_DELETE', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_CONVERT_TO_PROJECT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_CONVERT_TO_PROJECT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_CONTRACT_CONVERT_TO_PROJECT', 'ACCOUNTANT', 'ALLOW');

