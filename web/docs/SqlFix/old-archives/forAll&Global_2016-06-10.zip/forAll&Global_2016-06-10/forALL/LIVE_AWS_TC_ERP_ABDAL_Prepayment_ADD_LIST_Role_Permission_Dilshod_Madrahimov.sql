
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
   ('ACCOUNTING_PREPAYMENT_LIST', 'ACCOUNTING', 'Prepayment List', 17, false, (select id from permission where code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PREPAYMENT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PREPAYMENT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PREPAYMENT_LIST', 'ACCOUNTANT', 'ALLOW');

update permission set parent=(select id from permission where code='ACCOUNTING_PREPAYMENT_LIST'), sorder=1  where code='ACCOUNTING_PREPAYMENT_ADD';

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PREPAYMENT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PREPAYMENT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PREPAYMENT_LIST', 'ACCOUNTANT', 'ALLOW');


