/*to Public*/
INSERT INTO pdfreference (code, name, deleted) VALUES ('MEET_MINUTES','Meeting Minutes', false);