//BUNI URMANGLAR!!! FAQAT PROJECT/TASK NUMBER DISEBLE HOHLAGAN COMPANYLARGA URIB BEERILADI!!!

insert into "anv".genericSettings (key,value) values ('ENABLE_PROJECT_NUMBERING','NO');
insert into "anv".genericSettings (key,value) values ('ENABLE_TASK_NUMBERING','NO');
