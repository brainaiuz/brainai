//-- after this patch need Employee_Workflow_Dilshod_Faxriddin.sql sql pacht!!!
//-- posle etom patch need Employee_Workflow_Dilshod_Faxriddin.sql sql pacht!!!

delete from  modelfield where form_ID ='HRMS_EMPLOYEE_FORM';
delete from  model where formID ='HRMS_EMPLOYEE_FORM';

insert into model(active,formID, title,viewname) values(true,'HRMS_EMPLOYEE_FORM', 'HRMS Employee Form','Employee');


-- HRMS EMPLOYEE EDIT FORM
 -- drawEmployeeInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',     'FIRST_NAME',                     'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (05,     false,      false,  false,          '',           true ,           '',     'LAST_NAME',                      'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (10,     false,      false,  false,          '',           false ,          '',     'MIDDLE_NAME',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (15,     false,      false,  false,          '',           false,           '',     'BIRTH_DAY',                      'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      --(05,     false,      false,  false,          '',           false,           '',     'DRIVER_ID',                      'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),

		                  (20,     false,      false,  false,          '',           false,           '',     'GENDER',                         'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (25,     false,      false,  false,          '',           false,           '',     'NATIONALITY',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (30,     false,      false,  false,          '',           false,           '',     'MARTIAL_STATUS',                 'EMPLOYEE_INFORMATION',   'DropDown' ,   'HRMS_EMPLOYEE_FORM',''),
                      (35,     false,      false,  false,          '',           false,           '',     'LANGUAGE',                       'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM',''),
                      (40,     false,      false,  false,          '',           false,           '',     'PAYMENT_METHOD',                       'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'HRMS_EMPLOYEE_FORM','');

-- drawContactDetails

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (45,     false,      false,  false,          '',           true,            '',     'EMAIL',                         'CONTACT_INFORMATION',   'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM','viewForm'),
                      (50,     false,      false,  false,          '',           false ,          '',     'PHONE',                         'CONTACT_INFORMATION',   'MULTITABLE'  ,   'HRMS_EMPLOYEE_FORM','viewForm'),

					            (55,     false,      false,  false,          '',           false ,          '',     'IM_ADDRESS',                    'CONTACT_INFORMATION',   'MULTITABLE'  ,   'HRMS_EMPLOYEE_FORM','viewForm'),
                      (60,     false,      false,  false,          '',           false ,          '',     'WEB_ADDRESS',                   'CONTACT_INFORMATION',   'MULTITABLE'  ,   'HRMS_EMPLOYEE_FORM','viewForm');

--- drawAddressInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor,                        field_ID,    section,                 widget      ,form_ID,     noWrapperFor ) values
                      (65,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'ADDRESS',    'ADDRESS_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');

--drawEmploymentInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (70,     false,      false,  false,          '',           false,            '',     'EMPLOYEE_CODE',            'EMPLOYMENT_INFORMATION',   'NUMBER'  , 'HRMS_EMPLOYEE_FORM',''),
                      (75,     false,      false,  false,          '',           false,            '',     'DEPARTMENT',               'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (80,     false,      false,  false,          '',           false,            '',     'POSITION',                 'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
					            (85,     false,      false,  false,          '',           false,            '',     'APPLY_ALLOUNCE_ALL_EMPLOYEE','EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (90,     false,      false,  false,          '',           false,            '',     'LOCATION',           'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (95,     false,      false,  false,          '',           false,            '',     'SUPERVISOR',               'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (100,     false,      false,  false,          '',           false,            '',     'WAGE_RATE',                'EMPLOYMENT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (105,     false,      false,  false,          '',           false,            '',     'CLIENT_CHARGE_RATE',       'EMPLOYMENT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),

					            (110,     false,      false,  false,          '',           false,            '',     'HIRE_DATE',                'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (115,     false,      false,  false,          '',           false,            '',     'RESIGNATION_DATE',         'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (120,     false,      false,  false,          '',           false,            '',     'EMPLOYMENT_CONTACT_TERMS', 'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (125,     false,      false,  false,          '',           false,            '',     'EMPLOYMENT_MODE',          'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (130,     false,      false,  false,          '',           false,            '',     'SALARY_GRADE',             'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (135,     false,      false,  false,          '',           false,            '',     'JOB_TITLE',             'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (140,     false,      false,  false,          '',           false,            '',     'SALARY_AMOUNT',            'EMPLOYMENT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (145,     false,      false,  false,          '',           false,            '',     'QUALIFICATION',            'EMPLOYMENT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (150,     false,      false,  false,          '',           false,            '',     'COMPETENCIES',            'EMPLOYMENT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');

--bank information
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (155,     false,      false,  false,          '',           false,            '',     'BANK_NAME',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (160,     false,      false,  false,          '',           false,            '',     'ACCOUNT_NUMBER',           'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (165,     false,      false,  false,          '',           false,            '',     'ACCOUNT_NAME',             'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (170,     false,      false,  false,          '',           false,            '',     'BANK_ADDRESS',             'BANK_ACCOUNT_INFORMATION',   'TextArea'  , 'HRMS_EMPLOYEE_FORM',''),

					            (175,     false,      false,  false,          '',           false,            '',     'SWIFT_CODE',               'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (180,     false,      false,  false,          '',           false,            '',     'SORT_CODE',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (185,     false,      false,  false,          '',           false,            '',     'IBAN_CODE',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (190,     false,      false,  false,          '',           false,            '',     'AGENT_ID',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM','');


--- drawAccountInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (195,     false,      false,  false,          '',           false,            '',     'ACCOUNT_ROLES',             'ACCOUNT_INFORMATION',   'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM',''),
                      (200,     false,      false,  false,          '',           false,            '',     'ACCOUNT_STATUS',            'ACCOUNT_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (205,     false,      false,  false,          '',           false,            '',     'NO_ACCESS',                 'ACCOUNT_INFORMATION',   'Checkbox'  , 'HRMS_EMPLOYEE_FORM','');

---drawPersonalIdentityInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (210,     false,      false,  false,          '',           false,            '',     'PASSPORT_NUMBER',              'PERSONAL_IDENTITY_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (215,     false,      false,  false,          '',           false,            '',     'PASSPORT_ISSUE',              'PERSONAL_IDENTITY_INFORMATION',   'DropDown'  , 'HRMS_EMPLOYEE_FORM',''),
                      (220,     false,      false,  false,          '',           false,            '',     'PASSPORT_ISSUE_DATE',          'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (225,     false,      false,  false,          '',           false,            '',     'PASSPORT_EXPIRY_DATE',          'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (230,     false,      false,  false,          '',           false,            '',     'INSURANCE_NUMBER',             'PERSONAL_IDENTITY_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (235,     false,      false,  false,          '',           false,            '',     'INSURANCE_EXPIRY_DATE',         'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (240,     false,       false, false,          '',           false,            '',     'VISA_NUMBER',                  'PERSONAL_IDENTITY_INFORMATION',   'TextBox'  , 'HRMS_EMPLOYEE_FORM',''),
                      (245,     false,      false,  false,          '',           false,            '',     'VISA_ISSUE_DATE',              'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (250,     false,      false,  false,          '',           false,            '',     'VISA_EXPIRATION_DATE',         'PERSONAL_IDENTITY_INFORMATION',   'DatePicker'  , 'HRMS_EMPLOYEE_FORM',''),
                      (255,     false,      false,  false,          '',           false,            '',     'VISA_EXPIRATION_DATE_REMINDER','PERSONAL_IDENTITY_INFORMATION',   'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM','');

--- drawAttachments
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,   section,                 widget      ,form_ID,     noWrapperFor ) values
                      (260,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'ATTACHMENTS', 'ATTACHMENTS',           'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,                  section,                 widget      ,form_ID,     noWrapperFor ) values
                      (265,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'PUNISHMENT_PROMOTION', 'PUNISHMENT_PROMOTION',       'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,                  section,                 widget      ,form_ID,     noWrapperFor ) values
                      (270,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'INTERNAL_EMPLOYMENT', 'INTERNAL_EMPLOYMENT',       'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,                  section,                 widget      ,form_ID,     noWrapperFor ) values
                      (275,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'PAST_EMPLOYMENT', 'PAST_EMPLOYMENT',       'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,                  section,                 widget      ,form_ID,     noWrapperFor ) values
                      (280,     false,      true,  false,          '',           false,            'addForm,editForm,viewForm',     'YEAR_LEAVE_DURATION', 'YEAR_LEAVE_DURATION',       'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');


insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory,   noLabelFor,                        field_ID,                  section,                 widget      ,form_ID,     noWrapperFor ) values
                      (285,     false,      true,  false,          '',           false,            'addForm,editForm,viewForm',     'YEAR_LEAVE_HOUR_DURATION', 'YEAR_LEAVE_HOUR_DURATION',       'UNKNOWN'  , 'HRMS_EMPLOYEE_FORM','');


UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ATTACHMENTS';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PUNISHMENT_PROMOTION';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'INTERNAL_EMPLOYMENT';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PAST_EMPLOYMENT';
update modelfield set split=true where field_ID in ('INSURANCE_EXPIRY_DATE', 'EMPLOYMENT_CONTACT_TERMS') and form_ID='HRMS_EMPLOYEE_FORM';

UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='HRMS_EMPLOYEE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='HRMS_EMPLOYEE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='HRMS_EMPLOYEE_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='HRMS_EMPLOYEE_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='HRMS_EMPLOYEE_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='HRMS_EMPLOYEE_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='HRMS_EMPLOYEE_FORM';
update modelfield set halfsetstyle='halfSet-1 left' where form_id='HRMS_EMPLOYEE_FORM' and field_id='ADDRESS';

--------------------------------------------------------------------------------------------------------------------
delete from "anv".modelfield where form_ID ='HRMS_EMPLOYEE_FORM';
delete from "anv".model where formID ='HRMS_EMPLOYEE_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('HRMS_EMPLOYEE_FORM', 'Employee')) IS NOT NULL;
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ATTACHMENTS';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PUNISHMENT_PROMOTION';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'INTERNAL_EMPLOYMENT';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'PAST_EMPLOYMENT';
update "anv".modelfield set split=true where field_ID in ('INSURANCE_EXPIRY_DATE', 'EMPLOYMENT_CONTACT_TERMS') and form_ID='HRMS_EMPLOYEE_FORM';
update "anv".modelfield set halfsetstyle='halfSet-1 left' where form_id='HRMS_EMPLOYEE_FORM' and field_id='ADDRESS';


---ATTENTION!!!  Alfursanda lastname mandatory emas shuni hisobga olish kerak!!!
update "200138".modelfield set mandatory=false, systemmandatory=false where form_id='HRMS_EMPLOYEE_FORM' and field_ID='LAST_NAME';

