//!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Этот патч только для AWS

update modelfield set sorder=(select sorder from modelfield where field_id='LAST_NAME' and form_id='CONTACT_FORM')+1 where form_id='CONTACT_FORM' and field_id='IMAGE_UPLOAD';
update modelfield set sorder=(select sorder from modelfield where field_id='LAST_NAME' and form_id='LEAD_FORM')+1 where form_id='LEAD_FORM' and field_id='IMAGE_UPLOAD';

update "0".modelfield set sorder=(select sorder from "0".modelfield where field_id='LAST_NAME' and form_id='CONTACT_FORM')+1 where form_id='CONTACT_FORM' and field_id='IMAGE_UPLOAD';
update "0".modelfield set sorder=(select sorder from "0".modelfield where field_id='LAST_NAME' and form_id='LEAD_FORM')+1 where form_id='LEAD_FORM' and field_id='IMAGE_UPLOAD';

update "anv".modelfield set sorder=(select sorder from "anv".modelfield where field_id='LAST_NAME' and form_id='CONTACT_FORM')+1 where form_id='CONTACT_FORM' and field_id='IMAGE_UPLOAD';
update "anv".modelfield set sorder=(select sorder from "anv".modelfield where field_id='LAST_NAME' and form_id='LEAD_FORM')+1 where form_id='LEAD_FORM' and field_id='IMAGE_UPLOAD';
