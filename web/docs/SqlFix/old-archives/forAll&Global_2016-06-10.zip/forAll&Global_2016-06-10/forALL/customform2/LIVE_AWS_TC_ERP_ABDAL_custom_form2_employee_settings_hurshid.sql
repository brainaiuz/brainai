delete from  modelfield where form_ID ='SETTINGS_EMPLOYEE_FORM';
delete from  model where formID ='SETTINGS_EMPLOYEE_FORM';


insert into model(active,formID, title,viewname) values(true,'SETTINGS_EMPLOYEE_FORM', 'Setting Employee Form','Employee');


-- SETTINGS EMPLOYEE EDIT FORM
 -- drawEmployeeInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (01,     false,      false,  false,          '',           true,            '',     'FIRST_NAME',                     'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'SETTINGS_EMPLOYEE_FORM',''),
                      (02,     false,      false,  false,          '',           true ,           '',     'LAST_NAME',                      'EMPLOYEE_INFORMATION',   'TextBox'  ,   'SETTINGS_EMPLOYEE_FORM',''),
                      (03,     false,      false,  false,          '',           false ,          '',     'MIDDLE_NAME',                    'EMPLOYEE_INFORMATION',   'TextBox'  ,   'SETTINGS_EMPLOYEE_FORM',''),
                      (04,     false,      false,  false,          '',           false,           '',     'BIRTH_DAY',                      'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'SETTINGS_EMPLOYEE_FORM',''),
                      (05,     false,      false,  false,          '',           false,           '',     'GENDER',                         'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'SETTINGS_EMPLOYEE_FORM',''),
                      (06,     false,      false,  false,          '',           false,           '',     'MARTIAL_STATUS',                 'EMPLOYEE_INFORMATION',   'DropDown' ,   'SETTINGS_EMPLOYEE_FORM',''),
                      (07,     false,      false,  false,          '',           false,           '',     'LANGUAGE',                       'EMPLOYEE_INFORMATION',   'UNKNOWN'  ,   'SETTINGS_EMPLOYEE_FORM','');

-- drawContactDetails

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (08,     false,      false,  false,          '',           true,            '',     'EMAIL',                         'CONTACT_INFORMATION',   'MULTITABLE'  , 'SETTINGS_EMPLOYEE_FORM','viewForm'),
                      (09,     false,      false,  false,          '',           false ,          '',     'PHONE',                         'CONTACT_INFORMATION',   'MULTITABLE'  ,   'SETTINGS_EMPLOYEE_FORM','viewForm'),
                      (10,     false,      false,  false,          '',           false ,          '',     'IM_ADDRESS',                    'CONTACT_INFORMATION',   'MULTITABLE'  ,   'SETTINGS_EMPLOYEE_FORM','viewForm'),
                      (11,     false,      false,  false,          '',           false ,          '',     'WEB_ADDRESS',                   'CONTACT_INFORMATION',   'MULTITABLE'  ,   'SETTINGS_EMPLOYEE_FORM','viewForm');



---- drawAddressInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (12,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'ADDRESS',            'ADDRESS_INFORMATION',   'UNKNOWN'  , 'SETTINGS_EMPLOYEE_FORM','');

--- drawBankInformation
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (13,     false,      false,  false,          '',           false,            '',     'BANK_NAME',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'SETTINGS_EMPLOYEE_FORM',''),
                      (14,     false,      false,  false,          '',           false,            '',     'ACCOUNT_NUMBER',           'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'SETTINGS_EMPLOYEE_FORM',''),
                      (15,     false,      false,  false,          '',           false,            '',     'ACCOUNT_NAME',             'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'SETTINGS_EMPLOYEE_FORM',''),
                      (16,     false,      false,  false,          '',           false,            '',     'BANK_ADDRESS',             'BANK_ACCOUNT_INFORMATION',   'TextArea'  , 'SETTINGS_EMPLOYEE_FORM',''),
                      (17,     false,      false,  false,          '',           false,            '',     'SWIFT_CODE',               'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'SETTINGS_EMPLOYEE_FORM',''),
                      (18,     false,      false,  false,          '',           false,            '',     'SORT_CODE',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'SETTINGS_EMPLOYEE_FORM',''),
                      (19,     false,      false,  false,          '',           false,            '',     'IBAN_CODE',                'BANK_ACCOUNT_INFORMATION',   'TextBox'  , 'SETTINGS_EMPLOYEE_FORM','');

--- drawAttachments
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (20,     false,      false,  false,          '',           false,            'addForm,editForm,viewForm',     'ATTACHMENTS',            'ATTACHMENTS',   'UNKNOWN'  , 'SETTINGS_EMPLOYEE_FORM','');


UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'SETTINGS_EMPLOYEE_FORM' AND field_id = 'ATTACHMENTS';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='SETTINGS_EMPLOYEE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='SETTINGS_EMPLOYEE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='SETTINGS_EMPLOYEE_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='SETTINGS_EMPLOYEE_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='SETTINGS_EMPLOYEE_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='SETTINGS_EMPLOYEE_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='SETTINGS_EMPLOYEE_FORM';
update modelfield set halfsetstyle='halfSet-1 left' where form_id='SETTINGS_EMPLOYEE_FORM' and field_id='ADDRESS';


delete from "anv".modelfield where form_ID ='SETTINGS_EMPLOYEE_FORM';
delete from  "anv".model where formID ='SETTINGS_EMPLOYEE_FORM';

