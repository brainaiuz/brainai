delete from "model"where formid = 'BENEFIT_FORM';
delete from "modelfield"where form_id = 'BENEFIT_FORM';

insert into model(formID, active, title) values('BENEFIT_FORM', true, 'Benefit');
insert into modelfield(form_ID,field_ID,sorder, mandatory,fullWidth, isCustomField,section,defaultValue, widget , systemmandatory, split, noLabelFor) values
  ('BENEFIT_FORM', 'NAME',1,true,false,false, 'INFORMATION', '','TextBox' ,false,false, ''),
  ('BENEFIT_FORM', 'DESCRIPION',2,false,false,true, 'INFORMATION', '','TextArea',false ,false ,''),
  ('BENEFIT_FORM', 'TYPE',3,true,false,false, 'INFORMATION', '','DropDown',false ,false, ''),
  ('BENEFIT_FORM', 'QTY_TYPE',4,true,false,false, 'INFORMATION', '','DropDown',false ,false, ''),
  ('BENEFIT_FORM', 'CURRENCY',5,false,false,false, 'INFORMATION', '','DropDown',false ,false, ''),
  ('BENEFIT_FORM', 'LEAVE_ALLOUNCE_PANEL',6,false,false,false, 'INFORMATION', '','CheckBox',false ,false, ''),
  ('BENEFIT_FORM', 'TRANSFERRABLE',7,false,false,false, 'INFORMATION', '','Unknown',false ,false ,''),
--   ('BENEFIT_FORM', 'QTY_RESTRICTION',8,false,false,false, 'INFORMATION', '','Unknown' ,false ,false , ''),
  ('BENEFIT_FORM', 'EXPIRE_DATE',9,false,false,false, 'INFORMATION', '','DatePicker',false ,false ,''),
--   ('BENEFIT_FORM', 'BY_EMPLOYEES',9,false,false,true, 'INFORMATION', '','Unknown',false ,false ,''),
  ('BENEFIT_FORM', 'DEBIT_TO_ACCOUNT',10,false,false,true, 'INFORMATION', '','LOOKUP',false ,false ,''),
  ('BENEFIT_FORM', 'CREDIT_TO_ACCOUNT',11,false,false,true, 'INFORMATION', '','LOOKUP',false ,false ,''),
  ('BENEFIT_FORM', 'STATUS',12,false,false,true, 'INFORMATION', '','CheckBox',false ,false ,'');


UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='BENEFIT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='BENEFIT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='BENEFIT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='BENEFIT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='BENEFIT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='BENEFIT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='BENEFIT_FORM';