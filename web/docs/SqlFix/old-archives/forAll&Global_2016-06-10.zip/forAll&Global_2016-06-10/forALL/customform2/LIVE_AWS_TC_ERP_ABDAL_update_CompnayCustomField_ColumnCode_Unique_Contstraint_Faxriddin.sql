DROP INDEX if exists "anv".customfield_column_unique_idx;
CREATE UNIQUE INDEX customfield_column_unique_idx
  ON "anv".companycustomfieldssettings
  USING btree
  (columncode, entityname)
  WHERE (relationship IS NULL and entityCategoryName IS NULL);