//!!!!!!!!!!!!!!!!!!!!!!!!
//Этот патч только для LIVE, вместо старых. не для AWS

INSERT INTO modelfield(
            field_id, form_id,
            hide, iscustomfield, labelless, mandatory, section, sorder, 
            systemmandatory, widget,isentityfield, 
            usablebyworkflow, type, fullwidth, place, split, fieldsetstyle, 
            fieldstyle, halfsetstyle, rowstyle, sectionstyle)
    VALUES ('IMAGE_UPLOAD', 'CONTACT_FORM', false,
            false, false, false, 'CONTACT_INFORMATION', (select sorder from modelfield where field_id='LAST_NAME' and form_id='CONTACT_FORM')+1, false,
            'UNKNOWN', false,false, 
            'text', false, 0, false, 'slideDown-content group labelLine', 'field', 
            'halfSet-1 left', 'row hideCustomField', 'slideDown-box group expand hideCustomField');


    INSERT INTO "anv".modelfield(
            field_id, form_id,
            hide, iscustomfield, labelless, mandatory, section, sorder,
            systemmandatory, widget,isentityfield,
            usablebyworkflow, type, fullwidth, place, split, fieldsetstyle,
            fieldstyle, halfsetstyle, rowstyle, sectionstyle)
    VALUES ('IMAGE_UPLOAD', 'CONTACT_FORM', false,
            false, false, false, 'CONTACT_INFORMATION', (select sorder from "anv".modelfield where field_id='LAST_NAME' and form_id='CONTACT_FORM')+1, false,
            'UNKNOWN', false,false,
            'text', false, 0, false, 'slideDown-content group labelLine', 'field',
            'halfSet-1 left', 'row hideCustomField', 'slideDown-box group expand hideCustomField');


    INSERT INTO "0".modelfield(
            field_id, form_id,
            hide, iscustomfield, labelless, mandatory, section, sorder,
            systemmandatory, widget,isentityfield,
            usablebyworkflow, type, fullwidth, place, split, fieldsetstyle,
            fieldstyle, halfsetstyle, rowstyle, sectionstyle)
    VALUES ('IMAGE_UPLOAD', 'CONTACT_FORM', false,
            false, false, false, 'CONTACT_INFORMATION', (select sorder from "0".modelfield where field_id='LAST_NAME' and form_id='CONTACT_FORM')+1, false,
            'UNKNOWN', false,false,
            'text', false, 0, false, 'slideDown-content group labelLine', 'field',
            'halfSet-1 left', 'row hideCustomField', 'slideDown-box group expand hideCustomField');


INSERT INTO modelfield(
            field_id, form_id,
            hide, iscustomfield, mandatory, section, sorder,
            systemmandatory, widget,isentityfield,
            usablebyworkflow, type, fullwidth, place, split, fieldsetstyle,
            fieldstyle, halfsetstyle, rowstyle, sectionstyle)
    VALUES ('IMAGE_UPLOAD', 'LEAD_FORM', false,
            false, false, 'LEAD_INFORMATION', (select sorder from modelfield where field_id='LAST_NAME' and form_id='LEAD_FORM')+1, false,
            'UNKNOWN', false,false,
            'text', false, 0, false, 'slideDown-content group labelLine', 'field',
            'halfSet-1 left', 'row hideCustomField', 'slideDown-box group expand hideCustomField');


INSERT INTO "0".modelfield(
            field_id, form_id,
            hide, iscustomfield, mandatory, section, sorder,
            systemmandatory, widget,isentityfield,
            usablebyworkflow, type, fullwidth, place, split, fieldsetstyle,
            fieldstyle, halfsetstyle, rowstyle, sectionstyle)
    VALUES ('IMAGE_UPLOAD', 'LEAD_FORM', false,
            false, false, 'LEAD_INFORMATION', (select sorder from "0".modelfield where field_id='LAST_NAME' and form_id='LEAD_FORM')+1, false,
            'UNKNOWN', false,false,
            'text', false, 0, false, 'slideDown-content group labelLine', 'field',
            'halfSet-1 left', 'row hideCustomField', 'slideDown-box group expand hideCustomField');



INSERT INTO "anv".modelfield(
            field_id, form_id,
            hide, iscustomfield, mandatory, section, sorder,
            systemmandatory, widget,isentityfield,
            usablebyworkflow, type, fullwidth, place, split, fieldsetstyle,
            fieldstyle, halfsetstyle, rowstyle, sectionstyle)
    VALUES ('IMAGE_UPLOAD', 'LEAD_FORM', false,
            false, false, 'LEAD_INFORMATION', (select sorder from "anv".modelfield where field_id='LAST_NAME' and form_id='LEAD_FORM')+1, false,
            'UNKNOWN', false,false,
            'text', false, 0, false, 'slideDown-content group labelLine', 'field',
            'halfSet-1 left', 'row hideCustomField', 'slideDown-box group expand hideCustomField');
