delete from "model"  where formid = 'IMPORT_MANUAL_TRANSACTION_FORM';
delete from "modelfield"  where form_id = 'IMPORT_MANUAL_TRANSACTION_FORM';

delete from "anv"."model"  where formid = 'IMPORT_MANUAL_TRANSACTION_FORM';
delete from "anv"."modelfield"  where form_id = 'IMPORT_MANUAL_TRANSACTION_FORM';


insert into model(formID, active, title) values('IMPORT_MANUAL_TRANSACTION_FORM', true, 'Import Manual Transaction');
insert into modelfield(form_ID,         field_ID,                           sorder, mandatory,  fullWidth,   isCustomField,                section,  defaultValue,   widget , systemmandatory, split,   noLabelFor) values
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'HAS_CSV_HEADER',                 1,      false,      false,  false,          'REQUIRED_INFORMATIONS', '',           'CheckBox'  ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'NUMBER',                  2,      false,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown'   ,false             ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'DATE',                  3,      true,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown'  ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'NARRATION',           4,      true,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown'  ,false            ,true,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'REFERENCE',           5,      false,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown'  ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'ACCOUNT_CODE',             6,      true,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown',false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'DEBIT',               7,      true,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown',false            ,false ,      ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'CREDIT',                8,      true,      false,  false,          'REQUIRED_INFORMATIONS', '',           'DropDown'   ,false            ,false ,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'DESCRIPTION',              9,      false,      false,  false,          'OPTIONAL_INFORMATIONS', '',           'DropDown'   ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'DEPARTMENT',   10,      false,     false,  false,          'OPTIONAL_INFORMATIONS', '',           'DropDown'  ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'NAME',       11,     false,      false,  false,          'OPTIONAL_INFORMATIONS', '',           'DropDown'   ,false            ,true,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'PROJECT_CODE',      12,     false,      false,  false,          'OPTIONAL_INFORMATIONS', '',           'DropDown'   ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'EXCHANGE_RATE',              13,     false,      false,  false,          'OPTIONAL_INFORMATIONS', '',           'DropDown'   ,false            ,false,     ''),
                      ('IMPORT_MANUAL_TRANSACTION_FORM', 'CURRENCY',               14,     false,     false,  false,          'OPTIONAL_INFORMATIONS', '',           'DropDown'   ,false            ,false,     '');



UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM';
