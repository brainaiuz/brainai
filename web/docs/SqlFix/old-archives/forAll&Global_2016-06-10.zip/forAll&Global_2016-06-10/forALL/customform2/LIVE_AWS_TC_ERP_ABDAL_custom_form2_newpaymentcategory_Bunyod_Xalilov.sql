DELETE FROM "model"  WHERE formid = 'NEW_PAYMENT_CATEGORY' OR formid = 'NEW_DEDUCTION_CATEGORY';
DELETE FROM "modelfield"  WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';

insert into model(active, formID, title, viewname) values(true, 'NEW_PAYMENT_CATEGORY', 'Add New Payment Category', 'addpaymentcategory');
insert into modelfield(form_ID,                           field_ID,                               sorder, mandatory,   hide,   isCustomField,        section,           defaultValue, widget, systemmandatory,            nolabelfor,                   nowrapperfor,           fullWidth, split) values
                      ('NEW_PAYMENT_CATEGORY', 'CODE',                                    01,      false,   false,       false,   'PAYMENT CATEGORY',             '',    'TextBox',    false,                      '',                            '',                   false,   false),
                      ('NEW_PAYMENT_CATEGORY', 'NAME',                                    02,      false,   false,       false,   'PAYMENT CATEGORY',             '',    'TextBox',    false,                      '',                            '',                   false,   false),
                      ('NEW_PAYMENT_CATEGORY', 'DEBIT_TO_ACCOUNT',                        03,      false,   false,       false,   'PAYMENT CATEGORY',             '',    'LOOKUP',     false,                      '',                            '',                   false,   false),
                      ('NEW_PAYMENT_CATEGORY', 'CREDIT_TO_ACCOUNT',                       04,      false,   false,       false,   'PAYMENT CATEGORY',             '',    'LOOKUP',     false,                      '',                            '',                   false,   false);

insert into model(active, formID, title, viewname) values(true, 'NEW_DEDUCTION_CATEGORY', 'Add New Deduction Category', 'adddeductioncategory');
insert into modelfield(form_ID,                           field_ID,                               sorder, mandatory,   hide,   isCustomField,        section,           defaultValue, widget, systemmandatory,            nolabelfor,                   nowrapperfor,           fullWidth, split) values
                      ('NEW_DEDUCTION_CATEGORY', 'CODE',                                    01,      false,   false,       false,   'DEDUCTION CATEGORY',             '',    'TextBox',    false,                      '',                            '',                   false,   false),
                      ('NEW_DEDUCTION_CATEGORY', 'NAME',                                    02,      false,   false,       false,   'DEDUCTION CATEGORY',             '',    'TextBox',    false,                      '',                            '',                   false,   false),
                      ('NEW_DEDUCTION_CATEGORY', 'DEBIT_TO_ACCOUNT',                        03,      false,   false,       false,   'DEDUCTION CATEGORY',             '',    'LOOKUP',     false,                      '',                            '',                   false,   false),
                      ('NEW_DEDUCTION_CATEGORY', 'CREDIT_TO_ACCOUNT',                       04,      false,   false,       false,   'DEDUCTION CATEGORY',             '',    'LOOKUP',     false,                      '',                            '',                   false,   false),
                      ('NEW_DEDUCTION_CATEGORY', 'IS_CASH_ADVANCE',                         05,      false,   false,       false,   'DEDUCTION CATEGORY',             '',    'UNKNOWN',     false,                      '',                            '',                   false,   false);

UPDATE modelfield set sectionStyle  = 'slideDown-box  group expand hideCustomField' WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND (form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY');
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND (form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY');
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';

DELETE FROM "anv"."model"  WHERE formid = 'NEW_PAYMENT_CATEGORY' OR formid = 'NEW_DEDUCTION_CATEGORY';
DELETE FROM "anv"."modelfield"  WHERE form_id = 'NEW_PAYMENT_CATEGORY' OR form_id = 'NEW_DEDUCTION_CATEGORY';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('NEW_PAYMENT_CATEGORY', 'addpaymentcategory')) IS NOT NULL;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('NEW_DEDUCTION_CATEGORY', 'adddeductioncategory')) IS NOT NULL;
