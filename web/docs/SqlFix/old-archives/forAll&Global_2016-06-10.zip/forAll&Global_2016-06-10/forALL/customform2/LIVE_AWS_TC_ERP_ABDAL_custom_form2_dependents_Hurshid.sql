delete from "model"  where formid = 'DEPENDENT_FORM';
delete from "modelfield"  where form_id = 'DEPENDENT_FORM';

insert into model(formID, active, title, viewname) values('DEPENDENT_FORM', true, 'Dependent Form', 'Dependent');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, labelless, field_ID,         section,                 widget      ,form_ID,               noLabelFor) values
                      (01,     true,      false,  false,          null,           true,           false,'FIRST_NAME',       'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (02,     false,      false,  false,          null,           false,           false,'MIDDLE_NAME',      'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (03,     true,      false,  false,          null,           true ,           false,'LAST_NAME',        'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (04,     true,      false,  false,          null,           true ,           false,'RELATIONSHIP',     'DETAILS',   'DropDown'  ,  'DEPENDENT_FORM',  ''),
                      (05,     false,      false,  false,          null,           false,           false,'ADDRESS',          'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (06,     false,      false,  false,          null,           false,           false,'ADDRESS_2',        'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (07,     false,      false,  false,          null,           false,           false,'CITY',             'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (08,     false,      false,  false,          null,           false,           false,'TOWN',             'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (09,     false,      false,  false,          null,           false,           false,'COUNTRY',          'DETAILS',   'DropDown'  ,  'DEPENDENT_FORM',  ''),
                      (10,     false,      false,  false,          null,           false,           false,'PHONE',            'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (11,     false,      false,  false,          null,           false,           false,'PHONE_2',          'DETAILS',   'TextBox'  ,   'DEPENDENT_FORM',  ''),
                      (12,     false,      false,  false,          null,           false,           true ,'ATTACHMENTS',      'ATTACHMENTS','UNKNOWN'  ,  'DEPENDENT_FORM',  'addForm,editForm,viewForm');


UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'DEPENDENT_FORM' AND field_id = 'ATTACHMENTS';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='DEPENDENT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='DEPENDENT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='DEPENDENT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='DEPENDENT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='DEPENDENT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='DEPENDENT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='DEPENDENT_FORM';
update modelfield mf set fieldSetStyle='slideDown-content group nobrd', halfSetStyle='', section=label where widget='FileUploadWidget' and form_id='DEPENDENT_FORM';

delete from "anv"."model"  where formid = 'DEPENDENT_FORM';
delete from "anv"."modelfield"  where form_id = 'DEPENDENT_FORM';

update company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('DEPENDENT_FORM', 'Dependent')) is not null;

UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'DEPENDENT_FORM' AND field_id = 'ATTACHMENTS';
update "anv".modelfield mf set fieldSetStyle='slideDown-content group nobrd', halfSetStyle='halfSet-1', section='<div class="gwt-HTML">'||replace(replace(label,'<div class="gwt-HTML">',''),'</div>','')||'</div>' where widget='FileUploadWidget' and form_id='DEPENDENT_FORM';
