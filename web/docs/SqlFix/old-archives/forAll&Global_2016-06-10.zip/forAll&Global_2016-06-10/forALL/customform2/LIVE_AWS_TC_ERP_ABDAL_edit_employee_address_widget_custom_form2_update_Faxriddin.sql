
update modelfield set halfsetstyle='halfSet-1 left' where form_id='HRMS_EMPLOYEE_FORM' and field_id='ADDRESS';

update "anv".modelfield set halfsetstyle='halfSet-1 left' where form_id='HRMS_EMPLOYEE_FORM' and field_id='ADDRESS';