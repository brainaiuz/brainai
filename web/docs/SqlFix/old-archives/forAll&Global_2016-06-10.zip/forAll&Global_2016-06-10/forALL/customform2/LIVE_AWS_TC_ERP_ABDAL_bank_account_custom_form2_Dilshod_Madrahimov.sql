delete from "model"  where formid = 'BANK_ACCOUNT_FORM';
delete from "modelfield"  where form_id = 'BANK_ACCOUNT_FORM';

delete from "anv"."model"  where formid = 'BANK_ACCOUNT_FORM';
delete from "anv"."modelfield"  where form_id = 'BANK_ACCOUNT_FORM';


insert into model(formID, active, title) values('BANK_ACCOUNT_FORM', true, 'Bank Account Form');
insert into modelfield(form_ID,              field_ID,            sorder, mandatory,  fullWidth,   isCustomField,                section,  defaultValue,   widget , systemmandatory,    split,   noLabelFor, helpmessage) values
                      ('BANK_ACCOUNT_FORM', 'BANK_NAME',          1,      true,       false,        false,          'ACCOUNT_INFORMATION', '',             'TextBox'   ,true            ,false,     '',      'The Bank name as you would like to appear(limited to 30 characters)'),
                      ('BANK_ACCOUNT_FORM', 'ACCOUNT_NUMBER',     2,      true,       false,        false,          'ACCOUNT_INFORMATION', '',             'TextBox'   ,true            ,false,     '',      'Numbers, dashes and spaces are ok'),
                      ('BANK_ACCOUNT_FORM', 'ACCOUNT_CODE',       3,      true,       false,       false,          'ACCOUNT_INFORMATION', '',              'TextBox'   ,false            ,false,     '',     'An unique code/number for this account (limited to 20 characters)'),
                      ('BANK_ACCOUNT_FORM', 'ACCOUNT_NAME',       4,      false,      false,      false,          'ACCOUNT_INFORMATION', '',               'TextBox'   ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'BANK_BRANCH',        5,      false,      false,       false,          'ACCOUNT_INFORMATION', '',              'TextBox'   ,false            ,false,     '','');

insert into modelfield(form_ID,              field_ID,            sorder, mandatory,  fullWidth,   isCustomField,                section,  defaultValue,   widget , systemmandatory, split,   noLabelFor,helpmessage) values
                      ('BANK_ACCOUNT_FORM', 'STREET_ADDRESS',      6,      false,       false,      false,          'ADDRESS_INFORMATION', '',           'TextBox'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'CITY',                7,      false,       false,      false,          'ADDRESS_INFORMATION', '',           'TextBox'   ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'COUNTRY',             8,      false,       false,      false,          'ADDRESS_INFORMATION', '',           'DropDown'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'STATE',               9,      false,       false,      false,          'ADDRESS_INFORMATION', '',           'TextBox'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'POST_CODE',           10,     false,       false,      false,          'ADDRESS_INFORMATION', '',           'TextBox'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'PHONE_NUMBER',        11,     false,       false,      false,          'ADDRESS_INFORMATION', '',           'TextBox'  ,false            ,false,     '','');

insert into modelfield(form_ID,              field_ID,             sorder, mandatory,  fullWidth,   isCustomField,    section,  defaultValue,   widget , systemmandatory, split,   noLabelFor, helpmessage) values
                      ('BANK_ACCOUNT_FORM', 'SWIFT_CODE',           12,      false,      false,      false,          'CODES', '',            'TextBox'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'SORT_CODE',            13,      false,      false,      false,          'CODES', '',            'TextBox'   ,false             ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'IBAN_CODE',            14,      false,       false,      false,          'CODES', '',           'TextBox'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'ABA_CODE',             15,      false,       false,      false,          'CODES', '',           'TextBox'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'AGENT_ID',             16,      false,      false,      false,          'CODES', '',            'TextBox'  ,false            ,false,     '','Upto 9 Characters');

insert into modelfield(form_ID,              field_ID,              sorder, mandatory,  fullWidth,   isCustomField,                section,       defaultValue,   widget , systemmandatory, split,   noLabelFor, helpmessage) values
                      ('BANK_ACCOUNT_FORM', 'CURRENCY',              17,      false,      false,     false,              'FINANCIAL_INFORMATION', '',           'UNKNOWN'  ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'OPENING_BALANCE_DATE',  18,      false,      false,     false,              'FINANCIAL_INFORMATION', '',           'DatePicker'   ,false            ,false,     '',''),
                      ('BANK_ACCOUNT_FORM', 'AMOUNT_TABLE',          19,      false,      false,     false,              'FINANCIAL_INFORMATION', '',           'UNKNOWN'   ,false            ,false,     '','');

insert into modelfield(form_ID,              field_ID,             sorder, mandatory,  fullWidth,     labelless,      section,       defaultValue,   widget , systemmandatory, split,   noLabelFor,                 helpmessage) values
                      ('BANK_ACCOUNT_FORM',  'ATTACHMENTS',           20,      false,      false,      true ,    'ATTACHMENTS',         '',         'UNKNOWN',   false         ,false,  'addForm,editForm,viewForm','');




UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='BANK_ACCOUNT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='BANK_ACCOUNT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='BANK_ACCOUNT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='BANK_ACCOUNT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='BANK_ACCOUNT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='BANK_ACCOUNT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='BANK_ACCOUNT_FORM';
UPDATE company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('BANK_ACCOUNT_FORM', 'BankAccounts')) is not null;
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'BANK_ACCOUNT_FORM' AND field_id = 'ATTACHMENTS';