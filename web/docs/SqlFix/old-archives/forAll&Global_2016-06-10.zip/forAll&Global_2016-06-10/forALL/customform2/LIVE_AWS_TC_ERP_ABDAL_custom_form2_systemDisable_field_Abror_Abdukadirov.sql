--need to after the upgrade scheme and after that AWS_custom_form2_account_add_terms_field_Abror_Abdukadirov

UPDATE modelfield set systemdisable = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'ADDRESS';

UPDATE modelfield set systemdisable = true WHERE form_id = 'LEAD_FORM' AND field_id = 'ADDRESS';


UPDATE "anv".modelfield set systemdisable = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'ADDRESS';

UPDATE "anv".modelfield set systemdisable = true WHERE form_id = 'LEAD_FORM' AND field_id = 'ADDRESS';