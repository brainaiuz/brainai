DELETE FROM "model"  WHERE formid = 'ONBOARDING_STEP_FORM';
DELETE FROM "modelfield"  WHERE form_id = 'ONBOARDING_STEP_FORM';

insert into model(active, formID, title, viewname) values(true, 'ONBOARDING_STEP_FORM', 'Onboarding Step Form', 'OnboardingStep');
insert into modelfield(form_ID,                field_ID,                                    sorder, mandatory,   hide,      isCustomField,        section,                        defaultValue, widget,         systemmandatory,  nolabelfor,    nowrapperfor, fullWidth, split) values
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_ACTIVITY_NAME',             1,      false,       false,     false,                'ONBOARDING_STEP_TITLE',        '',           'TextBox',      true,            '',             '',           false,   false),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_ACTIVITY_DESCRIPTION',      2,      false,       false,     false,                'ONBOARDING_STEP_TITLE',        '',           'TextArea',     false,           '',             '',           false,   true),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_ACTIVITY_PERIOD',           3,      false,       false,     false,                'ONBOARDING_STEP_TITLE',        '',           'DropDown',     false,           '',             '',           false,   false),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_PARENT_STEPS',              4,      false,       false,     false,                'ONBOARDING_STEP_TITLE',        '',           'DropDown',     false,           '',             '',           false,   false),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_SHOW_IN_EMPLOYEE_PROFILE',  5,      false,       false,     false,                'ONBOARDING_STEP_TITLE',        '',           'CheckBox',     false,           '',             '',           false,   false),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_CREATE_FORM',               6,      false,       false,     false,                'ONBOARDING_STEP_TITLE',        '',           'CheckBox',     false,           '',             '',           false,   false),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_STATUSES',                  7,      false,       false,     false,                'ONBOARDING_STEP_STATUSES',     '',           'UNKNOWN',      false,           '',             '',           false,   false),
                      ('ONBOARDING_STEP_FORM', 'ONBOARDING_STEP_EMPLOYEES',                 8,      false,       false,     false,                'ONBOARDING_STEP_EMPLOYEES',    '',           'UNKNOWN',      false,           '',             '',           false,   false);


UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id = 'ONBOARDING_STEP_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id = 'ONBOARDING_STEP_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'ONBOARDING_STEP_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id = 'ONBOARDING_STEP_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'ONBOARDING_STEP_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id = 'ONBOARDING_STEP_FORM';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id = 'ONBOARDING_STEP_FORM';

DELETE FROM "anv"."model"  WHERE formid = 'ONBOARDING_STEP_FORM';
DELETE FROM "anv"."modelfield"  WHERE form_id = 'ONBOARDING_STEP_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('ONBOARDING_STEP_FORM', 'OnboardingStep')) IS NOT NULL;