DELETE FROM "model"  WHERE formid = 'SMS_TEMPLATE_FORM';
DELETE FROM "modelfield"  WHERE form_id = 'SMS_TEMPLATE_FORM';

insert into model(active, formID, title, viewname) values(true, 'SMS_TEMPLATE_FORM', 'SMS Template Form', 'SMSTemplate');
insert into modelfield(form_ID,     field_ID,     sorder, mandatory,  hide,   isCustomField,        section,        defaultValue, widget,   systemmandatory,  nolabelfor,    nowrapperfor, fullWidth, split) values
                ('SMS_TEMPLATE_FORM', 'NAME',        1,     false,     false,     false,        'SMS_INFORMATION',        '',    'TextBox',       true,            '',             '',         false,   false),
                ('SMS_TEMPLATE_FORM', 'MODULE',      2,     false,     false,     false,        'SMS_INFORMATION',        '',    'DropDown',      true,            '',             '',         false,   false),
                ('SMS_TEMPLATE_FORM', 'IS_DEFAULT',  3,     false,     false,     false,        'SMS_INFORMATION',        '',   'RadioButton',   false,            '',             '',         false,   true),
                ('SMS_TEMPLATE_FORM', 'CONTENT',     4,     false,     false,     false,        'SMS_INFORMATION',        '',    'TextArea',     false,            '',             '',         false,   false);


UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id = 'SMS_TEMPLATE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id = 'SMS_TEMPLATE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'SMS_TEMPLATE_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id = 'SMS_TEMPLATE_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'SMS_TEMPLATE_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id = 'SMS_TEMPLATE_FORM';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id = 'SMS_TEMPLATE_FORM';

DELETE FROM "anv"."model"  WHERE formid = 'SMS_TEMPLATE_FORM';
DELETE FROM "anv"."modelfield"  WHERE form_id = 'SMS_TEMPLATE_FORM';

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('SMS_TEMPLATE_FORM', 'SMSTemplate')) IS NOT NULL;