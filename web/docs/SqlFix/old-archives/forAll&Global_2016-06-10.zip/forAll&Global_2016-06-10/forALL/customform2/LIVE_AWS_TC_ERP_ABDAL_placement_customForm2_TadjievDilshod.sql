delete from  modelfield where form_ID ='PLACEMENT_FORM';
delete from  model where formID ='PLACEMENT_FORM';

insert into model(active,formID, title,viewname) values(true,'PLACEMENT_FORM', 'Placement Form','Placement');

-- HRMS Placement ADD,EDIT FORM
 -- Candidates
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (01,     true,      false,  false,          '',           true,            '',     'placementcandidate',                     'PLACEMENT_CANDIDATES',   'TextBox'  ,   'PLACEMENT_FORM',''),
                      (02,     true,      false,  false,          '',           true ,           '',     'placementDateOffer',                      'PLACEMENT_CANDIDATES',   'TextBox'  ,   'PLACEMENT_FORM',''),
                      (03,     false,      false,  false,          '',           false ,          '',     'placementVacancies',                    'PLACEMENT_CANDIDATES',   'TextBox'  ,   'PLACEMENT_FORM','');

-- Placement Details

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (04,     false,      false,  false,          '',           false,            '',     'placementPosition',                          'PLACEMENT_DETAILS',   'UNKNOWN'  , 'PLACEMENT_FORM',''),
                      (05,     true,      false,  false,          '',           true ,          '',     'placementDepartment',                          'PLACEMENT_DETAILS',   'DropDown'  ,   'PLACEMENT_FORM',''),
                      (06,     false,      false,  false,          '',           false ,          '',     'placementLocation',                     'PLACEMENT_DETAILS',   'UNKNOWN'  ,   'PLACEMENT_FORM',''),
                      (07,     false,       false,  false,          '',          false ,          '',     'placementProject',                    'PLACEMENT_DETAILS',   'DropDown'  ,   'PLACEMENT_FORM','');


-- attachment
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (08,     false,      false,  false,          '',           false,            'addForm,editForm',     'PLACEMENT_FILES',            'PLACEMENT_FILES',         'UNKNOWN'  , 'PLACEMENT_FORM','');

-- Note
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      (09,     false,      false,  false,          '',           false,            'addForm,editForm',     'PLACEMENT_NOTES',              'PLACEMENT_NOTES',   'UNKNOWN'  , 'PLACEMENT_FORM','');

update modelfield set nolabelfor='addForm,editForm' where form_ID ='PLACEMENT_FORM' and field_id='PLACEMENT_FILES';
update modelfield set nolabelfor='addForm,editForm' where form_ID ='PLACEMENT_FORM' and field_id='PLACEMENT_NOTES';

UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PLACEMENT_FORM' AND field_id = 'PLACEMENT_FILES';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='PLACEMENT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='PLACEMENT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='PLACEMENT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='PLACEMENT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='PLACEMENT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='PLACEMENT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='PLACEMENT_FORM';

--------------------------------------------------------------------------------------------------------------------
delete from "anv".modelfield where form_ID ='PLACEMENT_FORM';
delete from "anv".model where formID ='PLACEMENT_FORM';

update company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('PLACEMENT_FORM', 'Placement')) is not null;

update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PLACEMENT_FORM' and field_id='PLACEMENT_FILES';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='PLACEMENT_FORM' and field_id='PLACEMENT_NOTES';
