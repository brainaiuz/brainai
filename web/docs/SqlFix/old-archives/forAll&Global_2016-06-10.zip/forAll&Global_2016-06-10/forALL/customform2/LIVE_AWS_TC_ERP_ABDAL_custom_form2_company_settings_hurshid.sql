
delete from  modelfield where form_ID ='COMPANY_SETTINGS_FORM'; --delete agar bu formani patchi oldin urilgan busa
delete from  model where formID ='COMPANY_SETTINGS_FORM';       --delete agar bu formani patchi oldin urilgan busa

insert into model(active, formID, title, viewname) values(true, 'COMPANY_SETTINGS_FORM', 'Company Settings Form', 'CompanySettings');

--Company details
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,      helpmessage ) values
                      (01,     false,      false,  false,          '',           true,            '',     'CS_COMPANY_NAME',                     'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     'Your company name which will be visible to all employees.'),
                      (05,     false,      false,  false,          '',           false ,          '',     'PHONE',                               'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (10,     false,      false,  false,          '',           false ,          '',     'CS_FAX_NUMBER',                       'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (15,     false,      false,  false,          '',           false ,          '',     'EMAIL',                               'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (20,     false,      false,  false,          '',           false,           '',     'CS_WEBSITE',                          'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (25,     false,      false,  false,          '',           false,           '',     'INDUSTRY',                            'CS_COMPANY_DETAILS',   'DropDown'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (30,     false,      false,  false,          '',           false,           '',     'CS_NO_OF_EMPLOYEES',                  'CS_COMPANY_DETAILS',   'DropDown'  ,   'COMPANY_SETTINGS_FORM','',     ''),

		                  (35,     false,      false,  false,          '',           false,           '',     'CS_LICENSE_NO',                        'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (40,     false,      false,  false,          '',           false,           '',     'CS_LICENSE_START_DATE',                'CS_COMPANY_DETAILS',   'DatePicker'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (45,     false,      false,  false,          '',           false,           '',     'EXPIRATION_DATE',                      'CS_COMPANY_DETAILS',   'DatePicker' ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (50,     false,      false,  false,          '',           false,           '',     'CS_VISA_ALLOWANCE_LIMITS',             'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (55,     false,      false,  false,          '',           false,           '',     'CS_WPS_LABOR_PAYROLL_ID',              'CS_COMPANY_DETAILS',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (60,     false,      false,  false,          '',           false,           '',     'CS_ACCOUNTING_AUDIT_FILE_DATE',        'CS_COMPANY_DETAILS',   'DatePicker'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (65,     false,      false,  false,          '',           false,           '',     'CS_ACCOUNTING_AUDIT_FREQUENCY',        'CS_COMPANY_DETAILS',   'DropDown'  ,   'COMPANY_SETTINGS_FORM','',     '');

-- Address information

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,                helpmessage  ) values
                      (70,     false,      false,  false,          '',           false,            '',     'BILLING_ADDRESS',             'ADDRESS_INFORMATION',         'UNKNOWN',   'COMPANY_SETTINGS_FORM','editForm, addForm',     'Company billing address is the address to which company is registered to and to which company will receive payment information.'),
                      (75,     false,      false,  false,          '',           true,            '',     'BILLING_ADDRESS_LINE1',             'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     ''),
                      (80,     false,      false,  false,          '',           false ,          '',     'BILLING_ADDRESS_LINE2',             'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     ''),
                      (85,     false,      false,  false,          '',           true ,           '',     'BILLING_CITY',                      'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     ''),
                      (90,     false,      false,  false,          '',           true ,           '',     'BILLING_COUNTRY',                   'ADDRESS_INFORMATION',   'DropDown',   'COMPANY_SETTINGS_FORM','',     ''),
                      (95,     false,      false,  false,          '',           false ,           '',     'BILLING_STATE',                     'ADDRESS_INFORMATION',   'DropDown',   'COMPANY_SETTINGS_FORM','',     ''),
                      (100,     false,      false,  false,          '',           false ,          '',     'BILLING_POST_CODE',                 'ADDRESS_INFORMATION',   'TextBox'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (105,     false,      false,  false,          '',           false ,          '',     'HIDDEN_FIELD',                 'ADDRESS_INFORMATION',   'UNKNOWN'  ,   'COMPANY_SETTINGS_FORM','editForm, addForm',     ''),

					            (110,     false,      false,  false,          '',           false ,          '',     'MAILING_ADDRESS',                   'ADDRESS_INFORMATION',   'HTML',   'COMPANY_SETTINGS_FORM','editForm, addForm',     'Company mailing/shipping address is the address of the physical location of the company, which should be shown if different from billing address.'),
					            (115,     false,      false,  false,          '',           false ,          '',     'CS_ADDRESS_SAME',                   'ADDRESS_INFORMATION',   'CheckBox',   'COMPANY_SETTINGS_FORM','editForm, addForm',     ''),
                      (120,     false,      false,  false,          '',           false ,          '',     'CS_ADDRESS_LINE',                   'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     ''),
                      (125,     false,      false,  false,          '',           false ,          '',     'CS_ADDRESS_LINE2',                  'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     ''),
                      (130,     false,      false,  false,          '',           false ,          '',     'CS_MAILING_ADDRESS_CITY',           'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     ''),
                      (135,     false,      false,  false,          '',           false ,          '',     'CS_MAILING_ADDRESS_COUNTRY',        'ADDRESS_INFORMATION',   'DropDown',   'COMPANY_SETTINGS_FORM','',     ''),
                      (140,     false,      false,  false,          '',           false ,          '',     'CS_MAILING_ADDRESS_STATE',          'ADDRESS_INFORMATION',   'DropDown',   'COMPANY_SETTINGS_FORM','',     ''),
                      (145,     false,      false,  false,          '',           false ,          '',     'CS_MAILING_ADDRESS_POSTAL_CODE',    'ADDRESS_INFORMATION',   'TextBox',   'COMPANY_SETTINGS_FORM','',     '');


--Financial widget
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,            widget,           form_ID,     noWrapperFor, helpmessage  ) values
                      (150,     false,      false,  false,          '',           false,            '',     'CURRENCY',                   'CS_FINANCIAL_WIDGET',   'UNKNOWN',     'COMPANY_SETTINGS_FORM','',     ''),
                      (155,     false,      false,  false,          '',           false,            '',     'CS_FINANCIAL_YEAR_END',      'CS_FINANCIAL_WIDGET',   'UNKNOWN'  ,   'COMPANY_SETTINGS_FORM','',     ''),
                      (160,     false,      false,  false,          '',           false,            '',     'CS_CONVERSION_DATE',         'CS_FINANCIAL_WIDGET',   'UNKNOWN'  ,   'COMPANY_SETTINGS_FORM','',     '');

--Company Settings
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,    helpmessage  ) values
                      (165,     false,      false,  false,          '',           false,            '',     'LANGUAGE',                 'CS_COMPANY_SETTINGS',   'DropDown'  , 'COMPANY_SETTINGS_FORM','',     'Apply this language for all users.'),
                      (170,     false,      false,  false,          '',           false,            '',     'CS_SYTEM_THEME_COLOR',     'CS_COMPANY_SETTINGS',   'DropDown', 'COMPANY_SETTINGS_FORM','',     ''),
                      (175,     false,      false,  false,          '',           false,            '',     'CS_WEEK_START_ON',         'CS_COMPANY_SETTINGS',   'DropDown' , 'COMPANY_SETTINGS_FORM','',     ''),
                      (180,     false,      false,  false,          '',           false,            '',     'CS_ALTERNATE_CALENDAR',         'CS_COMPANY_SETTINGS',   'DropDown' , 'COMPANY_SETTINGS_FORM','',     ''),
                      (185,     false,      false,  false,          '',           false,            '',     'CS_COMPANY_BBC_EMAIL',     'CS_COMPANY_SETTINGS',   'TextBox' , 'COMPANY_SETTINGS_FORM','',     ''),
                      (190,     false,      false,  false,          '',           false,            '',     'CS_SSL',                   'CS_COMPANY_SETTINGS',   'CheckBox' , 'COMPANY_SETTINGS_FORM','editForm, addForm',     ''),

					  (195,     false,      false,  false,          '',           true,            '',     'CS_COMPANY_TIME_ZONE',     'CS_COMPANY_SETTINGS',   'DropDown' , 'COMPANY_SETTINGS_FORM','',     ''),
					  (200,     false,      false,  false,          '',           false,            '',     'CS_SHORT_DATE_FORMAT',     'CS_COMPANY_SETTINGS',   'UNKNOWN' , 'COMPANY_SETTINGS_FORM','',     ''),
					  (205,     false,      false,  false,          '',           false,            '',     'CS_LONG_DATE_FORMAT',      'CS_COMPANY_SETTINGS',   'UNKNOWN' , 'COMPANY_SETTINGS_FORM','',     ''),
					  (210,     false,      false,  false,          '',           false,            '',     'CS_PDF_FONT_TYPE',         'CS_COMPANY_SETTINGS',   'DropDown' , 'COMPANY_SETTINGS_FORM','',     '');

--Company logos
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,               section,                    widget,         form_ID,               noWrapperFor,    helpmessage  ) values
                      (215,     false,      false,  false,          '',           false,              '',     'COMPANY_LOGO_LABEL',  'COMPANY_LOGOS',            'UNKNOWN',   'COMPANY_SETTINGS_FORM',   'editForm, addForm',     'Company&#39;s logo to be displayed to all employees instead of kpi.com logo on the top left'),
                      (220,     false,      false,  false,          '',             false,            '',     'COMPANY_LOGO',        'COMPANY_LOGOS',            'UNKNOWN'  , 'COMPANY_SETTINGS_FORM', 'editForm, addForm',     ''),
                      (225,     false,      false,  false,          '',           false,              '',     'PDF_LOGO_LABEL',      'COMPANY_LOGOS',            'UNKNOWN',   'COMPANY_SETTINGS_FORM',   'editForm, addForm',     'Choose the logo for your company which will appear in all reports and PDF documents'),
                      (230,     false,      false,  false,          '',             false,            '',     'PDF_LOGO',            'COMPANY_LOGOS',            'UNKNOWN'  , 'COMPANY_SETTINGS_FORM', 'editForm, addForm',     '');


--System access details
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget,            form_ID,      noWrapperFor, helpmessage  ) values
                      (235,     false,      false,  false,          '',           false,            '',     'IP_ADDRESS',                 'SYSTEM_ACCESS_DETAILS',   'MULTITABLE',   'COMPANY_SETTINGS_FORM','',     'Company users can access the system only from the indicated IP address or IP address range.'),
                      (240,     false,      false,  false,          '',           false,            '',     'PASSWORD_EXPIRES_IN',        'SYSTEM_ACCESS_DETAILS',   'DropDown'  ,   'COMPANY_SETTINGS_FORM','',     '');



--- set styles
update company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('COMPANY_SETTINGS_FORM', 'CompanySettings')) is not null;
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id='COMPANY_SETTINGS_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='COMPANY_SETTINGS_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND  form_id='COMPANY_SETTINGS_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='COMPANY_SETTINGS_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='COMPANY_SETTINGS_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id='COMPANY_SETTINGS_FORM';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id='COMPANY_SETTINGS_FORM';


delete from "anv".modelfield where form_ID ='COMPANY_SETTINGS_FORM';   --delete agar bu formani patchi oldin urilgan busa
delete from "anv".model where formID ='COMPANY_SETTINGS_FORM';      --delete agar bu formani patchi oldin urilgan busa


UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' WHERE form_id='COMPANY_SETTINGS_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='COMPANY_SETTINGS_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND  form_id='COMPANY_SETTINGS_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id='COMPANY_SETTINGS_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND  form_id='COMPANY_SETTINGS_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' WHERE form_id='COMPANY_SETTINGS_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' WHERE form_id='COMPANY_SETTINGS_FORM';
update "anv".modelfield mf set fieldSetStyle='slideDown-content group nobrd', halfSetStyle='halfSet-1', section=label where widget='FileUploadWidget' and form_id='COMPANY_SETTINGS_FORM';



