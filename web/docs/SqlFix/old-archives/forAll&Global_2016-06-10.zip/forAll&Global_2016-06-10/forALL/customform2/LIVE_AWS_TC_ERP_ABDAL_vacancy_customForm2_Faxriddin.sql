delete from  modelfield where form_ID ='VACANCY_FORM';
delete from  model where formID ='VACANCY_FORM';

insert into model(active,formID, title,viewname) values(true,'VACANCY_FORM', 'Vacancy Form','Vacancy');

-- HRMS Vacancy ADD,EDIT FORM
 -- General Details
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,    split ) values
                      (10,     true,      false,  false,          '',           true,            '',     'vacancyJobTitle',                     'VACANCY_GENERAL_DETAILS',   'TextBox'  ,   'VACANCY_FORM','',          false   ),
                      (20,     false,      false,  false,          '',           false ,           '',     'vacancyDescription',                      'VACANCY_GENERAL_DETAILS',   'TextArea'  ,   'VACANCY_FORM','',   false   ),
                      (30,     true,      false,  false,          '',           true ,          '',     'vacancyStartDate',                    'VACANCY_GENERAL_DETAILS',   'DatePicker'  ,   'VACANCY_FORM','',        false   ),
                      (40,     true,      false,  false,          '',           true,           '',     'vacancyEndDate',                      'VACANCY_GENERAL_DETAILS',   'DatePicker'  ,   'VACANCY_FORM','',        false   ),
                      (50,     false,      false,  false,          '',           false,          '',         'vacancyType',                      'VACANCY_GENERAL_DETAILS',   'DropDown'  , 'VACANCY_FORM','',          true    ),
                      (60,     false,      false,  false,          '',           false,          '',         'jobRequirement',                   'VACANCY_GENERAL_DETAILS',   'TextArea'  , 'VACANCY_FORM','',          false    ),
                      (70,     false,      false,  false,          '',           false,          '',         'gender',                           'VACANCY_GENERAL_DETAILS',   'UNKNOWN'  , 'VACANCY_FORM','',           false   ),
                      (80,     false,      false,  false,          '',           false,          '',         'proposedSalary',                   'VACANCY_GENERAL_DETAILS',   'TextBox'  , 'VACANCY_FORM','',           false   ),
                      (90,     false,      false,  false,          '',           false,           '',     'vacancyStatus',                         'VACANCY_GENERAL_DETAILS',   'DropDown'  ,   'VACANCY_FORM','',      false   ),
                      (100,     false,      false,  false,          '',           false,           '',     'vacancyPlaceCount',                 'VACANCY_GENERAL_DETAILS',   'TextBox' ,   'VACANCY_FORM','',           false    );

-- Initernal Details

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor,  field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ,       split) values
                      (110,     true,      false,  false,          '',           true,            '',          'vacancyNumberID',                'VACANCY_INTERNAL_DETAILS',   'TextBox'  , 'VACANCY_FORM','',        false        ),
                      (115,     false,      false,  false,          '',           false ,           '',           'vacancyPosition',               'VACANCY_INTERNAL_DETAILS',   'UNKNOWN'  ,   'VACANCY_FORM','',     false       ),
                      (120,     false,      false,  false,          '',            false ,           '',           'vacancyManager',               'VACANCY_INTERNAL_DETAILS',   'DropDown'  ,   'VACANCY_FORM','',    false       ),
                      (130,     false,       false,  false,          '',          false ,         '',         'vacancyLocation',                  'VACANCY_INTERNAL_DETAILS',   'TextArea'  ,   'VACANCY_FORM','',     true      ),
                      (140,     false,      false,  false,          '',           false,          '',         'PROJECT',                          'VACANCY_INTERNAL_DETAILS',   'UNKNOWN'  , 'VACANCY_FORM','',        false      ),
                      (150,     false,      false,  false,          '',           false,          '',         'COUNTRY',                          'VACANCY_INTERNAL_DETAILS',   'UNKNOWN'  , 'VACANCY_FORM','',        false      ),
                      (160,     false,      false,  false,          '',           false,          '',         'COUNTRYEMBASSY',                   'VACANCY_INTERNAL_DETAILS',   'UNKNOWN'  , 'VACANCY_FORM','',        false      ),
                      (170,     false,      false,  false,          '',           false,          '',         'contractPeriod',                   'VACANCY_INTERNAL_DETAILS',   'UNKNOWN'  , 'VACANCY_FORM','',         false     ),
                      (180,     false,      true,  false,          '',           false,          '',         'religion',                         'VACANCY_INTERNAL_DETAILS',   'UNKNOWN'  , 'VACANCY_FORM','',         false     );



-- position information
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,              split  ) values
                      (190,     false,      false,  false,          '',           false,            '',     'vacancyJobType',            'VACANCY_POSITION_INFORMATION',         'DropDown'  , 'VACANCY_FORM','',            false        ),
                      (200,     false,      false,  false,          '',           false,            '',     'vacancyJobFamily',            'VACANCY_POSITION_INFORMATION',         'UNKNOWN'  , 'VACANCY_FORM','',            false       ),
                      (210,     false,      false,  false,          '',           false,            '',     'vacancyRequiredDegree',            'VACANCY_POSITION_INFORMATION',         'DropDown'  , 'VACANCY_FORM','',       true       ),
                      (220,     false,      false,  false,          '',           false,            '',     'vacancyResponsibilities',            'VACANCY_POSITION_INFORMATION',         'UNKNOWN'  , 'VACANCY_FORM','',      false        );

-- Attachment
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,              split  ) values
                      (230,     false,      false,  false,          '',           false,            'addForm,editForm',     'VACANCY_ATTACHMENTS',              'VACANCY_ATTACHMENTS',   'UNKNOWN'  , 'VACANCY_FORM','',        false     );

--- Note
insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor,              split  ) values
                      (240,     false,      false,  false,          '',           false,            'addForm,editForm',     'VACANCY_NOTES',             'VACANCY_NOTES',   'UNKNOWN'  , 'VACANCY_FORM','',                  false        );

UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'VACANCY_FORM' AND field_id = 'VACANCY_ATTACHMENTS';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='VACANCY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='VACANCY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='VACANCY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='VACANCY_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='VACANCY_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='VACANCY_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='VACANCY_FORM';

--------------------------------------------------------------------------------------------------------------------
delete from "anv".modelfield where form_ID ='VACANCY_FORM';
delete from "anv".model where formID ='VACANCY_FORM';

update company set isdeleted = false where isdeleted is null and (select "anv".convertCustomFieldsToModelFields('VACANCY_FORM', 'Vacancy')) is not null;

update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='VACANCY_FORM' and field_id='VACANCY_ATTACHMENTS';
update "anv".modelfield set nolabelfor='addForm,editForm' where form_ID ='VACANCY_FORM' and field_id='VACANCY_NOTES';
