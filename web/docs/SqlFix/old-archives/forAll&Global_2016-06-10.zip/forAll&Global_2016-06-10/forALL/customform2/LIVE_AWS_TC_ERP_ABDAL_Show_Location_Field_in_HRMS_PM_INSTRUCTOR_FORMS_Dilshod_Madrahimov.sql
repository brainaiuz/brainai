UPDATE modelfield  set field_id='LOCATION' where field_id='LOCATION_FIELD' and form_ID='HRMS_EMPLOYEE_FORM';
UPDATE modelfield  set field_id='LOCATION' where field_id='LOCATION_FIELD' and form_ID='PM_EMPLOYEE_FORM';
UPDATE modelfield  set field_id='LOCATION' where field_id='LOCATION_FIELD' and form_ID='INSTRUCTOR_FORM';

UPDATE "anv".modelfield  set field_id='LOCATION' where field_id='LOCATION_FIELD' and form_ID='HRMS_EMPLOYEE_FORM';
UPDATE "anv".modelfield  set field_id='LOCATION' where field_id='LOCATION_FIELD' and form_ID='PM_EMPLOYEE_FORM';
UPDATE "anv".modelfield  set field_id='LOCATION' where field_id='LOCATION_FIELD' and form_ID='INSTRUCTOR_FORM';