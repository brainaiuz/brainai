delete from  modelfield where form_ID ='PROJECT_SUMMARY_FORM';
delete from  model where formID ='PROJECT_SUMMARY_FORM';

insert into model(active, formID, title, viewname) values(true, 'PROJECT_SUMMARY_FORM', 'Project Summary', 'Project');

--Project details
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,   section,       widget,       form_ID,   noWrapperFor) values
                      (01,     false,      false,  false,       '',           false ,          '',     'NUMBER',      'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM',''),
                      (02,     false,      false,  false,       '',           false,            '',     'NAME',        'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM',''),
                      (03,     false,      false,  false,       '',           false ,          '',     'DESCRIPTION', 'DETAILS', 'TextArea'  , 'PROJECT_SUMMARY_FORM',''),
                      (04,     false,      false,  false,       '',           false,           '',     'START_DATE',  'DETAILS', 'DatePicker', 'PROJECT_SUMMARY_FORM',''),
                      (05,     false,      false,  false,       '',           false,           '',     'DUE_DATE',    'DETAILS', 'DatePicker', 'PROJECT_SUMMARY_FORM',''),
                      (06,     false,      false,  false,       '',           false,           '',     'STATUS',      'DETAILS', 'DropDown'  , 'PROJECT_SUMMARY_FORM',''),
                      (07,     false,      false,  false,       '',           false,           '',     'EMPLOYEE_ASSIGNMENT',            'DETAILS', 'DropDown'  , 'PROJECT_SUMMARY_FORM',''),
                      (08,     false,      false,  false,       '',           false,           '',     'COMPLETED',   'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM',''),
                      (09,     false,      false,  false,       '',           false,           '',     'CONTRACT',   'DETAILS', 'TextBox'  ,  'PROJECT_SUMMARY_FORM',''),
                      (10,     false,      false,  false,       '',           false,           '',     'PDF_VERSION',  'DETAILS', 'UNKNOWN'  ,  'PROJECT_SUMMARY_FORM','');

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      (20,     false,      false,  false,        '',           false,           'viewForm',     'INVOLVED_EMPLOYEE',   'INVOLVED_EMPLOYEES',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');


insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor) values
                       (250,     false,      false,  false,          '',           false,            '',     'MANAGER',  'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (260,     false,      false,  false,          '',           false,            '',     'BACKUP_MANAGER',  'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (270,     false,      false,  false,          '',           false,            '',     'CLIENT',           'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (280,     false,      false,  false,          '',           false,            '',     'ACTUAL_START_DATE','MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (290,     false,      false,  false,          '',           false,            '',     'ACTUAL_END_DATE',  'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (300,     false,      false,  false,          '',           false,            '',     'ESTIMATED_TIME',   'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (310,     false,      false,  false,          '',           false,            '',     'TIME_SPENT',       'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (320,     false,      false,  false,          '',           false,            '',     'ACTUAL_TIME_SPENT','MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (330,     false,      false,  false,          '',           false,            '',     'ESTIMATED_COST',   'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (340,     false,      false,  false,          '',           false,            '',     'ACTUAL_COST',      'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (350,     false,      false,  false,          '',           false,            '',     'WAITING_HOURS',   'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (360,     false,      false,  false,          '',           false,            '',     'REJECTED_HOURS',      'MORE_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,          section,       widget      ,form_ID,     noWrapperFor) values
                       (400,     false,      false,  false,          '',           false,            '',     'NOT_STARTED_TASKS',  'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (410,     false,      false,  false,          '',           false,            '',     'IN_PORGRESS_TASKS',  'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (420,     false,      false,  false,          '',           false,            '',     'COMPLETED_TASKS',    'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (430,     false,      false,  false,          '',           false,            '',     'CANCELLED_TASKS',    'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (440,     false,      false,  false,          '',           false,            '',     'WAITING_FOR_SOMEONE_ELSE',  'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   ''),
                       (450,     false,      false,  false,          '',           false,            '',     'CLOSED_TASKS',       'TASK_DETAILS', 'TextBox',   'PROJECT_SUMMARY_FORM',   '');


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,    section,       widget      ,form_ID,     noWrapperFor) values
                      (500,     false,      false,  false,       '',           false,            'viewForm',     'ATTACHMENTS',  'ATTACHMENTS', 'UNKNOWN', 'PROJECT_SUMMARY_FORM',   'viewForm');

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,  section,     widget      ,form_ID,     noWrapperFor) values
                      (510,     false,      false, false,          '',           false,            'viewForm',     'LINKS',    'LINKS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor,  field_ID,     section,        widget      ,form_ID,              noWrapperFor) values
                      (520,     false,      false, false,          '',           false,            'viewForm', 'PROJECT_NOTE', 'PROJECT_NOTE', 'NoteWidget',   'PROJECT_SUMMARY_FORM',   'viewForm');

insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      (530,     false,      false,  false,        '',           false,           'viewForm',     'PROJECT_CHART',   'PROJECT_CHARTS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');


insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,noLabelFor,field_ID,   section,    widget      ,form_ID,   noWrapperFor) values
                      (550,     false,      false, false,          '',           false,            '', 'CREATED_BY', 'UPDATES',  'TextBox',  'PROJECT_SUMMARY_FORM', ''),
                      (560,     false,      false, false,          '',           false,            '', 'CREATED_DATE', 'UPDATES','TextBox',  'PROJECT_SUMMARY_FORM', ''),
                      (570,     false,      false, false,          '',           false,            '', 'UPDATED_BY', 'UPDATES',  'TextBox',  'PROJECT_SUMMARY_FORM', ''),
                      (580,     false,      false, false,          '',           false,            '', 'UPDATED_DATE', 'UPDATES','TextBox',  'PROJECT_SUMMARY_FORM', '');

update modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';
update modelfield set split=true where field_ID='CREATED_DATE' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'ATTACHMENTS';




delete from "anv".modelfield where form_ID ='PROJECT_SUMMARY_FORM';
delete from "anv".model where formID ='PROJECT_SUMMARY_FORM';
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (SELECT "anv".convertCustomFieldsToModelFields('PROJECT_SUMMARY_FORM', 'Project')) IS NOT NULL;

update "anv".modelfield set nolabelfor='viewForm' where form_ID ='PROJECT_SUMMARY_FORM' and field_id='LINKS';
update "anv".modelfield set nolabelfor='viewForm' where form_ID ='PROJECT_SUMMARY_FORM' and field_id='ATTACHMENTS';
update "anv".modelfield set nolabelfor='viewForm' where form_ID ='PROJECT_SUMMARY_FORM' and field_id='INVOLVED_EMPLOYEE';
update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';


update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';
update "anv".modelfield set split=true where field_ID='CREATED_DATE' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'ATTACHMENTS';