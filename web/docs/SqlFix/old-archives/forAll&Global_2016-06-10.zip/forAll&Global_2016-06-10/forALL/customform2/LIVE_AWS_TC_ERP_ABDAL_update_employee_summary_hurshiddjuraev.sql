
delete from  modelfield where field_ID='LOCATION_FIELD' and form_ID ='PM_EMPLOYEE_FORM';
delete from  "anv".modelfield where field_ID='LOCATION_FIELD' and form_ID ='PM_EMPLOYEE_FORM';