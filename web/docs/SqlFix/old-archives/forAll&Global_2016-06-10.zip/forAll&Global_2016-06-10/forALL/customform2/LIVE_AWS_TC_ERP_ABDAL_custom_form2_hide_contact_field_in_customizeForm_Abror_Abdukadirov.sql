--need to after the upgrade scheme and after that AWS_custom_form2_account_add_terms_field_Abror_Abdukadirov

--------------------------------LEAD------------------------------------------------------------------------

update modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'STREET_ADDRESS1';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'STREET_ADDRESS2';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'CITY';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'STATE';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'COUNTRY';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'POST_CODE';

update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'STREET_ADDRESS1';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'STREET_ADDRESS2';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'CITY';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'STATE';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'COUNTRY';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'LEAD_FORM' AND field_id = 'POST_CODE';

--------------------------------CONTACT------------------------------------------------------------------------

update modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'STREET_ADDRESS1';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'STREET_ADDRESS2';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'CITY';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'STATE';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'COUNTRY';
update modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'POST_CODE';

update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'STREET_ADDRESS1';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'STREET_ADDRESS2';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'CITY';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'STATE';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'COUNTRY';
update "anv".modelfield SET hideInCustomizeForm = true WHERE form_id = 'CONTACT_FORM' AND field_id = 'POST_CODE';