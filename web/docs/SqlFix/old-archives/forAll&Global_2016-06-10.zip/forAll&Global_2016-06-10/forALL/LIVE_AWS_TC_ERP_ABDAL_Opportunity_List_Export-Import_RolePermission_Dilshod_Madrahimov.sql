insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
('CRM_OPPORTUNITIES_IMPORT_LIST', 'CRM', 'Opportunities Import', '5', 'false',
    (select id from permission where code='CRM_OPPORTUNITIES_LIST'), 'false', 'OPPORTUNITY_TRACKING');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_IMPORT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_IMPORT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_IMPORT_LIST', 'ACCOUNTANT', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_IMPORT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_IMPORT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_IMPORT_LIST', 'ACCOUNTANT', 'ALLOW');


-----------------
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
('CRM_OPPORTUNITIES_EXPORT_LIST', 'CRM', 'Opportunities Export', '6', 'false',
    (select id from permission where code='CRM_OPPORTUNITIES_LIST'), 'false', 'OPPORTUNITY_TRACKING');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPORT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPORT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPORT_LIST', 'ACCOUNTANT', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPORT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPORT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPORT_LIST', 'ACCOUNTANT', 'ALLOW');

