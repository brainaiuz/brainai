
update permission set parent=(select id from permission where code='PAYROLL_MAIN_MENU') where code='PAYROLL_EMPLOYEES_LIST';