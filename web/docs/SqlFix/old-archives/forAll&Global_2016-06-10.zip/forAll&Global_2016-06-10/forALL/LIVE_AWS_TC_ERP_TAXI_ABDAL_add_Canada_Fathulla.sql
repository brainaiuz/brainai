insert into Region (name,countryid) values('Nunavut',(select id from country where code='CA'));
insert into Region (name,countryid) values('Yukon',(select id from country where code='CA'));
insert into Region (name,countryid) values('Northwest Territories',(select id from country where code='CA'));