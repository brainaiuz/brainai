
update "anv".reference set name='Employee Document Types' where code='_DOCUMENT_TYPES';
insert into "anv".reference (code, name, description) values ('_COMPANY_DOCUMENT_TYPES', 'Company Document Types', 'Company Document Types');

insert into "0".reference (code, name, description) values ('_COMPANY_DOCUMENT_TYPES', 'Company Document Types', 'Company Document Types');
update "0".reference set name='Employee Document Types' where code='_DOCUMENT_TYPES';
