delete from "0".approver_roles;
delete from "0".approvers;
delete from "0".workflow_alerts where workflow in (select id from "0".workflowrule where module = '_WORKFLOW_MODULE_LEAVE_REQUEST');
delete from "0".workflowrule where module = '_WORKFLOW_MODULE_LEAVE_REQUEST';
--create workflow rule for created execution;
INSERT INTO "0".workflowrule (deleted, description, executioncriteria, executioncriteriaupdatefield, module, name, pattern, rulecriteria, status, creator, recurrenceid, showinlist) VALUES (false, '', '_WORKFLOW_EXECUTION_CRITERIA_CREATE', null, '_WORKFLOW_MODULE_LEAVE_REQUEST', 'Leave Request on create', '', null, '_WORKFLOW_STATUS_ACTIVE', (select id from "0".employee limit 1), null, true);
--create workflowalert for that rule
INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, '${reason} notification', '', '', null, (select a.id from "0".workflowrule a where a.executioncriteria='_WORKFLOW_EXECUTION_CRITERIA_CREATE' and a.module='_WORKFLOW_MODULE_LEAVE_REQUEST' limit 1), 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear <span>${current_approver}</span>,</p><p>Please be informed that&nbsp;<strong>${registered_by}<strong/>&nbsp;added a ${reason}.</p><p><strong>Request Details:</strong><br /><br />Reason: ${reason}<br /><br />Description: ${description}<br /><br />Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${approve_link}" ><span >Click here to view the ${reason}</span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p ><span>${approve_link}</span></p></body></html>');

DROP function if EXISTS "0".createDefaultApprovers();
CREATE OR replace function "0".createDefaultApprovers()
  returns INTEGER AS
  $body$
DECLARE
    approver1ID INTEGER;
    approver2ID INTEGER;
    approved1WorkflowID INTEGER;
    rejected1WorkflowID INTEGER;
    approved2WorkflowID INTEGER;
    rejected2WorkflowID INTEGER;
    leaves_approver_id1 INTEGER;
    leaves_approver_id2 INTEGER;
    sr record;

    BEGIN
        --one level approval here
        --create approver item in "0".approvers table
        insert into "0".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'LEAVE_REQUEST', true, 5, 6) RETURNING id INTO approver1ID;
        --create approvers_role rows.!!!!!!!!!
        insert into "0".approver_roles(approver_id, role_id) (select approver1ID, r.id from "0".role r where code in ('ADMIN','DR','HR'));
        --create workflows for approval1
        insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id into approved1WorkflowID;
        insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id INTO rejected1WorkflowID;
        --set workflowids to the approver
        update "0".approvers set workflow=approved1WorkflowID, rejected_workflow=approved2WorkflowID where id=approver1ID;
        --create workflow alert on actions
        INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request rejected', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${reason}.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${link}"><span style="color:blue">Click here to view the ${reason} </span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p></body></html>');
        INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request approved', '', '', null,approved1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${reason}.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${link}"><span style="color:blue">Click here to view the ${reason} </span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p></body></html>');
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "0".createDefaultApprovers() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "0".createDefaultApprovers()) IS NOT NULL;

