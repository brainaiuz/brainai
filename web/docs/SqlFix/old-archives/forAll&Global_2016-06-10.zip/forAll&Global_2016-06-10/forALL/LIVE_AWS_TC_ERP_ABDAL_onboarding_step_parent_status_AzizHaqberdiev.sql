insert into "0".reference (code, name, description) values ('_ONBOARDING_STEP_STATUSES', 'Onboarding Step Statuses', 'Onboarding Step Statuses');
insert into "anv".reference (code, name, description) values ('_ONBOARDING_STEP_STATUSES', 'Onboarding Step Statuses', 'Onboarding Step Statuses');
