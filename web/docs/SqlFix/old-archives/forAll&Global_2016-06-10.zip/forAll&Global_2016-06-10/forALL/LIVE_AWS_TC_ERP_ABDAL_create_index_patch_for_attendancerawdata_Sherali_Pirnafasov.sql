CREATE INDEX attendancerawdata_employeeId_idx
ON "anv".attendancerawdata
USING btree
(employeeId);

CREATE INDEX attendancerawdata_reasonid_idx
ON "anv".attendancerawdata
USING btree
(reasonid);

CREATE INDEX sickrequest_employeeId_idx
ON "anv".SickRequest
USING btree
(employeeId);

CREATE INDEX sickrequest_reason_idx
ON "anv".SickRequest
USING btree
(reason);