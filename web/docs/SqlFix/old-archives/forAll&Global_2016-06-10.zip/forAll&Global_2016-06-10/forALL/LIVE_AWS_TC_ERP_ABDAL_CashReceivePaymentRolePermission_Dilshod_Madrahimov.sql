insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'ACCOUNTING', 'Cash Receipt', 6, false,
  (select id from permission where code='ACCOUNTING_BANK_ACCOUNT_LIST'), false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT', 'PM', 'ALLOW');



insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
  values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'ACCOUNTING', 'Cash Payment', 7, false,
  (select id from permission where code='ACCOUNTING_BANK_ACCOUNT_LIST'), false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT', 'PM', 'ALLOW');



---- Sorting  -----
---- Tepadagilardan keyin urilsin! --------

update permission set sorder=1 where code='ACCOUNTING_BANK_ACCOUNT_ADD';
update permission set sorder=2 where code='ACCOUNTING_BANK_ACCOUNT_EDIT';
update permission set sorder=3 where code='ACCOUNTING_BANK_ACCOUNT_DELETE';
update permission set sorder=4 where code='ACCOUNTING_BANK_ACCOUNT_SPEND';
update permission set sorder=5 where code='ACCOUNTING_BANK_ACCOUNT_RECEIVE';
update permission set sorder=6 where code='ACCOUNTING_BANK_ACCOUNT_CASH_RECEIPT';
update permission set sorder=7 where code='ACCOUNTING_BANK_ACCOUNT_CASH_PAYMENT';
update permission set sorder=8 where code='ACCOUNTING_BANK_ACCOUNT_TRANSFER';
update permission set sorder=9 where code='ACCOUNTING_BANK_ACCOUNT_TRANSACTION_IMPORT';
update permission set sorder=10 where code='ACCOUNTING_BANK_ACCOUNT_TRANSACTIONS';
update permission set sorder=11 where code='ACCOUNTING_BANK_STATEMENT';

