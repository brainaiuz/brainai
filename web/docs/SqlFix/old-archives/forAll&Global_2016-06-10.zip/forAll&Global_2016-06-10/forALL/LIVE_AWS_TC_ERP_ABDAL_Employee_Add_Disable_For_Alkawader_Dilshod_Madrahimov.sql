 delete from  "54099".genericsettings where key='EMPLOYEE_ADD_ENABLE';
 insert into "54099".genericsettings(key,value) values('EMPLOYEE_ADD_ENABLE_HIDE','YES');