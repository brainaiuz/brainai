
DELETE FROM permission WHERE code in ('HRMS_SHOW_ALL_CANDIDATES', 'HRMS_SHOW_OWNED_CANDIDATES', 'HRMS_SHOW_RELATED_CANDIDATES');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_SHOW_ALL_CANDIDATES', 'HRMS', 'Show All candidates', 12, false, (select id from permission where code='HRMS_CANDIDATE_LIST_VIEW'), false,  'RECRUITMENT_SYSTEM');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_SHOW_OWNED_CANDIDATES', 'HRMS', 'Show Owned candidates', 13, false, (select id from permission where code='HRMS_CANDIDATE_LIST_VIEW'), false,  'RECRUITMENT_SYSTEM');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_SHOW_RELATED_CANDIDATES', 'HRMS', 'Show Related candidates', 14, false, (select id from permission where code='HRMS_CANDIDATE_LIST_VIEW'), false,  'RECRUITMENT_SYSTEM');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_ALL_CANDIDATES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_ALL_CANDIDATES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_ALL_CANDIDATES', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_OWNED_CANDIDATES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_OWNED_CANDIDATES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_OWNED_CANDIDATES', 'MEM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_RELATED_CANDIDATES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_RELATED_CANDIDATES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_RELATED_CANDIDATES', 'MEM', 'ALLOW');


DELETE FROM "anv".rolepermission WHERE permissioncode in ('HRMS_SHOW_ALL_CANDIDATES', 'HRMS_SHOW_OWNED_CANDIDATES', 'HRMS_SHOW_RELATED_CANDIDATES');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_ALL_CANDIDATES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_ALL_CANDIDATES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_ALL_CANDIDATES', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_OWNED_CANDIDATES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_OWNED_CANDIDATES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_OWNED_CANDIDATES', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_RELATED_CANDIDATES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_RELATED_CANDIDATES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_RELATED_CANDIDATES', 'MEM', 'ALLOW');


