
update "anv".invoicepayments set paymentstatus=NULL where type in ('RECEIVABLE_PREPAYMENT','PAYABLE_SUPPLIER_CREDIT');