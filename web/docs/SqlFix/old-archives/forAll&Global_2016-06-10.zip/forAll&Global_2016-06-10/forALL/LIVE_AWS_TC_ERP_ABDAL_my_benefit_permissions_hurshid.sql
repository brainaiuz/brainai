delete from permission where code='MY_BENEFIT_REQUEST_LIST';
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('MY_BENEFIT_REQUEST_LIST', 'HRMS', 'My Benefit request list', 12, false, (select id from permission where code='HRMS_CURENT_EMPLOYEE_PROFILE_TAB'), false,  'HRMS_MODULE');

delete from "0".rolepermission where permissioncode='MY_BENEFIT_REQUEST_LIST';
insert into "0".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'MEM', 'ALLOW');

delete from "anv".rolepermission where permissioncode='MY_BENEFIT_REQUEST_LIST';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MY_BENEFIT_REQUEST_LIST', 'MEM', 'ALLOW');


