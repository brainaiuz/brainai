insert into "anv".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values ((select max(sorder)+1 from "anv".reference
where parentid = (select id from "anv".reference where code = '_EMAIL_TEMPLATE_MODULE')), 'ET_PENALTIES_PROMOTIONS_MODULE', 'Penalty/Promotion', false, true, false, false, (select id from "anv".reference where code = '_EMAIL_TEMPLATE_MODULE'));

insert into "anv".reference (sorder,                             code,  name,                  isremovable, issystemreference, shared, iscustombutton, parentid)
 values                       (1,   'CATEGORY_PROMOTION',               'Promotion', false,       true,              false,  false,         (select id from "anv".reference where code = 'ET_PENALTIES_PROMOTIONS_MODULE'));

insert into "anv".reference (sorder,                             code,  name,                  isremovable, issystemreference, shared, iscustombutton, parentid)
 values                       (2,     'CATEGORY_PENALTY',               'Penalty', false,       true,              false,  false,         (select id from "anv".reference where code = 'ET_PENALTIES_PROMOTIONS_MODULE'));

 insert into "anv".emailtemplate(code, deleted, fromuserid, iscompanyemailtemplate, isdefault, locale, messagehtml, name, subject, categoryid, module_id)
VALUES ('DEFAULT_PROMOTION_NOTIFICATION', false, -1, 'DEFAULT_EMAIL_TEMPLATE', true, 'en', '&nbsp;<p>Dear ${employeename},</p><p>This is to inform you that ${creator_name} added promotion for you at ${assigned_date}.</p><p>Click <a href="${link}">here</a> to view the promotion details.</p><p>* If you are not able to click on the link, you can instead copy and paste the following address into your web browser:</p><p>${link}</p>&nbsp;', 'Promotion Notification', 'You have been promoted by ${creator_name}', (select id from "anv".reference where code='CATEGORY_PROMOTION'), (select id from "anv".reference where code='ET_PENALTIES_PROMOTIONS_MODULE'));

insert into "anv".emailtemplate(code, deleted, fromuserid, iscompanyemailtemplate, isdefault, locale, messagehtml, name, subject, categoryid, module_id)
VALUES ('DEFAULT_PENALTY_NOTIFICATION', false, -1, 'DEFAULT_EMAIL_TEMPLATE', true, 'en', '&nbsp; <p>Dear ${employeename},</p><p>This is to inform you that ${creator_name} added penalty for you at ${assigned_date}.</p><p>Click <a href="${link}">here</a> to view the penalty details.</p><p>* If you are not able to click on the link, you can instead copy and paste the following address into your web browser:</p><p>${link}</p>&nbsp;', 'Penalty Notification', 'You have been penalized by ${creator_name}', (select id from "anv".reference where code='CATEGORY_PENALTY'), (select id from "anv".reference where code='ET_PENALTIES_PROMOTIONS_MODULE'));