   -- it had been run on aws and live
---- ACCOUNTING_REQUEST_FOR_QUOTE_LIST
     insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ACCOUNTING', 'Request For Quote List', '1', 'false', (select id from permission where code='ACCOUNTING_ACCOUNTING_MENU'), 'false', 'ACCOUNTING_MODULE');

  	    insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ACCOUNTANT', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'SUPPLIER', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ACCOUNTANT', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'SUPPLIER', 'ALLOW');


    ---------------------------------------------------------------------------------------------------------------------------------------
    --- ACCOUNTING_REQUEST_FOR_QUOTE_ADD

        insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ACCOUNTING', 'Request For Quote Add', '2', 'false', (select id from permission where code='ACCOUNTING_REQUEST_FOR_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');

		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ACCOUNTANT', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ACCOUNTANT', 'ALLOW');



     -------------------------------------------------------------------------------------------------------------------------------------
     --- ACCOUNTING_REQUEST_FOR_QUOTE_EDIT
        insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ACCOUNTING', 'Request For Quote Edit', '3', 'false', (select id from permission where code='ACCOUNTING_REQUEST_FOR_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');

	    insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ACCOUNTANT', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ACCOUNTANT', 'ALLOW');

      --------------------------------------------------------------------------------------------------------------------------------------------

    -- ACCOUNTING_REQUEST_FOR_QUOTE_DELETE
	   insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ACCOUNTING', 'Request For Quote Delete', '4', 'false', (select id from permission where code='ACCOUNTING_REQUEST_FOR_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');

	    insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ACCOUNTANT', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ACCOUNTANT', 'ALLOW');

	---------------------------------------------------------------------------------------------------------------------------------------------
    --- ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY
	   insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ACCOUNTING', 'Request For Quote Summary', '5', 'false', (select id from permission where code='ACCOUNTING_REQUEST_FOR_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');

	    insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ACCOUNTANT', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'SUPPLIER', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ACCOUNTANT', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'SUPPLIER', 'ALLOW');

	 --------------------------------------------------------------------------------------------------------------------------------------------------
    --- ACCOUNTING_REQUEST_FOR_QUOTE_COPY
	   insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ACCOUNTING', 'Request For Quote Copy', '6', 'false', (select id from permission where code='ACCOUNTING_REQUEST_FOR_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');

	    insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ACCOUNTANT', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ACCOUNTANT', 'ALLOW');


    ------------------------------------------------------------------------------------------------------------------------------------------------------
	-- ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT

       insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ACCOUNTING', 'Request For Quote Copy', '7', 'false', (select id from permission where code='ACCOUNTING_REQUEST_FOR_QUOTE_LIST'), 'false', 'ACCOUNTING_MODULE');

	    insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ADMIN', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'DR', 'ALLOW');
		insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ACCOUNTANT', 'ALLOW');

		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ADMIN', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'DR', 'ALLOW');
		insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ACCOUNTANT', 'ALLOW');





