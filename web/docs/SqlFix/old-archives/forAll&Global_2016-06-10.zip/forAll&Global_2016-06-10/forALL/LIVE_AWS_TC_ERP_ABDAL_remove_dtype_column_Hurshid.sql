
alter table "anv".crmcustomfields drop column if exists dtype;