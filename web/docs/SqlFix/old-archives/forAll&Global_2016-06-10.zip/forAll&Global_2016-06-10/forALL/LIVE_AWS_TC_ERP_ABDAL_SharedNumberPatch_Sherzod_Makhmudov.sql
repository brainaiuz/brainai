
INSERT INTO "anv".sharednumber(intnumber, "number", code, entityID, entityCode, deleted)
 (select intnumber,"number",'REM',id,'REM',false from "anv".spendreceivemoney where transfertype=0);

INSERT INTO "anv".sharednumber(intnumber, "number", code, entityID, entityCode, deleted)
 (select intnumber,"number",'SPM',id,'SPM',false from "anv".spendreceivemoney where transfertype=1);