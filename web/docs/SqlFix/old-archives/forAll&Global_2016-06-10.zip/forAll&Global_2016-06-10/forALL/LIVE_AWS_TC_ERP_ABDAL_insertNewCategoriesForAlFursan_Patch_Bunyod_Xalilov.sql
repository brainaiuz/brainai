
insert into "anv".category(code, name, type, pensionable, forall) values('FOOD_ALLOWANCE','Food Allowance', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, forall) values('REGULAR_OVERTIME','Overtime Regular', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, forall) values('WEEKEND_OVERTIME','Overtime Weekend', 'Payment', true, true);
insert into "anv".category(code, name, type, pensionable, forall) values('HOLIDAY_OVERTIME','Overtime Holiday', 'Payment', true, true);
