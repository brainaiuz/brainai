--Tulqin here delete constraint
alter table "anv".approvers drop constraint if exists "fk_ro3n3tt77skj8fa7plyc85cux";


delete from "0".reference where code = '_WORKFLOW_MODULE_LEAVE_REQUEST';
insert into "0".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_LEAVE_REQUEST', false, true, 'Leave Request', true, 8, (select id from "0".reference where code='_WORKFLOW_MODULE'), true);

delete from "anv".reference where code = '_WORKFLOW_MODULE_LEAVE_REQUEST';
insert into "anv".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive) values('_WORKFLOW_MODULE_LEAVE_REQUEST', false, true, 'Leave Request', true, 8, (select id from "anv".reference where code='_WORKFLOW_MODULE'), true);

--We need Model and ModelField for workflow to act normally.
delete from "public".model where formid = 'LEAVE_REQUEST_FORM';
insert into "public".model(active, formid, title, viewname) values(true, 'LEAVE_REQUEST_FORM', 'Leave Request', 'Leave Request');
--modelfield table
delete from "public".modelfield where form_id='LEAVE_REQUEST_FORM';
insert into "public".modelfield (form_id,            sorder  ,usablebyworkflow, field_id) values
                                ('LEAVE_REQUEST_FORM',     1 ,true,             'STATUS'),
                                ('LEAVE_REQUEST_FORM',     2 ,true,             'PREV_APPROVER'),
                                ('LEAVE_REQUEST_FORM',     3 ,true,             'CURRENT_APPROVER'),
                                ('LEAVE_REQUEST_FORM',     4 ,true,             'PREV_APPROVER_STATUS'),
                                ('LEAVE_REQUEST_FORM',     5 ,true,             'CURRENT_APPROVER_STATUS'),
                                ('LEAVE_REQUEST_FORM',     6 ,true,             'REGISTERED_BY'),
                                ('LEAVE_REQUEST_FORM',     6 ,true,             'REGISTERED_BY_EMAIL'),
                                ('LEAVE_REQUEST_FORM',     7 ,true,             'START_DATE'),
                                ('LEAVE_REQUEST_FORM',     8 ,true,             'DUE_DATE'),
                                ('LEAVE_REQUEST_FORM',     9 ,true,             'REASON'),
                                ('LEAVE_REQUEST_FORM',    10 ,true,             'OTHER_REASON'),
                                ('LEAVE_REQUEST_FORM',    11 ,true,             'TYPE'),
                                ('LEAVE_REQUEST_FORM',    12 ,true,             'TAKE_LIVE_TYPE'),
                                ('LEAVE_REQUEST_FORM',    13 ,true,             'CONFIRM_DATE'),
                                ('LEAVE_REQUEST_FORM',    14 ,true,             'START_TIME'),
                                ('LEAVE_REQUEST_FORM',    15 ,true,             'DUE_TIME'),
                                ('LEAVE_REQUEST_FORM',    16 ,true,             'DESCRIPTION'),
                                ('LEAVE_REQUEST_FORM',    17 ,true,             'PREV_APPROVER_EMAIL'),
                                ('LEAVE_REQUEST_FORM',    18 ,true,             'CURRENT_APPROVER_EMAIL');


update "anv".sickrequest set currentapprover=null, prevapprover=null, overallstatus = status;
delete from "anv".approver_roles where approver_id in (select id from "anv".approvers where entitytype='LEAVE_REQUEST');
delete from "anv".approver_employees where approver_id in (select id from "anv".approvers where entitytype='LEAVE_REQUEST');
delete from "anv".approvers where entitytype='LEAVE_REQUEST';
delete from "anv".workflow_alerts where workflow in (select id from "anv".workflowrule where (executioncriteria='_WORKFLOW_ACTION_APPROVING' or executioncriteria='_WORKFLOW_EXECUTION_CRITERIA_CREATE') and module='_WORKFLOW_MODULE_LEAVE_REQUEST');
delete from "anv".workflowrule where (executioncriteria='_WORKFLOW_ACTION_APPROVING' or executioncriteria='_WORKFLOW_EXECUTION_CRITERIA_CREATE') and module='_WORKFLOW_MODULE_LEAVE_REQUEST';


--create workflow rule for created execution;
INSERT INTO "anv".workflowrule (deleted, description, executioncriteria, executioncriteriaupdatefield, module, name, pattern, rulecriteria, status, creator, recurrenceid, showinlist) VALUES (false, '', '_WORKFLOW_EXECUTION_CRITERIA_CREATE', null, '_WORKFLOW_MODULE_LEAVE_REQUEST', 'Leave Request on create', '', null, '_WORKFLOW_STATUS_ACTIVE', (select id from "anv".employee limit 1), null, true);
--create workflowalert for that rule
INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, '${reason} notification', '', '', null, (select a.id from "anv".workflowrule a where a.executioncriteria='_WORKFLOW_EXECUTION_CRITERIA_CREATE' and a.module='_WORKFLOW_MODULE_LEAVE_REQUEST' limit 1), 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear <span>${current_approver}</span>,</p><p>Please be informed that&nbsp;<strong>${registered_by}<strong/>&nbsp;added a ${reason}.</p><p><strong>Request Details:</strong><br /><br />Reason: ${reason}<br /><br />Description: ${description}<br /><br />Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${approve_link}" ><span >Click here to view the ${reason}</span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p ><span>${approve_link}</span></p></body></html>');

DROP function if EXISTS "anv".createDefaultApprovers();
CREATE OR replace function "anv".createDefaultApprovers()
  returns INTEGER AS
  $body$
DECLARE
    approver1ID INTEGER;
    approver2ID INTEGER;
    approved1WorkflowID INTEGER;
    rejected1WorkflowID INTEGER;
    approved2WorkflowID INTEGER;
    rejected2WorkflowID INTEGER;
    leaves_approver_id1 INTEGER;
    leaves_approver_id2 INTEGER;
    sr record;

    BEGIN
        IF EXISTS (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') AND (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') = 'YES' THEN
          --two level approval here
          --create approver item in "anv".approvers table
          insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'LEAVE_REQUEST', true, 1, 3) RETURNING id INTO approver1ID;
          insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (2, 'LEAVE_REQUEST', true, 1, 3) RETURNING id INTO approver2ID;
          --create approvers_role rows.!!!!!!!!!
          insert into "anv".approver_roles(approver_id, role_id) (select approver1ID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
          insert into "anv".approver_roles(approver_id, role_id) (select approver2ID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
          --create workflows for approval1
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id into approved1WorkflowID;
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id INTO rejected1WorkflowID;
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id into approved2WorkflowID;
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id INTO rejected2WorkflowID;
          --set workflowids to the approver
          update "anv".approvers set workflow=approved1WorkflowID, rejected_workflow=rejected1WorkflowID where id=approver1ID;
          update "anv".approvers set workflow=approved2WorkflowID, rejected_workflow=rejected2WorkflowID where id=approver2ID;
          --create workflow alert on actions
          INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request rejected', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${reason}.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${link}"><span style="color:blue">Click here to view the ${reason} </span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p></body></html>');
          INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request rejected', '', '', null,rejected2WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${reason}.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${link}"><span style="color:blue">Click here to view the ${reason} </span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p></body></html>');
          INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request approved', '', '', null,approved2WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body><p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${reason}.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} [${start_time}] to ${due_date} [${due_time}]</p><p><a href="${link}"><span style="color:blue">Click here to view the ${reason} </span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p></body></html>');
          --create approvers for every "anv".sickrequest
          FOR sr IN (SELECT * FROM "anv".sickrequest)
          LOOP
            --create new item in approvers
            INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
            values (1, 'LEAVE_REQUEST', sr.id, false, 1, 2,approved1WorkflowID, rejected1WorkflowID,sr.approver1id,sr.approver1status) RETURNING id INTO leaves_approver_id1;
            --create new item in approvers
            INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
            values (2, 'LEAVE_REQUEST', sr.id, false, 1, 2,approved2WorkflowID, rejected2WorkflowID,sr.approver2id,sr.approver2status) RETURNING id INTO leaves_approver_id2;
            -- update current sickrequest with new approver item.
            update "anv".sickrequest a set currentapprover=leaves_approver_id2, prevapprover=leaves_approver_id1, overallstatus=a.status where id = sr.id;
          END LOOP;
        ELSE
            --one level approval here
            --create approver item in "anv".approvers table
            insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'LEAVE_REQUEST', true, 5, 6) RETURNING id INTO approver1ID;
            --create approvers_role rows.!!!!!!!!!
            insert into "anv".approver_roles(approver_id, role_id) (select approver1ID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
            --create workflows for approval1
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id into approved1WorkflowID;
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id INTO rejected1WorkflowID;
            --set workflowids to the approver
            update "anv".approvers set workflow=approved1WorkflowID, rejected_workflow=approved2WorkflowID where id=approver1ID;
            --create workflow alert on actions
            INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request rejected', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${type} request.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} to ${due_date}</p><p><a href="${link}"><span style="color:blue">Click here to view the ${type} request</span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p>');
            INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request approved', '', '', null,approved1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${type} request.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} to ${due_date}</p><p><a href="${link}"><span style="color:blue">Click here to view the ${type} request</span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p>');
            --create approvers for every "anv".sickrequest
            FOR sr IN (SELECT * FROM "anv".sickrequest)
            LOOP
                INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
                values (1, 'LEAVE_REQUEST', sr.id, false, 5, 6,approved1WorkflowID, rejected1WorkflowID,sr.approver1id,sr.approver1status) RETURNING id INTO leaves_approver_id1;
                -- update current sickrequest with new approver item.
                update "anv".sickrequest a set currentapprover=leaves_approver_id1, prevapprover=leaves_approver_id1, overallstatus=a.status where id = sr.id;
            END LOOP;
        END IF;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".createDefaultApprovers() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".createDefaultApprovers()) IS NOT NULL;

