
delete from pdfreference where code='SINLE_PAYRUN';

insert into pdfreference(code, name) values('SINGLE_PAYRUN','Single Payrun');