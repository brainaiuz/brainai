-- Public Schema
INSERT INTO permission(context,code,name,sorder,ismainmenu,iscore,modulecode) VALUES('ACCOUNTING','ACCOUNTING_STOCK_TRANSFER_EDIT','Stock Transfer Edit',1, false,false,'INVENTORY_MANAGEMENT');

-- Zero Schema
INSERT INTO "0".rolepermission(permissioncode,rolecode, access) VALUES('ACCOUNTING_STOCK_TRANSFER_EDIT','DR','ALLOW');
INSERT INTO "0".rolepermission(permissioncode,rolecode, access) VALUES('ACCOUNTING_STOCK_TRANSFER_EDIT','ADMIN','ALLOW');
INSERT INTO "0".rolepermission(permissioncode,rolecode, access) VALUES('ACCOUNTING_STOCK_TRANSFER_EDIT','ACCOUNTANT','ALLOW');

-- For Company Schemas
INSERT INTO "anv".rolepermission(permissioncode,rolecode, access) VALUES('ACCOUNTING_STOCK_TRANSFER_EDIT','DR','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode,rolecode, access) VALUES('ACCOUNTING_STOCK_TRANSFER_EDIT','ADMIN','ALLOW');
INSERT INTO "anv".rolepermission(permissioncode,rolecode, access) VALUES('ACCOUNTING_STOCK_TRANSFER_EDIT','ACCOUNTANT','ALLOW');