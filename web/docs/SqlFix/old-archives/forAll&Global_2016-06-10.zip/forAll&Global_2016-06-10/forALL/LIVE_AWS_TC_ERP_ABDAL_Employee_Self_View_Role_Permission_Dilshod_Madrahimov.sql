
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'HRMS', 'Employee Self Service View', '1', 'false',
    (select id from permission where code='HRMS_CURENT_EMPLOYEE_PROFILE_TAB'), 'false', 'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'MEM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_SELF_SERVICE_VIEW', 'MEM', 'ALLOW');

UPDATE permission set sorder=2 where code='HRMS_EMPLOYEE_PROFILE_SUMMARY';
