update "anv".reference  set name = 'Not Started' where code = 'NOT_STARTED' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');
update "anv".reference  set name = 'In Progress' where code = 'IN_PROGRESS' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');
update "anv".reference  set name = 'On Hold' where code = 'ON_HOLD' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');
update "anv".reference  set name = 'Completed' where code = 'COMPLETED' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');
update "anv".reference  set name = 'Cancelled' where code = 'CANCELLED' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');
update "anv".reference  set name = 'Waiting for someone else' where code = 'WAITING_FOR_SOMEONE_ELSE' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');
update "anv".reference  set name = 'Closed' where code = 'CLOSED' and parentid = (select id from "anv".reference where code = '_TASK_STATUS');


update "anv".reference  set name = 'High' where code = '_TASK_PRIORITY_HIGH' and parentid = (select id from "anv".reference where code = '_TASK_PRIORITY');
update "anv".reference  set name = 'Medium' where code = '_TASK_PRIORITY_MEDIUM' and parentid = (select id from "anv".reference where code = '_TASK_PRIORITY');
update "anv".reference  set name = 'Low' where code = '_TASK_PRIORITY_LOW' and parentid = (select id from "anv".reference where code = '_TASK_PRIORITY');