ALTER TABLE "0".mailmessage ALTER COLUMN replyto TYPE text;

ALTER TABLE "anv".mailmessage ALTER COLUMN replyto TYPE text;