insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
   ('CRM_ACTIVITIES_LOG_CALL_VIEW', 'CRM', 'Permission For Log a Call', 5, false, (select id from permission where code='CRM_ACTIVITIES_LIST'), false, 'CRM_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACTIVITIES_LOG_CALL_VIEW', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACTIVITIES_LOG_CALL_VIEW', 'DR', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACTIVITIES_LOG_CALL_VIEW', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACTIVITIES_LOG_CALL_VIEW', 'DR', 'ALLOW');