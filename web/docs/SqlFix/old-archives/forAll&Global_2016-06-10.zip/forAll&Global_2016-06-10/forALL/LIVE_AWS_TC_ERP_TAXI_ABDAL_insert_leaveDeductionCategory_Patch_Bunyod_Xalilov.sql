
insert into "anv".category(code, name, type, pensionable, forall) values('LEAVE_DEDUCTIONS','Leave Deductions', 'Deduction', true, true);