delete from dashboard_widget where section='ACCOUNTING' and view='ACCOUNTING_DASHBOARD';
insert into dashboard_widget (code,name,section,view,sorder) values('PURCHASE_TRANSACTION','Purchase Transactions','ACCOUNTING','ACCOUNTING_DASHBOARD',1);
insert into dashboard_widget (code,name,section,view,sorder) values('SALES_TRANSACTION','Sales Transactions','ACCOUNTING','ACCOUNTING_DASHBOARD',2);
insert into dashboard_widget (code,name,section,view,sorder) values('AGING_RECEIVABLE','Aged Receivables','ACCOUNTING','ACCOUNTING_DASHBOARD',3);
insert into dashboard_widget (code,name,section,view,sorder) values('AGING_PAYABLE','Aged Payables','ACCOUNTING','ACCOUNTING_DASHBOARD',4);
insert into dashboard_widget (code,name,section,view,sorder) values('TOP_EXPENSES','Expenses(YTD)','ACCOUNTING','ACCOUNTING_DASHBOARD',5);
insert into dashboard_widget (code,name,section,view,sorder) values('INCOME_EXPENSE','Income And Expense','ACCOUNTING','ACCOUNTING_DASHBOARD',6);
