
--HRMS permissions
delete from permission where code in ('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'HRMS_EDIT_OWN_PROFILE');
update permission set sorder=sorder+2 where parent=(select id from permission where code='HRMS_SECTION_TAB' limit 1);
update permission set sorder=1, parent=(select id from permission where code='HRMS_SECTION_TAB' limit 1) where code='HRMS_MANAGER_SELF_SERVICE_VIEW';
update permission set sorder=2, parent=(select id from permission where code='HRMS_SECTION_TAB' limit 1) where code='HRMS_EMPLOYEE_SELF_SERVICE_VIEW';
update permission set sorder=9 where code='HRMS_EDIT_PROFILE';
update permission set sorder=12 where code='HRMS_EDIT_GOAL_WEIGHTS';
update permission set sorder=13 where code='HRMS_ACTIVATE_DEACTIVATE';
update permission set sorder=14 where code='HRMS_TERMINATE_EMPLOYMENT';
update permission set sorder=15 where code='HRMS_EMPLOYEES_EXPORT_TO_PDF';
update permission set sorder=16 where code='HRMS_EMPLOYEE_REMOVE';
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('HRMS_EDIT_OWN_PROFILE', 'HRMS', 'Edit own profile', 10, false, (select id from permission where code='HRMS_EMPLOYEES'), false,  'HRMS_MODULE');

--PM permissions
update permission set sorder=14 where code='PM_EMPLOYEE_ACTIVATE_DEACTIVATE';
update permission set sorder=15 where code='PM_EMPLOYEE_REMOVE';
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'PM', 'Edit own profile', 11, false, (select id from permission where code='PM_EMPLOYEE_LIST'), false,  'PM');





delete from "0".rolepermission where permissioncode in ('HRMS_EDIT_OWN_PROFILE','PM_EMPLOYEE_EDIT_OWN_PROFILE');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_OWN_PROFILE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_OWN_PROFILE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_OWN_PROFILE', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'MEM', 'ALLOW');




delete from "anv".rolepermission where permissioncode in ('HRMS_EDIT_OWN_PROFILE','PM_EMPLOYEE_EDIT_OWN_PROFILE');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_OWN_PROFILE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_OWN_PROFILE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EDIT_OWN_PROFILE', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_EMPLOYEE_EDIT_OWN_PROFILE', 'MEM', 'ALLOW');
