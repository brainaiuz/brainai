INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Salary certificate', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>

        <tr>
            <td><span style="font-family:times new roman,times,serif;">${currentdate}</span></td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>
                <h2 style="text-align: center; margin: 0pt; font: bold 20px/1.4 Arial;"><span style="font-family:times new roman,times,serif;">TO WHOM IT MAY CONCERN</span></h2>
            </td>
        </tr>
        </tbody>
    </table>
    <table style="margin-top: 20px;margin-bottom: 20px; margin-left: 5px;">
        <tr>
            <td><b>Sub:</b></td>
            <td style="padding-left: 20px;"><b>SALARY CERTIFICATE</b></td>
        </tr>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td align="left" style="font-family: times new roman,times,serif;font-size:16px;line-height: 1.6; ">
                <p style="text-indent:20px;">This is to certify that&nbsp; ${firstname} ${lastname},
                    ${nationality} national, holding passport number
                    <strong>${passportnumber} </strong> is working with us in the position of
                    ${jobtitle}. ${heshe} has joined the company last ${hiredate} with a salary of ${salaryamount}(${salarytext}).
                    we have no objection to transfer ${hisher} employment to any private or government sector.<br/></p>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td align="left" style="font-family: times new roman,times,serif;font-size:16px;line-height: 1.6;"><p style="text-indent: 20px;">This certificate is issued upon ${hisher} request.
                However, the company is not in any way responsible for whatever purpose this certificate is used to serve him. </p><br/>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Best regards,</span></span>

                <table border="0" cellpadding="0" cellspacing="0" width="30%">
                    <tbody>
                    <tr>
                        <td style="padding-bottom: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourname}</span></span></td>
                    </tr>
                    <tr>
                        <td style=" padding-top: 20px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourrole}</strong></span></span></td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Salary certificate' and deleted is not true
    );

--     Salary transfer letter
    INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Salary transfer letter', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>
        <tr>
            <td align="right"><span style="font-family:times new roman,times,serif;">${currentdate}</span></td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>
    <table width="500">
        <tbody>
        <tr>
            <td>
                <span style="font-family:times new roman,times,serif; font-size:14px;"><strong>To </strong></span>
            </td>
            <td style="padding-left:140px">
                <span style="font-family:times new roman,times,serif; font-size:14px;">  :&nbsp;&nbsp;<strong>$$input:textbox3$$</strong></span>
            </td>
        </tr>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>
                <span style="font-family:times new roman,times,serif; font-size:14px;"><strong>Re </strong></span>
            </td>
            <td style="padding-left:140px">
                <span style="font-family:times new roman,times,serif; font-size:14px;">  :&nbsp;&nbsp;<u><strong>SALARY TRANSFER LETTER</strong></u></span>
            </td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td align="left"><span style="font-size:16px;"><span style="font-family: times new roman,times,serif;">
			<span style="line-height: 1.6;"> Dear Sirs,<br/><br/>This is to certify that&nbsp; ${firstname} ${lastname},
			is working as ${jobtitle} with us ${hiredate} and has drawing monthly salary of ${salaryamount} inclusive of all allowances.
                </br></br>
                We confirm that ${hisher} monthly salary will be transferred for the credit of ${hisher} A/C No. ${accountnumber} with yourself.
			</span></span></span><br/>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Yours faithfully,</span></span>

                <table border="0" cellpadding="0" cellspacing="0" width="30%">
                    <tbody>
                    <tr>
                        <td style="padding-bottom: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourname}</span></span></td>
                    </tr>
                    <tr>
                        <td style=" padding-top: 20px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourrole}</strong></span></span></td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Salary transfer letter' and deleted is not true
    );


--     Termination certificate


INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Termination letter', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>
        <tr>
            <td><span style="font-family:times new roman,times,serif;">${currentdate}</span></td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>
    <table width="500">
        <tbody>
        <tr>
            <td>
                <span style="font-family:times new roman,times,serif; font-size:14px;"><strong>To </strong></span>
            </td>
            <td style="padding-left:140px">
                <span style="font-family:times new roman,times,serif; font-size:14px;">  :&nbsp;&nbsp;<strong>${bankname}<br/>${bankaddress}</strong></span>
            </td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td align="left"><span style="font-size:16px;"><span style="font-family: times new roman,times,serif;">
			<span style="line-height: 1.6;">	We regret to inform you that your employment with ${companyname} shall be terminated on ${firedate}. In this regard,
			you are given 1 month duration from this day forward to find another job opportunity outside the ${companyname} organization.<br/><br/>
			Please arrange to return any company property or any pending jobs that is in your possession.<br/><br/>
			Although we regret the situation, this act is compulsory.

			</span></span></span><br/>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Respectfully,</span></span>
                <table border="0" cellpadding="0" cellspacing="0" width="30%">
                    <tbody>
                    <tr>
                        <td style="padding-bottom: 4px;padding-top: 20px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourname}</strong></span></span></td>
                    </tr>
                    <tr>
                        <td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourrole}</span></span></td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Termination letter' and deleted is not true
    );


--     Warning Certificate

INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Warning letter', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table">
        <tr>
            <td><span style="font-family:times new roman,times,serif;"><strong>INTER-OFFICE MEMORANDUM</strong></span></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td><span style="font-family:times new roman,times,serif;">${date}</span></td>
        </tr>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>

        <tr>
            <td><span style="font-family:times new roman,times,serif;"><strong>TO</strong></span></td>
            <td><span style="font-family:times new roman,times,serif;">: &nbsp;&nbsp;&nbsp;<strong>${firstname} ${lastname}</strong></span></td>
        </tr>
        <tr>
            <td><span style="font-family:times new roman,times,serif;"><strong>SUBJECT</strong></span></td>
            <td><strong>:&nbsp;&nbsp;&nbsp; WARNING FOR</strong></td>
        </tr>
        <tr>
            <td colspan="2">
                <hr></hr>
            </td>
        </tr>

        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td align="left"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">
			<span style="line-height: 1.6;">The Human Resource has given a memorandum to you; as to serve a warning to your misconduct at work by not performing your duties well and not obeying your superior.<br/><br/>
            Another action shall be dealt to you accordingly whenever you do some unpunctuality again.<br/><br/><br/><br/>
            For your information and guidance.
</span></span></span><br/>
                &nbsp;
            </td>
        </tr>

        </tbody>
    </table>

</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Warning letter' and deleted is not true
    );



--     No objection Certificate




INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'No objection certificate', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>

        <tr>
            <td><span style="font-family:times new roman,times,serif;">Date: ${currentdate}</span></td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>
                <h2 style="text-align: center; margin: 0pt; font: bold 20px/1.4 Arial;"><span style="font-family:times new roman,times,serif;">TO WHOM IT MAY CONCERN</span></h2>
            </td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td align="left"><span style="font-size:16px;"><span style="font-family: times new roman,times,serif;">
			<span style="line-height: 1.6;">This is to certify that&nbsp; ${firstname} ${lastname}, holding passport number
			<strong>${passportnumber} </strong> is working with us, as
			<strong> ${jobtitle} </strong>
			we have no objection to transfer ${hisher} employment to any private  or government sector.</span></span></span><br/>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td align="left"><span style="font-size:16px;"><span style="font-family: times new roman,times,serif;">
			<span style="line-height: 1.6;">This certificate is issued upon ${hisher} request.
			However, the company is not in any way responsible for whatever purpose this certificate is used to serve him. </span></span></span><br/>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Best regards,</span></span>

                <table border="0" cellpadding="0" cellspacing="0" width="30%">
                    <tbody>
                    <tr>
                        <td style="padding-bottom: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourname}</span></span></td>
                    </tr>
                    <tr>
                        <td style=" padding-top: 20px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourrole}</strong></span></span></td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='No objection certificate' and deleted is not true
    );

-- Employment Offerf

    INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Employment Offer', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>

        <tr>
            <td><span style="font-family:times new roman,times,serif;">Date:</span></td>
            <td><span style="font-family:times new roman,times,serif;">${currentdate}</span></td>
        </tr>
        <tr>
            <td><span style="font-family:times new roman,times,serif;">To:</span></td>
            <td><strong>${firstname} &nbsp; ${lastname}</strong></td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>

    <table width="100%">
        <tr>
            <td style="font-family:times new roman,times,serif; font-size:14px; width:250px; padding-left:50px; width: 250px; padding-left: 50px;">
                <strong>Subject </strong>
            </td>
            <td style="font-family:times new roman,times,serif; font-size:14px; ">
                :&nbsp;&nbsp;<strong>Employment Offer</strong>
            </td>
        </tr>
        <tr>
            <td align="left" colspan="2" style="font-family:times new roman,times,serif; font-size:14px; "><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">
			<span style="line-height: 1.6;">We are pleased to inform you that you have been selected to work
			with us in the position of ${position} with the following terms below;</span></span></span><br/>
                &nbsp;
            </td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif;font-size:14px; width: 250px; padding-left: 50px;">
                1. Probation Period
            </td>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif; font-size:14px; ">
                :&nbsp;&nbsp;$$input:textbox1$$
            </td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif; font-size:14px; width:250px; padding-left:50px;  ">2. Monthly Basic Salary</td>
            <td>:&nbsp;&nbsp;${salaryamount}</td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif;font-size:14px;width: 250px; padding-left: 50px; ">
              3 .General Allowances
            </td>
            <td style="font-family:times new roman,times,serif;font-size:14px; ">
                :&nbsp;&nbsp;${generalallowance}
            </td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif;font-size:14px;width: 250px; padding-left: 50px; ">
               4. Air ticket
            </td>
            <td style="font-family:times new roman,times,serif;font-size:14px; ">
               :&nbsp;&nbsp;$$input:textbox2$$
            </td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif;font-size:14px;width: 250px; padding-left: 50px; ">
                5. Annual Leave
            </td>
            <td style="font-family:times new roman,times,serif;font-size:14px; ">
                :&nbsp;&nbsp;${leaveallowance}
            </td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif;font-size:14px;width: 250px; padding-left: 50px; ">
              6. Other Terms
            </td>
            <td style="font-family:times new roman,times,serif;font-size:14px; ">
                :&nbsp;&nbsp;$$input:textbox3$$
            </td>
        </tr>
        <tr>
            <td nowrap="nowrap" style="font-family:times new roman,times,serif;font-size:14px; width: 250px; padding-left: 50px;">
               7. Working Hours
            </td>
            <td style="font-family:times new roman,times,serif;font-size:14px; ">
               ${workinghours}
            </td>
        </tr>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>
    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>
                <span style="font-family:times new roman,times,serif;">Kind regards, </span>
            </td>
            <td>
                <span style="font-family:times new roman,times,serif;">Read &amp; Accepted </span>
            </td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Best regards,</span></span>

                <table border="0" cellpadding="0" cellspacing="0" width="30%">
                    <tbody>
                    <tr>
                        <td style="padding-bottom: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourname}</span></span></td>
                    </tr>
                    <tr>
                        <td style=" padding-top: 20px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourrole}</strong></span></span></td>
                    </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
    <table width="400">
        <tr>
            <td align="right">Name <br/>Signature<br/> Date</td>
        </tr>
    </table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Employment Offer' and deleted is not true
    );


-- Certificate of salary offer 2

    INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Salary certificate 2', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
    <table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
        <tbody>
        <tr>
            <td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
        </tr>

        <tr>
            <td><span style="font-family:times new roman,times,serif;">${firstname} ${lastname}</span></td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>&nbsp;</td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700">
        <tbody>
        <tr>
            <td>
                <h2 style="text-align: center; margin: 0pt; font: bold 20px/1.4 Arial;"><span style="font-family:times new roman,times,serif; border-bottom: 1px solid">SUBJECT: SALARY CERTIFICATE</span></h2>
            </td>
        </tr>
        </tbody>
    </table>

    <table cellpadding="10" cellspacing="0" class="section" width="700" style="padding-top: 50px;">
        <tbody>
        <tr>
            <td align="left" style="font-family: times new roman,times,serif;font-size:16px;line-height: 1.6; ">
                <p style="text-indent:20px;">We hereby certify that that&nbsp;${mrms} ${firstname} ${lastname},
                    has been appointed as ${jobtitle} since ${hiredate}
                    ${heshe} is currently drawing an all-inclusive salary of AED
                    ${salaryamount} only � per month.
                </p>

                <p>This certificate is being issued upon the employee�s request and shall not, in any way, be interpreted as a
                    guarantee and shall not create any financial or legal obligation on the part of our company, nor does
                    the company assume
                    any financial or legal responsibility of and when the employee�s services are terminated.</p>
                &nbsp;
            </td>
        </tr>
        </tbody>
    </table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Salary certificate 2' and deleted is not true
    );


