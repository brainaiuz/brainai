
insert into "anv".category(code, name, type, pensionable, forall) values('BENEFIT_PAYMENT','Benefit Payment', 'Payment', true, true);