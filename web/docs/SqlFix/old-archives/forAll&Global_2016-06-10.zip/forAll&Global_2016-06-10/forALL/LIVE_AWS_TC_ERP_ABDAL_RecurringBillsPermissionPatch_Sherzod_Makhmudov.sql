insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECURRING_BILL_LIST', 'ACCOUNTING', 'Recurring Bills', 8, false, (select id from permission where code='ACCOUNTING_ACCOUNTING_MENU'), false, 'RECURRING_BILLS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECURRING_BILL_ADD', 'ACCOUNTING', 'Add Recurring Bill', 1, false, (select id from permission where code='ACCOUNTING_RECURRING_BILL_LIST'), false, 'RECURRING_BILLS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECURRING_BILL_EDIT', 'ACCOUNTING', 'Edit Recurring Bill', 2, false, (select id from permission where code='ACCOUNTING_RECURRING_BILL_LIST'), false, 'RECURRING_BILLS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'ACCOUNTING', 'Recurring Bill Summary', 3, false, (select id from permission where code='ACCOUNTING_RECURRING_BILL_LIST'), false, 'RECURRING_BILLS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECURRING_BILL_COPY', 'ACCOUNTING', 'Copy Recurring Bill', 4, false, (select id from permission where code='ACCOUNTING_RECURRING_BILL_LIST'), false, 'RECURRING_BILLS');



insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_COPY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_COPY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_COPY', 'ACCOUNTANT', 'ALLOW');



insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_SUMMARY', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_COPY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_COPY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECURRING_BILL_COPY', 'ACCOUNTANT', 'ALLOW');