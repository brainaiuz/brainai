-- For the Zero schema
INSERT INTO "0".team_tree(parent_id, child_id, depth) SELECT t.id,t.id,0 FROM "0".team t WHERE (t.isdeleted is null OR t.isdeleted=false);
-- For All schema
INSERT INTO "anv".team_tree(parent_id, child_id, depth) SELECT t.id,t.id,0 FROM "anv".team t WHERE (t.isdeleted is null OR t.isdeleted=false);