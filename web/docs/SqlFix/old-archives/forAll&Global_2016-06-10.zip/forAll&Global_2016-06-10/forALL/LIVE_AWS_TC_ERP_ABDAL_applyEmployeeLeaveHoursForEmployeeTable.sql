-- schema anv

update "anv".employee ee set leaveDurationHour=
(select hoursFromAnnual from (SELECT sr.employeeid employeeid,
SUM(CASE WHEN a.holiday = false and s.durationtime > 0 THEN cast(s.durationtime as real)/60  ELSE (CASE WHEN a.holidayfromannualleave = true THEN cast(a.timeslot as real)/60 ELSE 0 END) END) as hoursFromAnnual
FROM "anv".sickrequestduration s
inner join "anv".sickrequest sr on s.sickrequestid=sr.id
inner join "anv".attendancerawdata a on (sr.employeeid=a.employeeid and s.dateid=a.dateid)
inner join datejoin d ON a.dateid = d.id
LEFT JOIN "anv".reference st on sr.status=st.id
WHERE date_part('year', d.from_date) =date_part('year', now()) AND st.code!='DENIED' AND a.timeslot <> 0
GROUP BY sr.employeeid) pdh where pdh.employeeid = ee.id);

update "anv".employee ee set leaveDurationDay=
(select daysFromAnnual from (SELECT sr.employeeid employeeid,
SUM(CASE WHEN a.holiday = false and s.durationtime > 0 THEN cast(s.durationtime as real)/a.timeslot  ELSE (CASE WHEN a.holidayfromannualleave = true THEN cast(a.timeslot as real)/a.timeslot ELSE 0 END) END) as daysFromAnnual
FROM "anv".sickrequestduration s
inner join "anv".sickrequest sr on s.sickrequestid=sr.id
inner join "anv".attendancerawdata a on (sr.employeeid=a.employeeid and s.dateid=a.dateid)
inner join datejoin d ON a.dateid = d.id
LEFT JOIN "anv".reference st on sr.status=st.id
WHERE date_part('year', d.from_date) =date_part('year', now()) AND st.code!='DENIED' AND a.timeslot <> 0
GROUP BY sr.employeeid) pdd where pdd.employeeid = ee.id);