
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "anv".genericSettings (key,value) values('CUSTOM_ROLE_IS_FIRST', 'YES');
