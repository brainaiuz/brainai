CREATE INDEX emails_tracker_id_idx ON "anv".emails USING btree (tracker_id);
update "anv".emails as s set folder_id = (select f.folder_id from "anv".email_folders as f where f.email_id=s.id limit 1);
update "anv".tracker as s set emailSetting_id = (select e.emailSetting_id from "anv".emails as e where e.tracker_id=s.tracker_id and deleted is not true limit 1);