--SOLR REINDX DAN OLDIN URILSIN

update "0".folder set parent_id =null where foldertype=41;

update "anv".folder set parent_id =null where foldertype=41;