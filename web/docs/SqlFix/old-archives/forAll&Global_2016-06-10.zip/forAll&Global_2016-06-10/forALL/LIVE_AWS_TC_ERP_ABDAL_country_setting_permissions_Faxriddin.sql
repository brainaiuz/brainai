insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COUNTRY_SETTINGS_LIST', 'SETTINGS', 'Country Settings List', 6, false, (select id from permission where code='SETTINGS_HRMS_SETTINGS'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'SETTINGS', 'Country Settings List', 7, false, (select id from permission where code='SETTINGS_HRMS_SETTINGS'), false,  'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_COUNTRY_SETTINGS_ADD_EDIT', 'ACCOUNTANT', 'ALLOW');

