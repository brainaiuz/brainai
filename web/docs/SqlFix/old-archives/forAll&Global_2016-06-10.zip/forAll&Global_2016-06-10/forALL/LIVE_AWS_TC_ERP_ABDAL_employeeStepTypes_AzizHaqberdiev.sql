insert into "0".reference (code, name, description) values ('_STEP_TYPES', 'Employee Step Types', 'Employee Step Types');
insert into "0".reference (code, name, description, parentid, sorder) values ('EMPLOYEE_TYPE', 'Employee', 'Employee type of step', (select id from "0".reference r where r.code = '_STEP_TYPES'), 1);
insert into "0".reference (code, name, description, parentid, sorder) values ('CANDIDATE_TYPE', 'Candidate', 'Candidate type of step', (select id from "0".reference r where r.code = '_STEP_TYPES'), 2);

insert into "anv".reference (code, name, description) values ('_STEP_TYPES', 'Employee Step Types', 'Employee Step Types');
insert into "anv".reference (code, name, description, parentid, sorder) values ('EMPLOYEE_TYPE', 'Employee', 'Employee type of step', (select id from "anv".reference r where r.code = '_STEP_TYPES'), 1);
insert into "anv".reference (code, name, description, parentid, sorder) values ('CANDIDATE_TYPE', 'Candidate', 'Candidate type of step', (select id from "anv".reference r where r.code = '_STEP_TYPES'), 2);

update "anv".stepemployee set type = (select id from "anv".reference where code = 'EMPLOYEE_TYPE' and parentid = (select id from "anv".reference where code = '_STEP_TYPES'));

--keyin Employee Step Core reindex yana