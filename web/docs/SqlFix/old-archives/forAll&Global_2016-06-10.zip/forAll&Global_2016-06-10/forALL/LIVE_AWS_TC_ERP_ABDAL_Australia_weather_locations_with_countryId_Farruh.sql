
-------FOR PUBLIC SCHEMA----
INSERT INTO weather_locations (location, location_id, country_id) values ('Adelaide, SAS', 'ASXX0001', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Albury-Wodonga, VCT', 'ASXX6309', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Alice Springs, NTR', 'ASXX0002', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Brisbane, QNS', 'ASXX0016', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Cairns, QNS', 'ASXX0020', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Canberra, ACT', 'ASXX0023', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Darwin, NTR', 'ASXX0032', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Hobart, TSM', 'ASXX0057', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Melbourne, VCT', 'ASXX0075', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Perth, WAS', 'ASXX0089', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Newcastle, NSW', 'ASXX0083', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('North Sydney, NSW', 'ASXX0274', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Sydney, NSW', 'ASXX0112', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Townsville, QNS', 'ASXX0117', (select id from country c where c.alias='Australia;AU;'));
INSERT INTO weather_locations (location, location_id, country_id) values ('Wollongong, NSW', 'ASXX0124', (select id from country c where c.alias='Australia;AU;'));