

--- Update EMPLOYEE DASHBOARD WIDGETS
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=1 where code='NOTIFICATION';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=2 where code='NEWS';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=3 where code='LEAVE_REQUEST';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=4 where code='COMPANY_DOCUMENT';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=5 where code='EMPLOYEE_DOCUMENT';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=6 where code='BIRTHDAY';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=7 where code='CONTACT';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=8 where code='PAYSLIP';
UPDATE dashboard_widget set view ='EMPLOYEE_SELF_SERVICE', sorder=9 where code='TODO_LIST';


-- INSERT MANAGER DASHBOARD WIDGET
insert into dashboard_widget (code,name,section,view,sorder) values('WAITING_FOR_APPROVAL','Waiting For Approval','HRMS','MANAGER_SELF_SERVICE',1);
insert into dashboard_widget (code,name,section,view,sorder) values('UNAVAILABLE_EMPLOYEES','Unavailable employees','HRMS','MANAGER_SELF_SERVICE',2);
insert into dashboard_widget (code,name,section,view,sorder) values('IN_OUT','In/Out','HRMS','MANAGER_SELF_SERVICE',3);
insert into dashboard_widget (code,name,section,view,sorder) values('DOCUMENT_EXPIRY','Document Expiry','HRMS','MANAGER_SELF_SERVICE',4);
insert into dashboard_widget (code,name,section,view,sorder) values('INCIDENT','Incidents','HRMS','MANAGER_SELF_SERVICE',5);
insert into dashboard_widget (code,name,section,view,sorder) values('PAYROLL','Payroll','HRMS','MANAGER_SELF_SERVICE',6);
insert into dashboard_widget (code,name,section,view,sorder) values('CANDIDATE_PER_VACANCY','Candidates Per Vacancies','HRMS','MANAGER_SELF_SERVICE',7);
insert into dashboard_widget (code,name,section,view,sorder) values('HEADCOUNT','Headcount','HRMS','MANAGER_SELF_SERVICE',8);
insert into dashboard_widget(code,name,section,view,sorder) values('ONBOARDING','Onboarding','HRMS','MANAGER_SELF_SERVICE',9);