
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PRODUCT_COST', 'ACCOUNTING', 'Product Cost', 8, false, (select id from permission where code='ACCOUNTING_PRODUCT_LIST'), false, 'CORE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PRODUCT_COST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PRODUCT_COST', 'DR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PRODUCT_COST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PRODUCT_COST', 'DR', 'ALLOW');
