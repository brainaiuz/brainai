UPDATE permission SET name='Organization chart' WHERE code='HRMS_TEAM_ORGANIZATION_CHART_VIEW';
UPDATE permission SET name='Supervisor Structure' WHERE code='HRMS_ORGANIZATION_CHART_VIEW';