insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('NOTIFICATION_CONFIG_EVENT', 'SETTINGS', 'Notification Config Event', 10, false, (select id from permission where code='SETTINGS_HRMS_SETTINGS'), false,  'HRMS_MODULE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('NOTIFICATION_CONFIG_EVENT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('NOTIFICATION_CONFIG_EVENT', 'DR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('NOTIFICATION_CONFIG_EVENT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('NOTIFICATION_CONFIG_EVENT', 'DR', 'ALLOW');
