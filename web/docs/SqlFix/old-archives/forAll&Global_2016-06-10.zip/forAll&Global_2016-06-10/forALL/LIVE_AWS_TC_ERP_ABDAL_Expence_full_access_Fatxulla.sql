insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'ACCOUNTING', 'Expence Claims Full List Access ', 8, false, (select id from permission where code='ACCOUNTING_EXPENSE_REPORT_LIST'), false,  'ACCOUNTING_MODULE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');