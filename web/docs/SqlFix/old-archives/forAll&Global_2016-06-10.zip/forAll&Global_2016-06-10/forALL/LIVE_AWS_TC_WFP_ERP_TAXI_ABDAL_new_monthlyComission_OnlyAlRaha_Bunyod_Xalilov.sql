select setval('"47229".monthly_commission_id_seq',(select max(id) from "47229".monthly_commission));

insert into "47229".monthly_commission(collection, commission, dailycollection, date, fuelpercentage, sorder, salary) values(0.00, 0.00, '0.00 TO 213.99', '2014-07-30', 15.00, 0, 500.00);