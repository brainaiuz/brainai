
insert into "anv".category(code, name, type, pensionable, forall) values('LEAVE_ENCHASHMENT','Leave Enchashment', 'Payment', true, true);