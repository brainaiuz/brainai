INSERT INTO pdfreference(code, name) VALUES('BATCH_RECEIVE_PAYMENT', 'Receive Payment');
INSERT INTO pdfreference(code, name) VALUES('BATCH_PAY_BILL', 'Pay Bill');