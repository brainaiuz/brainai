-- schema anv
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('_BENEFIT_TYPE', '',  '_BENEFIT_TYPE', null,null );
INSERT INTO "anv".reference( code, description, name, sorder, parentid) VALUES ('CASH', '', 'Cash', 1, (select id from "anv".reference where code = '_BENEFIT_TYPE' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('NON_CASH', '',  'Non-Cash', 2, (select id from "anv".reference where code = '_BENEFIT_TYPE' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('CASH_AND_NON_CASH', '',  'Both', 3, (select id from "anv".reference where code = '_BENEFIT_TYPE' limit 1) );

INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('_BENEFIT_QTYTYPE', '',  '_BENEFIT_QTYTYPE', null,null );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('CURRENCY', '',  'Currency', 1, (select id from "anv".reference where code = '_BENEFIT_QTYTYPE' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('ITEMS', '',  'Items', 2, (select id from "anv".reference where code = '_BENEFIT_QTYTYPE' limit 1) );
INSERT INTO "anv".reference( code, description,  name, sorder, parentid) VALUES ('DAYS', '',  'Days', 3, (select id from "anv".reference where code = '_BENEFIT_QTYTYPE' limit 1) );





-- for schema 0
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('_BENEFIT_TYPE', '',  '_BENEFIT_TYPE', null,null );
INSERT INTO "0".reference( code, description, name, sorder, parentid) VALUES ('CASH', '', 'Cash', 1, (select id from "0".reference where code = '_BENEFIT_TYPE' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('NON_CASH', '',  'Non-Cash', 2, (select id from "0".reference where code = '_BENEFIT_TYPE' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('CASH_AND_NON_CASH', '',  'Both', 3, (select id from "0".reference where code = '_BENEFIT_TYPE' limit 1) );

INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('_BENEFIT_QTYTYPE', '',  '_BENEFIT_QTYTYPE', null,null );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('CURRENCY', '',  'Currency', 1, (select id from "0".reference where code = '_BENEFIT_QTYTYPE' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('ITEMS', '',  'Items', 2, (select id from "0".reference where code = '_BENEFIT_QTYTYPE' limit 1) );
INSERT INTO "0".reference( code, description,  name, sorder, parentid) VALUES ('DAYS', '',  'Days', 3, (select id from "0".reference where code = '_BENEFIT_QTYTYPE' limit 1) );