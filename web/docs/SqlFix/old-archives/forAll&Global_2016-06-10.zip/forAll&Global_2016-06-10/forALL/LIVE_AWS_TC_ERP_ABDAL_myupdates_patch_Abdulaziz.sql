insert into myupdatetype (code, description, parentid) values('PANEL_SETTING', 'Listing Panel related updates', null);
insert into myupdatetype (code, description, parentid) values('PANEL_SETTING_EDIT', 'Listing Panel Edited', (select id from myupdatetype where code='PANEL_SETTING'));
