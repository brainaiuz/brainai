update smsSettings s set keyvalues = 'username='||coalesce(s.username,'')||';'||'password='||coalesce(s.userpassword,'')||';'||coalesce(s.keyvalues,'');
