insert into "anv".reference (code, name, description) values ('_BENEFIT_REQUEST_STATUSES', 'Benefit Request Statuses', 'Statuses of Benefit Requests');
insert into "anv".reference (code, name, description, parentid, sorder) values ('BR_WAITING_FOR_APPROVAL', 'Waiting for approval', 'Waiting for approval', (select id from "anv".reference r where r.code = '_BENEFIT_REQUEST_STATUSES'), 1);
insert into "anv".reference (code, name, description, parentid, sorder) values ('BR_APPROVED', 'Approved', 'Approved', (select id from "anv".reference r where r.code = '_BENEFIT_REQUEST_STATUSES'), 2);
insert into "anv".reference (code, name, description, parentid, sorder) values ('BR_REJECTED', 'Rejected', 'Rejected', (select id from "anv".reference r where r.code = '_BENEFIT_REQUEST_STATUSES'), 3);


insert into "0".reference (code, name, description) values ('_BENEFIT_REQUEST_STATUSES', 'Benefit Request Statuses', 'Statuses of Benefit Requests');
insert into "0".reference (code, name, description, parentid, sorder) values ('BR_WAITING_FOR_APPROVAL', 'Waiting for approval', 'Waiting for approval', (select id from "0".reference r where r.code = '_BENEFIT_REQUEST_STATUSES'), 1);
insert into "0".reference (code, name, description, parentid, sorder) values ('BR_APPROVED', 'Approved', 'Approved', (select id from "0".reference r where r.code = '_BENEFIT_REQUEST_STATUSES'), 2);
insert into "0".reference (code, name, description, parentid, sorder) values ('BR_REJECTED', 'Rejected', 'Rejected', (select id from "0".reference r where r.code = '_BENEFIT_REQUEST_STATUSES'), 3);
