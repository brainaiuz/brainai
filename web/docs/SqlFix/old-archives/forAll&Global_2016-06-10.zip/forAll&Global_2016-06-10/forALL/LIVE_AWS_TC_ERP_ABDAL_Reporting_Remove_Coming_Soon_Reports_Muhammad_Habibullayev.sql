
  DELETE FROM "anv".rolepermission WHERE id IN (
    SELECT rp.id FROM "anv".rolepermission AS rp
    JOIN "anv".reporting AS r ON rp.permissioncode = r.permissioncode and r.fakereport IS TRUE  AND r.targetlink NOT LIKE '%#%'
  );

  DELETE FROM permission WHERE id IN (
    SELECT p.id FROM permission AS p
    JOIN "anv".reporting AS r ON p.code = r.permissioncode AND r.fakereport IS TRUE  AND r.targetlink NOT LIKE '%#%'
  );


UPDATE "anv".reporting SET deleted = TRUE, code = code||'###'||id WHERE fakereport IS TRUE AND targetlink NOT LIKE '%#%';
