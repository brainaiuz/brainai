------ For zero


INSERT INTO "0".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Certificate of employment', (SELECT id from "0".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
<table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
	<tbody>
		<tr>
			<td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
		</tr>
		<tr>
			<td>
			<table align="left" border="0" cellpadding="10" cellspacing="0" height="120" style="border: 1px solid rgb(221, 221, 221);" width="35%">
				<tbody>
					<tr>
						<th align="left" height="120" valign="top" width="30"><span style="font-family:times new roman,times,serif;"><label style="font-size: 14px;">From: </label></span></th>
						<td style="font-size: 12px;" valign="top"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${companyname},<br />
						${companyaddress}</span></span></td>
					</tr>
				</tbody>
			</table>

			<table align="right" border="0" cellpadding="10" cellspacing="0" height="120" style="border: 1px solid rgb(221, 221, 221);" width="35%">
				<tbody>
					<tr>
						<th align="left" height="120" valign="top" width="30"><span style="font-family:times new roman,times,serif;"><label for="hrCert_to" style="font-size: 14px;">To: </label></span></th>
						<td style="font-size: 12px;" valign="top"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">$$input:textarea1$$</span></span></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<td style="color: rgb(187, 187, 187);"><span style="font-family:times new roman,times,serif;">Date: ${currentdate}</span></td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td>
			<h1 style="text-align: center; margin: 0pt; font: bold 28px/1.4 Arial;"><span style="font-family:times new roman,times,serif;">Certificate of Employment</span></h1>
			</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td align="left"><span style="font-size:16px;"><span style="font-family: times new roman,times,serif;"><span style="line-height: 1.6;">This is to certify that&nbsp; ${firstname} ${lastname}, Passport <strong>No.${passportnumber} </strong> and his monthly gross salary is <strong> ${currency} </strong>${salaryamount}. He is working in <strong>${companyname}</strong> as ${position} from<strong> </strong> ${hiredate} till this date. He wants to spend his annual vacation in the $$input:textbox1$$ for the purpose of tourism. </span></span></span><br />
			&nbsp;
			<p><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><small>This certificate is granted upon his/her request and without any responsibility on the part of <strong>${companyname}</strong>.</small></span></span></p>
			</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Regards,</span></span>

			<table border="0" cellpadding="0" cellspacing="0" width="30%">
				<tbody>
					<tr>
						<td style="padding-bottom: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourname}</span></span></td>
					</tr>
					<tr>
						<td style="border-top: 1px solid rgb(221, 221, 221); padding-top: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourrole}</strong></span></span></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "0".certificateofemploymenttype WHERE name='Certificate of employment' and deleted is not true
    );



-------For All
INSERT INTO "anv".certificateofemploymenttype
    (name, type, defaulthtml, deleted)
SELECT 'Certificate of employment', (SELECT id from "anv".reference  where code='CERTIFICATE_TEMPLATE_TYPE'),
'<div class="mainStyle_reset">
<table cellpadding="10" cellspacing="0" class="section" id="table" width="700">
	<tbody>
		<tr>
			<td class="space_y" style="font: 20px/20px Arial;">&nbsp;</td>
		</tr>
		<tr>
			<td>
			<table align="left" border="0" cellpadding="10" cellspacing="0" height="120" style="border: 1px solid rgb(221, 221, 221);" width="35%">
				<tbody>
					<tr>
						<th align="left" height="120" valign="top" width="30"><span style="font-family:times new roman,times,serif;"><label style="font-size: 14px;">From: </label></span></th>
						<td style="font-size: 12px;" valign="top"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${companyname},<br />
						${companyaddress}</span></span></td>
					</tr>
				</tbody>
			</table>

			<table align="right" border="0" cellpadding="10" cellspacing="0" height="120" style="border: 1px solid rgb(221, 221, 221);" width="35%">
				<tbody>
					<tr>
						<th align="left" height="120" valign="top" width="30"><span style="font-family:times new roman,times,serif;"><label for="hrCert_to" style="font-size: 14px;">To: </label></span></th>
						<td style="font-size: 12px;" valign="top"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">$$input:textarea1$$</span></span></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
		<tr>
			<td style="color: rgb(187, 187, 187);"><span style="font-family:times new roman,times,serif;">Date: ${currentdate}</span></td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td>&nbsp;</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td>
			<h1 style="text-align: center; margin: 0pt; font: bold 28px/1.4 Arial;"><span style="font-family:times new roman,times,serif;">Certificate of Employment</span></h1>
			</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td align="left"><span style="font-size:16px;"><span style="font-family: times new roman,times,serif;"><span style="line-height: 1.6;">This is to certify that&nbsp; ${firstname} ${lastname}, Passport <strong>No.${passportnumber} </strong> and his monthly gross salary is <strong> ${currency} </strong>${salaryamount}. He is working in <strong>${companyname}</strong> as ${position} from<strong> </strong> ${hiredate} till this date. He wants to spend his annual vacation in the $$input:textbox1$$ for the purpose of tourism. </span></span></span><br />
			&nbsp;
			<p><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><small>This certificate is granted upon his/her request and without any responsibility on the part of <strong>${companyname}</strong>.</small></span></span></p>
			</td>
		</tr>
	</tbody>
</table>

<table cellpadding="10" cellspacing="0" class="section" width="700">
	<tbody>
		<tr>
			<td><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">Regards,</span></span>

			<table border="0" cellpadding="0" cellspacing="0" width="30%">
				<tbody>
					<tr>
						<td style="padding-bottom: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;">${yourname}</span></span></td>
					</tr>
					<tr>
						<td style="border-top: 1px solid rgb(221, 221, 221); padding-top: 4px;"><span style="font-size:14px;"><span style="font-family: times new roman,times,serif;"><strong>${yourrole}</strong></span></span></td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
</div>', false
WHERE
    NOT EXISTS (
        SELECT id FROM "anv".certificateofemploymenttype WHERE name='Certificate of employment' and deleted is not true
    );