delete from "0".reference where name = 'Reminder template (for Employee)';
delete from "0".reference where name = 'Reminder template (for Managers)';

insert into "0".emailtemplate (deleted,fromuserid,iscompanyemailtemplate,isdefault,messagehtml,
name,subject,categoryid,fromusername,module_id)
values (false,-1,'COMPANY_EMAIL_TEMPLATE',false,'${receiverFullName} ,<br /> Please be advised that you have ${remindertype} on ${reminderfieldvalue}.',
'Reminder template (for Employee)','Your ${remindertype} reminder',(select id from "0".reference where code='_HR_REMINDERS_CATEGORY'),'Current User',(select id from "0".reference where code='_SYSTEM_REMINDERS_MODULE'));

insert into "0".emailtemplate (deleted,fromuserid,iscompanyemailtemplate,isdefault,messagehtml,
name,subject,categoryid,fromusername,module_id)
values (false,-1,'COMPANY_EMAIL_TEMPLATE',false,'${receiverFullName} ,<br/><br/> Please be advised that the following employees have ${remindertype} on ${reminderfieldvalue}.<br/><br/> ${reminderemployees}.',
'Reminder template (for Managers)','${remindertype} reminder',(select id from "0".reference where code='_HR_REMINDERS_CATEGORY'),'Current User',(select id from "0".reference where code='_SYSTEM_REMINDERS_MODULE'));