



insert into companypdffonts(file_name, font_name) values('dejavusans.ttf', 'DejaVu Sans');