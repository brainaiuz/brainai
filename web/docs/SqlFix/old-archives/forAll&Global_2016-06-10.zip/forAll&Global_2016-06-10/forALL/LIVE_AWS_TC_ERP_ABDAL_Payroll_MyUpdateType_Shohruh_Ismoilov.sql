insert into myupdatetype (code, description) values ('SINGLE_PAYRUN', 'All single payrun related updates');
insert into myupdatetype (code, description, parentid) values ('SINGLE_PAYRUN_ADD',     'Records when user has added single payrun',     (select id from myupdatetype where code='SINGLE_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('SINGLE_PAYRUN_EDIT',    'Records when user has edited single payrun',    (select id from myupdatetype where code='SINGLE_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('SINGLE_PAYRUN_DELETE',  'Records when user has deleted single payrun',   (select id from myupdatetype where code='SINGLE_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('SINGLE_PAYRUN_SUBMIT',  'Records when user has submitted single payrun', (select id from myupdatetype where code='SINGLE_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('SINGLE_PAYRUN_APPROVE', 'Records when user has aproved single payrun',   (select id from myupdatetype where code='SINGLE_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('SINGLE_PAYRUN_REJECT',  'Records when user has rejevted single payrun',  (select id from myupdatetype where code='SINGLE_PAYRUN'));

insert into myupdatetype (code, description) values ('GROUP_PAYRUN', 'All group payrun related updates');
insert into myupdatetype (code, description, parentid) values ('GROUP_PAYRUN_ADD',      'Records when user has added group payrun',     (select id from myupdatetype where code='GROUP_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('GROUP_PAYRUN_EDIT',     'Records when user has edited group payrun',    (select id from myupdatetype where code='GROUP_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('GROUP_PAYRUN_DELETE',   'Records when user has deleted group payrun',   (select id from myupdatetype where code='GROUP_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('GROUP_PAYRUN_SUBMIT',   'Records when user has submitted group payrun', (select id from myupdatetype where code='GROUP_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('GROUP_PAYRUN_APPROVE',  'Records when user has aproved group payrun',   (select id from myupdatetype where code='GROUP_PAYRUN'));
insert into myupdatetype (code, description, parentid) values ('GROUP_PAYRUN_REJECT',   'Records when user has rejevted group payrun',  (select id from myupdatetype where code='GROUP_PAYRUN'));

insert into myupdatetype (code, description) values ('CASH_ADVANCE', 'All cash advance related updates');
insert into myupdatetype (code, description, parentid) values ('CASH_ADVANCE_ADD',      'Records when user has added cash advance',     (select id from myupdatetype where code='CASH_ADVANCE'));
insert into myupdatetype (code, description, parentid) values ('CASH_ADVANCE_EDIT',     'Records when user has edited cash advance',    (select id from myupdatetype where code='CASH_ADVANCE'));
insert into myupdatetype (code, description, parentid) values ('CASH_ADVANCE_DELETE',   'Records when user has deleted cash advance',   (select id from myupdatetype where code='CASH_ADVANCE'));
insert into myupdatetype (code, description, parentid) values ('CASH_ADVANCE_SUBMIT',   'Records when user has submitted cash advance', (select id from myupdatetype where code='CASH_ADVANCE'));
insert into myupdatetype (code, description, parentid) values ('CASH_ADVANCE_APPROVE',  'Records when user has aproved cash advance',   (select id from myupdatetype where code='CASH_ADVANCE'));
insert into myupdatetype (code, description, parentid) values ('CASH_ADVANCE_REJECT',   'Records when user has rejevted cash advance',  (select id from myupdatetype where code='CASH_ADVANCE'));

insert into myupdatetype (code, description) values ('PENSION_SCHEME', 'All pension scheme related updates');
insert into myupdatetype (code, description, parentid) values ('PENSION_SCHEME_ADD',      'Records when user has added pension scheme',     (select id from myupdatetype where code='PENSION_SCHEME'));
insert into myupdatetype (code, description, parentid) values ('PENSION_SCHEME_EDIT',     'Records when user has edited pension scheme',    (select id from myupdatetype where code='PENSION_SCHEME'));

insert into myupdatetype (code, description) values ('END_OF_SERVICE_SETTINGS', 'All end of service settings related updates');
insert into myupdatetype (code, description, parentid) values ('END_OF_SERVICE_SETTINGS_EDIT',     'Records when user has edited end of service settings',    (select id from myupdatetype where code='END_OF_SERVICE_SETTINGS'));
