
insert into "anv".category(code, name, type, pensionable, forall) values('ADDITIONAL_PAYMENT','Additional Payment', 'Payment', true, true);