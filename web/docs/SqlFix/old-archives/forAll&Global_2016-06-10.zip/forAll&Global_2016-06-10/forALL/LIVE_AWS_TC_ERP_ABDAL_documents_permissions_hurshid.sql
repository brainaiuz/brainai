--for HRMS, schema anv
delete from permission where code in ('EMPLOYEE_DOCUMENTS_LIST', 'UPLOAD_EMPLOYEE_DOCUMENTS', 'EDIT_EMPLOYEE_DOCUMENTS', 'REMOVE_EMPLOYEE_DOCUMENTS', 'COMPANY_DOCUMENTS_LIST', 'UPLOAD_COMPANY_DOCUMENTS', 'EDIT_COMPANY_DOCUMENTS', 'REMOVE_COMPANY_DOCUMENTS');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('EMPLOYEE_DOCUMENTS_LIST', 'HRMS', 'Employee documents list', 12, false, (select id from permission where code='HRMS_SECTION_TAB'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'HRMS', 'View all documents', 1, false, (select id from permission where code='EMPLOYEE_DOCUMENTS_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'HRMS', 'Upload document', 2, false, (select id from permission where code='EMPLOYEE_DOCUMENTS_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('EDIT_EMPLOYEE_DOCUMENTS', 'HRMS', 'Edit document', 3, false, (select id from permission where code='EMPLOYEE_DOCUMENTS_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('REMOVE_EMPLOYEE_DOCUMENTS', 'HRMS', 'Remove document', 4, false, (select id from permission where code='EMPLOYEE_DOCUMENTS_LIST'), false,  'HRMS_MODULE');

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('COMPANY_DOCUMENTS_LIST', 'HRMS', 'Company documents list', 13, false, (select id from permission where code='HRMS_SECTION_TAB'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('UPLOAD_COMPANY_DOCUMENTS', 'HRMS', 'Upload document', 1, false, (select id from permission where code='COMPANY_DOCUMENTS_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('EDIT_COMPANY_DOCUMENTS', 'HRMS', 'Edit document', 2, false, (select id from permission where code='COMPANY_DOCUMENTS_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('REMOVE_COMPANY_DOCUMENTS', 'HRMS', 'Remove document', 3, false, (select id from permission where code='COMPANY_DOCUMENTS_LIST'), false,  'HRMS_MODULE');

delete from "anv".rolepermission where permissioncode in ('EMPLOYEE_DOCUMENTS_LIST', 'UPLOAD_EMPLOYEE_DOCUMENTS', 'EDIT_EMPLOYEE_DOCUMENTS', 'REMOVE_EMPLOYEE_DOCUMENTS', 'COMPANY_DOCUMENTS_LIST', 'UPLOAD_COMPANY_DOCUMENTS', 'EDIT_COMPANY_DOCUMENTS', 'REMOVE_COMPANY_DOCUMENTS');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_EMPLOYEE_DOCUMENTS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_EMPLOYEE_DOCUMENTS', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('UPLOAD_COMPANY_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('UPLOAD_COMPANY_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('UPLOAD_COMPANY_DOCUMENTS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_COMPANY_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_COMPANY_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_COMPANY_DOCUMENTS', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_COMPANY_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_COMPANY_DOCUMENTS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_COMPANY_DOCUMENTS', 'HR', 'ALLOW');


--For schema 0
delete from "0".rolepermission where permissioncode in ('EMPLOYEE_DOCUMENTS_LIST', 'UPLOAD_EMPLOYEE_DOCUMENTS', 'EDIT_EMPLOYEE_DOCUMENTS', 'REMOVE_EMPLOYEE_DOCUMENTS', 'COMPANY_DOCUMENTS_LIST', 'UPLOAD_COMPANY_DOCUMENTS', 'EDIT_COMPANY_DOCUMENTS', 'REMOVE_COMPANY_DOCUMENTS');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EMPLOYEE_DOCUMENTS_LIST', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('VIEW_ALL_EMPLOYEE_DOCUMENTS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('UPLOAD_EMPLOYEE_DOCUMENTS', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_EMPLOYEE_DOCUMENTS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_EMPLOYEE_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_EMPLOYEE_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_EMPLOYEE_DOCUMENTS', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('COMPANY_DOCUMENTS_LIST', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('UPLOAD_COMPANY_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('UPLOAD_COMPANY_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('UPLOAD_COMPANY_DOCUMENTS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_COMPANY_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_COMPANY_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_COMPANY_DOCUMENTS', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_COMPANY_DOCUMENTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_COMPANY_DOCUMENTS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_COMPANY_DOCUMENTS', 'HR', 'ALLOW');