insert into pdfreference (code,name) values('ATTENDANCE_TRACKING', 'Attendance Tracking');
---------------------------------anv schema----------------------------------------------------
insert into "anv".pdftemplate (content, typeid) values('<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style type="text/css">
	@page
	{
            size: 12in 8.3in;
            padding: 0;
			margin: 70px 5px;

    }
	table.attendance-report-table
	{
		border-color: rgb(63, 98, 154);
		border-width: 0px 0px 1px 0px;
		border-style: solid;
		width:1100px;
	}
	table.attendance-report-table tr{
		page-break-inside:avoid;

	}
	body {
		font-family: Arial,Helvetica,sans-serif;
		font-size: 10px;
	}

	table.attendance-report-table td.label-
	{
		width: 130px;
		color: rgb(63, 98, 154);
		font-weight: bold;
		vertical-align: middle;
		padding: 2px 15px 2px 10px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 1px;
		border-style: solid;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
		font-size:11px;
	}
	table.attendance-report-table td.without-lr-unauth
	{
		color: rgb(242, 213, 3);
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(193, 0, 1);
		overflow: hidden;
	}
	table.attendance-report-table td.inhour-overtime
	{
		color: black;
		font-weight: bold;
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.total-absent
	{
		color: white;
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(121, 167, 229);
		overflow: hidden;
	}
	table.attendance-report-table td.total-with-lr-column
	{
		color: black;
		font-weight: bold;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.sample-column {
		width: 25px;
		height: 16px;
		color: black;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.without-lr
	{
		color: rgb(0, 0, 0);
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(255, 249, 34);
		overflow: hidden;
	}
	table.attendance-report-table td.with-lr
	{
		color: black;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(146, 208, 81);
		overflow: hidden;
	}
	table.attendance-report-table td.total-month-column, table.attendance-report-table td.total-without-lr-column
	{
		color: black;
		font-weight: bold;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.total-month-title
	{
		color: white;
		font-weight: bold;
		font-size:10px;
		text-align: center;
		vertical-align: middle;
		padding: 3px 2px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(121, 167, 229);
		overflow: hidden;
		font-size:10px;
	}
	table.attendance-report-table td.column-title
	{
		color: rgb(63, 98, 154);
		font-weight: bold;
		text-align: center;
		vertical-align: middle;
		padding: 3px 2px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
	}
	table.attendance-report-table td.month-name
	{
		color: rgb(63, 98, 154);
		font-size: 10px;
		font-weight: bold;
		text-align: center;
		vertical-align: middle;
		border-style: solid;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
	}
	th, td {
		border: 0px none;
		font-size:11px;
		text-align: center;
	}
	table.attendance-report-table td.l-title
	{
		color: black;
		font-weight: bold;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 1px 0px;
		border-style: solid;
		background-color: rgb(146, 208, 81);
		overflow: hidden;
	}

	table.attendance-report-table td.waitingForApproval
	{
		color: black;
		font-weight: bold;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 1px 0px;
		border-style: solid;
		background-color: rgb(255, 249, 34);
		overflow: hidden;
	}

	table.attendance-report-table td.a-title
	{
		color: rgb(242, 213, 3);
		font-weight: bold;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 1px 0px;
		border-style: solid;
		background-color: rgb(193, 0, 1);
		position: relative;
		overflow: hidden;
	}
	table.attendance-report-table td.month-day
	{
		width: 25px;
		height: 16px;
		color: black;
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(216, 216, 216);
		overflow: hidden;
	}
	table.attendance-report-table td.work-month-holiday
	{
		height: 16px;
		width: 25px;
		color: black;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(149, 179, 215);
		overflow: hidden;
	}

	table.attendance-report-table td.employee-name
	{
		width: 130px;
		color: black;
		vertical-align: middle;
		padding: 2px 5px 2px 10px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 1px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}

	table.attendance-report-table td.month-sunday {
		height: 16px;
		width: 25px;
		color: black;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(194, 215, 155);
		overflow: hidden;
	}
	table.attendance-report-table td.current-day
	{
		height: 16px;
		width: 25px;
		color: white;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(25, 70, 138);
		overflow: hidden;
	}
	table.attendance-report-table td.employee-label-month-day
	{
		width: 25px;
		height: 16px;
		color: rgb(63, 98, 154);
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
	}
	table.attendance-report-table td.sample-in-out-hours
	{
		height: 16px;
		width: 20px;
		font-size: 7pt;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
    </style>
</head>
<body>
$itextGenericPdfData.userData.position
</body>
</html>', (select id from pdfreference where code='ATTENDANCE_TRACKING'));


insert into "anv".companypdftemplate (defaulttemplate, fontfamily, name, templateid) values(true, 'arial.ttf', 'Attendance Tracking', (select id from "anv".pdftemplate where typeid=(select id from pdfreference where code='ATTENDANCE_TRACKING')));


------------------------------ZERO SCHEMA---------------------------------------

insert into "0".pdftemplate (content, typeid) values('<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style type="text/css">
	@page
	{
            size: 12in 8.3in;
            padding: 0;
			margin: 70px 5px;

    }
	table.attendance-report-table
	{
		border-color: rgb(63, 98, 154);
		border-width: 0px 0px 1px 0px;
		border-style: solid;
		width:1100px;
	}
	table.attendance-report-table tr{
		page-break-inside:avoid;

	}
	body {
		font-family: Arial,Helvetica,sans-serif;
		font-size: 10px;
	}

	table.attendance-report-table td.label-
	{
		width: 130px;
		color: rgb(63, 98, 154);
		font-weight: bold;
		vertical-align: middle;
		padding: 2px 15px 2px 10px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 1px;
		border-style: solid;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
		font-size:11px;
	}
	table.attendance-report-table td.without-lr-unauth
	{
		color: rgb(242, 213, 3);
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(193, 0, 1);
		overflow: hidden;
	}
	table.attendance-report-table td.inhour-overtime
	{
		color: black;
		font-weight: bold;
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.total-absent
	{
		color: white;
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(121, 167, 229);
		overflow: hidden;
	}
	table.attendance-report-table td.total-with-lr-column
	{
		color: black;
		font-weight: bold;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.sample-column {
		width: 25px;
		height: 16px;
		color: black;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.without-lr
	{
		color: rgb(0, 0, 0);
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(255, 249, 34);
		overflow: hidden;
	}
	table.attendance-report-table td.with-lr
	{
		color: black;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(146, 208, 81);
		overflow: hidden;
	}
	table.attendance-report-table td.total-month-column, table.attendance-report-table td.total-without-lr-column
	{
		color: black;
		font-weight: bold;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
	table.attendance-report-table td.total-month-title
	{
		color: white;
		font-weight: bold;
		font-size:10px;
		text-align: center;
		vertical-align: middle;
		padding: 3px 2px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(121, 167, 229);
		overflow: hidden;
		font-size:10px;
	}
	table.attendance-report-table td.column-title
	{
		color: rgb(63, 98, 154);
		font-weight: bold;
		text-align: center;
		vertical-align: middle;
		padding: 3px 2px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
	}
	table.attendance-report-table td.month-name
	{
		color: rgb(63, 98, 154);
		font-size: 10px;
		font-weight: bold;
		text-align: center;
		vertical-align: middle;
		border-style: solid;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
	}
	th, td {
		border: 0px none;
		font-size:11px;
		text-align: center;
	}
	table.attendance-report-table td.l-title
	{
		color: black;
		font-weight: bold;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 1px 0px;
		border-style: solid;
		background-color: rgb(146, 208, 81);
		overflow: hidden;
	}

	table.attendance-report-table td.waitingForApproval
	{
		color: black;
		font-weight: bold;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 1px 0px;
		border-style: solid;
		background-color: rgb(255, 249, 34);
		overflow: hidden;
	}

	table.attendance-report-table td.a-title
	{
		color: rgb(242, 213, 3);
		font-weight: bold;
		text-align: center;
		text-transform: uppercase;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 1px 0px;
		border-style: solid;
		background-color: rgb(193, 0, 1);
		position: relative;
		overflow: hidden;
	}
	table.attendance-report-table td.month-day
	{
		width: 25px;
		height: 16px;
		color: black;
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(216, 216, 216);
		overflow: hidden;
	}
	table.attendance-report-table td.work-month-holiday
	{
		height: 16px;
		width: 25px;
		color: black;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(149, 179, 215);
		overflow: hidden;
	}

	table.attendance-report-table td.employee-name
	{
		width: 130px;
		color: black;
		vertical-align: middle;
		padding: 2px 5px 2px 10px;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 1px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}

	table.attendance-report-table td.month-sunday {
		height: 16px;
		width: 25px;
		color: black;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(194, 215, 155);
		overflow: hidden;
	}
	table.attendance-report-table td.current-day
	{
		height: 16px;
		width: 25px;
		color: white;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(25, 70, 138);
		overflow: hidden;
	}
	table.attendance-report-table td.employee-label-month-day
	{
		width: 25px;
		height: 16px;
		color: rgb(63, 98, 154);
		text-align: center;
		vertical-align: middle;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: rgb(187, 222, 250);
		overflow: hidden;
	}
	table.attendance-report-table td.sample-in-out-hours
	{
		height: 16px;
		width: 20px;
		font-size: 7pt;
		vertical-align: middle;
		text-align: center;
		border-color: rgb(63, 98, 154);
		border-width: 1px 1px 0px 0px;
		border-style: solid;
		background-color: white;
		overflow: hidden;
	}
    </style>
</head>
<body>
$itextGenericPdfData.userData.position
</body>
</html>', (select id from pdfreference where code='ATTENDANCE_TRACKING'));

insert into "0".companypdftemplate (defaulttemplate, fontfamily, name, templateid) values(true, 'arial.ttf', 'Attendance Tracking', (select id from "0".pdftemplate where typeid=(select id from pdfreference where code='ATTENDANCE_TRACKING')));