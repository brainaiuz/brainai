
update "anv".employeeprofile ep set employeeCode=(select e.employeeCode from "anv".employee e where ep.id=e.profileid) where ep.employeeCode is null or ep.employeeCode='';
update "anv".employeeprofile ep set intnumber=(select e.intnumber from "anv".employee e where ep.id=e.profileid) where ep.intnumber is null;