UPDATE "0".reference SET name = 'Sent' WHERE code = 'ONSUCCESS' AND parentid = (SELECT id FROM "0".reference WHERE code = '_SEND_LEAD_MESSAGE_STATUS');
UPDATE "0".reference SET name = 'Failed' WHERE code = 'ONFAILURE' AND parentid = (SELECT id FROM "0".reference WHERE code = '_SEND_LEAD_MESSAGE_STATUS');
UPDATE "0".reference SET name = 'Bounced' WHERE code = 'ONBOUNCE' AND parentid = (SELECT id FROM "0".reference WHERE code = '_SEND_LEAD_MESSAGE_STATUS');

UPDATE "anv".reference SET name = 'Sent' WHERE code = 'ONSUCCESS' AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SEND_LEAD_MESSAGE_STATUS');
UPDATE "anv".reference SET name = 'Failed' WHERE code = 'ONFAILURE' AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SEND_LEAD_MESSAGE_STATUS');
UPDATE "anv".reference SET name = 'Bounced' WHERE code = 'ONBOUNCE' AND parentid = (SELECT id FROM "anv".reference WHERE code = '_SEND_LEAD_MESSAGE_STATUS');