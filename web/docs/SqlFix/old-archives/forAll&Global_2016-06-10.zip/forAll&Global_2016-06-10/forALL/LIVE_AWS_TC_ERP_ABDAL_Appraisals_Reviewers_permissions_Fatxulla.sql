insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_APPRAISALS_REVIEWER', 'HRMS', 'Appraisals Reviewer(s)', 2, false, (select id from permission where code='HRMS_SIMPLE_APPRAISALS'), false,  'HRMS_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'TL', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_APPRAISALS_REVIEWER', 'TL', 'ALLOW');



