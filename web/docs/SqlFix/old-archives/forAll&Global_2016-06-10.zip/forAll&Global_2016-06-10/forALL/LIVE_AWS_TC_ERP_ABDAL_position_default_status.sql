
update "anv".position set status=(select id from "anv".reference where code='POS_STATUS_ACTIVE') where status is null;
