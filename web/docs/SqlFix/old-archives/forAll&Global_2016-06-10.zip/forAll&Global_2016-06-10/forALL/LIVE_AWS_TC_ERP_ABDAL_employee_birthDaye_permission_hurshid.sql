
delete from permission where code in ('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'PM_SHOW_EMPLOYEE_BIRTH_DAY');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'HRMS', 'Show Employee Birth Day', 6, false, (select id from permission where code='HRMS_EMPLOYEE_PROFILE'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'PM', 'Show Employee Birth Day', 19, false, (select id from permission where code='PM_EMPLOYEE_LIST'), false,  'PM');

delete from "0".rolepermission where permissioncode in ('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'PM_SHOW_EMPLOYEE_BIRTH_DAY');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'MEM', 'ALLOW');


--anv
delete from "anv".rolepermission where permissioncode in ('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'PM_SHOW_EMPLOYEE_BIRTH_DAY');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SHOW_EMPLOYEE_BIRTH_DAY', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_SHOW_EMPLOYEE_BIRTH_DAY', 'MEM', 'ALLOW');