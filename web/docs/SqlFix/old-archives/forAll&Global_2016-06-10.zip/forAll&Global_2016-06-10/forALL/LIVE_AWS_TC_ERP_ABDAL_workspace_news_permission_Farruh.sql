
insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'WORKSPACE', 'f', 'Add news', '800', (select id from permission where code='WORKSPACE_MAIN_MENU'), 'WORKSPACE');

insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'WORKSPACE', 'f', 'Edit news', '801', (select id from permission where code='WORKSPACE_MAIN_MENU'), 'WORKSPACE');

----------anv
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_ADD', 'SALESPERSON', 'ALLOW');

----------anv
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'ADMIN_LOCATION', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('WORKSPACE_COMPANY_NEWS_EDIT', 'SALESPERSON', 'ALLOW');



