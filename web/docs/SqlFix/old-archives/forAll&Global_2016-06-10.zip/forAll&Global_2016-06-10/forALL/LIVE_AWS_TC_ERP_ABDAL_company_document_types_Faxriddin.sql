DELETE from "anv".reference where parentid = (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES');
DELETE from "anv".reference where code='_COMPANY_DOCUMENT_TYPES';
insert into "anv".reference (code, name, description) values ('_COMPANY_DOCUMENT_TYPES', 'Company Document Types', 'Company Document Types');
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_PASSPORT', 'Passport', 'Passport', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 1);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_WORK_PERMIT', 'Work permit', 'Work permit', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 2);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_VISA', 'Visa', 'Visa', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 3);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_MEDICAL', 'Medical', 'Medical', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 4);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_INSURANCE', 'Insurance', 'Insurance', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 5);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_LABOUR_CARD', 'Labour card', 'Labour card', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 6);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_RESIDENCE_PERMIT', 'Residence permit', 'Residence permit', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 7);
insert into "anv".reference (code, name, description, parentid, sorder) values ('COM_DT_EMPLOYEMENT_CONTRACT', 'Employment contract', 'Employment contract', (select id from "anv".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 8);


DELETE from "0".reference where parentid = (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES');
DELETE from "0".reference where code='_COMPANY_DOCUMENT_TYPES';
insert into "0".reference (code, name, description) values ('_COMPANY_DOCUMENT_TYPES', 'Company Document Types', 'Company Document Types');
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_PASSPORT', 'Passport', 'Passport', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 1);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_WORK_PERMIT', 'Work permit', 'Work permit', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 2);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_VISA', 'Visa', 'Visa', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 3);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_MEDICAL', 'Medical', 'Medical', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 4);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_INSURANCE', 'Insurance', 'Insurance', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 5);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_LABOUR_CARD', 'Labour card', 'Labour card', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 6);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_RESIDENCE_PERMIT', 'Residence permit', 'Residence permit', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 7);
insert into "0".reference (code, name, description, parentid, sorder) values ('COM_DT_EMPLOYEMENT_CONTRACT', 'Employment contract', 'Employment contract', (select id from "0".reference r where r.code = '_COMPANY_DOCUMENT_TYPES'), 8);

