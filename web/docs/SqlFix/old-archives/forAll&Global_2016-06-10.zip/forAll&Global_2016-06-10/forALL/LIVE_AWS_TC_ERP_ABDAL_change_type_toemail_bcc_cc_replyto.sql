
ALTER TABLE message
ALTER COLUMN bcc TYPE text;

ALTER TABLE message
 ALTER COLUMN cc TYPE text;  

ALTER TABLE message
 ALTER COLUMN replyto TYPE text; 

ALTER TABLE message
 ALTER COLUMN toemail TYPE text;