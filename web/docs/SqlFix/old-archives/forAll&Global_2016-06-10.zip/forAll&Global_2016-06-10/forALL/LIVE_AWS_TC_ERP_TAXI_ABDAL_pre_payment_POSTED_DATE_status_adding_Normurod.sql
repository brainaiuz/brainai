--- for ZERO schema ---
insert into "0".reference (code, name, deleted, iscustombutton, isremovable, issystemreference, shared, sorder, parentid)
            values('POST_DATED', 'Post Dated', false, false, false, true, true, 2, (select id from "0".reference where code = 'INVOICEPAYMENT_STATUS'));

--- for All schema ---
insert into "anv".reference (code, name, deleted, iscustombutton, isremovable, issystemreference, shared, sorder, parentid)
            values('POST_DATED', 'Post Dated', false, false, false, true, true, 2, (select id from "anv".reference where code = 'INVOICEPAYMENT_STATUS'));
