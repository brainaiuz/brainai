-- schema updatedan kn urilsin

update "anv".location l set name = (select name from country where id = l.countryid)||''||
(CASE WHEN l.stateid is null THEN '' ELSE ','||(select name from region where id = l.stateid) END)||''||
(CASE WHEN l.city is null THEN '' ELSE ','||l.city END);