
update "anv".account set key=9995, accountcode='9995', codestring='9995'  where key=9998;