CREATE INDEX ON "anv".reference (code ASC NULLS LAST);
CREATE INDEX ON "anv".attendancerawdata (employeeid ASC NULLS LAST);