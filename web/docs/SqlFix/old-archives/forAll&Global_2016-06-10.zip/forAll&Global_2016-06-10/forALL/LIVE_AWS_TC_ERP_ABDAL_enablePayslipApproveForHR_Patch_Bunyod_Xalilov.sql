-- for zero schema
insert into "0".rolepermission (permissioncode,  rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'HR', 'ALLOW');

-- for company schema
insert into "anv".rolepermission (permissioncode,  rolecode, access) VALUES('PAYROLL_CAN_APPROVE_PAYSLIP', 'HR', 'ALLOW');