insert into permission(code, context, name, ismainmenu, parent, modulecode) values('PAYROLL_EMPLOYEE_APPROVAL', 'PAYROLL', 'Employee Approval', false, (select id from permission where code='PAYROLL'), 'PAYROLL');


insert into "0".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_APPROVAL', 'ADMIN');
insert into "0".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_APPROVAL', 'DR');


insert into "anv".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_APPROVAL', 'ADMIN');
insert into "anv".rolepermission(access, permissioncode, rolecode) values('ALLOW', 'PAYROLL_EMPLOYEE_APPROVAL', 'DR');