
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_LEAVE_REQUEST_REASON_LIST', 'SETTINGS', 'Leave Request Reson List', 8, false, (select id from permission where code='SETTINGS_HRMS_SETTINGS'), false, 'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_LEAVE_REQUEST_REASON_ADD_EDIT', 'SETTINGS', 'Leave Request Reson Add/Edit', 9, false, (select id from permission where code='SETTINGS_HRMS_SETTINGS'), false, 'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_ADD_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_ADD_EDIT', 'DR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_ADD_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUEST_REASON_ADD_EDIT', 'DR', 'ALLOW');
