-- For Zero Schema
INSERT INTO "0".mymodule(code) VALUES('RECURRING_BILLS');

-- For All Companies
INSERT INTO "anv".mymodule(code) VALUES('RECURRING_BILLS');