ALTER TABLE "0".trainingcontractcourse DROP CONSTRAINT if exists fk_iysxro0r9s0iglay2pq04yv91 CASCADE;
ALTER TABLE "0".trainingcontractcourse DROP CONSTRAINT if exists fk_t4xgv3ww90lso8cw0375vmpwn CASCADE;
UPDATE "0".trainingcontractcourse SET trainingcontractid = courseid, courseid = trainingcontractid;

ALTER TABLE "anv".trainingcontractcourse DROP CONSTRAINT if exists fk_iysxro0r9s0iglay2pq04yv91 CASCADE;
ALTER TABLE "anv".trainingcontractcourse DROP CONSTRAINT if exists fk_t4xgv3ww90lso8cw0375vmpwn CASCADE;
UPDATE "anv".trainingcontractcourse SET trainingcontractid = courseid, courseid = trainingcontractid;

