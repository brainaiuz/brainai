

delete from modelfield where section='ONBOARDING_STEP_EMPLOYEES' and form_id = 'ONBOARDING_STEP_FORM';
delete from "anv".modelfield where section='ONBOARDING_STEP_EMPLOYEES' and form_id = 'ONBOARDING_STEP_FORM';
