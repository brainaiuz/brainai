DELETE FROM "0".rolepermission where permissioncode = 'ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF';
DELETE FROM "anv".rolepermission where permissioncode = 'ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF';
DELETE FROM permission where code = 'ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'ACCOUNTING', 'Expense Claim add to the staff', 7, false, (select id from permission where code='ACCOUNTING_EXPENSE_REPORT_LIST'), false, 'EXPENSE_REPORTING');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EXPENSE_REPORT_ADD_TO_STAFF', 'PM', 'ALLOW');