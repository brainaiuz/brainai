-- Don't run this patch on AWS
-- To'lqin had already done it

DELETE FROM "0".rolepermission where permissioncode = 'ACCOUNTING_TRANSACTION_MENU';
DELETE FROM "anv".rolepermission where permissioncode = 'ACCOUNTING_TRANSACTION_MENU';
DELETE FROM permission where code = 'ACCOUNTING_TRANSACTION_MENU';



insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values
   ('ACCOUNTING_TRANSACTION_MENU', 'ACCOUNTING', 'Transactions Menu', 2, false ,
   (select id from permission where code='ACCOUNTING_MAIN_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TRANSACTION_MENU', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TRANSACTION_MENU', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TRANSACTION_MENU', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TRANSACTION_MENU', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TRANSACTION_MENU', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TRANSACTION_MENU', 'ACCOUNTANT', 'ALLOW');


---update ordering

update permission set sorder = 3 where code='ACCOUNTING_ACCOUNTING_MENU';
update permission set sorder = 4 where code='ACCOUNTING_WAREHOUSE_MENU';
update permission set sorder = 5 where code='ACCOUNTING_REPORTS_MENU';
update permission set sorder = 6 where code='ACCOUNTING_SETTINGS_MENU';