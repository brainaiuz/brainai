alter table "anv".attendancerawdata drop column paid;
alter table "anv".attendancerawdata drop column fromAnnualLeave;
ALTER TABLE "anv".attendancerawdata DROP CONSTRAINT fk_31gn64cbv8vk5u7s9x1125t7h;