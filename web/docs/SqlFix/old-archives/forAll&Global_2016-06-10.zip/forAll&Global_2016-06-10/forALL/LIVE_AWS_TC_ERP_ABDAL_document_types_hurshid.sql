

insert into "anv".reference (code, name, description) values ('_DOCUMENT_TYPES', 'Document Types', 'Document Types');
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_PASSPORT', 'Passport', 'Passport', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 1);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_WORK_PERMIT', 'Work permit', 'Work permit', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 2);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_VISA', 'Visa', 'Visa', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 3);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_MEDICAL', 'Medical', 'Medical', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 4);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_INSURANCE', 'Insurance', 'Insurance', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 5);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_LABOUR_CARD', 'Labour card', 'Labour card', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 6);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_RESIDENCE_PERMIT', 'Residence permit', 'Residence permit', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 7);
insert into "anv".reference (code, name, description, parentid, sorder) values ('DT_EMPLOYEMENT_CONTRACT', 'Employment contract', 'Employment contract', (select id from "anv".reference r where r.code = '_DOCUMENT_TYPES'), 8);




insert into "0".reference (code, name, description) values ('_DOCUMENT_TYPES', 'Document Types', 'Document Types');
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_PASSPORT', 'Passport', 'Passport', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 1);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_WORK_PERMIT', 'Work permit', 'Work permit', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 2);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_VISA', 'Visa', 'Visa', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 3);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_MEDICAL', 'Medical', 'Medical', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 4);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_INSURANCE', 'Insurance', 'Insurance', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 5);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_LABOUR_CARD', 'Labour card', 'Labour card', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 6);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_RESIDENCE_PERMIT', 'Residence permit', 'Residence permit', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 7);
insert into "0".reference (code, name, description, parentid, sorder) values ('DT_EMPLOYEMENT_CONTRACT', 'Employment contract', 'Employment contract', (select id from "0".reference r where r.code = '_DOCUMENT_TYPES'), 8);

