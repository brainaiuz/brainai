insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('HRMS_ORGANIZATION_CHART_VIEW', 'HRMS', 'Organization Chart', 20, false,
  (select id from permission where code='HRMS_SECTION_TAB'), false, 'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ORGANIZATION_CHART_VIEW', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ORGANIZATION_CHART_VIEW', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ORGANIZATION_CHART_VIEW', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ORGANIZATION_CHART_VIEW', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ORGANIZATION_CHART_VIEW', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ORGANIZATION_CHART_VIEW', 'HR', 'ALLOW');