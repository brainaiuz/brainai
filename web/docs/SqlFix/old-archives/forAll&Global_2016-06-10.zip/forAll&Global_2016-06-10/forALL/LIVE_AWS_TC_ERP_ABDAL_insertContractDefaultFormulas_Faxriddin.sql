insert into "anv".contracttotalchargeformula  (formula_byHour,formula_byMonth,formula_byMarkup,formula_byMarkupAndOT,formula_byDayAndOT,formula_byDayAndOTSpec)
values
('_unitprice_*_unitqty_','_unitprice_*_unitqty_','_unitprice_*_unitqty_','_unitprice_*_unitqty_','_unitprice_*_unitqty_','_unitprice_*_unitqty_');