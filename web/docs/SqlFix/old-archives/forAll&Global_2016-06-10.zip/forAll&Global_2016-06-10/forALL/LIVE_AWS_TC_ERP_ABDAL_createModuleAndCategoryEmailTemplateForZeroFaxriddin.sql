delete from "0".reference where code = '_HR_REMINDERS_CATEGORY';
delete from "0".reference where code = '_SYSTEM_REMINDERS_MODULE';

INSERT INTO "0".reference(code, deleted, isremovable, issystemreference, name, shared, parentid, iscustombutton)
VALUES ('_SYSTEM_REMINDERS_MODULE', false, false, true, 'System reminders', false, (select r.id from "0".reference r where (r.code) = '_EMAIL_TEMPLATE_MODULE'), false);

INSERT INTO "0".reference(code, deleted, isremovable, issystemreference, name, shared, parentid, iscustombutton)
VALUES ('_HR_REMINDERS_CATEGORY', false, false, true, 'HR reminders', false,(select r.id from "0".reference r where (r.code) = '_SYSTEM_REMINDERS_MODULE'), false);
