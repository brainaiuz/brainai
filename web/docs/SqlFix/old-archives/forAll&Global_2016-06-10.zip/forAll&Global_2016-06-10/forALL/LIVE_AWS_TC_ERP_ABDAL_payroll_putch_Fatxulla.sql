delete from permission where code = 'PAYROLL_PAYSLIP_DELETE';
delete from permission where code = 'PAYROLL_PAYSLIP_UPDATE';
delete from permission where code = 'PAYROLL_PAYSLIP_VIEW';
delete from permission where code = 'PAYROLL_GROUP_PAYRUN_LIST';
delete from permission where code = 'PAYROLL_GROUP_PAYRUN_ADD';
delete from permission where code = 'PAYROLL_GROUP_PAYRUN_VIEW';
delete from permission where code = 'PAYROLL_GROUP_PAYRUN_EDIT';
delete from permission where code = 'PAYROLL_GROUP_PAYRUN_UPDATES';
delete from permission where code = 'END_OF_SERVICE_GRATUITY_LIST';
delete from permission where code = 'END_OF_SERVICE_GRATUITY_ADD';
delete from permission where code = 'END_OF_SERVICE_GRATUITY_EDIT';
delete from permission where code = 'END_OF_SERVICE_GRATUITY_DELETE';
delete from permission where code = 'PAYROLL_CASH_ADVANCE_LIST';
delete from permission where code = 'PAYROLL_CASH_ADVANCE_ADD';
delete from permission where code = 'PAYROLL_CASH_ADVANCE_VIEW';
delete from permission where code = 'PAYROLL_CASH_ADVANCE_EDIT';
delete from permission where code = 'PAYROLL_CASH_ADVANCE_DELETE';
delete from permission where code = 'PAYROLL_CASH_ADVANCE_UPDATES';
delete from permission where code = 'PAYROLL_WPS_REPORT';
delete from permission where code = 'PAYROLL_PENSION_CONTRIBUTION_REPORT';
delete from permission where code = 'PAYROLL_END_OF_SERVICE_REPORT';
delete from permission where code = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT';
delete from permission where code = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE';
delete from permission where code = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD';


insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_PAYSLIP_DELETE', 'PAYROLL', false, 'Delete Payrol', 3, (select id from permission where code ='PAYROLL_PAYSLIP_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_PAYSLIP_UPDATE', 'PAYROLL', false, 'Update Payrol', 4, (select id from permission where code ='PAYROLL_PAYSLIP_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_PAYSLIP_VIEW', 'PAYROLL', false, 'View Payrol', 4, (select id from permission where code ='PAYROLL_PAYSLIP_LIST'), false, 'CORE');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_GROUP_PAYRUN_LIST', 'PAYROLL', false, 'Group Payrun List', 4, (select id from permission where code ='PAYROLL_MAIN_MENU'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_GROUP_PAYRUN_ADD', 'PAYROLL', false, 'Group Payrun Add', 1, (select id from permission where code ='PAYROLL_GROUP_PAYRUN_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_GROUP_PAYRUN_VIEW', 'PAYROLL', false, 'Group Payrun View', 2, (select id from permission where code ='PAYROLL_GROUP_PAYRUN_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_GROUP_PAYRUN_EDIT', 'PAYROLL', false, 'Group Payrun Edit', 3, (select id from permission where code ='PAYROLL_GROUP_PAYRUN_LIST'), false, 'CORE');
update permission set parent=(select id from permission where code='PAYROLL_GROUP_PAYRUN_LIST'), sorder=4 where code='PAYROLL_CAN_APPROVE_PAYSLIP';
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'PAYROLL', false, 'Group Payrun Updates', 5, (select id from permission where code ='PAYROLL_GROUP_PAYRUN_LIST'), false, 'CORE');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('END_OF_SERVICE_GRATUITY_LIST', 'PAYROLL', false, 'End Of Service Gratuity', 5, (select id from permission where code ='PAYROLL_MAIN_MENU'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('END_OF_SERVICE_GRATUITY_ADD', 'PAYROLL', false, 'End Of Service Gratuity Add', 1, (select id from permission where code ='END_OF_SERVICE_GRATUITY_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('END_OF_SERVICE_GRATUITY_EDIT', 'PAYROLL', false, 'End Of Service Gratuity Edit', 2, (select id from permission where code ='END_OF_SERVICE_GRATUITY_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('END_OF_SERVICE_GRATUITY_DELETE', 'PAYROLL', false, 'End Of Service Gratuity Delete', 3, (select id from permission where code ='END_OF_SERVICE_GRATUITY_LIST'), false, 'CORE');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_CASH_ADVANCE_LIST', 'PAYROLL', false, 'Cash Advance List', 6, (select id from permission where code ='PAYROLL_MAIN_MENU'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_CASH_ADVANCE_ADD', 'PAYROLL', false, 'Cash Advance Add', 1, (select id from permission where code ='PAYROLL_CASH_ADVANCE_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_CASH_ADVANCE_VIEW', 'PAYROLL', false, 'Cash Advance View', 2, (select id from permission where code ='PAYROLL_CASH_ADVANCE_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_CASH_ADVANCE_EDIT', 'PAYROLL', false, 'Cash Advance Edit', 3, (select id from permission where code ='PAYROLL_CASH_ADVANCE_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_CASH_ADVANCE_DELETE', 'PAYROLL', false, 'Cash Advance Delete', 4, (select id from permission where code ='PAYROLL_CASH_ADVANCE_LIST'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_CASH_ADVANCE_UPDATES', 'PAYROLL', false, 'Cash Advance Updates', 5, (select id from permission where code ='PAYROLL_CASH_ADVANCE_LIST'), false, 'CORE');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_WPS_REPORT', 'PAYROLL', false, 'Wps Report', 7, (select id from permission where code ='PAYROLL_MAIN_MENU'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'PAYROLL', false, 'Pension Contribution Report', 8, (select id from permission where code ='PAYROLL_MAIN_MENU'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_END_OF_SERVICE_REPORT', 'PAYROLL', false, 'End Of Service Report', 9, (select id from permission where code ='PAYROLL_MAIN_MENU'), false, 'CORE');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'PAYROLL', false, 'Deduction Categories Edit', 2, (select id from permission where code ='PAYROLL_SETTINGS_DEDUCATION_CATEGORIES'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'PAYROLL', false, 'Deduction Categories Delete', 3, (select id from permission where code ='PAYROLL_SETTINGS_DEDUCATION_CATEGORIES'), false, 'CORE');
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'PAYROLL', false, 'Deduction Categories Add', 1, (select id from permission where code ='PAYROLL_SETTINGS_DEDUCATION_CATEGORIES'), false, 'CORE');


delete from "anv".rolepermission where permissioncode = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_END_OF_SERVICE_REPORT';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_PENSION_CONTRIBUTION_REPORT';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_WPS_REPORT';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_UPDATES';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_EDIT';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_DELETE';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_VIEW';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_ADD';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_LIST';
delete from "anv".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_ADD';
delete from "anv".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_DELETE';
delete from "anv".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_EDIT';
delete from "anv".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_LIST';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_ADD';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_PAYSLIP_DELETE';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_PAYSLIP_VIEW';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_LIST';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_VIEW';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_EDIT';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_UPDATES';
delete from "anv".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_UPDATES';


insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_END_OF_SERVICE_REPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_END_OF_SERVICE_REPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_END_OF_SERVICE_REPORT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WPS_REPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WPS_REPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WPS_REPORT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_UPDATES', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_UPDATES', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_UPDATES', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_DELETE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_DELETE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_DELETE', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_EDIT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_EDIT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_EDIT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_VIEW', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_VIEW', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_VIEW', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_ADD', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_ADD', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_ADD', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_LIST', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_LIST', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_LIST', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_ADD', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_ADD', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_ADD', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_DELETE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_DELETE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_DELETE', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_EDIT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_EDIT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_EDIT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_LIST', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_LIST', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_LIST', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_ADD', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_ADD', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_ADD', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_VIEW', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_VIEW', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_VIEW', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_VIEW', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_VIEW', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_VIEW', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_EDIT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_EDIT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_EDIT', 'ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'ACCOUNTANT','ALLOW');



delete from "0".rolepermission where permissioncode = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD';
delete from "0".rolepermission where permissioncode = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE';
delete from "0".rolepermission where permissioncode = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT';
delete from "0".rolepermission where permissioncode = 'PAYROLL_END_OF_SERVICE_REPORT';
delete from "0".rolepermission where permissioncode = 'PAYROLL_PENSION_CONTRIBUTION_REPORT';
delete from "0".rolepermission where permissioncode = 'PAYROLL_WPS_REPORT';
delete from "0".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_UPDATES';
delete from "0".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_EDIT';
delete from "0".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_DELETE';
delete from "0".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_VIEW';
delete from "0".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_ADD';
delete from "0".rolepermission where permissioncode = 'PAYROLL_CASH_ADVANCE_LIST';
delete from "0".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_ADD';
delete from "0".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_DELETE';
delete from "0".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_EDIT';
delete from "0".rolepermission where permissioncode = 'END_OF_SERVICE_GRATUITY_LIST';
delete from "0".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_ADD';
delete from "0".rolepermission where permissioncode = 'PAYROLL_PAYSLIP_DELETE';
delete from "0".rolepermission where permissioncode = 'PAYROLL_PAYSLIP_VIEW';
delete from "0".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_LIST';
delete from "0".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_VIEW';
delete from "0".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_EDIT';
delete from "0".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_UPDATES';
delete from "0".rolepermission where permissioncode = 'PAYROLL_GROUP_PAYRUN_UPDATES';

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_DELETE', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_UPDATE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_UPDATE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_UPDATE', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_VIEW', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_VIEW', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PAYSLIP_VIEW', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_VIEW', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_VIEW', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_VIEW', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_EDIT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_EDIT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_EDIT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_UPDATES', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_ADD', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_ADD', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_ADD', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_LIST', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_LIST', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_LIST', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_EDIT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_EDIT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_EDIT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_DELETE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_DELETE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_DELETE', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_ADD', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_ADD', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('END_OF_SERVICE_GRATUITY_ADD', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_LIST', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_LIST', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_LIST', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_ADD', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_ADD', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_ADD', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_VIEW', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_VIEW', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_VIEW', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_EDIT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_EDIT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_EDIT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_DELETE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_DELETE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_DELETE', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_UPDATES', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_UPDATES', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_CASH_ADVANCE_UPDATES', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WPS_REPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WPS_REPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WPS_REPORT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_PENSION_CONTRIBUTION_REPORT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_END_OF_SERVICE_REPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_END_OF_SERVICE_REPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_END_OF_SERVICE_REPORT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_EDIT', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_DELETE', 'ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_SETTINGS_DEDUCATION_CATEGORIES_ADD', 'ACCOUNTANT','ALLOW');