
insert into pdfreference(code,name) values('PROJECT_SUMMARY','Project');