insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PAYROLL_BATCH_LIST', 'PAYROLL', 'Payroll Batch List', 11, false, (select id from permission where code='PAYROLL_MAIN_MENU'), false,  'PAYROLL');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PAYROLL_BATCH_ADD', 'PAYROLL', 'Payroll Batch Add', 12, false, (select id from permission where code='PAYROLL_BATCH_LIST'), false,  'PAYROLL');

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_LIST', 'ADMIN', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_LIST', 'DR', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_LIST', 'HR', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_LIST', 'ACCOUNTANT', 'ALLOW' );

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_ADD', 'ADMIN', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_ADD', 'DR', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_ADD', 'HR', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_BATCH_ADD', 'ACCOUNTANT', 'ALLOW' );


