insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='ADMINISTRATORS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='DIRECTORS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='PROJECT_MANAGERS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='DEPARTMENT_LEADERS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='HRS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='MEMBERS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='ACCOUNTANTS'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='SALESMEN'));
insert into "0".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "0".trusteegroup where constantname='CUSTOMER_SERVICE_REPRESENTATIVES'));



insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='ADMINISTRATORS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='DIRECTORS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='PROJECT_MANAGERS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='DEPARTMENT_LEADERS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='HRS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='MEMBERS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='ACCOUNTANTS'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='SALESMEN'));
insert into "anv".companyEmailNotificationSettings (category,description,isenabled,notificationname,rolegroupid)
values ('CATEGORY_PM','Actual time reached to estimated',false,'ACTUAL_TIME_REACHED_TO_ESTIMATED',(select id from "anv".trusteegroup where constantname='CUSTOMER_SERVICE_REPRESENTATIVES'));