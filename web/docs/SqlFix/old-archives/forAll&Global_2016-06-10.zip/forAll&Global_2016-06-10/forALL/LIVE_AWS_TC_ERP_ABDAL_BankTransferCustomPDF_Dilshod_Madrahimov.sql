insert into pdfreference(code,name) values('BANK_RECEIPT','Bank Receipt');
insert into pdfreference(code,name) values('BANK_PAYMENT','Bank Payment');
insert into pdfreference(code,name) values('CASH_RECEIPT','Cash Receipt');
insert into pdfreference(code,name) values('CASH_PAYMENT','Cash Payment');
