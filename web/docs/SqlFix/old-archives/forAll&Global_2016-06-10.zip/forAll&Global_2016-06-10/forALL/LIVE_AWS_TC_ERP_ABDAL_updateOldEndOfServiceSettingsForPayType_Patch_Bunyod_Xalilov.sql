-- after schema update
update "anv".eos_settings set payFrom=0 where payFrom is null;