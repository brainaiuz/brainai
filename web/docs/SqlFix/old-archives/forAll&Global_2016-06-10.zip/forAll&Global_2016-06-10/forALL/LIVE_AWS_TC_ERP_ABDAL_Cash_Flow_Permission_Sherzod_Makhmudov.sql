-- For Public Schema
INSERT INTO permission(code,context,ismainmenu,name,sorder,parent,iscore,modulecode) VALUES('ACCOUNTING_CASH_FLOW','ACCOUNTING', false, 'Cash Flow', 11,(select id from permission where code='ACCOUNTING_REPORTS_MENU'), false, 'ACCOUNTING_MODULE');

-- For Zero Schema
INSERT INTO "0".rolepermission(permissioncode,rolecode,access) VALUES('ACCOUNTING_CASH_FLOW', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission(permissioncode,rolecode,access) VALUES('ACCOUNTING_CASH_FLOW', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission(permissioncode,rolecode,access) VALUES('ACCOUNTING_CASH_FLOW', 'ACCOUNTANT', 'ALLOW');

-- For Company Schemas
INSERT INTO "anv".rolepermission(permissioncode,rolecode,access) VALUES('ACCOUNTING_CASH_FLOW', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission(permissioncode,rolecode,access) VALUES('ACCOUNTING_CASH_FLOW', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission(permissioncode,rolecode,access) VALUES('ACCOUNTING_CASH_FLOW', 'ACCOUNTANT', 'ALLOW');