insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                 values('HRMS_SEE_ALL_EMPLOYEES', 'HRMS', 'See all employees list', 0, false,
  (select id from permission where code='HRMS_EMPLOYEES'), false, 'HRMS_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SEE_ALL_EMPLOYEES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SEE_ALL_EMPLOYEES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_SEE_ALL_EMPLOYEES', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SEE_ALL_EMPLOYEES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SEE_ALL_EMPLOYEES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_SEE_ALL_EMPLOYEES', 'HR', 'ALLOW');
