//bu faqat AWS ava NFC serverlar uchun app ga bu constraint hali chiqmagan (Boshqa serverlarga urishni zarari yuq faqat doesn't exist chiqsa ajablanmanglar diymanda)!!!
Tolko dlya AWS i NFC server!!!

ALTER TABLE "0".overtimehistory DROP CONSTRAINT fk_mi56lmy92njpx6nn6hg8dt6r5

ALTER TABLE "anv".overtimehistory DROP CONSTRAINT fk_mi56lmy92njpx6nn6hg8dt6r5