insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'ACCOUNTING', 'Invoice Payments', 8, false, (select id from permission where code='ACCOUNTING_ACCOUNTING_MENU'), false, 'CUSTOMER_CENTER');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PAY_BILL_LIST', 'ACCOUNTING', 'Paid Bills', 9, false, (select id from permission where code='ACCOUNTING_ACCOUNTING_MENU'), false, 'PURCHASE_INVOICING');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAY_BILL_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAY_BILL_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAY_BILL_LIST', 'ACCOUNTANT', 'ALLOW');



insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_RECEIVE_PAYMENT_LIST', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAY_BILL_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAY_BILL_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PAY_BILL_LIST', 'ACCOUNTANT', 'ALLOW');