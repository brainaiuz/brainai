insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('HRMS_POSITION_RATES', 'HRMS', 'Position Rates', 6, false, (select id from permission where code='HRMS_POSITION'), false,  'HRMS_MODULE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_POSITION_RATES', 'ACCOUNTANT', 'ALLOW');
