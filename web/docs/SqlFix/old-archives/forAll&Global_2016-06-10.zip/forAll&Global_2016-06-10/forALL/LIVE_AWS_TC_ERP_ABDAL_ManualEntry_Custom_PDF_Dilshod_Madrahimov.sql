insert into pdfreference(code,name) values('MANUAL_ENTRY','Manual Entry');
