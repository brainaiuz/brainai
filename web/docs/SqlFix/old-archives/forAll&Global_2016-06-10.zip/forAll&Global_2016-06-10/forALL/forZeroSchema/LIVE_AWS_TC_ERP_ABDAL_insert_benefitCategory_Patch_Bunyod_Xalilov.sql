select setval('"0".category_id_seq',(select max(id) from "0".category));

insert into "0".category(code, name, type, pensionable, forall) values('BENEFIT_PAYMENT','Benefit Payment', 'Payment', true, true);