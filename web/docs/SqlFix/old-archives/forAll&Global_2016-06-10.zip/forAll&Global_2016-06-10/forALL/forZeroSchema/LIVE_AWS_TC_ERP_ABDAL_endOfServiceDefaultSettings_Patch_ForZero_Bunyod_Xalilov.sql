-- after schema update
insert into "0".eos_settings(countrycode) values('AE');
insert into "0".eos_settings(countrycode, payFrom, fromallallowances) values('SA', 1, true);



insert into "0".eos_rules(paymentaward, reasoncode, rule, settings_id, rulecode) values('No award', 'EMPLOYEE_RESIGNATION', 'Less than 2 years', (select id from "0".eos_settings where countrycode='SA' limit 1), '0<x<2');
insert into "0".eos_rules(paymentaward, reasoncode, rule, settings_id, rulecode) values('One-third of the award',  'EMPLOYEE_RESIGNATION', '2 to 5 successive years', (select id from "0".eos_settings where countrycode='SA' limit 1), '2<=x<5');
insert into "0".eos_rules(paymentaward, reasoncode, rule, settings_id, rulecode) values('Two-thirds of the award', 'EMPLOYEE_RESIGNATION', 'More than 5 successive years but less than 10 years', (select id from "0".eos_settings where countrycode='SA' limit 1), '5<=x<10');
insert into "0".eos_rules(paymentaward, reasoncode, rule, settings_id, rulecode) values('Full award', 'EMPLOYEE_RESIGNATION', '10 successive years or more', (select id from "0".eos_settings where countrycode='SA' limit 1), 'x>=10');
insert into "0".eos_rules(paymentaward, reasoncode, rule, settings_id, rulecode) values('Half Salary', 'CONTRACT_TERMINATION', 'Less than 5 years', (select id from "0".eos_settings where countrycode='SA' limit 1), 'x<=5');
insert into "0".eos_rules(paymentaward, reasoncode, rule, settings_id, rulecode) values('Full Salary', 'CONTRACT_TERMINATION', 'More than 5 years', (select id from "0".eos_settings where countrycode='SA' limit 1), 'x>5');




insert into "0".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(20, 'EMPLOYEE_RESIGNATION', 'Less than 1 year', (select id from "0".eos_settings where countrycode='AE' limit 1), '0<x<1');
insert into "0".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(7, 'EMPLOYEE_RESIGNATION', '1 to 3 years', (select id from "0".eos_settings where countrycode='AE' limit 1), '1<=x<3');
insert into "0".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(14, 'EMPLOYEE_RESIGNATION', '3 to 5 years', (select id from "0".eos_settings where countrycode='AE' limit 1), '3<=x<5');
insert into "0".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(21, 'EMPLOYEE_RESIGNATION', 'More than 5 years', (select id from "0".eos_settings where countrycode='AE' limit 1), 'x>5');
insert into "0".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(21, 'CONTRACT_TERMINATION', 'Less than 5 years', (select id from "0".eos_settings where countrycode='AE' limit 1), 'x<=5');
insert into "0".eos_rules(days, reasoncode, rule, settings_id, rulecode) values(30, 'CONTRACT_TERMINATION', 'More than 5 years', (select id from "0".eos_settings where countrycode='AE' limit 1), 'x>5');