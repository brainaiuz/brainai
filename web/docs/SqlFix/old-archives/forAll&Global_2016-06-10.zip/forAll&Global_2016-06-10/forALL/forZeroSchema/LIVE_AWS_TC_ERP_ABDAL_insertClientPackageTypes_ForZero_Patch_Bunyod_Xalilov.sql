insert into "0".reference(code, name, description) values('CLIENT_TYPES', 'Client types', 'Client package types');
insert into "0".reference(code, name, description, parentid) values('BRONZE_CLIENT_TYPE', 'Bronze', 'Bronze', (select id from "0".reference where code='CLIENT_TYPES'));
insert into "0".reference(code, name, description, parentid) values('SILVER_CLIENT_TYPE', 'Silver', 'Silver', (select id from "0".reference where code='CLIENT_TYPES'));
insert into "0".reference(code, name, description, parentid) values('GOLD_CLIENT_TYPE', 'Gold', 'Gold', (select id from "0".reference where code='CLIENT_TYPES'));
insert into "0".reference(code, name, description, parentid) values('PLATINUM_CLIENT_TYPE', 'Platinum', 'Platinum', (select id from "0".reference where code='CLIENT_TYPES'));