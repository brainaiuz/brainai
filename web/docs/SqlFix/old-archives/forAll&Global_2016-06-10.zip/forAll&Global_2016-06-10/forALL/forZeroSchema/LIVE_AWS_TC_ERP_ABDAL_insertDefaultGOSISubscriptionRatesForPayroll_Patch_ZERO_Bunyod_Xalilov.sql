-- for Saudi
insert into "0".pensionscheme(deductfrom, deductiontype, deductionvalue, employerdeductiontype, employerdeductionvalue, name, nonlocaldeductionvalue, employernonlocaldeductionvalue, countrycode)
values(0, 1, 9.00, 1, 9.00, 'Default Pension Schema', 9.00, 9.00, 'SA');
-- for UAE
insert into "0".pensionscheme(deductfrom, deductiontype, deductionvalue, employerdeductiontype, employerdeductionvalue, name, nonlocaldeductionvalue, employernonlocaldeductionvalue, countrycode)
values(0, 1, 9.00, 1, 9.00, 'Default Pension Schema', 9.00, 9.00, 'AE');
-- for Kuwait
insert into "0".pensionscheme(deductfrom, deductiontype, deductionvalue, employerdeductiontype, employerdeductionvalue, name, nonlocaldeductionvalue, employernonlocaldeductionvalue, countrycode)
values(0, 1, 5.00, 1, 10.00, 'Default Pension Schema', 5.00, 10.00, 'KW');
 -- for Oman
insert into "0".pensionscheme(deductfrom, deductiontype, deductionvalue, employerdeductiontype, employerdeductionvalue, name, nonlocaldeductionvalue, employernonlocaldeductionvalue, countrycode)
values(0, 1, 6.50, 1, 9.50, 'Default Pension Schema', 6.50, 9.50, 'OM');
 -- for Bahrain
insert into "0".pensionscheme(deductfrom, deductiontype, deductionvalue, employerdeductiontype, employerdeductionvalue, name, nonlocaldeductionvalue, employernonlocaldeductionvalue, countrycode)
values(0, 1, 5.00, 1, 0.00, 'Default Pension Schema', 5.00, 0.00, 'BH');