alter table "0".attendancerawdata drop column paid;
alter table "0".attendancerawdata drop column fromAnnualLeave;
ALTER TABLE "0".attendancerawdata DROP CONSTRAINT fk_31gn64cbv8vk5u7s9x1125t7h;