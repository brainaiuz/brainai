 insert into "0".reference (sorder, code, name, isremovable, issystemreference, shared, iscustombutton, parentid)
 values (1, 'ET_MEETING_MINUTES_MODULE', 'Meeting Minutes', false, true, false, false, (select id from "0".reference where code = '_EMAIL_TEMPLATE_MODULE'));

 insert into "0".reference
(code,deleted,description,isremovable,issystemreference,name,shared,sorder,parentid,iscustombutton,isactive) values
('MEETING_MINUTES_NOTIFICATION',false,'for meeting minutes notification',false,true,'Meeting minutes notification',true,1,(select id from "0".reference where code='ET_MEETING_MINUTES_MODULE'),false,true);