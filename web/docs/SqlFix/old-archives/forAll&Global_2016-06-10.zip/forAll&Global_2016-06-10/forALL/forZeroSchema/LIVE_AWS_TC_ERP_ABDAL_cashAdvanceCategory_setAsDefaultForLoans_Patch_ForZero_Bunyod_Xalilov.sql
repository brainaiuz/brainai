-- after schema update
update "0".category set iscashadvance=true where code='CASH_ADVANCE';