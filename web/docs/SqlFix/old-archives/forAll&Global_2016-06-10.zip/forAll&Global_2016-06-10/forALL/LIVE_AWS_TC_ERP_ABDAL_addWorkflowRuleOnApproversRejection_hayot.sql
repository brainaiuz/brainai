DROP function if EXISTS "anv".createRejectionWorkflowForApprovers();
CREATE OR replace function "anv".createRejectionWorkflowForApprovers()
  returns INTEGER AS
  $body$
DECLARE
    approver1ID INTEGER;
    approver2ID INTEGER;
    approved1WorkflowID INTEGER;
    rejected1WorkflowID INTEGER;
    approved2WorkflowID INTEGER;
    rejected2WorkflowID INTEGER;
    leaves_approver_id1 INTEGER;
    leaves_approver_id2 INTEGER;
    sr record;

    BEGIN
        IF EXISTS (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') AND (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') = 'YES' THEN
            -- nothing here.
        ELSE
            --one level approval here
            -- we need to update workflow_alerts subject
            update "anv".workflow_alerts set subject = 'Leave request approved' WHERE subject = 'Leave request rejected' and
              workflow in (select workflow from "anv".approvers where
                  entitytype='LEAVE_REQUEST' and
                  is_default = true
                  );
            -- we need to delete rejection workflow which is not updated in early patches.
            update "anv".workflow_alerts set deleted = true where
              workflow in (select id from "anv".workflowrule where
                executioncriteria='_WORKFLOW_ACTION_APPROVING' and
                module='_WORKFLOW_MODULE_LEAVE_REQUEST' and
                showinlist=false and
                id not in (select workflow from "anv".approvers where
                  entitytype='LEAVE_REQUEST' and
                  is_default = true
                  )
                );
              --  now delete workflowrule..
            update "anv".workflowrule  set deleted = true where 
              executioncriteria='_WORKFLOW_ACTION_APPROVING' and 
              module='_WORKFLOW_MODULE_LEAVE_REQUEST' and 
              showinlist=false and 
              id not in (select workflow from "anv".approvers where 
                entitytype='LEAVE_REQUEST' and 
                  is_default = true
                 );
            --create workflows for approval1
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_LEAVE_REQUEST', false) RETURNING id INTO rejected1WorkflowID;
            --set workflowids to the approver
            update "anv".approvers set rejected_workflow=rejected1WorkflowID where entitytype='LEAVE_REQUEST' and is_default=true;
            --create workflow alert on actions
            INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${registered_by_email}', null, 'Leave request rejected', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${registered_by},</p><p>Please be informed that ${current_approver} has ${current_approver_status} your ${type} request.</p><p><strong>Request Details:</strong><br />&nbsp; &nbsp;Reason: ${reason}<br />&nbsp; &nbsp;Description: ${description}<br />&nbsp; &nbsp;Date: From ${start_date} to ${due_date}</p><p><a href="${link}"><span style="color:blue">Click here to view the ${type} request</span></a>*</p><p>* If you are not able to click on the link, you can copy and paste the following address into your web browser:</p><p><span style="color: #0033FF">${link}</span></p>');
        END IF;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".createRejectionWorkflowForApprovers() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".createRejectionWorkflowForApprovers()) IS NOT NULL;

