update locale set country='Dutch' where countrycode='NL';

update locale set country='Norwegian' where countrycode='NO';

update locale set country='Portuguese' where countrycode='PT';

update locale set country='Russian' where countrycode='RU';