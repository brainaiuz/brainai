insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_STOCK_TRANSFER_LIST', 'ACCOUNTING', 'Stock Transfer List', '7', 'false', (select id from permission where code='ACCOUNTING_STOCK_ADJUSTMENT_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_STOCK_TRANSFER_ADD', 'ACCOUNTING', 'Stock Transfer Add', '8', 'false', (select id from permission where code='ACCOUNTING_STOCK_TRANSFER_LIST'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'ACCOUNTING', 'Stock Transfer Summary', '9', 'false', (select id from permission where code='ACCOUNTING_STOCK_TRANSFER_ADD'), 'false', 'ACCOUNTING_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values ('ACCOUNTING_STOCK_TRANSFER_DELETE', 'ACCOUNTING', 'Stock Transfer Delete', '10', 'false', (select id from permission where code='ACCOUNTING_STOCK_TRANSFER_ADD'), 'false', 'ACCOUNTING_MODULE');

delete from "0".rolepermission where permissioncode in ('ACCOUNTING_STOCK_TRANSFER_LIST','ACCOUNTING_STOCK_TRANSFER_ADD','ACCOUNTING_STOCK_TRANSFER_SUMMARY','ACCOUNTING_STOCK_TRANSFER_DELETE');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'CLIENT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'CLIENT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'CLIENT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'CLIENT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'PM', 'ALLOW');


delete from "anv".rolepermission where permissioncode in ('ACCOUNTING_STOCK_TRANSFER_LIST','ACCOUNTING_STOCK_TRANSFER_ADD','ACCOUNTING_STOCK_TRANSFER_SUMMARY','ACCOUNTING_STOCK_TRANSFER_DELETE');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'CLIENT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_LIST', 'PM', 'ALLOW');



insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'CLIENT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_ADD', 'PM', 'ALLOW');



insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'CLIENT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_SUMMARY', 'PM', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'CLIENT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_STOCK_TRANSFER_DELETE', 'PM', 'ALLOW');