update "0".spendreceivemoneyitem set amount = (quantity * unitprice);
update "anv".spendreceivemoneyitem set amount = (quantity * unitprice);
