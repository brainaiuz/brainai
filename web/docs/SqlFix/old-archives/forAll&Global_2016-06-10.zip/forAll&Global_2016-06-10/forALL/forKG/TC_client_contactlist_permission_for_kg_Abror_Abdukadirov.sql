INSERT INTO "31287".rolepermission(permissioncode, priviledgeid, rolecode, access)
VALUES('CRM_SEE_ALL_CONTACT_LIST', null, 'CLIENT', 'ALLOW');