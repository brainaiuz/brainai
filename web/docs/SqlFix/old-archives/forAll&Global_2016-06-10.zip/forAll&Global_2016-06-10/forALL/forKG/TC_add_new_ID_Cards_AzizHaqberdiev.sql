insert into "31287".certificateType (backimageurl, frontimageurl, fieldcount, name)
values('/tc/images/15-2.png', '/tc/images/15-1.png', 2, 'FIRST AIDER'),
('/tc/images/16-2.png', '/tc/images/16-1.png', 3, 'DEFENSIVE DRIVING'),
('/tc/images/17-2.png', '/tc/images/17-1.png', 2, 'FIRE WARDEN'),
('/tc/images/18-2.png', '/tc/images/18-1.png', 2, 'AUTHORISED GAS TESTER AUTHORISATION'),
('/tc/images/19-2.png', '/tc/images/19-1.png', 2, 'H2S AND SO2 AWARENESS AND ESCAPE');
