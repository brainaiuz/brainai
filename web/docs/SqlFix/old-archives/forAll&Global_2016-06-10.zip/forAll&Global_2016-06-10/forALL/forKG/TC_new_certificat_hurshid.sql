
insert into "31287".certificatetype (backimageurl, fieldcount, frontimageurl, name) values('/tc/images/20-2.png', 3, '/tc/images/20-1.png', 'Rusayl Lifting and handling');