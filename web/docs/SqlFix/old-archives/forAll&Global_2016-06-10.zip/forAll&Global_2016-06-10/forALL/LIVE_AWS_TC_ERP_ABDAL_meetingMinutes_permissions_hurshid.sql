--for HRMS, schema anv
delete from permission where code in ('MEETING_MINUTES_LIST', 'SHOW_ALL_MEETING_MINUTES', 'ADD_MEETING_MINUTES', 'EDIT_MEETING_MINUTES', 'REMOVE_MEETING_MINUTES', 'CONVERT_MEETING_MINUTES');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('MEETING_MINUTES_LIST', 'HRMS', 'Meeting minutes list', 11, false, (select id from permission where code='HRMS_SECTION_TAB'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('SHOW_ALL_MEETING_MINUTES', 'HRMS', 'Show all meeting minutes', 1, false, (select id from permission where code='MEETING_MINUTES_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ADD_MEETING_MINUTES', 'HRMS', 'Add meeting minutes', 2, false, (select id from permission where code='MEETING_MINUTES_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('EDIT_MEETING_MINUTES', 'HRMS', 'Edit meeting minutes', 3, false, (select id from permission where code='MEETING_MINUTES_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('REMOVE_MEETING_MINUTES', 'HRMS', 'Remove meeting minutes', 4, false, (select id from permission where code='MEETING_MINUTES_LIST'), false,  'HRMS_MODULE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CONVERT_MEETING_MINUTES', 'HRMS', 'Convert meeting minutes', 5, false, (select id from permission where code='MEETING_MINUTES_LIST'), false,  'HRMS_MODULE');

delete from "anv".rolepermission where permissioncode in ('MEETING_MINUTES_LIST', 'SHOW_ALL_MEETING_MINUTES', 'ADD_MEETING_MINUTES', 'EDIT_MEETING_MINUTES', 'REMOVE_MEETING_MINUTES', 'CONVERT_MEETING_MINUTES');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES', 'HR', 'ALLOW');



--For schem 0
delete from "0".rolepermission where permissioncode in ('MEETING_MINUTES_LIST', 'SHOW_ALL_MEETING_MINUTES', 'ADD_MEETING_MINUTES', 'EDIT_MEETING_MINUTES', 'REMOVE_MEETING_MINUTES', 'CONVERT_MEETING_MINUTES');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES', 'HR', 'ALLOW');


