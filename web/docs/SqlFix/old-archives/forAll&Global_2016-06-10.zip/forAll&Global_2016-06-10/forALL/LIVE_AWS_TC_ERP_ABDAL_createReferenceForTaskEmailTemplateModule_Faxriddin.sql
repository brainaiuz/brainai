
insert into "0".reference
(code,deleted,description,isremovable,issystemreference,name,shared,sorder,parentid,iscustombutton,isactive) values
('ACTUAL_TIME_REACHED_TO_ESTIMATED',false,'for actual time reached to estimated',false,true,'Actual time reached to estimated',true,35,(select id from "0".reference where code='ET_TASK_MODULE'),false,true);


insert into "anv".reference
(code,deleted,description,isremovable,issystemreference,name,shared,sorder,parentid,iscustombutton,isactive) values 
('ACTUAL_TIME_REACHED_TO_ESTIMATED',false,'for actual time reached to estimated',false,true,'Actual time reached to estimated',true,35,(select id from "anv".reference where code='ET_TASK_MODULE' limit 1),false,true);