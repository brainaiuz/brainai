--schema updatedan oldin urilsin

DROP TABLE "0".emailsetting_filters CASCADE;
DROP TABLE "anv".emailsetting_filters CASCADE;

ALTER TABLE "0".autoresponse DROP COLUMN type;
ALTER TABLE "0".autoresponse DROP COLUMN saveCopyToSentFolder;
ALTER TABLE "0".autoresponse DROP COLUMN isGmail;
ALTER TABLE "0".autoresponse DROP COLUMN interval;
ALTER TABLE "0".autoresponse DROP COLUMN fetch_priority;
ALTER TABLE "0".autoresponse DROP COLUMN fetch_counter;
ALTER TABLE "0".autoresponse DROP COLUMN fetch_limit;
ALTER TABLE "0".autoresponse DROP COLUMN sent_nextuid;
ALTER TABLE "0".autoresponse DROP COLUMN draft_nextuid;
ALTER TABLE "0".autoresponse DROP COLUMN counter_restart_date;
ALTER TABLE "0".autoresponse DROP COLUMN nextuid;
ALTER TABLE "0".autoresponse DROP COLUMN fetchable;
ALTER TABLE "0".autoresponse DROP COLUMN issmtpconnectionnotauth;
ALTER TABLE "0".autoresponse DROP COLUMN corporateemail;
ALTER TABLE "0".autoresponse DROP COLUMN primaryemail;
ALTER TABLE "0".autoresponse DROP COLUMN errorofdisactivation;
ALTER TABLE "0".autoresponse DROP COLUMN trashfilter;
ALTER TABLE "0".autoresponse DROP COLUMN deletefilter;
ALTER TABLE "0".autoresponse DROP COLUMN resolver_id;
ALTER TABLE "0".autoresponse DROP COLUMN emailTemplate;
ALTER TABLE "0".autoresponse DROP COLUMN company_id;
ALTER TABLE "0".autoresponse DROP COLUMN assignee_id;
ALTER TABLE "0".autoresponse DROP COLUMN startdate;

ALTER TABLE "anv".autoresponse DROP COLUMN type;
ALTER TABLE "anv".autoresponse DROP COLUMN saveCopyToSentFolder;
ALTER TABLE "anv".autoresponse DROP COLUMN isGmail;
ALTER TABLE "anv".autoresponse DROP COLUMN interval;
ALTER TABLE "anv".autoresponse DROP COLUMN fetch_priority;
ALTER TABLE "anv".autoresponse DROP COLUMN fetch_counter;
ALTER TABLE "anv".autoresponse DROP COLUMN fetch_limit;
ALTER TABLE "anv".autoresponse DROP COLUMN sent_nextuid;
ALTER TABLE "anv".autoresponse DROP COLUMN draft_nextuid;
ALTER TABLE "anv".autoresponse DROP COLUMN counter_restart_date;
ALTER TABLE "anv".autoresponse DROP COLUMN nextuid;
ALTER TABLE "anv".autoresponse DROP COLUMN fetchable;
ALTER TABLE "anv".autoresponse DROP COLUMN issmtpconnectionnotauth;


ALTER TABLE "anv".autoresponse DROP COLUMN corporateemail;
ALTER TABLE "anv".autoresponse DROP COLUMN primaryemail;
ALTER TABLE "anv".autoresponse DROP COLUMN errorofdisactivation;
ALTER TABLE "anv".autoresponse DROP COLUMN resolver_id;
ALTER TABLE "anv".autoresponse DROP COLUMN emailTemplate;
ALTER TABLE "anv".autoresponse DROP COLUMN assignee_id;
ALTER TABLE "anv".autoresponse DROP COLUMN startdate;