
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PAYROLL_WELCOME', 'PAYROLL', 'Payroll Welcome', 12, false, (select id from permission where code='PAYROLL'), false,  'PAYROLL');

insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_WELCOME', 'ADMIN', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_WELCOME', 'DR', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_WELCOME', 'HR', 'ALLOW' );
insert into "anv".rolepermission ("permissioncode", "rolecode", "access") VALUES ('PAYROLL_WELCOME', 'ACCOUNTANT', 'ALLOW' );