update "0".reference set name = 'Industry' where code = '_COMPANY_WORKAREA';
update "0".reference set name = 'Network Categories' where code = '_NETWORK_CATEGORIES';

update "anv".reference set name = 'Network Categories' where code = '_NETWORK_CATEGORIES';
update "anv".reference set name = 'Industry' where code = '_COMPANY_WORKAREA';
