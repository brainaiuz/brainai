insert into dashboard_widget (code,name,section,view,sorder) values('EXPENSES_BY_CATEGORIES','Expenses by Category','HRMS','MANAGER_SELF_SERVICE',10);
insert into dashboard_widget (code,name,section,view,sorder) values('OLD_NEW_EXPENSES','Expenses','HRMS','MANAGER_SELF_SERVICE',11);
insert into dashboard_widget (code,name,section,view,sorder) values('LEAVES','Leaves','HRMS','MANAGER_SELF_SERVICE',12);
insert into dashboard_widget (code,name,section,view,sorder) values('SALARY','Salary','HRMS','MANAGER_SELF_SERVICE',13);
insert into dashboard_widget (code,name,section,view,sorder) values('INCENTIVES','Total Incentives by Department','HRMS','MANAGER_SELF_SERVICE',14);
insert into dashboard_widget (code,name,section,view,sorder) values('EXPIRED_DOCUMENTS','Expired Documents','HRMS','MANAGER_SELF_SERVICE',15);
insert into dashboard_widget (code,name,section,view,sorder) values('EMPLOYEE_BY_STATUS','Employee by Status','HRMS','MANAGER_SELF_SERVICE',16);
insert into dashboard_widget (code,name,section,view,sorder) values('NEW_EMPLOYEE_JOINING','New Employee Joining','HRMS','MANAGER_SELF_SERVICE',17);
insert into dashboard_widget (code,name,section,view,sorder) values('SALARY_RATIO','Total Salary Ratio','HRMS','MANAGER_SELF_SERVICE',18);