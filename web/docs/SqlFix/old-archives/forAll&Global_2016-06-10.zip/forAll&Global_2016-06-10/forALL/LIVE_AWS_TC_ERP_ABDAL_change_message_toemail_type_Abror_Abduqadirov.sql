ALTER TABLE message 
ALTER COLUMN toemail TYPE text;