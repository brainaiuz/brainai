
------------------------------------------------------------------------------------------------------------------------
--first step -> ne nujno
--DROP TABLE "anv".skill_rating_comment;
--DROP TABLE "anv".goal_rating_comment;



------------------------------------------------------------------------------------------------------------------------
--second step
--inserting skill comments
insert into "anv".ratingcomment(creationtime,employeecomment,lastupdatetime,reviewercomment,type,skillRatingID)

select ea.date as creationtime,sr.employeescomment,ea.date as lastupdatetime,sr.reviewerscomment,
(CASE WHEN 1=1 THEN 'RATING_COMMENT_TYPE_SKILL' ELSE 'RATING_COMMENT_TYPE_SKILL' END) as type,sr.id
from "anv".employeeAssessment ea
	left outer join "anv".skillAssessment sa on (sa.id=ea.skillAssessmentId)
	left outer join "anv".skillRating sr on (sr.skillAssessmentId=sa.id)
	where sr.skillassessmentid is not null;

------------------------------------------------------------------------------------------------------------------------
--third step
--inserting goal comments
insert into "anv".ratingcomment(creationtime,employeecomment,lastupdatetime,reviewercomment,type,goalRatingID)

select ea.date as creationtime,gr.employeescomment,ea.date as lastupdatetime,gr.reviewerscomment,
(CASE WHEN 1=1 THEN 'RATING_COMMENT_TYPE_GOAL' ELSE 'RATING_COMMENT_TYPE_GOAL' END) as type,gr.id
from "anv".employeeAssessment ea
	left outer join "anv".goalAssessment ga on (ga.id=ea.goalAssessmentId)
	left outer join "anv".goalRating gr on (gr.goalAssessmentId=ga.id)
	where gr.goalAssessmentId is not null;

------------------------------------------------------------------------------------------------------------------------






--DROP TABLE "anv".goal_employees_comment;
--DROP TABLE "anv".goal_reviewers_comment;

--DROP TABLE "anv".skill_reviewers_comment;
--DROP TABLE "anv".skill_employees_comment;