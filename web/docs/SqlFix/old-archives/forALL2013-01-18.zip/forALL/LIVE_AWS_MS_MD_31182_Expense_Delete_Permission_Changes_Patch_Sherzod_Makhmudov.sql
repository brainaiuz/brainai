/*Zero schema uchun*/
delete from "0".rolepermission where permissioncode='ACCOUNTING_EXPENSE_REPORT_DELETE' and rolecode in ('PM','MEM');

/*Hamma companylar uchun*/
delete from "anv".rolepermission where permissioncode='ACCOUNTING_EXPENSE_REPORT_DELETE' and rolecode in ('PM','MEM');
