-------------TO ZERO SCHEMA-------------
insert into "0".reference(code, name, description,   parentid , id )
  values(
    'TC_QUESTIONAIRE',
    'Tc Questionaire Status',
    'Tc Questionaire Status',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    'ASSESSMENT',
    'Assessment',
    'Assessment',

    (select id from "0".reference where code='TC_QUESTIONAIRE'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);
insert into "0".reference(code, name, description,   parentid , id )
  values(
    'FEEDBACK',
    'Feedback',
    'Feedback',

    (select id from "0".reference where code='TC_QUESTIONAIRE'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

----------- TO ALL OTHER SCHEMA ----------
insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'TC_QUESTIONAIRE',
    'Tc Questionaire Status',
    'Tc Questionaire Status',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'ASSESSMENT',
    'Assessment',
    'Assessment',

    (select id from "anv".reference where code='TC_QUESTIONAIRE'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);
insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'FEEDBACK',
    'Feedback',
    'Feedback',

    (select id from "anv".reference where code='TC_QUESTIONAIRE'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);