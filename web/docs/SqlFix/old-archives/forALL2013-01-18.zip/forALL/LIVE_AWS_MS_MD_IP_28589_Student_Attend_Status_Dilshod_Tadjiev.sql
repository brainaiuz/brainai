------------------------------------------------------------------------------------------------------------------------
insert into "0".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_COURSE_STATUS',
    'Student Course Status',
    'Student Course Status',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);


insert into "0".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_PASSED',
    'Competent',
    'Competent',

    (select id from "0".reference where code='_STUDENT_COURSE_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_FAIL',
    'Not yet competent',
    'Not yet competent',

    (select id from "0".reference where code='_STUDENT_COURSE_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

------------------------------------------------ FOR ALL DB -----------------------------------------------------
insert into "anv".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_COURSE_STATUS',
    'Student Course Status',
    'Student Course Status',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);


insert into "anv".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_PASSED',
    'Competent',
    'Competent',

    (select id from "anv".reference where code='_STUDENT_COURSE_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_FAIL',
    'Not yet competent',
    'Not yet competent',

    (select id from "anv".reference where code='_STUDENT_COURSE_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);