--for ZERO schema
update updater set id = 1 where id = 2 and (select setval('"0".role_id_seq',(select max(id) from "0".role))) is not null;
insert into "0".role (code,description,name,issystem,isdeleted,isentityspecific,sorder)
	values('ASSESSOR', '','Assessor', false, false, false, (select max(sorder)+1 from "0".role where issystem=true));
	
--for ALL schema
update updater set id = 1 where id = 2 and (select setval('"anv".role_id_seq',(select max(id) from "anv".role))) is not null;
insert into "anv".role (code,description,name,issystem,isdeleted,isentityspecific,sorder)
	values('ASSESSOR', '','Assessor', false, false, false, (select max(sorder)+1 from "anv".role where issystem=true));