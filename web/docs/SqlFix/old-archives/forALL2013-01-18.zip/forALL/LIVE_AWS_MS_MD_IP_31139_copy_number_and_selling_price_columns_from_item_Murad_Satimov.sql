-- this is for only 31287(Knowledge Grid LLC) company

insert into "31287".scheduledcourse(id, location_id, course_id, language_id, instructor_id, assessor_id, status_id, scheduleduration, numberofseats, startdate, enddate, expiredate) select id, location_id, course_id, language_id, instructor_id, assessor_id, status_id, scheduleduration, numberofseats, startdate, enddate, expiredate from "31287".scheduledcourse_old;

UPDATE  "31287".scheduledcourse cs set intnumber = it.intnumber, number=it.product_number, price=it.sellingprice, deleted = it.deleted from "31287".item it where cs.id=it.id;

-------------------------------------------------------------------------
