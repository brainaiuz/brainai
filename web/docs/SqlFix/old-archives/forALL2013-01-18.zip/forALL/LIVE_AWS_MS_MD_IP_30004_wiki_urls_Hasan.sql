<--schema update dan keyin urish kerak-->
<--bir marta uriladi-->
INSERT into wikiurls (pagecode, url) VALUES ('CRM_WEB_FORMS_ADD_EDIT', 'http://wiki.kpi.com/s/document/3862ed4a-b530-4ffd-aaea-d4991023a00f');
INSERT into wikiurls (pagecode, url) VALUES ('CRM_LEAD_ADD_EDIT', 'http://wiki.kpi.com/s/document/6e240c1f-b45e-4c9e-bc17-a461ad08912a');
INSERT into wikiurls (pagecode, url) VALUES ('CRM_CONTACT_ADD_EDIT', 'http://wiki.kpi.com/s/document/8985b02e-3b65-4360-b381-c4f47d5c10b1');
INSERT into wikiurls (pagecode, url) VALUES ('CRM_CASE_ADD_EDIT', 'http://wiki.kpi.com/s/document/3111a805-104c-4ce3-9c53-5582d92d08cd');
INSERT into wikiurls (pagecode, url) VALUES ('CRM_SOLUTIONS_ADD_EDIT', 'http://wiki.kpi.com/s/document/3c1fb493-cc7e-4e5b-b141-35c618ec3185');
INSERT into wikiurls (pagecode, url) VALUES ('CRM_E_MAIL_MARKETING', 'http://wiki.kpi.com/s/document/bd3e2691-1fdd-4c4d-abbc-0c5bec753c27');
