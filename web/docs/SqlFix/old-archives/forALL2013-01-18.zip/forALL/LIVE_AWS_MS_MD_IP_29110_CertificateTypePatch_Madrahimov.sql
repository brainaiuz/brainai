INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('SCAFFOLD INSPECTOR',3,'/tc/images/11-1.png','/tc/images/11-2.png');

