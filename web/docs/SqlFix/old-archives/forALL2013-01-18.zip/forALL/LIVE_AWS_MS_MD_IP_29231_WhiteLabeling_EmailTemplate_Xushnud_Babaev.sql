-- SELECT name, * from "1".emailtemplate  where name like ('%Default Google Contact Synchronization%');
update "anv".emailtemplate set messagehtml ='Dear ${username},
                Your Google Contact and ${productName} Contact  Synchronization is finished'
where name like ('%Default Google Contact Synchronization%');


-- SELECT name, * from "anv".emailtemplate  where name like ('%Default Sales Quote For Manager%');
update "anv".emailtemplate set messagehtml ='<p>Dear ${firstname}  ${lastname},</p>
				<p>Please be advised that ${name} has submitted a Sales Quote for your attention at ${productName} on ${startdate}</p>
				<p>${hasaccesslink}</p>
				<p>Once you approve or Reject the Sales Quote ${name} will receive email notification about its status.</p>
                <p>Your Sincerely,</br> ${name} </br><b> ${companyname} </b></p>'
where name like ('%Default Sales Quote For Manager%');


-- SELECT name, * from "anv".emailtemplate  where name like ('%Default Expense Claim Submit%');
update "anv".emailtemplate set messagehtml ='<p>Dear ${approverfirstname}  ${approverlastname},</p><br>
             <p>Pelase be advised that ${reporterfirstname} ${reporterlastname} has submitted an Expense Claim for your attention
             at ${productName} on ${submitdate}.
              The Expense Claim details are as follows:</p>
              <p>Report Title: ${reporttitle}<br/>
              Report Period: ${startdate} &mdash; ${enddate}<br/>
              Amount: ${expenseamount}</p>
              <p>The PDF version of the Expense Claim is attached for your attention.</p>
              <p>Click <a href="${reportlink}" title="View Expense Claims" target="_blank">here</a>
              to view the Expense Claims where you can approve or decline it.</p>
              <p>Once you approve or decline the report ${reporterfirstname} ${reporterlastname} will receive email notification about its status.</p>
              <p><font color="red">* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br/>
              ${reportlink}</p>'
where name like ('%Default Expense Claim Submit%');


-- SELECT name, * from "anv".emailtemplate  where name like ('%Default Expense Claim Submit%');
update "anv".emailtemplate set messagehtml ='<p>Dear ${approverfirstname}  ${approverlastname},</p><br>
             <p>Pelase be advised that ${reporterfirstname} ${reporterlastname} has resubmitted an Expense Claim for your attention
             at ${productName} on ${resubmitdate}.
              This report was originally declined by you on $(declinedate). The resubmitted Expense Claim details are as follows:</p>
              <p>Report Title: ${reporttitle}<br/>
              Report Period: ${startdate} &mdash; ${enddate}<br/>
              Amount: ${expenseamount}</p>
              <p>The PDF version of the Expense Claim is attached for your attention.</p>
              <p>Click <a href="${reportlink}" title="View Expense Claims" target="_blank">here</a>
              to view the Expense Claims where you can approve or decline it.</p>
              <p>Once you approve or decline the report ${reporterfirstname} ${reporterlastname} will receive email notification about its status.</p>
              <p><font color="red">* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br/>
              ${reportlink}</p>'
where name like ('%Default Expense Claim Resubmit%');






