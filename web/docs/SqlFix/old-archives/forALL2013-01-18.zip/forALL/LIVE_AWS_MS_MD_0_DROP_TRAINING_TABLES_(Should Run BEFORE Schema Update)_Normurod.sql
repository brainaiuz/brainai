--Should run BEFORE Schema Update.
---For Zero Schema-----------
DROP TABLE "0".course CASCADE;
alter table "0".certificatetypecourses DROP CONSTRAINT if exists "fk103e8947c6657fba";
alter table "0".coursePrice DROP CONSTRAINT "fkfa38b9ee33b90503";
alter table "0".course_instructor DROP CONSTRAINT "fk67f4f74133b90503";
alter table "0".course_preRequisites DROP CONSTRAINT "fk20acb77933b90503";
alter table "0".course_preRequisites DROP CONSTRAINT "fk20acb779b65cb888";
alter table "0".file DROP CONSTRAINT "fk2ff57c701043d1";
alter table "0".courserequirements DROP CONSTRAINT "fk49373c2b33b90503";
alter table "0".courseregistration DROP CONSTRAINT "fk6313cc74701043d1";
alter table "0".lesson DROP CONSTRAINT "fkbe10ad38701043d1";
alter table "0".courseattachment DROP CONSTRAINT "fkd712ef9e701043d1";

DROP TABLE "0".scheduledcourse CASCADE;

--For All Schema--------------
DROP TABLE "anv".course CASCADE;
alter table "anv".certificatetypecourses DROP CONSTRAINT if exists "fk103e8947c6657fba";
alter table "anv".coursePrice DROP CONSTRAINT if exists "fkfa38b9ee33b90503";
alter table "anv".course_instructor DROP CONSTRAINT if exists "fk67f4f74133b90503";
alter table "anv".course_preRequisites DROP CONSTRAINT if exists "fk20acb77933b90503";
alter table "anv".course_preRequisites DROP CONSTRAINT if exists "fk20acb779b65cb888";
alter table "anv".file DROP CONSTRAINT if exists "fk2ff57c701043d1";
alter table "anv".courserequirements DROP CONSTRAINT if exists "fk49373c2b33b90503";
alter table "anv".courseregistration DROP CONSTRAINT if exists "fk6313cc74701043d1";
alter table "anv".lesson DROP CONSTRAINT if exists "fkbe10ad38701043d1";
alter table "anv".courseattachment DROP CONSTRAINT if exists "fkd712ef9e701043d1";

DROP TABLE "anv".scheduledcourse CASCADE;