--------------------------------------------------FOR ZERO SCHEMA----------------------------------------------------------------------
insert into "0".reference(code, name, description,   parentid , id )
  values(
    '_CS_DELIVERED_STATUS',
    'Delivered status',
    'Delivered status',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    'CS_NOT_STARTED',
    'Not Started',
    'Not Started',

    (select id from "0".reference where code='_CS_DELIVERED_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    'CS_DELIVERED',
    'Delivered',
    'Delivered',

    (select id from "0".reference where code='_CS_DELIVERED_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    'CS_NOT_DELIVERED',
    'Not Delivered',
    'Not Delivered',

    (select id from "0".reference where code='_CS_DELIVERED_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

--------------------------------------------------FOR ALL SCHEMA----------------------------------------------------------------------
insert into "anv".reference(code, name, description,   parentid , id )
  values(
    '_CS_DELIVERED_STATUS',
    'Delivered status',
    'Delivered status',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'CS_NOT_STARTED',
    'Not Started',
    'Not Started',

    (select id from "anv".reference where code='_CS_DELIVERED_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'CS_DELIVERED',
    'Delivered',
    'Delivered',

    (select id from "anv".reference where code='_CS_DELIVERED_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'CS_NOT_DELIVERED',
    'Not Delivered',
    'Not Delivered',

    (select id from "anv".reference where code='_CS_DELIVERED_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);
