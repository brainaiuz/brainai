--for public schema
delete from blackList where blackemail is null or blackemail ='';

update blackList set hostName = 'app.kpi.com';