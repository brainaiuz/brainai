insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_TASK_TO_MEMBER', 'CLIENT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'CLIENT', (SELECT id from "0".reference where code='ALLOW') );


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_TASK_TO_MEMBER', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_ASSIGN_ISSUE_TO_MEMBER', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
