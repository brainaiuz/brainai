---------------------------------------------------------------------------
------- Ehtiyot bo`ling katta patch, serverni down qilib qo`ymasin---------
---------------------------------------------------------------------------
update "anv".timesheet e set wageRate=x.wageRate, clientChargeRate=x.clientChargeRate

from "anv".ProjectEmployeeWageClientRateHistory x
join (select t.id, coalesce(max(case t.date>=x.changeDate when true then x.id else null end), min(case x.changeDate>=t.date when true then x.id else null end)) x
from "anv".timesheet t
left join "anv".employeetask et on t.employeetaskId=et.id
left join "anv".ProjectEmployeeWageClientRateHistory x on x.projectemployeeid=et.projectEmployeeId
group by t.id) tsh on x.id=tsh.x

where tsh.id=e.id;