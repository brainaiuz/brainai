/*Public schemaga bir marta apply qilinadi*/

ALTER TABLE vatefiling ALTER COLUMN vatOnSalesAndOutputs TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN vatFromECMemberStates TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN totalVatDue TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN vatOnPurchaseAndInputs TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN vatToReclaimFromCustoms TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN totalSalesAndOutputs TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN totalPurchasesAndInputs TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN totalSupplies TYPE numeric(25,5);
ALTER TABLE vatefiling ALTER COLUMN totalAcquisitions TYPE numeric(25,5);


/*Company schemalarga apply qilinadi*/

ALTER TABLE "anv".invoice ALTER COLUMN discount TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN subtotal TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN total TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN totalininvoicecurrency TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN comissionamount TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN exchangerate TYPE numeric(25,10);
ALTER TABLE "anv".invoice ALTER COLUMN totaldiscount TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN billexptotal TYPE numeric(25,5);
ALTER TABLE "anv".invoice ALTER COLUMN markupamount TYPE numeric(25,5);

ALTER TABLE "anv".quote ALTER COLUMN discount TYPE numeric(25,5);
ALTER TABLE "anv".quote ALTER COLUMN subtotal TYPE numeric(25,5);
ALTER TABLE "anv".quote ALTER COLUMN total TYPE numeric(25,5);
ALTER TABLE "anv".quote ALTER COLUMN totalininvoicecurrency TYPE numeric(25,5);
ALTER TABLE "anv".quote ALTER COLUMN comissionamount TYPE numeric(25,5);
ALTER TABLE "anv".quote ALTER COLUMN exchangerate TYPE numeric(25,10);

ALTER TABLE "anv".invoiceitem ALTER COLUMN qty TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN unitprice TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN net TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN ammount TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN pricelevelamount TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN receive TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN receivedqty TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN receivedallocation TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN discount_amount TYPE numeric(25,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN discount TYPE numeric(10,5);
ALTER TABLE "anv".invoiceitem ALTER COLUMN comission TYPE numeric(10,5);

ALTER TABLE "anv".quoteitem ALTER COLUMN qty TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN unitprice TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN net TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN ammount TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN pricelevelamount TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN receive TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN receivedqty TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN receivedallocation TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN discount_amount TYPE numeric(25,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN discount TYPE numeric(10,5);
ALTER TABLE "anv".quoteitem ALTER COLUMN comission TYPE numeric(10,5);

ALTER TABLE "anv".invoicetaxtotal ALTER COLUMN amount TYPE numeric(25,5);
ALTER TABLE "anv".quotetaxtotal ALTER COLUMN amount TYPE numeric(25,5);

ALTER TABLE "anv".fixedasset ALTER COLUMN cost TYPE numeric(25,5);
ALTER TABLE "anv".fixedasset ALTER COLUMN residualvalue TYPE numeric(25,5);

ALTER TABLE "anv".depreciation ALTER COLUMN amount TYPE numeric(25,5);

ALTER TABLE "anv".invoicepayments ALTER COLUMN baseAmount TYPE numeric(25,5);

ALTER TABLE "anv".item_stock ALTER COLUMN quantity TYPE numeric(25,5);
ALTER TABLE "anv".item_stock ALTER COLUMN price TYPE numeric(25,5);
ALTER TABLE "anv".item_stock ALTER COLUMN transaction_value TYPE numeric(25,5);

ALTER TABLE "anv".invoicepayments ALTER COLUMN amount TYPE numeric(25,5);
ALTER TABLE "anv".invoicepayments ALTER COLUMN exchangerate TYPE numeric(25,5);

ALTER TABLE "anv".expensepayments ALTER COLUMN amount TYPE numeric(25,5);
ALTER TABLE "anv".expensepayments ALTER COLUMN exchangerate TYPE numeric(25,5);

ALTER TABLE "anv".customerpayment ALTER COLUMN amount TYPE numeric(25,5);
ALTER TABLE "anv".customerpayment ALTER COLUMN exchangerate TYPE numeric(25,5);

ALTER TABLE "anv".saleinvoice ALTER COLUMN quotePercent TYPE numeric(10,5);
ALTER TABLE "anv".saleinvoice ALTER COLUMN previousBalance TYPE numeric(25,5);
ALTER TABLE "anv".saleinvoice ALTER COLUMN paymentReceived TYPE numeric(25,5);

ALTER TABLE "anv".transactionitem ALTER COLUMN debit TYPE numeric(25,5);
ALTER TABLE "anv".transactionitem ALTER COLUMN credit TYPE numeric(25,5);

ALTER TABLE "anv".manualjournalitem ALTER COLUMN debit TYPE numeric(25,5);
ALTER TABLE "anv".manualjournalitem ALTER COLUMN credit TYPE numeric(25,5);


ALTER TABLE "anv".account ALTER COLUMN balance TYPE numeric(25,5);
ALTER TABLE "anv".bankaccount ALTER COLUMN openingamount TYPE numeric(25,5);

ALTER TABLE "anv".bankcheck ALTER COLUMN amount TYPE numeric(25,5);
ALTER TABLE "anv".bankcheckitem ALTER COLUMN amount TYPE numeric(25,5);
ALTER TABLE "anv".bankcheckhistory ALTER COLUMN amount TYPE numeric(25,5);


ALTER TABLE "anv".expenseReport ALTER COLUMN exchagerate TYPE numeric(25,10);

ALTER TABLE "anv".expense ALTER COLUMN units TYPE numeric(25,5);
ALTER TABLE "anv".expense ALTER COLUMN costperunit TYPE numeric(25,5);
ALTER TABLE "anv".expense ALTER COLUMN exchagerate TYPE numeric(25,5);
ALTER TABLE "anv".expense ALTER COLUMN subtotal TYPE numeric(25,5);
ALTER TABLE "anv".expense ALTER COLUMN basesubtotal TYPE numeric(25,5);

ALTER TABLE "anv".projectbudgetitem ALTER COLUMN amount TYPE numeric(25,5);

ALTER TABLE "anv".budgetedProfit ALTER COLUMN grossbudget TYPE numeric(25,5);
ALTER TABLE "anv".budgetedProfit ALTER COLUMN netbudget TYPE numeric(25,5);
ALTER TABLE "anv".accountBudget ALTER COLUMN budget TYPE numeric(25,5);

ALTER TABLE "anv".crmaccount ALTER COLUMN balanceamount TYPE numeric(25,5);
ALTER TABLE "anv".crmaccount ALTER COLUMN creditlimit TYPE numeric(25,5);
ALTER TABLE "anv".crmaccount ALTER COLUMN clientbalance TYPE numeric(25,5);
ALTER TABLE "anv".crmaccount ALTER COLUMN supplierbalance TYPE numeric(25,5);
ALTER TABLE "anv".prepaymentbalance ALTER COLUMN balance TYPE numeric(25,5);

ALTER TABLE "anv".picklist ALTER COLUMN total TYPE numeric(25,5);
ALTER TABLE "anv".picklist ALTER COLUMN taxAmount TYPE numeric(25,5);
ALTER TABLE "anv".picklist ALTER COLUMN discount TYPE numeric(10,5);

ALTER TABLE "anv".picklistitem ALTER COLUMN quantity TYPE numeric(25,5);
ALTER TABLE "anv".picklistitem ALTER COLUMN picked TYPE numeric(25,5);
ALTER TABLE "anv".picklistitem ALTER COLUMN packed TYPE numeric(25,5);
ALTER TABLE "anv".picklistitem ALTER COLUMN shipped TYPE numeric(25,5);

