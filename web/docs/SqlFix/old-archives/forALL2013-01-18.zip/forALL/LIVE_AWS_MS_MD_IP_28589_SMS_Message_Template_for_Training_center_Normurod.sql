insert into "0".reference(code, name, description,   parentid , id )
  values(
    'COURSE_BOOKING_SMS_SEND_CATEGORY',
    'Course booking sms send category',
    'Course booking sms send category',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);


insert into "0".emailtemplate(code, iscompanyemailtemplate, isdefault, locale, name, subject, categoryid, messagehtml)
values('DEFAULT_COURSE_BOOKING_SMS_SEND_CATEGORY', 'COMPANY_EMAIL_TEMPLATE', true, 'en', 'SMS Course confirmation', 'SMS Course confirmation', (select id from "0".reference where code='COURSE_BOOKING_SMS_SEND_CATEGORY'), 'Course confirmation. course#: $cnumber; scheduled course#: $scnumber; start date: $startdate.');
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'COURSE_BOOKING_SMS_SEND_CATEGORY',
    'Course booking sms send category',
    'Course booking sms send category',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

update "anv".myuser set deleted = false where deleted is not true and (SELECT setval('"anv".emailtemplate_id_seq', (select max(id) from "anv".emailtemplate))) is null;


insert into "anv".emailtemplate(code, iscompanyemailtemplate, isdefault, locale, name, subject, categoryid, messagehtml)
values('DEFAULT_COURSE_BOOKING_SMS_SEND_CATEGORY', 'COMPANY_EMAIL_TEMPLATE', true, 'en', 'SMS Course confirmation', 'SMS Course confirmation', (select id from "anv".reference where code='COURSE_BOOKING_SMS_SEND_CATEGORY'), 'Course confirmation. course#: $cnumber; scheduled course#: $scnumber; start date: $startdate.');

