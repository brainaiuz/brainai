--for all schemas --> candidate sources / statuses (parent)
------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION "anv".candidateSourcesViaStatusesParentFunction() RETURNS integer AS $$
BEGIN

    IF EXISTS
      (SELECT * FROM "anv".reference WHERE code = '_CANDIDATE_SOURCE' AND parentid is null)
    THEN
    ELSE
       INSERT INTO "anv".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Candidate Sources', '_CANDIDATE_SOURCE', true, false, null, 0);
    END IF;

    IF EXISTS
      (SELECT * FROM "anv".reference WHERE name = 'Candidate Statuses' AND code = '_CANDIDATE_STATUS')
    THEN
    ELSE
       INSERT INTO "anv".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Candidate Statuses', '_CANDIDATE_STATUS', true, false, null, 0);
    END IF;

  RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;


--after apply

update "anv".myuser set deleted = false where deleted is null and (select "anv".candidateSourcesViaStatusesParentFunction()) is not null;


--and
 --DROP FUNCTION "anv".candidateSourcesViaStatusesParentFunction();

------------------------------------------------------------------------------------------------------------------------