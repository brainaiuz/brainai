--for zero schema
alter table "0".skill alter column description type text;

--for all schemas

alter table "anv".skill alter column description type text;