--apply to public schema

INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Rostov-na-Donu, Russia', 'RSXX0090', 183);