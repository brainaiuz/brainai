insert into "anv".reference(code, name, description) values('_BONUS_DISTRIBUTION_STATUS', 'Bonus Distribution Status', 'Bonus Distribution Status');
insert into "anv".reference(code, name, description, parentid) values('NOT_DISTRIBUTED', 'Not distributed', 'Not distributed', (select id from "anv".reference where code='_BONUS_DISTRIBUTION_STATUS'));
insert into "anv".reference(code, name, description, parentid) values('DISTRIBUTED', 'Distributed', 'Distributed', (select id from "anv".reference where code='_BONUS_DISTRIBUTION_STATUS'));
insert into "anv".reference(code, name, description, parentid) values('REDISTRIBUTED', 'Redistributed ', 'Redistributed', (select id from "anv".reference where code='_BONUS_DISTRIBUTION_STATUS'));

insert into "anv".reference(code, name, description) values('_BONUS_DISTRIBUTION_APPROVAL_STATUS', 'Bonus Distribution Status', 'Bonus Distribution Status');
insert into "anv".reference(code, name, description, parentid) values('BONUS_DISTRIBUTION_DRAFT', 'Bonus Distribution Draft', 'Bonus Distribution Draft', (select id from "anv".reference where code='_BONUS_DISTRIBUTION_APPROVAL_STATUS'));
insert into "anv".reference(code, name, description, parentid) values('BONUS_DISTRIBUTION_APPROVED', 'Bonus Distribution Approved', 'Bonus Distribution Approved', (select id from "anv".reference where code='_BONUS_DISTRIBUTION_APPROVAL_STATUS'));
