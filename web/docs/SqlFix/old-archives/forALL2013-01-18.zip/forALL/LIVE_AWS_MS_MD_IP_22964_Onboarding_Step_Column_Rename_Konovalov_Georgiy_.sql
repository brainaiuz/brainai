 ALTER TABLE "anv".stepresponsibility RENAME COLUMN employeeid TO employeeid2stepid;
 ALTER TABLE "anv".stepresponsibility RENAME COLUMN stepid TO employeeid;
 ALTER TABLE "anv".stepresponsibility RENAME COLUMN employeeid2stepid TO stepid;


 ALTER TABLE "anv".steprole RENAME COLUMN roleid TO roleid2stepid;
 ALTER TABLE "anv".steprole RENAME COLUMN stepid TO roleid;
 ALTER TABLE "anv".steprole RENAME COLUMN roleid2stepid TO stepid;