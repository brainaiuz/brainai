--For zero
update "0".role set sorder = 15 where code = 'MEMBER';
update "0".role set sorder = 101 where code = 'PMOFPR';
update "0".role set sorder = 102 where code = 'BMOFPR';
update "0".role set sorder = 91 where code = 'DLOFPR';
update "0".role set sorder = 220 where code = 'CLIENT';
update "0".role set sorder = 230 where code = 'CREATOR';
update "0".role set sorder = 240 where code = 'INSTRUCTOR';

update "0".role set name = 'PM (Specific)' where code = 'PMOFPR';
update "0".role set name = 'Backup Manager (Specific)' where code = 'BMOFPR';
update "0".role set name = 'DL (Specific)' where code = 'DLOFPR';

--For all
update "anv".role set sorder = 15 where code = 'MEMBER';
update "anv".role set sorder = 101 where code = 'PMOFPR';
update "anv".role set sorder = 102 where code = 'BMOFPR';
update "anv".role set sorder = 91 where code = 'DLOFPR';
update "anv".role set sorder = 220 where code = 'CLIENT';
update "anv".role set sorder = 230 where code = 'CREATOR';
update "anv".role set sorder = 240 where code = 'INSTRUCTOR';

update "anv".role set name = 'PM (Specific)' where code = 'PMOFPR';
update "anv".role set name = 'Backup Manager (Specific)' where code = 'BMOFPR';
update "anv".role set name = 'DL (Specific)' where code = 'DLOFPR';
--For public
update permission set sorder = 1 where code = 'PM_MAIN_MENU';
