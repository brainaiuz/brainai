--copy to issue ID

update "anv".task set issue_id = id where isissue is true;


------------------------------------------------------------------------------------------------------------------------
--delete PERFORMANCE NOTE and INCIDENT

update "anv".task set deleted = true where id in (
select t.id from "anv".task t
	left outer join "anv".issue i on i.id=t.id
	left outer join "anv".projectissue pi on pi.id=i.id
	left outer join "anv".taskissue ti on ti.id=i.id
	left outer join "anv".departmentissue di on di.id=i.id
	left outer join "anv".clientissue ci on ci.id=i.id
	left outer join "anv".employeeissue ei on ei.id=i.id

where t.isissue is true	and ei.showinavailability is true or ei.showinpa is true);