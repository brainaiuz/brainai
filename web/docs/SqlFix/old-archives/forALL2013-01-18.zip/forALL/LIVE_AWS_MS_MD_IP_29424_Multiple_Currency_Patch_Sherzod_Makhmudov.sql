/*Schema updatedan keyin patch qilinadi*/

update "anv".account set currencyid=(select currency_id from financialsettings where id in (select financialsettingsid from company where id = anv order by id desc limit 1)) where currencyid is null;

update "anv".manualjournal set currencyid=(select currency_id from financialsettings where id in (select financialsettingsid from company where id = anv order by id desc limit 1)) where currencyid is null;
update "anv".manualjournal set exchangerate=1 where exchangerate is null;