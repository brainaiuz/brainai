-- for zero schema;
------------------------------------------------------------------------------------------------------------------------
-- _COURSE_BOOKING_STATUS
insert into "0".reference(code, name, description, parentid , id)
  values(
    '_COURSE_BOOKING_TYPE',
    'Course booking type',
    'Course booking type',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id)
  values(
    'BOOKING_BY_APPROVAL',
    'By Approval',
    'By Approval',

    (select id from "0".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid , id)
  values(
    'BOOKING_PAY_ONLINE',
    'Pay Online',
    'Pay Online',

    (select id from "0".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id)
  values(
    'BOOKING_PAY_UPON_ARRIVAL',
    'Pay upon Arrival',
    'Pay upon Arrival',

    (select id from "0".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id)
  values(
    'BOOKING_PAY_BY_BANK_TRANSFER',
    'Pay by Bank Transfer',
    'Pay by Bank Transfer',

    (select id from "0".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

------------------------------------------------ FOR ALL DB -----------------------------------------------------
-- _COURSE_BOOKING_STATUS
insert into "anv".reference(code, name, description, parentid , id)
  values(
    '_COURSE_BOOKING_TYPE',
    'Course booking type',
    'Course booking type',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id)
  values(
    'BOOKING_BY_APPROVAL',
    'By Approval',
    'By Approval',

    (select id from "anv".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid , id)
  values(
    'BOOKING_PAY_ONLINE',
    'Pay Online',
    'Pay Online',

    (select id from "anv".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id)
  values(
    'BOOKING_PAY_UPON_ARRIVAL',
    'Pay upon Arrival',
    'Pay upon Arrival',

    (select id from "anv".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id)
  values(
    'BOOKING_PAY_BY_BANK_TRANSFER',
    'Pay by Bank Transfer',
    'Pay by Bank Transfer',

    (select id from "anv".reference where code='_COURSE_BOOKING_TYPE'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);
