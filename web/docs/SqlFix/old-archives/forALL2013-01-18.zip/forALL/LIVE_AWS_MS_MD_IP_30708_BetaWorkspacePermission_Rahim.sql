--0 ni avval urish kerak

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_CONTACTS_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='CRM_ADD_NEW_CONTACT';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_EXPENSE_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='HRMS_ADD_NEW_EXPENSE_CLAIM';

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid")
VALUES ('WORKSPACE_LEAVE_REQUEST_ADD', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );