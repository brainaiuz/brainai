insert into "0".reference(code, name, description,   parentid , id )
  values(
    'COURSE_BOOKING_CONFIRMATION_CATEGORY',
    'Course booking confirmation category',
    'Course booking confirmation category',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);


insert into "0".emailtemplate(code, iscompanyemailtemplate, isdefault, locale, name, subject, categoryid, messagehtml)
values('DEFAULT_COURSE_BOOKING_CONFIRMATION_CATEGORY', 'COMPANY_EMAIL_TEMPLATE', true, 'en', 'Course booking confirmation', 'Course booking confirmation', (select id from "0".reference where code='COURSE_BOOKING_CONFIRMATION_CATEGORY'), '<p>Dear $fullname</p><p>We have course booking submitted for your approval on KGOnline training center.</p><p>To approve or reject the booking, please follow the link $host/bookingConfirmation.html?cid=$cid&bid=$bid</p>');

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'COURSE_BOOKING_CONFIRMATION_CATEGORY',
    'Course booking confirmation category',
    'Course booking confirmation category',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);


update "anv".myuser set deleted = false where deleted is not true and (SELECT setval('"anv".emailtemplate_id_seq', (select max(id) from "anv".emailtemplate))) is null;

insert into "anv".emailtemplate(code, iscompanyemailtemplate, isdefault, locale, name, subject, categoryid, deleted, messagehtml)
values('DEFAULT_COURSE_BOOKING_CONFIRMATION_CATEGORY', 'COMPANY_EMAIL_TEMPLATE', true, 'en', 'Course booking confirmation', 'Course booking confirmation', (select id from "anv".reference where code='COURSE_BOOKING_CONFIRMATION_CATEGORY'), false, '<p>Dear $fullname</p><p>We have course booking submitted for your approval on KGOnline training center.</p><p>To approve or reject the booking, please follow the link $host/bookingConfirmation.html?cid=$cid&bid=$bid</p>');

