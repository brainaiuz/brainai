-- Enquiry Mode
INSERT INTO "0".reference(code,name,issystemreference,deleted) VALUES('ENQUIRY_MODE_PARENT','Enquiry Mode',true,false);
INSERT INTO "0".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_DIRECT','Direct',(SELECT id FROM "0".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "0".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_EMAIL','Email',(SELECT id FROM "0".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "0".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_FAX','Fax',(SELECT id FROM "0".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "0".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_PHONE','Phone',(SELECT id FROM "0".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
-- Session
INSERT INTO "0".reference(code,name,issystemreference,deleted) VALUES('_SESSION_STATUS','Enquiry Item Session',true,false);
INSERT INTO "0".reference(code,name,parentid,issystemreference,deleted) VALUES('_SESSION_STATUS_MORNING','Morning',(SELECT id FROM "0".reference WHERE code='_SESSION_STATUS'),true,false);
INSERT INTO "0".reference(code,name,parentid,issystemreference,deleted) VALUES('_SESSION_STATUS_EVENING','Evening',(SELECT id FROM "0".reference WHERE code='_SESSION_STATUS'),true,false);

-- Enquiry Mode
INSERT INTO "anv".reference(code,name,issystemreference,deleted) VALUES('ENQUIRY_MODE_PARENT','Enquiry Mode',true,false);
INSERT INTO "anv".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_DIRECT','Direct',(SELECT id FROM "anv".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "anv".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_EMAIL','Email',(SELECT id FROM "anv".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "anv".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_FAX','Fax',(SELECT id FROM "anv".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "anv".reference(code,name,parentid,issystemreference,deleted) VALUES('ENQUIRY_MODE_PHONE','Phone',(SELECT id FROM "anv".reference WHERE code='ENQUIRY_MODE_PARENT'),true,false);
INSERT INTO "anv".reference(code,name,issystemreference,deleted) VALUES('_SESSION_STATUS','Enquiry Item Session',true,false);
INSERT INTO "anv".reference(code,name,parentid,issystemreference,deleted) VALUES('_SESSION_STATUS_MORNING','Morning',(SELECT id FROM "anv".reference WHERE code='_SESSION_STATUS'),true,false);
INSERT INTO "anv".reference(code,name,parentid,issystemreference,deleted) VALUES('_SESSION_STATUS_EVENING','Evening',(SELECT id FROM "anv".reference WHERE code='_SESSION_STATUS'),true,false);
