
--for all schemas

update "anv".companyCustomFieldsSettings set entityname = 'BusinessGoal' where entityname = 'Goal';