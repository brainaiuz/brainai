--CUSTOM COMPANY PATCH
delete from "21252".rolepermission where permissioncode = 'PM_EMPLOYEE_RATE_HISTORY' and rolecode != 'ADMIN';
delete from "25507".rolepermission where permissioncode = 'HRMS_SALARY_GRADE' and rolecode != 'ADMIN';
delete from "26338".rolepermission where permissioncode = 'HRMS_SALARY_GRADE' and rolecode != 'ADMIN';
--

--FOR PUBLIC
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", "parent") values ('PM_EMPLOYEE_RATE', 'PM', 'Employee Rate', 100, false, (select id from permission where code = 'PM_EMPLOYEE_LIST'));
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EMPLOYEE_RATE', 'HRMS', 'Employee Rate', 100, false);
--

-- FOR ZERO
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'DR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'HR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'DR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'HR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'DLOFPR', (SELECT id from "0".reference where code='ALLOW'));
--

--FOR ALL
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'DR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'HR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_EMPLOYEE_RATE', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'DR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'HR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_RATE', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW'));
