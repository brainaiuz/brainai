
-- 30411_hrms_dependent_role_permission_IlhomJumaev.sql DAN KEYIN APPLY QILINSIN!!!!!!

--for all schemas  - console dan apply qilinadi!!!

-- HRMS dependent list
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT', 'MEM', (SELECT id from "0".reference where code='ALLOW') );


-- HRMS dependent summary
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_SUMMARY', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

-- HRMS dependent add new
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_DEPENDENT', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

-- HRMS dependent edit
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EDIT_DEPENDENT', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

-- HRMS dependent remove
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'TL', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_DEPENDENT_REMOVE', 'MEM', (SELECT id from "0".reference where code='ALLOW') );