 ALTER TABLE "0".stepresponsibility RENAME COLUMN employeeid TO employeeid2stepid;
 ALTER TABLE "0".stepresponsibility RENAME COLUMN stepid TO employeeid;
 ALTER TABLE "0".stepresponsibility RENAME COLUMN employeeid2stepid TO stepid;


 ALTER TABLE "0".steprole RENAME COLUMN roleid TO roleid2stepid;
 ALTER TABLE "0".steprole RENAME COLUMN stepid TO roleid;
 ALTER TABLE "0".steprole RENAME COLUMN roleid2stepid TO stepid;