

alter table "0".dynamic_words alter column word type varchar; 
alter table "0".dynamic_words add CONSTRAINT dynamic_words_key_uq UNIQUE(key); 
ALTER TABLE "0".dynamic_words  CLUSTER ON dynamic_words_key_uq;

alter table "0".dynamic_query alter column sql type varchar;
alter table "0".dynamic_query alter column params type varchar;
ALTER TABLE "0".dynamic_query  CLUSTER ON dynamic_query_key_key;


alter table "0".dynamic_pages alter column words type varchar ;
alter table "0".dynamic_pages alter column option type varchar ;


COMMENT ON COLUMN "0".dynamic_pages.page
IS 'Наименование страницы';

COMMENT ON COLUMN "0".dynamic_pages.words
IS 'Список ключей для получения локализированных слов.';

COMMENT ON COLUMN "0".dynamic_pages.option
IS 'Настройки страницы';

CREATE UNIQUE INDEX "dynamic_pages_page&view_uq" ON "0".dynamic_pages
  USING btree (page, view);