--for zero schemas --> skills
------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION "0".skillsFunction() RETURNS integer AS $$
BEGIN

    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Project Management' AND code = 'PROJECT_MANAGEMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Project Management', 'PROJECT_MANAGEMENT',
        'Establishes project goals and responsibilities and can acquire and manage resources and co-ordinate the project company wide.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Customer Care' AND code = 'CUSTOMER_CARE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Customer Care', 'CUSTOMER_CARE',
        'Provides a professional image to the customer and handles questions and complaints politely and efficiently. Manages customer expectation and maintains a good relationship.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Job Knowledge' AND code = 'JOB_KNOWLEDGE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Job Knowledge', 'JOB_KNOWLEDGE',
        'Demonstrates a knowledge of the job and understands the company mission statement and values. Has a full and complete product and market knowledge. Competitor and industry awareness.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Organisational Knowledge' AND code = 'ORGANISATIONAL_KNOWLEDGE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Organisational Knowledge', 'ORGANISATIONAL_KNOWLEDGE',
        'Manages inter departmental relationships and understands others roles within the organisation to help bring about co-operation.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'International View' AND code = 'INTERNATIONAL_VIEW' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('International View', 'INTERNATIONAL_VIEW',
        'Understands global markets and international considerations.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Managing a budget' AND code = 'MANAGING_A_BUDGET' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Managing a budget', 'MANAGING_A_BUDGET',
        'Uses resources efficiently and creates accurate and realistic budgets.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Decision Making' AND code = 'DECISION_MAKING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Decision Making', 'DECISION_MAKING',
        'Can recognise the financial implications of business decisions. Can also weigh the pros and cons of an action before making a decision.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Results Orientation' AND code = 'RESULTS_ORIENTATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Results Orientation', 'RESULTS_ORIENTATION',
        'Demonstrates personal commitment and persistence in achieving goals, will expend the extra effort needed to "get the job done" or meet commitments. Will follow through an action plan and deliver results.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Negotiation Skills' AND code = 'NEGOTIATION_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Negotiation Skills', 'NEGOTIATION_SKILLS',
        'Conducts positive negotiations and demonstrates the ability to handle conflict and to bring about a positive resolution.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Presentation Skills' AND code = 'PRESENTATION_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Presentation Skills', 'PRESENTATION_SKILLS',
        'Uses effective presentation skills and techniques when delivering information or ideas and displays a confident and professional image to others.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Meetings' AND code = 'MEETINGS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Meetings', 'MEETINGS',
        'Planning and running of meetings and is also effective at following up issues that arise from the meeting.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Work Environment/Safety' AND code = 'WORK_ENVIRONMENT_SAFETY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Work Environment/Safety', 'WORK_ENVIRONMENT_SAFETY',
        'Promotes mutual respect, keeps workplace clean and safe and supports safety programs.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Business Skills' and code = 'BUSINESS_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Forward Thinking' AND code = 'FORWARD_THINKING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Forward Thinking', 'FORWARD_THINKING',
        'Can come up with new ideas using their own initiative, can adapt to change and inspire others with actions and ideas. Welcomes new responsibilities and can demonstrate creativity when problem solving.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Problem Solving' AND code = 'PROBLEM_SOLVING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Problem Solving', 'PROBLEM_SOLVING',
        'Developing solutions to problems and communicates the decision to others. Listening to all parties, grasping the key points and simplifying complex issues and seeking input from others and can use their own judgement.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Personal Management' AND code = 'PERSONAL_MANAGEMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Personal Management', 'PERSONAL_MANAGEMENT',
        'Managing time, planning, productive and reliable when under pressure to produce results. Can work independently and accept accountability. Develops good work procedures and can prioritise, react to opportunities and meet deadlines. Maintains a clean and functional workspace.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Initiative' AND code = 'INITIATIVE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Initiative', 'INITIATIVE',
        'Tackles problems and can take independent action. Seeking and picking up new responsibility and generate new ideas and practices self development.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Integrity/Morals' AND code = 'INTEGRITY_MORALS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Integrity/Morals', 'INTEGRITY_MORALS',
        'Deals and communicates with others in a straightforward and honest manner. Sets a strong example of integrity, dedication and fairness. Is accountable for actions and maintains confidentiality. Is respectful to others. Can deal with difficult situations head on. Follows through on commitments made to others.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Time Management/Planning' AND code = 'TIME_MANAGEMENT_PLANNING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Time Management/Planning', 'TIME_MANAGEMENT_PLANNING',
        'Manages time and resources, of themselves and others, planning and setting of goals, being effective, productive and reliable. Coordinates and cooperates with others.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Quality' AND code = 'QUALITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Quality', 'QUALITY',
        'Is attentive to detail and accuracy. Monitors quality levels and owns/acts on quality problems.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Innovation' AND code = 'INNOVATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Innovation', 'INNOVATION',
        'Challenges conventional ways of doing things to improve company performance, promotes the use of best practices that lead to improved department fiscal performance. Fosters an environment that encourages innovation and development of new ideas.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Risk Taking' AND code = 'RISK_TAKING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Risk Taking', 'RISK_TAKING',
        'Will make informed decisions when taking risks.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Team  ethics' AND code = 'TEAM_ETHICS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Team  ethics', 'TEAM_ETHICS',
        'Will work towards a common goal for the whole team not his own gratification or grandiosity. Must demonstrate a good team ethic for work and balance and to help others keeps things in balance.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Leadership' AND code = 'LEADERSHIP' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Leadership', 'LEADERSHIP',
        'Sets challenging and realistic goals for themselves and team members, accepts accountability and provides leadership and motivation. Leads by example.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Resilience Under Stress' AND code = 'RESILIENCE_UNDER_STRESS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Resilience Under Stress', 'RESILIENCE_UNDER_STRESS',
        'Remains calm and focused in stressful situations, and can clarify priorities during these times. Remains positive and optimistic despite setbacks.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Team  ethics' AND code = 'TEAM_ETHICS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Team  ethics', 'TEAM_ETHICS',
        'Strives to learn new skills, knowledge, experience and personal development. Accepts feedback and uses mistakes or misjudgements as learning opportunities.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Vision and Values' AND code = 'VISION_AND_VALUES' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Vision and Values', 'VISION_AND_VALUES',
        'Communicates company vision and values to others with enthusiasm and can incorporate that vision when planning.',
        (SELECT id FROM "0".skillgroup WHERE name = 'General' and code = 'GENERAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Monitoring People' AND code = 'MONITORING_PEOPLE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Monitoring People', 'MONITORING_PEOPLE',
        'Listens to others and diffuses conflict, finds solutions to problems. Maintains an inclusive workplace and maximizes contributions from all employees, develops strengths within the team. Monitors staff through their career progression. Manages Diversity.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Team Leadership' AND code = 'TEAM_LEADERSHIP' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Team Leadership', 'TEAM_LEADERSHIP',
        'Provides Leadership and motivation for the team and sets challenging and productive goals. Provides clear and concise roles for team members, motivates and leads through change and adversity. Is a role model for the team. Fosters an attitude of teamwork within the company.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Performance Management' AND code = 'PERFORMANCE_MANAGEMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Performance Management', 'PERFORMANCE_MANAGEMENT',
        'Set up systems to measure results. Applies clear and consistent performance standards, handles performance problems with understanding and allows for room for improvement.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Project Management' AND code = 'PROJECT_MANAGEMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Project Management', 'PROJECT_MANAGEMENT',
        'Establishes project goals and responsibilities and can acquire and manage resources and co-ordinate the project company wide.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Development of Subordinates' AND code = 'DEVELOPMENT_OF_SUBORDINATES' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Development of Subordinates', 'DEVELOPMENT_OF_SUBORDINATES',
        'Training and development of others, coaching and mentoring, assessessing and providing training. Puts people in challenging, learning situations to develop skills.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Delegation' AND code = 'DELEGATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Delegation', 'DELEGATION',
        'Sets challenging and realistic goals for team members. Also defines roles and responsibilities for staff so it is clear what their tasks are.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Control' AND code = 'CONTROL' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Control', 'CONTROL',
        'Keeps overall control of a task whilst providing others the appropriate level of independence and lets them take responsibility for their actions.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Staff Coordination' AND code = 'STAFF_COORDINATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Staff Coordination', 'STAFF_COORDINATION',
        'Holds regular team meetings that are clear and to the point, ensuring that all team members are clear on their tasks and responsibilities.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Planning and Organizing' AND code = 'PLANNING_AND_ORGANIZING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Planning and Organizing', 'PLANNING_AND_ORGANIZING',
        'Managing own time, planning and productive. Can organise staff and projects.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Self Organization' AND code = 'SELF_ORGANIZATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Self Organization', 'SELF_ORGANIZATION',
        'Can work independently and accepts accountability. Manages time, planning, productive and reliable when under pressure to produce results. Develops good work procedures and can prioritise, react to opportunities and meet deadlines. Maintains a clean and functional workspace.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Management' and code = 'MANAGEMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Teamwork' AND code = 'TEAMWORK' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Teamwork', 'TEAMWORK',
        'Is a good team member, promoting a positive and welcoming atmosphere. Meets all team deadlines and responsibilities, listens to others and values opinions and people.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Interpersonal Skills' AND code = 'INTERPERSONAL_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Interpersonal Skills', 'INTERPERSONAL_SKILLS',
        'Has good listening skills, builds strong relationships. Respecting and acknowledging others feelings and managing their own feeling also. Can show sensitivity when dealing with delicate issues.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Listening Skills' AND code = 'LISTENING_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Listening Skills', 'LISTENING_SKILLS',
        'Listens attentively to others, and asks relevant questions. Stays open minded to others viewpoints without distraction. Actively listens to others to gain an understanding of the problems/situation they are facing.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Mentoring' AND code = 'MENTORING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Mentoring', 'MENTORING',
        'Can bring on team members through mentoring  and allowing them to express themselves without fear of reprisals and therefore able to grow within the company.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Influence and Persuasion' AND code = 'INFLUENCE_AND_PERSUASION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Influence and Persuasion', 'INFLUENCE_AND_PERSUASION',
        'Develops good working relationships with the key people necessary to accomplish project goals, and can identify those with influence. Sells ideas and initiative to both peers and management. Acts as an advocate and representative for the department and staff that they lead.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sensitivity' AND code = 'SENSITIVITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sensitivity', 'SENSITIVITY',
        'Respecting and acknowledging others feelings and managing their own feelings also. Can also show sensitivity when dealing with delicate situations.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Leadership' AND code = 'LEADERSHIP' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Leadership', 'LEADERSHIP',
        'Sets a strong example of integrity, dedication and fairness when leading a team.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Communication' AND code = 'COMMUNICATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Communication', 'COMMUNICATION',
        'Good communications skills, questioning and active listening. Creates accurate and punctual reports and presentations. Shares information with others. Is also approachable and accessible to all members of staff. Keeps others informed about organisational plans and developments.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Interpersonal' and code = 'INTERPERSONAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Account Management' AND code = 'ACCOUNT_MANAGEMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Account Management', 'ACCOUNT_MANAGEMENT',
        'Manages existing sales accounts and responds to customer needs and nurtures relationships.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sales Administration' AND code = 'SALES_ADMINISTRATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sales Administration', 'SALES_ADMINISTRATION',
        'Develops detailed sales/marketing plans and forecast sales. Can manage his own time to generate new leads. Monitors the competition and can react accordingly to market changes.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sales Targets' AND code = 'SALES_TARGETS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sales Targets', 'SALES_TARGETS',
        'Achieves business plan goals, meets new business development goals. Achieves results within a given time frame. Is also goal directed and can show  achievement over a period of time.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sales Teamwork' AND code = 'SALES_TEAMWORK' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sales Teamwork', 'SALES_TEAMWORK',
        'Shares information with manager and team, works as part of a team, works with other departments, follows company policies and values, balances short- and long-term goals.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sales Ability/Persuasiveness' AND code = 'SALES_ABILITY_PERSUASIVENESS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sales Ability/Persuasiveness', 'SALES_ABILITY_PERSUASIVENESS',
        'Develops a good working relationship with key people to accomplish sales goals, and can identify those with influence.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sales Skills' AND code = 'SALES_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sales Skills', 'SALES_SKILLS',
        'Uses sales skills to develop new business to the right market. Listens to what the customer wants and can promote the produce effectively. Is able to supply the correct product to the customers requirements. Good presentation and negotiation skills.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Sales Organisation' AND code = 'SALES_ORGANISATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Sales Organisation', 'SALES_ORGANISATION',
        'Is incentivised to maximise sales promotions and produces accurate and timely sales reports.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Customer Focus' AND code = 'CUSTOMER_FOCUS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Customer Focus', 'CUSTOMER_FOCUS',
        'Understands what the customer wants and needs and has a full and complete product and market knowledge. Competitor and industry research and awareness.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Customer Service' AND code = 'CUSTOMER_SERVICE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Customer Service', 'CUSTOMER_SERVICE',
        'Provides a professional image to the customer and handles questions and complaints politely and efficiently. Manages customer expectation and maintains a professional relationship.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Sales' and code = 'SALES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Managing Technology' AND code = 'MANAGING_TECHNOLOGY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Managing Technology', 'MANAGING_TECHNOLOGY',
        'Uses technological resources to their advantage. Uses IT to maximum effect. Willingness to learn new IT skills and programs.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Technical Skills' AND code = 'TECHNICAL_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Technical Skills', 'TECHNICAL_SKILLS',
        'Understands specialty equipment, keeps knowledge up-to-date, is a technical resource for others, follows technology practices and standards.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Internet Use' AND code = 'INTERNET_USE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Internet Use', 'INTERNET_USE',
        'Uses the internet to the fullest and is familiar with all aspects of searching for information on markets and competitors.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Computer Knowledge' AND code = 'COMPUTER_KNOWLEDGE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Computer Knowledge', 'COMPUTER_KNOWLEDGE',
        'Is up to date on software packages that are needed on the job and the computer skills to utilise them. Can also use internal and external email to full advantage.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Technical' and code = 'TECHNICAL'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Decision Making/Judgment' AND code = 'DECISION_MAKING_JUDGMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Finance' and code = 'FINANCE'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Decision Making/Judgment', 'DECISION_MAKING_JUDGMENT',
        'Understands the financial impact of decisions.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Finance' and code = 'FINANCE'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Strategic Thinking/Management' AND code = 'STRATEGIC_THINKING_MANAGEMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Finance' and code = 'FINANCE'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Strategic Thinking/Management', 'STRATEGIC_THINKING_MANAGEMENT',
        'Shows an understanding of the industry and its competitors, and is able to predict market change and create both short and long term goals.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Finance' and code = 'FINANCE'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Financial Analytical Ability' AND code = 'FINANCIAL_ANALYTICAL_ABILITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Finance' and code = 'FINANCE'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Financial Analytical Ability', 'FINANCIAL_ANALYTICAL_ABILITY',
        'Recognises the impact of decisions on other areas of the business and the financial implications that it may mean.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Finance' and code = 'FINANCE'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Communication' AND code = 'COMMUNICATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Communication', 'COMMUNICATION',
        'Good communication skills, questioning and active listening skills also. Creates accurate and punctual reports and presentations. Shares information with others. Is also approachable and accessible to all members of staff. Keeps others informed about organisational plans and developments.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Motivation' AND code = 'MOTIVATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Motivation', 'MOTIVATION',
        'The drive to do the job well, to motivate staff, high work standards, shows an interest in all aspects of the job, including staff and technical know-how. Can withstand stress and identify the management structure.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Interpersonal' AND code = 'INTERPERSONAL' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Interpersonal', 'INTERPERSONAL',
        'To have an ability to emphasise when needed and show sensitivity and tact and persuasion.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Impact' AND code = 'IMPACT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Impact', 'IMPACT',
        'To be able to build up a rapport when needed, to be flexible in negotiations and staff and to show independence and resilience.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Decision Making' AND code = 'DECISION_MAKING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Decision Making', 'DECISION_MAKING',
        'Can show decisive decision making, and fact finding, and can show judgement when making decisions.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Extra-organizational Awareness' AND code = 'EXTRA_ORGANIZATIONAL_AWARENESS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Extra-organizational Awareness', 'EXTRA_ORGANIZATIONAL_AWARENESS',
        'Shows an awareness of the Health and safety regulations within the company. Is sensitive to the impact of decisions on other departments.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Knowledge/Skills' AND code = 'KNOWLEDGE_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Knowledge/Skills', 'KNOWLEDGE_SKILLS',
        'Has a good knowledge of the skills required to do the job, recognises short falls and strives to fill the gaps. Also manages the inter department relationships and understands others roles with the organisation to help bring about co-operation.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Career Developments' AND code = 'CAREER_DEVELOPMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Career Development', 'CAREER_DEVELOPMENT',
        'Strives to learn new skills, knowledge, experience and personal development. Accepts feedback and uses mistakes or misjudgements as learning opportunities. Expressed an interest in developing a career.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Job Characteristics' and code = 'JOB_CHARACTERISTICS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Listening' AND code = 'LISTENING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Listening', 'LISTENING',
        'Listens attentively to others, actively listens to gain an understanding and has an open mind.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Oral Communication' AND code = 'ORAL_COMMUNICATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Oral Communication', 'ORAL_COMMUNICATION',
        'Is able to communicate with superiors, peers and juniors alike.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Oral Presentation' AND code = 'ORAL_PRESENTATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Oral Presentation', 'ORAL_PRESENTATION',
        'Can deliver a confident and professional presentation.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Written Communications' AND code = 'WRITTEN_COMMUNICATIONS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Written Communications', 'WRITTEN_COMMUNICATIONS',
        'Produces concise and accurate reports.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Technical Translation' AND code = 'TECHNICAL_TRANSLATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Technical Translation', 'TECHNICAL_TRANSLATION',
        'Can put technical information in an easy to read/understand format.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Communication' and code = 'COMMUNICATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Job Motivation' AND code = 'JOB_MOTIVATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Job Motivation', 'JOB_MOTIVATION',
        'Demonstrates motivation in what he does by personal commitment and persistence in achieving goals and organisational objectives. Is self motivating and can be left to get on with the job in hand.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Work Standards' AND code = 'WORK_STANDARDS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Work Standards', 'WORK_STANDARDS',
        'Has the highest standards and good attitude to getting the job done. Will expand the extra effort needed to meet commitments and deliver quality results.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Initiative' AND code = 'INITIATIVE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Initiative', 'INITIATIVE',
        'Will take the initiative when dealing with an issue, and encourages team members to also think outside the box, challenges conventional ways of doing things.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Professional/Technical Interest' AND code = 'PROFESSIONAL_TECHNICAL_INTEREST' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Professional/Technical Interest', 'PROFESSIONAL_TECHNICAL_INTEREST',
        'Demonstrates an interest in all aspects of the job.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Energy' AND code = 'ENERGY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Energy', 'ENERGY',
        'Brings a positive and optimistic attitude to the job and praises staff when needed.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Attention to Detail' AND code = 'ATTENTION_TO_DETAIL' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Attention to Detail', 'ATTENTION_TO_DETAIL',
        'Is attentive to detail and accuracy. Monitors quality levels and owns/acts on quality problems.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Vigilance' AND code = 'VIGILANCE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Vigilance', 'VIGILANCE',
        '',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Integrity' AND code = 'INTEGRITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Integrity', 'INTEGRITY',
        'Shows integrity when dealing with others, deals with colleagues in an honest and straightforward manner. Is respectful to others and their opinions.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Ability to Learn' AND code = 'ABILITY_TO_LEARN' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Ability to Learn', 'ABILITY_TO_LEARN',
        'Strives to learn new skills, knowledge, experience and personal development. Accepts feedback and uses mistakes or misjudgements as learning opportunities.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Range of Interests' AND code = 'RANGE_OF_INTERESTS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Range of Interests', 'RANGE_OF_INTERESTS',
        'Has interests outside of the workplace, and can balance work life and home life.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Controlled Demeanour' AND code = 'CONTROLLED_DEMEANOUR' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Controlled Demeanour', 'CONTROLLED_DEMEANOUR',
        'Can remain calm, controlled and positive in challenging circumstances.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Motivation' and code = 'MOTIVATION'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Rapport Building' AND code = 'RAPPORT_BUILDING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Rapport Building', 'RAPPORT_BUILDING',
        'Builds a rapport within the team, through team building and communication.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Behavioural Flexibility' AND code = 'BEHAVIOURAL_FLEXIBILITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Behavioural Flexibility', 'BEHAVIOURAL_FLEXIBILITY',
        'Shows an ability to be flexible to others needs. Can adjust their own behaviour when needed.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Adaptability' AND code = 'ADAPTABILITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Adaptability', 'ADAPTABILITY',
        'Can adapt to different situations, when urgent action is required or when thought needs to be taken.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Negotiation' AND code = 'NEGOTIATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Negotiation', 'NEGOTIATION',
        'Conducts positive negotiations and demonstrates the ability to handle conflict and to bring about a positive resolution.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Independence' AND code = 'INDEPENDENCE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Independence', 'INDEPENDENCE',
        'Tackles problems and can independent action when needed.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Resilience' AND code = 'RESILIENCE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Resilience', 'RESILIENCE',
        'Despite knock backs can remain positive and proactive. Motivates the team and themselves.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Impact' and code = 'IMPACT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Analysis' AND code = 'ANALYSIS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Analysis', 'ANALYSIS',
        'Analyses the financial and personnel implications.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Judgment' AND code = 'JUDGMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Judgment', 'JUDGMENT',
        'Carefully weighs the pros and cons before making a decision.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Decisiveness' AND code = 'DECISIVENESS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Decisiveness', 'DECISIVENESS',
        'Can make a decision without delay.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Oral Fact Finding' AND code = 'ORAL_FACT_FINDING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Oral Fact Finding', 'ORAL_FACT_FINDING',
        'Talks to colleagues to find out more information before making a decision.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Financial Analytical Ability' AND code = 'FINANCIAL_ANALYTICAL_ABILITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Financial Analytical Ability', 'FINANCIAL_ANALYTICAL_ABILITY',
        'Recognises the impact of decisions on other areas of the business and the financial implications of that.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Decision Making' and code = 'DECISION_MAKING'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Recognition of Safety Needs' AND code = 'RECOGNITION_OF_SAFETY_NEEDS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Recognition of Safety Needs', 'RECOGNITION_OF_SAFETY_NEEDS',
        'Is up to date with Health and Safely regulations.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Innovativeness / Creativity' AND code = 'INNOVATIVENESS__CREATIVITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Innovativeness / Creativity', 'INNOVATIVENESS__CREATIVITY',
        'Fosters an environment that encourages innovation and development of ideas.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Risk Taking' AND code = 'RISK_TAKING' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Risk Taking', 'RISK_TAKING',
        'Will make informed decisions when taking risks.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Organisation Sensitivity' AND code = 'ORGANISATION_SENSITIVITY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Organisation Sensitivity', 'ORGANISATION_SENSITIVITY',
        'Manages inter-departmental relationships and understands others roles within the organisation.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' and code = 'EXTRA_ORGANISATIONAL_AWARENESS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Technical/Professional Knowledge' AND code = 'TECHNICAL_PROFESSIONAL_KNOWLEDGE' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Knowledge/Skills' and code = 'KNOWLEDGE_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Technical/Professional Knowledge', 'TECHNICAL_PROFESSIONAL_KNOWLEDGE',
        'Demonstrates knowledge of the job and understands the company mission statement and values. Has a full and complete product and market knowledge. Competitor and industry research and awareness.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Knowledge/Skills' and code = 'KNOWLEDGE_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Technical/Professional Proficiency' AND code = 'TECHNICAL_PROFESSIONAL_PROFICIENCY' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Knowledge/Skills' and code = 'KNOWLEDGE_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Technical/Professional Proficiency', 'TECHNICAL_PROFESSIONAL_PROFICIENCY',
        'Displays a thorough knowledge and competency of the job.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Knowledge/Skills' and code = 'KNOWLEDGE_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Basic Computer Skills' AND code = 'BASIC_COMPUTER_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Knowledge/Skills' and code = 'KNOWLEDGE_SKILLS'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Basic Computer Skills', 'BASIC_COMPUTER_SKILLS',
        'Is up to date on software packages that are needed on the job and the computer skills to utilise them. Can also use internal and external email to full advantage.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Knowledge/Skills' and code = 'KNOWLEDGE_SKILLS'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Career Ambition' AND code = 'CAREER_AMBITION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Career Development' and code = 'CAREER_DEVELOPMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Career Ambition', 'CAREER_AMBITION',
        'Demonstrates an ambition to move up the company but still being a team player.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Career Development' and code = 'CAREER_DEVELOPMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Self-development Orientation' AND code = 'SELF_DEVELOPMENT_ORIENTATION' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Career Development' and code = 'CAREER_DEVELOPMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Self-development Orientation', 'SELF_DEVELOPMENT_ORIENTATION',
        'Strives to learn new skills, gain knowledge and experience.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Career Development' and code = 'CAREER_DEVELOPMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Technical/Professional/Self-development' AND code = 'TECHNICAL_PROFESSIONAL_SELF_DEVELOPMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Career Development' and code = 'CAREER_DEVELOPMENT'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Technical/Professional/Self-development', 'TECHNICAL_PROFESSIONAL_SELF_DEVELOPMENT',
        'Will acknowledge the necessity to keep knowledge current and up to date, and will request further training to keep abreast of changes within the profession.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Career Development' and code = 'CAREER_DEVELOPMENT'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Hiring Employees' AND code = 'HIRING_EMPLOYEES' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Human Resources' and code = 'HUMAN_RESOURCES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Hiring Employees', 'HIRING_EMPLOYEES',
        'Can make a decision without delay.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Human Resources' and code = 'HUMAN_RESOURCES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Interpersonal Skills' AND code = 'INTERPERSONAL_SKILLS' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Human Resources' and code = 'HUMAN_RESOURCES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Interpersonal Skills', 'INTERPERSONAL_SKILLS',
        'Can make a decision without delay.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Human Resources' and code = 'HUMAN_RESOURCES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    IF EXISTS
      (SELECT * from "0".skill WHERE name = 'Recruitment' AND code = 'RECRUITMENT' AND
        groupid = (SELECT id FROM "0".skillgroup WHERE name = 'Human Resources' and code = 'HUMAN_RESOURCES'))
    THEN
    ELSE
       INSERT INTO "0".skill(name, code, description, groupid, id) VALUES
       ('Recruitment', 'RECRUITMENT',
        'Can make a decision without delay.',
        (SELECT id FROM "0".skillgroup WHERE name = 'Human Resources' and code = 'HUMAN_RESOURCES'),
        (SELECT setval('"0".skill_id_seq', (SELECT max(id) + 1 FROM "0".skill))) );
    END IF;

    --------------------------------------------------------------------------------------------------------------------

  RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

--after apply

update "0".myuser set deleted = false where deleted is null and (select "0".skillsFunction()) is not null;


--and
 --DROP FUNCTION "0".skillsFunction();
------------------------------------------------------------------------------------------------------------------------