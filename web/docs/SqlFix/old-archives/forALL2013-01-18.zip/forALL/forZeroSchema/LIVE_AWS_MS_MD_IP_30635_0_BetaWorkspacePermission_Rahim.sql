
insert into permission (code,context,name,sorder,ismainmenu)
select 'WORKSPACE_TASK_ADD','WORKSPACE','Add New Task',1,false
union all
select 'WORKSPACE_CASE_ADD','WORKSPACE','Add New Case',2,false
union all
select 'WORKSPACE_EVENT_ADD','WORKSPACE','Add New Event',3,false
union all
select 'WORKSPACE_ACCOUNT_ADD','WORKSPACE','Add New Account',4,false
union all
select 'WORKSPACE_OPPORTUNITIES_ADD','WORKSPACE','Add New Opportunity',5,false
union all
select 'WORKSPACE_LEAD_ADD','WORKSPACE','Add New Lead',6,false
union all
select 'WORKSPACE_SALES_INVOICE_ADD','WORKSPACE','Add New Sales Invoice',7,false
union all
select 'WORKSPACE_SALES_QUOTE_ADD','WORKSPACE','Add New Sales Quote',8,false;


insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_TASK_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='PM_TASKS_ADD';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_CASE_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='ADD_NEW_CASE';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_EVENT_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='CRM_ADD_NEW_ACTIVITY_EVENT';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_ACCOUNT_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='CRM_ACCOUNT_ADD';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_OPPORTUNITIES_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='CRM_ADD_NEW_OPPORTUNITIES';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_LEAD_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='ADD_NEW_LEAD';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_SALES_INVOICE_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='ACCOUNTING_SALES_INVOICE_ADD';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_SALES_QUOTE_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='ACCOUNTING_SALES_QUOTE_ADD';