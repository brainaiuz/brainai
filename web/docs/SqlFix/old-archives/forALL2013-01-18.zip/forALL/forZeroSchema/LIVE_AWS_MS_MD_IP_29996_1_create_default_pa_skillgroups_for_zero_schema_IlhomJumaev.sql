--for zero schema --> skill groups
------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION "0".skillGroupFunction() RETURNS integer AS $$
BEGIN

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Business Skills' AND code = 'BUSINESS_SKILLS')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Business Skills', 'BUSINESS_SKILLS', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'General' AND code = 'GENERAL')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('General', 'GENERAL', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Management' AND code = 'MANAGEMENT')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Management', 'MANAGEMENT', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Interpersonal' AND code = 'INTERPERSONAL')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Interpersonal', 'INTERPERSONAL', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Sales' AND code = 'SALES')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Sales', 'SALES', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Technical' AND code = 'TECHNICAL')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Technical', 'TECHNICAL', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Finance' AND code = 'FINANCE')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Finance', 'FINANCE', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Job Characteristics' AND code = 'JOB_CHARACTERISTICS')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Job Characteristics', 'JOB_CHARACTERISTICS', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Communication' AND code = 'COMMUNICATION')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Communication', 'COMMUNICATION', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Motivation' AND code = 'MOTIVATION')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Motivation', 'MOTIVATION', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Impact' AND code = 'IMPACT')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Impact', 'IMPACT', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Decision Making' AND code = 'DECISION_MAKING')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Decision Making', 'DECISION_MAKING', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Extra Organisational Awareness' AND code = 'EXTRA_ORGANISATIONAL_AWARENESS')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Extra Organisational Awareness', 'EXTRA_ORGANISATIONAL_AWARENESS', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Knowledge/Skills' AND code = 'KNOWLEDGE_SKILLS')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Knowledge/Skills', 'KNOWLEDGE_SKILLS', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Career Development' AND code = 'CAREER_DEVELOPMENT')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Career Development', 'CAREER_DEVELOPMENT', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

    IF EXISTS
      (SELECT * FROM "0".skillgroup WHERE name = 'Human Resources' AND code = 'HUMAN_RESOURCES')
    THEN
    ELSE
       INSERT INTO "0".skillgroup(name, code, id) VALUES
       ('Human Resources', 'HUMAN_RESOURCES', (SELECT setval('"0".skillgroup_id_seq', (SELECT max(id) + 1 FROM "0".skillgroup))) );
    END IF;

  RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;


--after apply

update "0".myuser set deleted = false where deleted is null and (select "0".skillGroupFunction()) is not null;


--and
 --DROP FUNCTION "0".skillGroupFunction();

------------------------------------------------------------------------------------------------------------------------