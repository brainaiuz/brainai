INSERT INTO permission(code,"name",context, parent, sorder, ismainmenu) VALUES('PM_SHOW_ALL_TASKS','Show all tasks','PM', (select id from permission where code = 'PM_TASKS_LIST'), 15, false);
INSERT INTO permission(code,"name",context, parent, sorder, ismainmenu) VALUES('PM_SHOW_UNASSIGNED_TASKS','Show non-assigned tasks','PM', (select id from permission where code = 'PM_TASKS_LIST'), 16, false);

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_SHOW_ALL_TASKS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_SHOW_ALL_TASKS', 'DR', (SELECT id from "0".reference where code='ALLOW') );