///////////----------- PUBLIC
CREATE OR REPLACE FUNCTION uuid_generate_v1()  RETURNS uuid
AS $$
DECLARE
value VARCHAR(36);
BEGIN
value = lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || '-';
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || '-';
value = value || lpad((to_hex((ceil(random() * 255)::int & 15) | 64)), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || '-';
value = value || lpad((to_hex((ceil(random() * 255)::int & 63) | 128)), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || '-';
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
value = value || lpad(to_hex(ceil(random() * 255)::int), 2, '0');
RETURN value::uuid;
END;
$$ LANGUAGE 'plpgsql';


/////////----- PRIVATE
--update bo`ladiganlari
update "anv".wfp_block set widget_id=855 where widget_id =69;
delete from "anv".wfp_block where id=69;

update "anv".wfp_block b set widget_guid=(select external_guid from wfp_widget where id=b.widget_id);

update "anv".wfp_block x set widget_id=(select min(id) from wfp_widget where external_guid=x.widget_guid group by external_guid );

update "anv".wfp_block set external_guid=uuid_generate_v1();
update "anv".wfp_draggableposition b set draggablecontainer_block_guid=(select external_guid from "anv".wfp_block where id=b.draggablecontainerid);
update "anv".wfp_page_block b set block_guid=(select external_guid from "anv".wfp_block where id=b.block_id);
update "anv".wfp_page_layout_block b set block_guid=(select external_guid from "anv".wfp_block where id=b.block_id);
update "anv".wfp_website_layout_block b set block_guid=(select external_guid from "anv".wfp_block where id=b.block_id);

update "anv".wfp_pagerbac b set block_guid=(select external_guid from "anv".wfp_block where id=b.block_id);

/*alohida*/
update "anv".wfp_page_layout set external_guid=uuid_generate_v1();
update "anv".wfp_page_layout_block b set pagelayout_guid=(select external_guid from "anv".wfp_page_layout where id=b.layout_id);
update "anv".wfp_page b set pagelayout_guid=(select external_guid from "anv".wfp_page_layout where id=b.page_layout_id);

update "anv".wfp_page set external_guid=uuid_generate_v1();
update "anv".wfp_page_block b set page_guid=(select external_guid from "anv".wfp_page where id=b.page_id);
update "anv".wfp_pagerbac b set page_guid=(select external_guid from "anv".wfp_page where id=b.page_id);
update "anv".wfp_website_menu b set page_guid=(select external_guid from "anv".wfp_page where id=b.page_id);

update "anv".wfp_website_layout set external_guid=uuid_generate_v1();
update "anv".wfp_website_layout_block b set websitelayout_guid=(select external_guid from "anv".wfp_website_layout where id=b.website_layout_id);
update "anv".wfp_website_layout_holders b set websitelayout_guid=(select external_guid from "anv".wfp_website_layout where id=b.website_layout_id);
update "anv".wfp_website_template b set websitelayout_guid=(select external_guid from "anv".wfp_website_layout where id=b.website_layout_id);
update "anv".wfp_page b set websitelayout_guid=(select external_guid from "anv".wfp_website_layout where id=b.website_layout_id);

update "anv".wfp_custom_forms set external_guid=uuid_generate_v1();
update "anv".wfp_custom_entities set external_guid=uuid_generate_v1();
update "anv".companypdftemplate b set customEntity_guid=(select external_guid from "anv".wfp_custom_entities where id=b.custom_Entityid);
update "anv".emailtemplate b set customEntity_guid=(select external_guid from "anv".wfp_custom_entities where id=b.customEntityid);
update "anv".wfp_custom_entity_group b set customEntity_guid=(select external_guid from "anv".wfp_custom_entities where id=b.customEntity_id);

update "anv".wfp_custom_list set external_guid=uuid_generate_v1();
update "anv".wfp_custom_list_items set external_guid=uuid_generate_v1();
update "anv".wfp_custom_list_items b set list_guid=(select external_guid from "anv".wfp_custom_list where id=b.listid);



/////----------------- PUBLIC
//////////////-- o`chiriladigan widgetlar
delete from wfp_widget where id in (select max(id) from wfp_widget group by external_guid having count(*)>1);

//////-------------- PRIVATE
ALTER TABLE "anv".wfp_custom_forms drop CONSTRAINT wfp_custom_forms_name_key;
ALTER TABLE "anv".wfp_custom_entities drop CONSTRAINT wfp_custom_entities_name_key;
ALTER TABLE "anv".wfp_custom_list DROP CONSTRAINT wfp_custom_list_name_key;


///////----------- PUBLIC
delete from wfp_widget where id in (select max(id) from wfp_widget group by external_guid having count(*)>1);
--unique constraint
ALTER TABLE wfp_widget ADD CONSTRAINT wfp_widget_external_guid_unique UNIQUE (external_guid);

////////////------------------ PRIVATE
ALTER TABLE "anv".wfp_block ADD CONSTRAINT wfp_block_widget_guid_unique UNIQUE (external_guid);