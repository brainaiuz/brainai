insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ASSESSMENT_MENU', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ATTENDENCE_SHEET', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_TEST_OPTION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_STUDENT_EXAM_STATUS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_IMPORT_STUDENT_ROSTER', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ASSESSMENT_MENU', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ATTENDENCE_SHEET', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_TEST_OPTION', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_STUDENT_EXAM_STATUS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_IMPORT_STUDENT_ROSTER', 'DR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'MEM', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'INSTRUCTOR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ATTENDENCE_SHEET', 'INSTRUCTOR', (SELECT id from "0".reference where code='ALLOW'));

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ASSESSMENT_MENU', 'ASSESSOR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_TEST_OPTION', 'ASSESSOR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_STUDENT_EXAM_STATUS', 'ASSESSOR', (SELECT id from "0".reference where code='ALLOW'));
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_IMPORT_STUDENT_ROSTER', 'ASSESSOR', (SELECT id from "0".reference where code='ALLOW') );
