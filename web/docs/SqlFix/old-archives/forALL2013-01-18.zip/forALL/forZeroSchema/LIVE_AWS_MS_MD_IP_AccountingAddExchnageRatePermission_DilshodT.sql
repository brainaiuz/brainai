-- ADD PERMISSION TABLE NEW PERMISSION
INSERT INTO permission(code,context,ismainmenu,name,sorder) VALUES('ACCOUNTING_SETTINGSE_EXCHANGE_RATE','ACCOUNTING',FALSE,'Multi company exchange rate',1);

-- ADD ROLEPERMISSION TO ZERO SCHEMA
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_SETTINGSE_EXCHANGE_RATE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_SETTINGSE_EXCHANGE_RATE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

-- ADD ROLEPERMISSION TO ANV SCHEMA
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_SETTINGSE_EXCHANGE_RATE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_SETTINGSE_EXCHANGE_RATE', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
