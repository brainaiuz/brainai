--for zero schema --> candidate sources / statuses (children)
------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION "0".candidateSourcesViaStatusesChildrenFunction() RETURNS integer AS $$
BEGIN

    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Internal' AND code = 'CANDIDATE_SOURCE_INTERNAL' AND parentid = (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Internal', 'CANDIDATE_SOURCE_INTERNAL', true, false, (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 1);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Imported' AND code = 'CANDIDATE_SOURCE_IMPORTED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Imported', 'CANDIDATE_SOURCE_IMPORTED', true, false, (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 2);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'API' AND code = 'CANDIDATE_SOURCE_API' AND parentid = (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('API', 'CANDIDATE_SOURCE_API', true, false, (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 3);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Google Import' AND code = 'CANDIDATE_SOURCE_GOOGLE_IMPORT' AND parentid = (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Google Import', 'CANDIDATE_SOURCE_GOOGLE_IMPORT', true, false, (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 4);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Web' AND code = 'CANDIDATE_SOURCE_WEB' AND parentid = (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Web', 'CANDIDATE_SOURCE_WEB', true, false, (select id from "0".reference where code = '_CANDIDATE_SOURCE' and parentid is null), 5);
    END IF;

    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'New' AND code = 'CANDIDATE_STATUS_NEW' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('New', 'CANDIDATE_STATUS_NEW', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 1);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Matched' AND code = 'CANDIDATE_STATUS_MATCHED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Matched', 'CANDIDATE_STATUS_MATCHED', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 2);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Shortlist' AND code = 'CANDIDATE_STATUS_SHORTLIST' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Shortlist', 'CANDIDATE_STATUS_SHORTLIST', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 3);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Interview' AND code = 'CANDIDATE_STATUS_INTERVIEW' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Interview', 'CANDIDATE_STATUS_INTERVIEW', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 4);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'On Hold' AND code = 'CANDIDATE_STATUS_ON_HOLD' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('On Hold', 'CANDIDATE_STATUS_ON_HOLD', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 5);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Rejected' AND code = 'CANDIDATE_STATUS_REJECTED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Rejected', 'CANDIDATE_STATUS_REJECTED', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 6);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Offer Made' AND code = 'CANDIDATE_STATUS_OFFER_MADE' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Offer Made', 'CANDIDATE_STATUS_OFFER_MADE', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 7);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Placed' AND code = 'CANDIDATE_STATUS_PLACED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Placed', 'CANDIDATE_STATUS_PLACED', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 8);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Offer Declined' AND code = 'CANDIDATE_STATUS_OFFER_DECLINED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Offer Declined', 'CANDIDATE_STATUS_OFFER_DECLINED', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 9);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Offer Withdrawn' AND code = 'CANDIDATE_STATUS_OFFER_WITHDRAWN' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Offer Withdrawn', 'CANDIDATE_STATUS_OFFER_WITHDRAWN', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 10);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Hired' AND code = 'CANDIDATE_STATUS_HIRED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Hired', 'CANDIDATE_STATUS_HIRED', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 11);
    END IF;

    IF EXISTS
      (SELECT * FROM "0".reference WHERE name = 'Unqualified' AND code = 'CANDIDATE_STATUS_UNQUALIFIED' AND parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null) )
    THEN
    ELSE
       INSERT INTO "0".reference(name, code, isSystemReference, isRemovable, parentid, sorder) VALUES
       ('Unqualified', 'CANDIDATE_STATUS_UNQUALIFIED', true, false, (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null), 12);
    END IF;

   ---------------------------------------------------------------------------------------------------------------------
  RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;


--after apply

update "0".myuser set deleted = false where deleted is null and (select "0".candidateSourcesViaStatusesChildrenFunction()) is not null;


--and
 --DROP FUNCTION "0".candidateSourcesViaStatusesChildrenFunction();

------------------------------------------------------------------------------------------------------------------------