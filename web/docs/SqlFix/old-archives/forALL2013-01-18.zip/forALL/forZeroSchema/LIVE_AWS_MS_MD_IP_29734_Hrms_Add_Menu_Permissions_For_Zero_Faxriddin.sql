// _Hrms_Add_Menu_Permissions_For_Zero_Faxriddin.sql urilgandan kiyin uriladi!!!

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'TL', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_BONUS_LIST', 'HR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTE_TAB_REMOVE_IMG', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTE_TAB_REMOVE_IMG', 'DR', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT_REMOVE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );

INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_BONUS_LIST', 'HR', (SELECT id from "0".reference where code='ALLOW') );
INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'HR', (SELECT id from "0".reference where code='ALLOW') );
INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'DR', (SELECT id from "0".reference where code='ALLOW') );
INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
