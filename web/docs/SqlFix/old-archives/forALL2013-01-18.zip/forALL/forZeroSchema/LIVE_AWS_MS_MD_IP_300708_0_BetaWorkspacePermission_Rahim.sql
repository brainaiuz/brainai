
insert into permission (code,context,name,sorder,ismainmenu)
select 'WORKSPACE_LEAVE_REQUEST_ADD','WORKSPACE','Add Leave Request',9,false
union all
select 'WORKSPACE_CONTACTS_ADD','WORKSPACE','Add CRM Contact',10,false
union all
select 'WORKSPACE_EXPENSE_ADD','WORKSPACE','Add Expense Claim',11,false;



insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_CONTACTS_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='CRM_ADD_NEW_CONTACT';

insert into "0".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_EXPENSE_ADD',priviledgeid,rolecode from "0".rolepermission where permissioncode='HRMS_ADD_NEW_EXPENSE_CLAIM';

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid")
VALUES ('WORKSPACE_LEAVE_REQUEST_ADD', 'MEM', (SELECT id from "0".reference where code='ALLOW') );