--for zero schema

---30090_4_Role_Permission_HRMS_Incident_and_Perofrmance_Note_IlhomJumaev.sql DAN KEYIN APPLY QILINSIN!!!

--incident delete
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'SALESMAN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'SALESPERSON', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'PM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'TL', (SELECT id from "0".reference where code='ALLOW') );



--performance note delete

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'TL', (SELECT id from "0".reference where code='ALLOW') );