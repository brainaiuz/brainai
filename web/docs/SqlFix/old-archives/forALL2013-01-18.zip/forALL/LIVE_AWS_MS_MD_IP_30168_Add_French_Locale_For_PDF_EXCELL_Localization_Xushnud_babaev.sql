INSERT INTO locale(country, countrycode, "language", languagecode)
    VALUES ('French', 'FR', 'fr', 'fr');
