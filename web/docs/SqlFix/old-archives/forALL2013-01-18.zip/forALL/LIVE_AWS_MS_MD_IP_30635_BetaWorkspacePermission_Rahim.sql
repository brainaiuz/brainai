--birinchi 0 schemani uring!!!!!!

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_TASK_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='PM_TASKS_ADD';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_CASE_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='ADD_NEW_CASE';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_EVENT_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='CRM_ADD_NEW_ACTIVITY_EVENT';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_ACCOUNT_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='CRM_ACCOUNT_ADD';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_OPPORTUNITIES_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='CRM_ADD_NEW_OPPORTUNITIES';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_LEAD_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='ADD_NEW_LEAD';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_SALES_INVOICE_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='ACCOUNTING_SALES_INVOICE_ADD';

insert into "anv".rolepermission (permissioncode,priviledgeid,rolecode)
select 'WORKSPACE_SALES_QUOTE_ADD',priviledgeid,rolecode from "anv".rolepermission where permissioncode='ACCOUNTING_SALES_QUOTE_ADD';