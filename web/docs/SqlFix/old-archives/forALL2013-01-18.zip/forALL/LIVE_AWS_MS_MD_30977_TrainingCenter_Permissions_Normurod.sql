INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('TC_OPERATION_MENU', 'TRAININGCENTER', 'Operation Menu', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('TC_ASSESSMENT_MENU', 'TRAININGCENTER', 'Assessment Menu', 2, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('TC_ATTENDENCE_SHEET', 'TRAININGCENTER', 'Attendence Sheet', 3, false, (SELECT id FROM permission WHERE code = 'TC_OPERATION_MENU'));
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('TC_TEST_OPTION', 'TRAININGCENTER', 'Assessment Test Option', 4, false, (SELECT id FROM permission WHERE code = 'TC_ASSESSMENT_MENU'));
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('TC_STUDENT_EXAM_STATUS', 'TRAININGCENTER', 'Student Exam Status', 5, false, (SELECT id FROM permission WHERE code = 'TC_ASSESSMENT_MENU'));
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('TC_IMPORT_STUDENT_ROSTER', 'TRAININGCENTER', 'Import Student Roster', 6, false, (SELECT id FROM permission WHERE code = 'TC_ASSESSMENT_MENU'));

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ASSESSMENT_MENU', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ATTENDENCE_SHEET', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_TEST_OPTION', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_STUDENT_EXAM_STATUS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_IMPORT_STUDENT_ROSTER', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ASSESSMENT_MENU', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ATTENDENCE_SHEET', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_TEST_OPTION', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_STUDENT_EXAM_STATUS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_IMPORT_STUDENT_ROSTER', 'DR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_OPERATION_MENU', 'INSTRUCTOR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ATTENDENCE_SHEET', 'INSTRUCTOR', (SELECT id from "anv".reference where code='ALLOW'));

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_ASSESSMENT_MENU', 'ASSESSOR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_TEST_OPTION', 'ASSESSOR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_STUDENT_EXAM_STATUS', 'ASSESSOR', (SELECT id from "anv".reference where code='ALLOW'));
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('TC_IMPORT_STUDENT_ROSTER', 'ASSESSOR', (SELECT id from "anv".reference where code='ALLOW') );