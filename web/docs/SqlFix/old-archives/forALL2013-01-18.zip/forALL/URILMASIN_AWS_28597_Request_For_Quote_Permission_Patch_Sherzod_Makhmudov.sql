/*public schemaga*/
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ACCOUNTING', 'Request For Quote List', null, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ACCOUNTING', 'Request For Quote Add', null, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ACCOUNTING', 'Request For Quote Edit', null, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ACCOUNTING', 'Request For Quote Delete', null, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ACCOUNTING', 'Request For Quote Summary', null, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ACCOUNTING', 'Request For Quote Copy', null, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ACCOUNTING', 'Request For Quote Convert', null, false);






/*0 schemaga*/
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );

insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );






/*Company schemalarga*/

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_LIST', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_ADD', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_EDIT', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_DELETE', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_COPY', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );