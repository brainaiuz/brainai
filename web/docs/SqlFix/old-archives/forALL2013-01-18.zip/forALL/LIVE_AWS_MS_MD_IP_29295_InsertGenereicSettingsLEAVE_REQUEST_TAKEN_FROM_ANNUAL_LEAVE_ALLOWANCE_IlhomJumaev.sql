--for custom companies

-- Company --> The POP Company -- companyID = 30458 (Szymon Bieniek's company)

insert into "30458".genericsettings (key, value) values ('LEAVE_REQUEST_TAKEN_FROM_ANNUAL_LEAVE_ALLOWANCE', 'YES');


--yana qaysidir company ga kerak bo'lsa companID ni qo'yib apply qilinadi!!!