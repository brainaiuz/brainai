/*0 schema uchun*/
INSERT INTO "0".reference(code,name,parentid,deleted,isremovable,issystemreference,shared) VALUES('INVOICE_STATUS_PENDING','Pending',166,false,false,true,true);

/*Hamma company schemalari uchun*/
INSERT INTO "anv".reference(code,name,parentid,deleted,isremovable,issystemreference,shared) VALUES('INVOICE_STATUS_PENDING','Pending',166,false,false,true,true);