CREATE OR REPLACE FUNCTION "anv".updateValidityPeriodFunc() RETURNS void AS $$
DECLARE v record;
BEGIN   
    for v IN (select * from "anv".validity_period where deleted is not true) 
       LOOP       
       if((select count(id) from "anv".reference where code='VALIDITY_PERIOD_APPRAISAL_GOAL' and id = v.periodType)>0)
       then
       begin
          insert into "anv".validity_period_Reference(validity_period_id, periodtypeitems_id) values(v.id,(select id from "anv".reference where code='VALIDITY_PERIOD_APPRAISAL'));
          insert into "anv".validity_period_Reference(validity_period_id, periodtypeitems_id) values(v.id,(select id from "anv".reference where code='VALIDITY_PERIOD_GOAL'));
          end;
        else
        begin
          insert into "anv".validity_period_Reference(validity_period_id, periodtypeitems_id) values(v.id,v.periodType);
          end;
       end if;           
       END LOOP;   
    
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

update "anv".myuser set deleted = false where deleted is not true and (select "anv".updateValidityPeriodFunc()) is null;

drop function "anv".updateValidityPeriodFunc();