insert into "anv".reference (name, code, description, deleted, isremovable, issystemreference, shared, parentid) values
  ('TC Questionaire type', '_TC_QUESTIONAIRE_TYPE', 'TC Questionaire type', false, false, true, true, null);

insert into "anv".reference (name, code, description, deleted, isremovable, issystemreference, shared, parentid) values
  ('TC Question type assesment', 'TC_QUESTION_TYPE_ASSESMENT', 'TC Question type assesment', false, false, true, true, (select distinct id from "anv".reference where code = '_TC_QUESTIONAIRE_TYPE')),
  ('TC Question type feedback', 'TC_QUESTION_TYPE_FEEDBACK', 'TC Question type feedback', false, false, true, true, (select distinct id from "anv".reference where code = '_TC_QUESTIONAIRE_TYPE'));