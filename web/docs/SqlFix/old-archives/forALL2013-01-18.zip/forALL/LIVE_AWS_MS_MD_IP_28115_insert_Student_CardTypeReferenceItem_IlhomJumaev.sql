--for zero schema --- bu patch schema update dan oldin apply qilinadi
DROP TABLE "0".student
--for all schema --- bu patch schema update dan oldin apply qilinadi
DROP TABLE "anv".student;

---------------------------------------------------------------------------------

--for zero schema

insert into "0".reference(name, code, parentid, isSystemReference, sorder) values ('Student Card Types', '_STUDENT_CARD_TYPES', null, true, 0);
insert into "0".reference(name, code, parentid, isSystemReference, sorder) values
('Driving License', 'STUDENT_CARD_TYPE_DRIVING_LICENSE', (select id from "0".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 1),
('Emirates Id', 'STUDENT_CARD_TYPE_EMIRATES_ID', (select id from "0".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 2),
('Labour Card', 'STUDENT_CARD_TYPE_LABOUR_CARD', (select id from "0".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 3),
('Passport', 'STUDENT_CARD_TYPE_PASSPORT', (select id from "0".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 4);


--for all schemas

insert into "anv".reference(name, code, parentid, isSystemReference, sorder) values ('Student Card Types', '_STUDENT_CARD_TYPES', null, true, 0);
insert into "anv".reference(name, code, parentid, isSystemReference, sorder) values
('Driving License', 'STUDENT_CARD_TYPE_DRIVING_LICENSE', (select id from "anv".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 1),
('Emirates Id', 'STUDENT_CARD_TYPE_EMIRATES_ID', (select id from "anv".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 2),
('Labour Card', 'STUDENT_CARD_TYPE_LABOUR_CARD', (select id from "anv".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 3),
('Passport', 'STUDENT_CARD_TYPE_PASSPORT', (select id from "anv".reference where code = '_STUDENT_CARD_TYPES' and parentid is null), true, 4);
