--for zero schema

insert into "0".reference (code, name, description, sorder, issystemreference, isremovable, deleted, shared, parentid) values('CANDIDATE_STATUS_AVAILABLE', 'Available', 'Candidate Available status', 1, true, false, false, true, (select id from "0".reference where code = '_CANDIDATE_STATUS'));
insert into "0".reference (code, name, description, sorder, issystemreference, isremovable, deleted, shared, parentid) values('CANDIDATE_STATUS_NOT_AVAILABLE', 'Not available', 'Candidate Not available status', 3, true, false, false, true, (select id from "0".reference where code = '_CANDIDATE_STATUS'));

update "0".reference set sorder = 1 where code = 'CANDIDATE_STATUS_AVAILABLE' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 2 where code = 'CANDIDATE_STATUS_NEW' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 3 where code = 'CANDIDATE_STATUS_NOT_AVAILABLE' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 4 where code = 'CANDIDATE_STATUS_MATCHED' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 5 where code = 'CANDIDATE_STATUS_SHORTLIST' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 6 where code = 'CANDIDATE_STATUS_INTERVIEW' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 7 where code = 'CANDIDATE_STATUS_ON_HOLD' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 8 where code = 'CANDIDATE_STATUS_REJECTED' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 9 where code = 'CANDIDATE_STATUS_OFFER_MADE' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 10 where code = 'CANDIDATE_STATUS_PLACED' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 11 where code = 'CANDIDATE_STATUS_OFFER_DECLINED' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 12 where code = 'CANDIDATE_STATUS_OFFER_WITHDRAWN' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 13 where code = 'CANDIDATE_STATUS_HIRED' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "0".reference set sorder = 14 where code = 'CANDIDATE_STATUS_UNQUALIFIED' and parentid = (select id from "0".reference where code = '_CANDIDATE_STATUS' and parentid is null);

-----------------------------------------------------------------------------------------------------------------------------

--for all schema

insert into "anv".reference (code, name, description, sorder, issystemreference, isremovable, deleted, shared, parentid) values('CANDIDATE_STATUS_AVAILABLE', 'Available', 'Candidate Available status', 1, true, false, false, true, (select id from "anv".reference where code = '_CANDIDATE_STATUS'));
insert into "anv".reference (code, name, description, sorder, issystemreference, isremovable, deleted, shared, parentid) values('CANDIDATE_STATUS_NOT_AVAILABLE', 'Not available', 'Candidate Not available status', 3, true, false, false, true, (select id from "anv".reference where code = '_CANDIDATE_STATUS'));

update "anv".reference set sorder = 1 where code = 'CANDIDATE_STATUS_AVAILABLE' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 2 where code = 'CANDIDATE_STATUS_NEW' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 3 where code = 'CANDIDATE_STATUS_NOT_AVAILABLE' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 4 where code = 'CANDIDATE_STATUS_MATCHED' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 5 where code = 'CANDIDATE_STATUS_SHORTLIST' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 6 where code = 'CANDIDATE_STATUS_INTERVIEW' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 7 where code = 'CANDIDATE_STATUS_ON_HOLD' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 8 where code = 'CANDIDATE_STATUS_REJECTED' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 9 where code = 'CANDIDATE_STATUS_OFFER_MADE' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 10 where code = 'CANDIDATE_STATUS_PLACED' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 11 where code = 'CANDIDATE_STATUS_OFFER_DECLINED' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 12 where code = 'CANDIDATE_STATUS_OFFER_WITHDRAWN' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 13 where code = 'CANDIDATE_STATUS_HIRED' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);
update "anv".reference set sorder = 14 where code = 'CANDIDATE_STATUS_UNQUALIFIED' and parentid = (select id from "anv".reference where code = '_CANDIDATE_STATUS' and parentid is null);


-----------------------------------------------------------------------------------------------------------------------------