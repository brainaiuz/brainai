INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_TASK_LIST_MORE_BUTTON', 'PM', 'Task list more button', 15, false,1);
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_WELLCOME_VIEW', 'PM', 'PM Wellcome view', 15, false,20);
INSERT INTO permission(code, context, "name", sorder, ismainmenu) VALUES ('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', 'ACCOUNTING', 'Purchase Order Approve and Send Button', 1, false);

