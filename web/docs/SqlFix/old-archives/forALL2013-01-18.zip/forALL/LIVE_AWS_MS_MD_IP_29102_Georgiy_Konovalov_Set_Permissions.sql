/*Public schema */
INSERT INTO permission(code,"name",context,ismainmenu, sorder) VALUES('HRMS_ONBOARDING_MANAGEMENT','HRMS Onboarding Period/Activity','HRMS',false,1);
INSERT INTO permission(code,"name",context,ismainmenu,sorder) VALUES('HRMS_ONBOARDING_CHECKLIST_VIEW','HRMS Onboarding Checklist View','HRMS',false,2);
INSERT INTO permission(code,"name",context,ismainmenu,sorder) VALUES('HRMS_ONBOARDING_CHECKLIST_EDIT','HRMS Onboarding Checklist Edit','HRMS',false,3);



insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'HR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_VIEW', 'MEM', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'ADMIN_LOCATION', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'DR', (SELECT id from "0".reference where code='ALLOW') );
insert into "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'HR', (SELECT id from "0".reference where code='ALLOW') );



/*Company schemas*/
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_MANAGEMENT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_VIEW', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ONBOARDING_CHECKLIST_EDIT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );