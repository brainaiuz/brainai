--for all schemas --> CRM_CASE_ASSIGNEE_NOTIFICATION
------------------------------------------------------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION "anv".crmCaseAssignNotificationFunction() RETURNS integer AS $$
BEGIN

    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "anv".companyEmailNotificationSettings WHERE category = 'CATEGORY_CRM' AND notificationname = 'CRM_CASE_ASSIGNEE_NOTIFICATION' AND
        rolegroupid = (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2))
    THEN
    ELSE
       INSERT INTO "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled, id) VALUES
       ('CATEGORY_CRM', 'Send auto message to "assignee" when the case is assigned to employee', 'CRM_CASE_ASSIGNEE_NOTIFICATION',
        (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), false,
        (SELECT setval('"anv".companyEmailNotificationSettings_id_seq', (SELECT max(id) + 1 FROM "anv".companyEmailNotificationSettings))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "anv".companyEmailNotificationSettings WHERE category = 'CATEGORY_CRM' AND notificationname = 'CRM_CASE_ASSIGNEE_NOTIFICATION' AND
        rolegroupid = (SELECT id FROM "anv".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2))
    THEN
    ELSE
       INSERT INTO "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled, id) VALUES
       ('CATEGORY_CRM', 'Send auto message to "assignee" when the case is assigned to employee', 'CRM_CASE_ASSIGNEE_NOTIFICATION',
        (SELECT id FROM "anv".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), false,
        (SELECT setval('"anv".companyEmailNotificationSettings_id_seq', (SELECT max(id) + 1 FROM "anv".companyEmailNotificationSettings))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "anv".companyEmailNotificationSettings WHERE category = 'CATEGORY_CRM' AND notificationname = 'CRM_CASE_ASSIGNEE_NOTIFICATION' AND
        rolegroupid = (SELECT id FROM "anv".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2))
    THEN
    ELSE
       INSERT INTO "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled, id) VALUES
       ('CATEGORY_CRM', 'Send auto message to "assignee" when the case is assigned to employee', 'CRM_CASE_ASSIGNEE_NOTIFICATION',
        (SELECT id FROM "anv".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), false,
        (SELECT setval('"anv".companyEmailNotificationSettings_id_seq', (SELECT max(id) + 1 FROM "anv".companyEmailNotificationSettings))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "anv".companyEmailNotificationSettings WHERE category = 'CATEGORY_CRM' AND notificationname = 'CRM_CASE_ASSIGNEE_NOTIFICATION' AND
        rolegroupid = (SELECT id FROM "anv".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2))
    THEN
    ELSE
       INSERT INTO "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled, id) VALUES
       ('CATEGORY_CRM', 'Send auto message to "assignee" when the case is assigned to employee', 'CRM_CASE_ASSIGNEE_NOTIFICATION',
        (SELECT id FROM "anv".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), false,
        (SELECT setval('"anv".companyEmailNotificationSettings_id_seq', (SELECT max(id) + 1 FROM "anv".companyEmailNotificationSettings))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "anv".companyEmailNotificationSettings WHERE category = 'CATEGORY_CRM' AND notificationname = 'CRM_CASE_ASSIGNEE_NOTIFICATION' AND
        rolegroupid = (SELECT id FROM "anv".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2))
    THEN
    ELSE
       INSERT INTO "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled, id) VALUES
       ('CATEGORY_CRM', 'Send auto message to "assignee" when the case is assigned to employee', 'CRM_CASE_ASSIGNEE_NOTIFICATION',
        (SELECT id FROM "anv".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), false,
        (SELECT setval('"anv".companyEmailNotificationSettings_id_seq', (SELECT max(id) + 1 FROM "anv".companyEmailNotificationSettings))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------
    IF EXISTS
      (SELECT * from "anv".companyEmailNotificationSettings WHERE category = 'CATEGORY_CRM' AND notificationname = 'CRM_CASE_ASSIGNEE_NOTIFICATION' AND
        rolegroupid = (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2))
    THEN
    ELSE
       INSERT INTO "anv".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled, id) VALUES
       ('CATEGORY_CRM', 'Send auto message to "assignee" when the case is assigned to employee', 'CRM_CASE_ASSIGNEE_NOTIFICATION',
        (SELECT id FROM "anv".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), false,
        (SELECT setval('"anv".companyEmailNotificationSettings_id_seq', (SELECT max(id) + 1 FROM "anv".companyEmailNotificationSettings))) );
    END IF;
    --------------------------------------------------------------------------------------------------------------------

  RETURN null;
END;
$$ LANGUAGE 'plpgsql' VOLATILE;

--after apply

update "anv".myuser set deleted = false where deleted is null and (select "anv".crmCaseAssignNotificationFunction()) is not null;


--and
 --DROP FUNCTION "anv".crmCaseAssignNotificationFunction();
------------------------------------------------------------------------------------------------------------------------