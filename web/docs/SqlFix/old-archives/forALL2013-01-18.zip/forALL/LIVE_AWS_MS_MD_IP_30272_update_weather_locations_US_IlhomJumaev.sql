--apply to public schema

UPDATE weather_locations SET location='Saint Louis, MO' WHERE country_id=46 AND location='St. Louis MO';
UPDATE weather_locations SET location='Los Angeles, CA' WHERE country_id=46 AND location='Los Angeles CA';
UPDATE weather_locations SET location='Chicago, IL' WHERE country_id=46 AND location='Chicago IL';
