UPDATE smssettings SET smsproviderid = 1, providerName = 'ClickAtell', keyvalues = '<apiid>=' || smsapi || ';<senderID>=' || fromname WHERE smsapi IS NOT NULL;
UPDATE smssettings SET smsproviderid = 2, providerName = 'MVaaYoo', keyvalues = '<apiid>=' || smsapi || ';<senderID>=' || fromname WHERE smsapi IS NULL;
ALTER TABLE smssettings ALTER COLUMN "type" SET DEFAULT 'URL';
