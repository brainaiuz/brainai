update "anv".myuser set deleted = false where deleted is not true and (SELECT setval('"anv".role_id_seq', (select max(id) + 1 from "anv".role))) is null;

insert into "anv".role (code,description,name,issystem,isdeleted,isentityspecific,sorder)
	values('INSTRUCTOR', '','Course Instructor', true, false, false, (select max(sorder)+1 from "anv".role where issystem=true));