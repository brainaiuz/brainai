--for all schemas  -- default
------------------------------------------------------------------------------------------------------------------------
--alphabetically ordering by project numbering
insert into "anv".genericsettings (key, value) values ('PROJECT_SORT_ALPHABETICALLY_BY_NUMBER', 'YES');

--show project name with project number
insert into "anv".genericsettings (key, value) values ('PROJECT_NAME_SHOW_WITH_PROJECT_NUMBER', 'YES');
------------------------------------------------------------------------------------------------------------------------

--- agar default project name bo'yicha alphabetically ordering qilinmoqchi bo'linsa, mana bu update ni apply qilinadi!!!!
--COMPANY_ID ni o'rniga kerakli company ni ID si qo'yiladi!!!
update "COMPANY_ID".genericsettings set value = 'NO' where key = 'PROJECT_SORT_ALPHABETICALLY_BY_NUMBER';

--- agar project drop daun da default project name ni o'zi chiqishi kerak bo'lsa, mana bu update ni apply qilinadi!!!!
--COMPANY_ID ni o'rniga kerakli company ni ID si qo'yiladi!!!
update "COMPANY_ID".genericsettings set value = 'NO' where key = 'PROJECT_NAME_SHOW_WITH_PROJECT_NUMBER';
------------------------------------------------------------------------------------------------------------------------


--for custom client
update "COMPANY_ID".genericsettings set value = 'NO' where key = 'PROJECT_SORT_ALPHABETICALLY_BY_NUMBER';
------------------------------------------------------------------------------------------------------------------------