-- LIVE ga free ga ham paid ga ham URILGAN!!!
INSERT INTO "anv".annualleave(allowanceyear, annualallowanceminutes, employeeid)
SELECT 2013, al.annualallowanceminutes, e.id
FROM "anv".employee e
LEFT JOIN "anv".annualleave al on al.employeeid = e.id
WHERE al.allowanceyear = 2012
GROUP BY e.id, al.annualallowanceminutes;