delete from "anv".myuser_role where roles_id=(select id from "anv".role where code = 'ONE_OFF');
delete from "anv".rolepermission where rolecode = 'ONE_OFF';
delete from "anv".steprole where stepid = (select id from "anv".role where code = 'ONE_OFF');
delete from "anv".role where code = 'ONE_OFF';