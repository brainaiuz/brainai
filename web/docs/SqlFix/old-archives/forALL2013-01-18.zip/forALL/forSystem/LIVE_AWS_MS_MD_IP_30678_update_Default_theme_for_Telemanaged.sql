UPDATE hostbasedsetting set defaultTheme = 'tele' where hostname = 'aws.telemanaged.com' or hostname = 'app.telemanaged.com';
