delete from pricing where hostName = 'app.kpi.com' and userCount > 20;


update pricing set price = 11.42 where hostName = 'app.kpi.com' and userCount in (19,20);