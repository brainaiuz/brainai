
------------------------------------------------------------------------------------------------------------------------
--for globalauth DB
--for pricing TABLE, insert new columns

ALTER TABLE pricing ADD COLUMN oneMonth numeric(11, 2);
ALTER TABLE pricing ADD COLUMN threeMonth numeric(11, 2);
ALTER TABLE pricing ADD COLUMN sixMonth numeric(11, 2);
ALTER TABLE pricing ADD COLUMN twentyMonth numeric(11, 2);


------------------------------------------------------------------------------------------------------------------------
--after update pricing table columns

--for APP.KPI.COM and AWS.KPI.COM      --> (1 month - not discount), 3 month - 15%, 6 month - 25%, 12 month - 30%;
update pricing set oneMonth=0.00, threeMonth=0.15, sixMonth=0.25, twentyMonth=0.30 where hostName ='app.kpi.com';
update pricing set oneMonth=0.00, threeMonth=0.15, sixMonth=0.25, twentyMonth=0.30 where hostName ='aws.kpi.com';

--for APP.SMEBU.COM and AWS.SMEBU.COM  --> (1 month - not discount), 3 month - 2%, 6 month - 4%, 12 month - 6%;
update pricing set oneMonth=0.00, threeMonth=0.02, sixMonth=0.04, twentyMonth=0.06 where hostName ='app.smebu.com';
update pricing set oneMonth=0.00, threeMonth=0.02, sixMonth=0.04, twentyMonth=0.06 where hostName ='aws.smebu.com';

------------------------------------------------------------------------------------------------------------------------