
--

ALTER TABLE hostBasedSetting ADD COLUMN currencyCODE character varying(255);
--

--for app.kpi.com and other hosts default currency CODE == 'USD'
update hostBasedSetting set currencyCODE = 'USD';

--for aws.tjilo.com AND app.tjilo.com currency CODE == 'EUR'

update hostBasedSetting set currencyCODE = 'EUR' where hostname = 'app.tjilo.com';
update hostBasedSetting set currencyCODE = 'EUR' where hostname = 'aws.tjilo.com';