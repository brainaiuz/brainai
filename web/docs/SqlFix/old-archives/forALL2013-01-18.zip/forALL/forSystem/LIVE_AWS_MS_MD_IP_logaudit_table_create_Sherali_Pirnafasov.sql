CREATE TABLE logaudit
(
  id serial NOT NULL,
  host character varying,
  ip character varying,
  company_id character varying,
  company_name character varying,
  company_type character varying,
  user_id character varying,
  username character varying,
  user_role character varying,
  entity_id character varying,
  entity_type character varying,
  entity_name character varying,
  action_type character varying,
  country_name character varying,
  user_agent character varying,
  app_version character varying,
  os_version character varying,
  device_name character varying,
  detail character varying,
  log_level character varying,
  log_location character varying,
  action_date character varying,
  CONSTRAINT logaudit_pkey PRIMARY KEY (id )
)
WITH (
  OIDS=FALSE
);
ALTER TABLE logaudit
  OWNER TO wfmtest;