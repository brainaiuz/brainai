CREATE TABLE pricing_package
(
  id serial NOT NULL,
  hostName character varying(255),
  packageName character varying(255),
  price numeric(11, 2),
  min_one_month integer,
  min_three_month integer,
  min_six_month integer,
  max_twenty_month integer,
  CONSTRAINT pricing_package_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE pricing_package OWNER TO wftauth;


--after !!!!


--- insert query
--PP_SMALL_BUSINESS
--//FOR APP.KPI.COM HOST --> (Pricing package - Small business), price - 9,99$; min user count -> 1 month - 11 user, 3 month - 3 user, 6 month - 1 user; max user count -> 12 month - 30 user;
insert into pricing_package (hostName, packageName, price, min_one_month, min_three_month, min_six_month, max_twenty_month)
  VALUES('app.kpi.com', 'PP_SMALL_BUSINESS', 9.99, 11, 3, 1, 30);
--PP_KPI_PRO
--//FOR APP.KPI.COM HOST --> (Pricing package - KPI pro), price - 14,99$; min user count -> 1 month - 6 user, 3 month - 2 user, 6 month - 1 user; max user count -> 12 month - 30 user;
insert into pricing_package (hostName, packageName, price, min_one_month, min_three_month, min_six_month, max_twenty_month)
  VALUES('app.kpi.com', 'PP_KPI_PRO', 14.99, 6, 2, 1, 30);
--PP_ENTERPRISE
--//FOR APP.KPI.COM HOST --> (Pricing package - Enterprise), price - 19,99$; min user count -> 1 month - 5 user, 3 month - 2 user, 6 month - 1 user; max user count -> 12 month - 30 user;
insert into pricing_package (hostName, packageName, price, min_one_month, min_three_month, min_six_month, max_twenty_month)
  VALUES('app.kpi.com', 'PP_ENTERPRISE', 19.99, 5, 2, 1, 30);