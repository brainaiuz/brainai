
------------------------------------------------------------------------------------------------------------------------
--aws.tjilo.com  ----------- AWS ga man apply qilib qo'ydim aws.kpi.com bilan (lekin app.tjilo.com yo'q)
--for app.tjilo.com

------------------------------------------------------------------------------------------------------------------------

--  --pricing table

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',1,'25.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',2,'25.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',3,'25.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',4,'25.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',5,'21.80','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',6,'19.67','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',7,'18.14','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',8,'17.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',9,'16.11','00.00','00.10','0.15','0.25');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',10,'15.40','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',11,'14.82','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',12,'14.33','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',13,'13.92','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',14,'13.57','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',15,'13.27','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',16,'13.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',17,'12.76','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',18,'12.56','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',19,'12.37','00.00','00.10','0.15','0.25');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',20,'12.20','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',21,'12.00','00.00','00.10','0.15','0.25');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',22,'11.83','00.01','00.11','0.16','0.26');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',23,'11.67','00.01','00.11','0.16','0.26');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',24,'11.52','00.01','00.11','0.16','0.26');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',25,'11.38','00.02','00.11','0.16','0.26');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',26,'11.25','00.02','00.12','0.17','0.26');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',27,'11.14','00.02','00.12','0.17','0.27');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',28,'11.03','00.02','00.12','0.17','0.27');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',29,'10.93','00.02','00.12','0.17','0.27');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',30,'10.83','00.03','00.12','0.17','0.27');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',31,'10.75','00.03','00.13','0.17','0.27');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',32,'10.66','00.03','00.13','0.18','0.27');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',33,'10.58','00.03','00.13','0.18','0.27');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',34,'10.51','00.03','00.13','0.18','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',35,'10.44','00.04','00.13','0.18','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',36,'10.38','00.04','00.13','0.18','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',37,'10.32','00.04','00.13','0.18','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',38,'10.26','00.04','00.14','0.18','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',39,'10.20','00.04','00.14','0.19','0.28');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',40,'10.15','00.04','00.14','0.19','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',41,'10.10','00.04','00.14','0.19','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',42,'10.05','00.04','00.14','0.19','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',43,'10.01','00.05','00.14','0.19','0.28');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',44,'9.96','00.05','00.14','0.19','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',45,'9.92','00.05','00.14','0.19','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',46,'9.88','00.05','00.14','0.19','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',47,'9.84','00.05','00.14','0.19','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',48,'9.81','00.05','00.15','0.19','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',49,'9.77','00.05','00.15','0.19','0.29');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',50,'9.74','00.05','00.15','0.19','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',51,'9.69','00.06','00.15','0.20','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',52,'9.64','00.06','00.15','0.20','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',53,'9.60','00.06','00.15','0.20','0.29');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',54,'9.55','00.06','00.16','0.20','0.30');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',55,'9.51','00.06','00.16','0.20','0.30');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',56,'9.47','00.07','00.16','0.21','0.30');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',57,'9.43','00.07','00.16','0.21','0.30');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',58,'9.39','00.07','00.16','0.21','0.30');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',59,'9.35','00.07','00.17','0.21','0.30');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',60,'9.32','00.07','00.17','0.21','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',61,'9.28','00.08','00.17','0.21','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',62,'9.25','00.08','00.17','0.22','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',63,'9.22','00.08','00.17','0.22','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',64,'9.18','00.08','00.17','0.22','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',65,'9.15','00.08','00.17','0.22','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',66,'9.12','00.08','00.18','0.22','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',67,'9.10','00.09','00.18','0.22','0.31');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',68,'9.07','00.09','00.18','0.22','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',69,'9.04','00.09','00.18','0.23','0.32');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',70,'9.01','00.09','00.18','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',71,'8.99','00.09','00.18','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',72,'8.96','00.09','00.18','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',73,'8.94','00.09','00.19','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',74,'8.92','00.10','00.19','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',75,'8.89','00.10','00.19','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',76,'8.87','00.10','00.19','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',77,'8.85','00.10','00.19','0.23','0.32');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',78,'8.83','00.10','00.19','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',79,'8.81','00.10','00.19','0.24','0.33');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',80,'8.79','00.10','00.19','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',81,'8.77','00.10','00.19','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',82,'8.75','00.11','00.19','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',83,'8.73','00.11','00.20','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',84,'8.71','00.11','00.20','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',85,'8.69','00.11','00.20','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',86,'8.68','00.11','00.20','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',87,'8.66','00.11','00.20','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',88,'8.64','00.11','00.20','0.24','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',89,'8.63','00.11','00.20','0.25','0.33');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',90,'8.61','00.11','00.20','0.25','0.33');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',91,'8.60','00.11','00.20','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',92,'8.58','00.12','00.20','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',93,'8.57','00.12','00.20','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',94,'8.55','00.12','00.21','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',95,'8.54','00.12','00.21','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',96,'8.52','00.12','00.21','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',97,'8.51','00.12','00.21','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',98,'8.50','00.12','00.21','0.25','0.34');
insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',99,'8.48','00.12','00.21','0.25','0.34');

insert into pricing (hostname,userCount,price,oneMonth,threeMonth,sixMonth,twentyMonth) values ('app.tjilo.com',100,'8.47','00.12','00.21','0.25','0.34');