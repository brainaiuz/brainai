CREATE TABLE support_package
(
  id serial NOT NULL,
  hostName character varying(255),
  packageName character varying(255),
  price numeric(11, 2),
  CONSTRAINT support_package_pkey PRIMARY KEY (id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE support_package OWNER TO wftauth;


--after !!!!


--- insert query
--SP_BASIC
--//FOR APP.KPI.COM HOST --> (Support package - Basic), price - 295$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_BASIC', 295);
--SP_STANDARD
--//FOR APP.KPI.COM HOST --> (Support package - Standard), price - 495$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_STANDARD', 495);
--SP_BRONZE
--//FOR APP.KPI.COM HOST --> (Support package - Bronze), price - 995$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_BRONZE', 995);
--SP_SILVER
--//FOR APP.KPI.COM HOST --> (Support package - Silver), price - 1795$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_SILVER', 1795);
--SP_GOLD
--//FOR APP.KPI.COM HOST --> (Support package - Gold), price - 2495$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_GOLD', 2495);
--SP_PLATINUM
--//FOR APP.KPI.COM HOST --> (Support package - Platinum), price - 4995$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_PLATINUM', 4995);
--SP_DIAMOND
--//FOR APP.KPI.COM HOST --> (Support package - Diamond), price - 7995$;
insert into support_package (hostName, packageName, price) VALUES('app.kpi.com', 'SP_DIAMOND', 7995);