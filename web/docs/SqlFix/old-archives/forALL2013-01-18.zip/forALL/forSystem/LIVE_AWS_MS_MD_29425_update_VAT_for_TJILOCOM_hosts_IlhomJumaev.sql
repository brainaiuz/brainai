--for aws.tjilo.com AND app.tjilo.com hosts

update hostBasedSetting set vat = 0.21 where hostname = 'app.tjilo.com';

update hostBasedSetting set vat = 0.21 where hostname = 'aws.tjilo.com';