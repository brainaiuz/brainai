UPDATE hostbasedsetting set wikiurl = 'smebu.com/content/support' where hostname like '%smebu%';
UPDATE hostbasedsetting set wikiurl = 'tjilo.com/content/support' where hostname like '%tjilo%';
UPDATE hostbasedsetting set wikiurl = 'ezyadmin.com/content/support' where hostname like '%ezyadmin%';
UPDATE hostbasedsetting set wikiurl = 'telemanaged.com/content/support' where hostname like '%telemanaged%';
UPDATE hostbasedsetting set wikiurl = 'ammali.omandatapark.com/content/support' where hostname like '%omandatapark%';