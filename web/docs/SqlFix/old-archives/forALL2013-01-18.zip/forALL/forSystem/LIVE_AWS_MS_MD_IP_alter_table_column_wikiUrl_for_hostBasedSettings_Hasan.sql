

ALTER TABLE hostBasedSetting ADD COLUMN wikiUrl character varying(255);
--


UPDATE hostbasedsetting set wikiurl = 'wiki.kpi.com' where hostname = 'aws.kpi.com';
UPDATE hostbasedsetting set wikiurl = 'wiki.kpi.com' where hostname = 'app.kpi.com';