--pm task/project issue permission
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('PM_TASKS_ISSUE', 'PM', 'Task issue', 7, false, (select id from permission where code='PM_TASKS_LIST'));
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('PM_PROJECT_ISSUE', 'PM', 'Project issue', 14, false, (select id from permission where code='PM_SEE_ALL_PROJECTS'));

--crm task issue permission
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu", parent) values ('CRM_TASKS_ISSUE', 'CRM', 'Task Compose', 10, false, (select id from permission where code='CRM_TASKS_LIST'));




-- PM task issue
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_TASKS_ISSUE', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );

--PM project issue
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'TL', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'CLIENT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'PMOFPR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('PM_PROJECT_ISSUE', 'DLOFPR', (SELECT id from "anv".reference where code='ALLOW') );


--CRM task issue
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ISSUE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ISSUE', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ISSUE', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ISSUE', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('CRM_TASKS_ISSUE', 'CREATOR', (SELECT id from "anv".reference where code='ALLOW') );