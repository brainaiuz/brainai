-- For zero schema
-- Task Relationship for zero schema
update updater set id = 1 where (select setval('"0".relationship_id_seq',(select max(id) from "0".relationship))) is not null;
update updater set id = 1 where (select setval('"0".taskpolicy_id_seq',(select max(id) from "0".taskpolicy))) is not null;
insert into "0".relationship(code,description,entityname,entrytype,name,rank,relationtype) values('TASK_NOT_ASSIGNEE','','TASK',1,'Task not assignee',8,'DIRECT');
insert into "0".taskpolicy(description,entryType,permissionid,relationid) values('Policy related to Task not assignee',2,1,(select id from "0".relationship where code='TASK_NOT_ASSIGNEE'));

-- For ALL schema
-- Task Relationship for zero schema
update updater set id = 1 where (select setval('"anv".relationship_id_seq',(select max(id) from "anv".relationship))) is not null;
update updater set id = 1 where (select setval('"anv".taskpolicy_id_seq',(select max(id) from "anv".taskpolicy))) is not null;
insert into "anv".relationship(code,description,entityname,entrytype,name,rank,relationtype) values('TASK_NOT_ASSIGNEE','','TASK',1,'Task not assignee',8,'DIRECT');
insert into "anv".taskpolicy(description,entryType,permissionid,relationid) values('Policy related to Task not assignee',2,1,(select id from "anv".relationship where code='TASK_NOT_ASSIGNEE'));