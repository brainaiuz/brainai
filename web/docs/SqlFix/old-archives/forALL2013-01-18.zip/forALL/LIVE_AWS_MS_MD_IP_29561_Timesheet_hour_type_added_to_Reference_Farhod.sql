insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared) values ('_TIMESHEET_TYPE', 'Timesheet Type', false, true, false, true);

insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared, parentid) values 
('TYPE_FOR_EDIT', 'Type for edit', false, true, false, true, (select id from "anv".reference where code = '_TIMESHEET_TYPE'));



