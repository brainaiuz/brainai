﻿INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('NORMA',2,'/tc/images/1-1.png','/tc/images/1-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('NORMS',2,'/tc/images/2-1.png','/tc/images/2-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('PLANT OPERATOR PERMIT',12,'/tc/images/3-1.png','/tc/images/3-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('PERMIT TO WORK',3,'/tc/images/4-1.png','/tc/images/4-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('RIGGER AND BANKSMAN',3,'/tc/images/5-1.png','/tc/images/5-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('BREATHING APPARATUS AUTHORISED USER',3,'/tc/images/6-1.png','/tc/images/6-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('AUTHORISED GAS TESTER',2,'/tc/images/7-1.png','/tc/images/7-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('H2S AND SO2 ENTRY PERMIT',2,'/tc/images/8-1.png','/tc/images/8-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('HSE TRAINING CARD',15,'/tc/images/9-1.png','/tc/images/9-2.png');
INSERT INTO "anv".certificatetype(name,fieldcount,frontimageurl,backimageurl) VALUES('SUPERVISOR LIFTING OPERATIONS',3,'/tc/images/10-1.png','/tc/images/10-2.png');

