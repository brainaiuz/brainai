INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_PROJECT_LIST_IMPORT_BUTTON', 'PM', 'Project Import', 1, false,5);
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_PROJECT_LIST_CUSTOMIZE_BUTTON', 'PM', 'Project List Customize', 2, false,5);
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_TASK_LIST_IMPORT_BUTTON', 'PM', 'Task Import', 18, false,1);
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_TASK_LIST_CUSTOMIZE_BUTTON', 'PM', 'Task List Customize', 19, false,1);
INSERT INTO permission(code, context, "name", sorder, ismainmenu, parent) VALUES ('PM_ISSUE_LIST_CUSTOMIZE_BUTTON', 'PM', 'Issue List Customize', 4, false,2);