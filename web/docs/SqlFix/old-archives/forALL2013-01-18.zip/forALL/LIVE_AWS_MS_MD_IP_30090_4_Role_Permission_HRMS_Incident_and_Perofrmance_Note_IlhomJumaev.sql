--for public schema
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_REMOVE_INCIDENT', 'HRMS', 'Hrms Remove Incident', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_REMOVE_PERFORMANCE_NOTE', 'HRMS', 'Hrms Remove Performance Note', 1, false);

------------------------------------------------------------------------------------------------------------------------

--for all schema

--incident delete                                 ---> 1 step
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'SALESMAN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'CUSTOMER_SERVICE_REPRESENTATIVE', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'SALESPERSON', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'MEM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'TL', (SELECT id from "anv".reference where code='ALLOW') );

--performance note delete                         ---> 1 step
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'TL', (SELECT id from "anv".reference where code='ALLOW') );



------------------------------------------------------------------------------------------------------------------------
--for custom schema
--incident delete FOR CUSTOM COMPANY              ---> 2 step --Bu patchlar xamma patchlardan keyin urilsin --
delete from "28492".rolepermission where permissioncode='HRMS_REMOVE_INCIDENT';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );


--performance note delete FOR CUSTOM COMPANY      ---> 2 step --Bu patchlar xamma patchlardan keyin urilsin --
delete from "28492".rolepermission where permissioncode='HRMS_REMOVE_PERFORMANCE_NOTE';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_REMOVE_PERFORMANCE_NOTE', 'HR', (SELECT id from "28492".reference where code='ALLOW') );