insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared) values ('_COURSE_STATUS', 'Course Status', false, true, false, true);

insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared, parentid) values
('COURSE_STATUS_OPEN', 'Course Open Status', false, true, false, true, (select id from "anv".reference where code = '_COURSE_STATUS')),
('COURSE_STATUS_DRAFT', 'Course Draft Status', false, true, false, true, (select id from "anv".reference where code = '_COURSE_STATUS'));