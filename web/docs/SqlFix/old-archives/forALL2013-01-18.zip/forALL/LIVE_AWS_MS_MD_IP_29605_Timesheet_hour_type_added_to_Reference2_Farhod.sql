delete from "anv".reference where code = 'TYPE_FOR_EDIT' and name = 'Type for edit';

insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared, parentid) values
('TYPE_OFFICE', 'Office', true, false, false, true, (select id from "anv".reference where code = '_TIMESHEET_TYPE'));

insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared, parentid) values
('TYPE_TRAVEL', 'Travel', true, false, false, true, (select id from "anv".reference where code = '_TIMESHEET_TYPE'));

insert into "anv".reference (code, name, isremovable, issystemreference, deleted, shared, parentid) values
('TYPE_ON_SITE', 'On-site', true, false, false, true, (select id from "anv".reference where code = '_TIMESHEET_TYPE'));