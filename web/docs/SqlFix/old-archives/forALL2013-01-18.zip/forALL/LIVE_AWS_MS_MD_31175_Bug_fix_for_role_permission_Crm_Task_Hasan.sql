insert into permission ("code", "context", "name", "sorder", "ismainmenu", "parent") VALUES('CRM_TASKS_CASE', 'CRM', 'Crm Task Case', (SELECT id from permission   where code = 'CRM_TASKS_LIST'),
 'f', (select id from permission where code = 'CRM_TASKS_LIST'));
insert into permission ("code", "context", "name", "sorder", "ismainmenu", "parent") VALUES('CRM_TASKS_EMAILS', 'CRM', 'Crm Task Email', (SELECT id from permission   where code = 'CRM_TASKS_LIST'), 
'f', (select id from permission where code = 'CRM_TASKS_LIST'));
insert into permission ("code", "context", "name", "sorder", "ismainmenu", "parent") VALUES('CRM_TASKS_COMMENTS', 'CRM', 'Crm Task Comments', (SELECT id from permission   where code = 'CRM_TASKS_LIST'), 
'f', (select id from permission where code = 'CRM_TASKS_LIST'));

/*for all schema*/
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'DR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'TL');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'PM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'CLIENT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'SALESMAN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'SALESPERSON');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'HR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'MEM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');

insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'DR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'TL');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'PM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'CLIENT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'SALESMAN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'SALESPERSON');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'HR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'MEM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');


insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'DR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'TL');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'PM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'CLIENT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'SALESMAN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'SALESPERSON');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'HR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'MEM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');
/*for zero schema*/
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'DR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'TL');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'PM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'CLIENT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'SALESMAN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'SALESPERSON');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'HR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'MEM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_CASE', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');

insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'DR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'TL');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'PM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'CLIENT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'SALESMAN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'SALESPERSON');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'HR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'MEM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_EMAILS', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');


insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'DR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'TL');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'PM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'CLIENT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'SALESMAN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'SALESPERSON');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'HR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'MEM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('CRM_TASKS_COMMENTS', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');