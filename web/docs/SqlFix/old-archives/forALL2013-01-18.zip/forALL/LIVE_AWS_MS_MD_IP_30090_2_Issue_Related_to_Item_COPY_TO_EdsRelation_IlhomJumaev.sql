--select * from "anv".relation

insert into "anv".relation (createdDate,fromID,fromName,fromType,lastModifiedDate,toID,toType,toName)

select t.creationtime,ii.id,t.name,
(CASE WHEN 1=1 THEN 'ISSUE' ELSE 'ISSUE' END) as fromType,
t.lastupdatetime,
(CASE WHEN tii.issuetaskid is not null THEN tii.issuetaskid ELSE
	(CASE WHEN pii.issueprojectid is not null THEN pii.issueprojectid ELSE
	(CASE WHEN dii.departmentid is not null THEN dii.departmentid ELSE
	(CASE WHEN cii.clientid is not null THEN cii.clientid ELSE
	(CASE WHEN eii.employeeid is not null THEN eii.employeeid ELSE 0 END) END) END) END) END) as toId,
(CASE WHEN tii.issuetaskid is not null THEN 'TASK' ELSE
	(CASE WHEN pii.issueprojectid is not null THEN 'PROJECT' ELSE
	(CASE WHEN dii.departmentid is not null THEN 'DEPARTMENT' ELSE
	(CASE WHEN cii.clientid is not null THEN (CASE WHEN cii.isSupplierIssue is true THEN 'supplier' ELSE 'client' END) ELSE
	(CASE WHEN eii.employeeid is not null THEN 'EMPLOYEE' ELSE '' END) END) END) END) END) as toType,
(CASE WHEN tii.issuetaskid is not null THEN t.name ELSE
	(CASE WHEN pii.issueprojectid is not null THEN p.name ELSE
	(CASE WHEN dii.departmentid is not null THEN te.name ELSE
	(CASE WHEN cii.clientid is not null THEN cs.name ELSE
	(CASE WHEN eii.employeeid is not null THEN (emp.firstname ||' '||emp.lastname) ELSE '' END) END) END) END) END) as toName
from "anv".issue ii
	left outer join "anv".taskissue tii on (tii.id= ii.id)
	left outer join "anv".projectissue pii on (pii.id= ii.id)
	left outer join "anv".project p on (p.id=pii.issueprojectid)
	left outer join "anv".departmentissue dii on (dii.id= ii.id)
	left outer join "anv".team te on (te.id=dii.departmentid)
	left outer join "anv".clientissue cii on (cii.id= ii.id)
	left outer join "anv".crmAccount cs on (cs.id=cii.clientid)
	left outer join "anv".employeeissue eii on (eii.id= ii.id)
	left outer join "anv".myuser emp on (emp.id=eii.employeeid)
	left outer join "anv".task t on (t.id= ii.id)

	where (eii.showinAvailability is not true  and eii.showinpa is not true and (eii.showinpm is null or eii.showinpm is true));
