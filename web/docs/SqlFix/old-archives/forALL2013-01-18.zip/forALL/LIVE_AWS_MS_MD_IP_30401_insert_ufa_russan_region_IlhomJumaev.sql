--in consol region table == public schema

insert into region(name,countryid) values ('Ufa', 183);