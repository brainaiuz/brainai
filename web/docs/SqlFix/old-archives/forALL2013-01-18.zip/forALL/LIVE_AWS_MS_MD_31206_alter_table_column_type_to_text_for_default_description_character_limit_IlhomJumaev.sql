--for zero schema
alter table "0".team alter column description type text;
alter table "0".task alter column description type text;
alter table "0".project alter column description type text;
alter table "0".workstream alter column description type text;

--for all schemas

alter table "anv".team alter column description type text;
alter table "anv".task alter column description type text;
alter table "anv".project alter column description type text;
alter table "anv".workstream alter column description type text;


--update companySystemSettings set descriptionCharacterLimit = 5000;