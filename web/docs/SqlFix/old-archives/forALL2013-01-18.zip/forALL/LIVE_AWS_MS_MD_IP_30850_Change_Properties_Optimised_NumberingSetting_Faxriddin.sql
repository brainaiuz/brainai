
/* -- PM, TASK, WORKSTREAM, EMPLOYEE numberlar generatsiya qilishi uchun va PMSETTINS dagi NumberingSettings ishlashi uchun shart va zarur!!! --*/

update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'prefixT','prefixP') where tasknumberingformat like ('%prefixT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'dateYearT','dateYearP') where tasknumberingformat like ('%dateYearT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'dateMonthT','dateMonthP') where tasknumberingformat like ('%dateMonthT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'dateDayT','dateDayP') where tasknumberingformat like ('%dateDayT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'clientCodeT','clientCodeP') where tasknumberingformat like ('%clientCodeT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'numbersT','numbersP') where tasknumberingformat like ('%numbersT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'suffixT','suffixP') where tasknumberingformat like ('%suffixT%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'projectNumber','projectNumber') where tasknumberingformat like ('%projectNumber%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'restartTaskNumber','restartNumber') where tasknumberingformat like ('%restartTaskNumber%');
update "anv".pmnumberingsettings set tasknumberingformat = replace(tasknumberingformat,'uniqueTaskNumber','uniqueNumber') where tasknumberingformat like ('%uniqueTaskNumber%');

update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'prefixW','prefixP') where workstreamnumberingformat like ('%prefixW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'dateYearW','dateYearP') where workstreamnumberingformat like ('%dateYearW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'dateMonthW','dateMonthP') where workstreamnumberingformat like ('%dateMonthW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'dateDayW','dateDayP') where workstreamnumberingformat like ('%dateDayW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'clientCodeW','clientCodeP') where workstreamnumberingformat like ('%clientCodeW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'numbersW','numbersP') where workstreamnumberingformat like ('%numbersW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'suffixW','suffixP') where workstreamnumberingformat like ('%suffixW%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'projectNumberForWorkstream','projectNumber') where workstreamnumberingformat like ('%projectNumberForWorkstream%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'restartWorkstreamNumber','restartNumber') where workstreamnumberingformat like ('%restartWorkstreamNumber%');
update "anv".pmnumberingsettings set workstreamnumberingformat = replace(workstreamnumberingformat,'uniqueWorkstreamNumber','uniqueNumber') where workstreamnumberingformat like ('%uniqueWorkstreamNumber%');

update "anv".pmnumberingsettings set employeenumberingformat = replace(employeenumberingformat,'prefixEmp','prefixP') where employeenumberingformat like ('%prefixEmp%');
update "anv".pmnumberingsettings set employeenumberingformat = replace(employeenumberingformat,'numbersEmp','numbersP') where employeenumberingformat like ('%numbersEmp%');
update "anv".pmnumberingsettings set employeenumberingformat = replace(employeenumberingformat,'suffixEmp','suffixP') where employeenumberingformat like ('%suffixEmp%');