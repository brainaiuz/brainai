--
--delete list panel settings
delete from "anv".listPanelSettings where paneltype='IncientListPanel';
delete from "anv".listPanelSettings where paneltype='PerformanceNoteListPanel';

--

insert into "anv".performanceNote (creationTime,deleted,lastUpdateTime,name,endDate,startDate,description,isIncident,relatedTo_id,reportedBy_id,resolver_id,status_id,visibility)

select t.creationtime,t.deleted,t.lastupdatetime,t.name,t.duedate,t.startdate,t.description,
    (CASE WHEN ei.showinpa is true THEN true ELSE false END) as isIncident,
    ei.employeeid,(CASE WHEN 1=1 THEN null ELSE 0 END) as reportedBy,
    ii.resolver,ii.issuestatusid,
    (CASE WHEN ii.access='PUBLIC' THEN true ELSE false END) as visibility
    from "anv".employeeissue ei
left outer join "anv".issue ii on (ii.id=ei.id)
left outer join "anv".task t on (t.id=ii.id)
where ei.showinavailability is true or ei.showinpa is true;