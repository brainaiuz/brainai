insert into "0".reference(code, name, description,   parentid , id )
  values(
    'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY',
    'Student course booking confirmation category',
    'Student course booking confirmation category',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);


insert into "0".emailtemplate(code, iscompanyemailtemplate, isdefault, locale, name, subject, categoryid, messagehtml)
values('DEFAULT_STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY', 'COMPANY_EMAIL_TEMPLATE', true, 'en', 'Student course booking confirmation', 'Student course booking confirmation', (select id from "0".reference where code='STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'), '<p><b>Scheduled Course #</b>: $number</p><p><b>Nominee’s Name</b>: $fullname</p><p><b>Company Name</b>: $companyname</p><p><b>Reference Indicator</b>: $companynumber</p><p><b>Course Title</b>: $course</p><p><b>Course Code</b>: $coursecode</p><p><b>Course Location</b>: $location</p><p><b>Course Start Date</b>: $startdate</p><p><b>Course End Date</b>: $enddate</p><p><b>Language</b>: $language</p><p/><p><b>Standard Pre Requisites:</b></p><p>$prerequisites</p><p/><p><b>Other Pre Requisites:</b></p><p>$otherprerequisites</p>');

-------------------------------------------------------------------------------------------------------

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY',
    'Student course booking confirmation category',
    'Student course booking confirmation category',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

update "anv".myuser set deleted = false where deleted is not true and (SELECT setval('"anv".emailtemplate_id_seq', (select max(id) from "anv".emailtemplate))) is null;


insert into "anv".emailtemplate(code, iscompanyemailtemplate, isdefault, locale, name, subject, categoryid, messagehtml)
values('DEFAULT_STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY', 'COMPANY_EMAIL_TEMPLATE', true, 'en', 'Student course booking confirmation', 'Student course booking confirmation', (select id from "anv".reference where code='STUDENT_COURSE_BOOKING_CONFIRMATION_CATEGORY'), '<p><b>Scheduled Course #</b>: $number</p><p><b>Nominee’s Name</b>: $fullname</p><p><b>Company Name</b>: $companyname</p><p><b>Reference Indicator</b>: $companynumber</p><p><b>Course Title</b>: $course</p><p><b>Course Code</b>: $coursecode</p><p><b>Course Location</b>: $location</p><p><b>Course Start Date</b>: $startdate</p><p><b>Course End Date</b>: $enddate</p><p><b>Language</b>: $language</p><p/><p><b>Standard Pre Requisites:</b></p><p>$prerequisites</p><p/><p><b>Other Pre Requisites:</b></p><p>$otherprerequisites</p>');
