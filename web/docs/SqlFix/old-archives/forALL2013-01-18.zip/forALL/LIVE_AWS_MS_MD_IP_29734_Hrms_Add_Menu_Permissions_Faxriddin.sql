

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_MAIN_SECTION', 'HRMS', 'Hrms Main Section ', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EMPLOYEE_BONUS_LIST', 'HRMS', 'Hrms Employee Bonus list', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_NOTE_TAB_REMOVE_IMG', 'HRMS', 'Hrms Noet Remove Img', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_EXPENCE_REPORT_REMOVE', 'HRMS', 'Hrms Expence Report remove', 1, false);
INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'HRMS', 'Hrms Add Bonus Distribution', 1, false);


insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'ADMIN_LOCATION', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'PM', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_MAIN_SECTION', 'TL', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTE_TAB_REMOVE_IMG', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_NOTE_TAB_REMOVE_IMG', 'DR', (SELECT id from "anv".reference where code='ALLOW') );

insert into "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EXPENCE_REPORT_REMOVE', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );

INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_EMPLOYEE_BONUS_LIST', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'HR', (SELECT id from "anv".reference where code='ALLOW') );
INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_BONUS_DISTRIBUTION', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );