-- for zero schema;
------------------------------------------------------------------------------------------------------------------------
-- _COURSE_BOOKING_STATUS
insert into "0".reference(code, name, description, parentid , id )
  values(
    '_COURSE_BOOKING_STATUS',
    'Course booking status',
    'Course booking status',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id)
  values(
    'BOOKING_DRAFT',
    'Draft',
    'Draft',

    (select id from "0".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid , id )
  values(
    'BOOKING_SUBMITTED_TO_MANAGER',
    'Submitted to manager',
    'Submitted to manager',

    (select id from "0".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id )
  values(
    'BOOKING_APPROVED',
    'Approved',
    'Approved',

    (select id from "0".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id )
  values(
    'BOOKING_REJECTED',
    'Rejected',
    'Rejected',

    (select id from "0".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description, parentid, id )
  values(
    'BOOKING_PAID',
    'Paid',
    'Paid',

    (select id from "0".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);








------------------------------------------------ FOR ALL DB -----------------------------------------------------
-- _COURSE_BOOKING_STATUS
insert into "anv".reference(code, name, description, parentid , id )
  values(
    '_COURSE_BOOKING_STATUS',
    'Course booking status',
    'Course booking status',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id)
  values(
    'BOOKING_DRAFT',
    'Draft',
    'Draft',

    (select id from "anv".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid , id )
  values(
    'BOOKING_SUBMITTED_TO_MANAGER',
    'Submitted to manager',
    'Submitted to manager',

    (select id from "anv".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id )
  values(
    'BOOKING_APPROVED',
    'Approved',
    'Approved',

    (select id from "anv".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id )
  values(
    'BOOKING_REJECTED',
    'Rejected',
    'Rejected',

    (select id from "anv".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description, parentid, id )
  values(
    'BOOKING_PAID',
    'Paid',
    'Paid',

    (select id from "anv".reference where code='_COURSE_BOOKING_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);