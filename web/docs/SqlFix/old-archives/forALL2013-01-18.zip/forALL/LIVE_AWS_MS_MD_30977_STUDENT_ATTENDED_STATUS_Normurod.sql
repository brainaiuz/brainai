--------------------------------------------------FOR ZERO SCHEMA----------------------------------------------------------------------
insert into "0".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_ATTENDED_STATUS',
    'Student Attended Status',
    'Student Attended Status',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);


insert into "0".reference(code, name, description,   parentid , id )
  values(
    'STUDENT_ATTENDED',
    'Attended',
    'Attended',

    (select id from "0".reference where code='_STUDENT_ATTENDED_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    'STUDENT_NO_SHOW',
    'No Show',
    'No Show',

    (select id from "0".reference where code='_STUDENT_ATTENDED_STATUS'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

--------------------------------------------------FOR ALL SCHEMA----------------------------------------------------------------------
insert into "anv".reference(code, name, description,   parentid , id )
  values(
    '_STUDENT_ATTENDED_STATUS',
    'Student Attended Status',
    'Student Attended Status',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);


insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'STUDENT_ATTENDED',
    'Attended',
    'Attended',

    (select id from "anv".reference where code='_STUDENT_ATTENDED_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'STUDENT_NO_SHOW',
    'No Show',
    'No Show',

    (select id from "anv".reference where code='_STUDENT_ATTENDED_STATUS'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);
