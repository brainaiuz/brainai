--Public schema patch's
insert into permission(code, context, name, sorder, ismainmenu) values('TC_MAIN_MENU', 'TC', 'Training Center', 12, true);


insert into "0".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "0".reference where code='ALLOW'), 'ADMIN');
insert into "0".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "0".reference where code='ALLOW'), 'DR');
insert into "0".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "0".reference where code='ALLOW'), 'HR');
insert into "0".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "0".reference where code='ALLOW'), 'ACCOUNTANT');

--ANV schema patch's
insert into "anv".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "anv".reference where code='ALLOW'), 'ADMIN');
insert into "anv".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "anv".reference where code='ALLOW'), 'DR');
insert into "anv".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "anv".reference where code='ALLOW'), 'HR');
insert into "anv".rolepermission(permissioncode, priviledgeid, rolecode) values('TC_MAIN_MENU', (select id from "anv".reference where code='ALLOW'), 'ACCOUNTANT');