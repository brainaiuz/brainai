--for ZERO schema
INSERT INTO "0".role (code, description, name, issystem, isdeleted, isentityspecific, sorder, id) VALUES ('SUPERVISOR', '', 'Supervisor', true, false, true, 90, (SELECT setval('"0".role_id_seq', (SELECT max(id) + 1 FROM "0".role))));

--for ALL schema
INSERT INTO "anv".role (code, description, name, issystem, isdeleted, isentityspecific, sorder, id) VALUES ('SUPERVISOR', '', 'Supervisor', true, false, true, 90, (SELECT setval('"anv".role_id_seq', (SELECT max(id) + 1 FROM "anv".role))));
