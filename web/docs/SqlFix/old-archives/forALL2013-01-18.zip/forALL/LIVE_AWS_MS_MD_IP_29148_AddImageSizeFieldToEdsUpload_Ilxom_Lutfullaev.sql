--For Company Logos
update "anv".upload set imageSize = 'SMALL' where id =
(select ca.id from "anv".companyattachment ca 
	inner join "anv".reference r1 on ca.logotypeid = r1.id 
	inner join "anv".reference r2 on r1.parentid = r2.id 
	where r1.code = 'FOR_EMPLOYEES' and r2.code = '_LOGO_TYPE');


-- For PDF Logos
update "anv".upload set imageSize = 'SMALL' where id =
(select ca.id from "anv".companyattachment ca
	inner join "anv".reference r1 on ca.logotypeid = r1.id
	inner join "anv".reference r2 on r1.parentid = r2.id
	where r1.code = 'FOR_PDF' and r2.code = '_LOGO_TYPE');