-- this is for only 31287(Knowledge Grid LLC) company

insert into "31287".coursesubject(id, deleted, description, name, parentid, sorder) select id, deleted, description, name, parentid, sorder from "31287".productcategory;

insert into "31287".course(id, duration, validity, otherprerequisites, opito, isexamrequired, medicalclearance)  select id, duration, validity, otherprerequisites, opito, isexamrequired, medicalclearance from "31287".course_old;

update "31287".course c set name = cit.name, intnumber = cit.intnumber, number = cit.product_number, subjectid = cit.categoryid, deleted = cit.deleted from "31287".item cit where cit.id = c.id;