ALTER TABLE "anv".appraisal_rate DROP COLUMN rating;
ALTER TABLE "anv".appraisal_rate ADD COLUMN rating numeric(4,1);