
insert into "anv".appraisalssettings_role (appraisalssettings_id, reviewers_id)
select appsett.id as appid, (select id from "anv".role where code ='SUPERVISOR') as roleid from "anv".appraisalssettings appsett where appsett.reviewerSupervisor is true;