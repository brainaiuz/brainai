-- for zero schema;
------------------------------------------------------------------------------------------------------------------------
-- _LANGUAGES
insert into "0".reference(code, name, description,   parentid , id )
  values(
    '_LANGUAGES',
    'Languages',
    'Languages',

    null,
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

-- Languages
insert into "0".reference(code, name, description,   parentid , id )
  values(
    'LANGUAGE_ARABIC',
    'Arabic',
    'Arabic',

    (select id from "0".reference where code='_LANGUAGES'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

insert into "0".reference(code, name, description,   parentid , id )
  values(
    'LANGUAGE_ENGLISH',
    'English',
    'English',

    (select id from "0".reference where code='_LANGUAGES'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);
insert into "0".reference(code, name, description,   parentid , id )
  values(
    'LANGUAGE_HINDI',
    'Hindi',
    'Hindi',

    (select id from "0".reference where code='_LANGUAGES'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);

------------------------------------------------ FOR ALL DB -----------------------------------------------------
-- _LANGUAGES
insert into "anv".reference(code, name, description,   parentid , id )
  values(
    '_LANGUAGES',
    'Languages',
    'Languages',

    null,
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'LANGUAGE_ARABIC',
    'Arabic',
    'Arabic',

    (select id from "anv".reference where code='_LANGUAGES'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'LANGUAGE_ENGLISH',
    'English',
    'English',

    (select id from "anv".reference where code='_LANGUAGES'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'LANGUAGE_HINDI',
    'Hindi',
    'Hindi',

    (select id from "anv".reference where code='_LANGUAGES'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);
