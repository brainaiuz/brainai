--apply to public schema

INSERT INTO weather_locations (location, location_id, country_id) VALUES ('St. Louis MO', 'USMO0787', 46);
INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Los Angeles CA', 'USCA0638', 46);
INSERT INTO weather_locations (location, location_id, country_id) VALUES ('Chicago IL', 'USIL0225', 46);
