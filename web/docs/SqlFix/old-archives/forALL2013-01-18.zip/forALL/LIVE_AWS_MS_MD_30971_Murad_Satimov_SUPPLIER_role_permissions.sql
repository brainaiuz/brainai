/*for zero schema*/
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'DR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'TL');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'PM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'CLIENT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'SALESMAN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'SALESPERSON');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'CALENDAR_VIEWER');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'HR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'MEM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'TIMESHEET_EDITOR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');

/*for all schemas*/
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'DR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'TL');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'PM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'CLIENT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'ACCOUNTANT');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'SALESMAN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_REPRESENTATIVE');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'SALESPERSON');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN_LOCATION');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'CALENDAR_VIEWER');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'HR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'MEM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'TIMESHEET_EDITOR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('PM_TASK_LIST_MORE_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'CUSTOMER_SERVICE_MANAGER');


/*for zero schema*/
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'DR');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'TL');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'PM');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'ADMIN');
insert into "0".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "0".reference where code='ALLOW'), 'ACCOUNTANT');

/*for all schema*/
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'DR');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'TL');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'PM');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'ADMIN');
insert into "anv".rolepermission ("permissioncode", "priviledgeid", "rolecode") VALUES('ACCOUNTING_PURCHASE_APPROVE_AND_SEND_BUTTON', (SELECT id from "anv".reference where code='ALLOW'), 'ACCOUNTANT');
