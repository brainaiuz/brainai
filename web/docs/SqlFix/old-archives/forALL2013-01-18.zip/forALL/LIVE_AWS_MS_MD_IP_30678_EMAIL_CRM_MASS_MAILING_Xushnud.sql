insert into "0".reference(code, name, description,   parentid , id )
  values(
    'CRM_MASS_MAILING_CATEGORY',
    'Crm mass mailing category',
    'Crm mass mailing category',

    (SELECT id from "0".reference where code='_EMAIL_TEMPLATE_CATEGORY'),
    (SELECT setval('"0".reference_id_seq', (SELECT max(id) + 1 FROM "0".reference)))
);


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

insert into "anv".reference(code, name, description,   parentid , id )
  values(
    'CRM_MASS_MAILING_CATEGORY',
    'Crm mass mailing category',
    'Crm mass mailing category',

    (SELECT id from "anv".reference  where code='_EMAIL_TEMPLATE_CATEGORY'),
    (SELECT setval('"anv".reference_id_seq', (SELECT max(id) + 1 FROM "anv".reference)))
);
