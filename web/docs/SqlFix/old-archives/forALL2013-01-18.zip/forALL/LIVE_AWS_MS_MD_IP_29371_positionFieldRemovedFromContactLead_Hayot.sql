update "anv".crmcontact set jobtitles = position where jobtitles is null and position is not null;
update "anv".crmcontact set jobtitles = jobtitles ||' ('|| position||')' where position is not null;