--schema updatedan keyin
update "anv".timesheet set entryDate = date where entryDate is null;