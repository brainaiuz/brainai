--English    --1
--Arabic     --2
--Cantonese  --3
--French     --4
--German     --5
--Hindi      --6
--Indonesian --7
--Italian    --8
--Japanese   --9
--Korean     --10
--Mandarin   --11
--Russian    --12
--Spanish    --13
--Taiwanese  --14
--Thai       --15

update "0".reference set sorder = 1 where code = 'LANGUAGE_ENGLISH';
update "0".reference set sorder = 2 where code = 'LANGUAGE_ARABIC';
update "0".reference set sorder = 6 where code = 'LANGUAGE_HINDI';
--for zero schema
------////////////////--------///////////////////----------////////////////------------/////////////////////------------
insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_CANTONESE', 'Cantonese', 'Cantonese', true, false, (select id from "0".reference where code='_LANGUAGES'), 3);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_FRENCH', 'French', 'French', true, false, (select id from "0".reference where code='_LANGUAGES'), 4);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_GERMAN', 'German', 'German', true, false, (select id from "0".reference where code='_LANGUAGES'), 5);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_INDONESIAN', 'Indonesian', 'Indonesian', true, false, (select id from "0".reference where code='_LANGUAGES'), 7);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_ITALIAN', 'Italian', 'Italian', true, false, (select id from "0".reference where code='_LANGUAGES'), 8);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid , sorder)
  values('LANGUAGE_JAPANESE', 'Japanese', 'Japanese', true, false, (select id from "0".reference where code='_LANGUAGES'), 9);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_KOREAN', 'Korean', 'Korean', true, false, (select id from "0".reference where code='_LANGUAGES'), 10);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_MANDARIN', 'Mandarin', 'Mandarin', true, false, (select id from "0".reference where code='_LANGUAGES'), 11);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_RUSSIAN', 'Russian', 'Russian', true, false, (select id from "0".reference where code='_LANGUAGES'), 12);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_SPANISH', 'Spanish', 'Spanish', true, false, (select id from "0".reference where code='_LANGUAGES'), 13);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_TAIWANESE', 'Taiwanese', 'Taiwanese', true, false, (select id from "0".reference where code='_LANGUAGES'), 14);

insert into "0".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_THAI', 'Thai', 'Thai', true, false, (select id from "0".reference where code='_LANGUAGES'), 15);

--for all schemas
--  ------////////////////--------///////////////////----------////////////////------------/////////////////////------------
update "anv".reference set sorder = 1 where code = 'LANGUAGE_ENGLISH';
update "anv".reference set sorder = 2 where code = 'LANGUAGE_ARABIC';
update "anv".reference set sorder = 6 where code = 'LANGUAGE_HINDI';

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_CANTONESE', 'Cantonese', 'Cantonese', true, false, (select id from "anv".reference where code='_LANGUAGES'), 3);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_FRENCH', 'French', 'French', true, false, (select id from "anv".reference where code='_LANGUAGES'), 4);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_GERMAN', 'German', 'German', true, false, (select id from "anv".reference where code='_LANGUAGES'), 5);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_INDONESIAN', 'Indonesian', 'Indonesian', true, false, (select id from "anv".reference where code='_LANGUAGES'), 7);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_ITALIAN', 'Italian', 'Italian', true, false, (select id from "anv".reference where code='_LANGUAGES'), 8);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid , sorder)
  values('LANGUAGE_JAPANESE', 'Japanese', 'Japanese', true, false, (select id from "anv".reference where code='_LANGUAGES'), 9);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_KOREAN', 'Korean', 'Korean', true, false, (select id from "anv".reference where code='_LANGUAGES'), 10);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_MANDARIN', 'Mandarin', 'Mandarin', true, false, (select id from "anv".reference where code='_LANGUAGES'), 11);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_RUSSIAN', 'Russian', 'Russian', true, false, (select id from "anv".reference where code='_LANGUAGES'), 12);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_SPANISH', 'Spanish', 'Spanish', true, false, (select id from "anv".reference where code='_LANGUAGES'), 13);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_TAIWANESE', 'Taiwanese', 'Taiwanese', true, false, (select id from "anv".reference where code='_LANGUAGES'), 14);

insert into "anv".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LANGUAGE_THAI', 'Thai', 'Thai', true, false, (select id from "anv".reference where code='_LANGUAGES'), 15);