// Custom companylar uchun permissionlar

delete from "28492".rolepermission  where permissioncode='HRMS_ADD_NEW_PERSONAL_GOALS';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PERSONAL_GOALS', 'TL', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission  where permissioncode='HRMS_ADD_NEW_PROJECT_GOALS';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'TL', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_PROJECT_GOALS', 'PROJECTS_DIRECTOR', (SELECT id from "28492".reference where code='ALLOW') );

delete from "28492".rolepermission  where permissioncode='HRMS_ADD_NEW_INCIDENT';
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'ADMIN', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'ADMIN_LOCATION', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'HR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'DR', (SELECT id from "28492".reference where code='ALLOW') );
insert into "28492".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('HRMS_ADD_NEW_INCIDENT', 'TL', (SELECT id from "28492".reference where code='ALLOW') );

update "28492".rolepermission set priviledgeid = (SELECT id from "28492".reference where code='DENY') where  permissioncode='HRMS_NEW_COMPANY_GOALS' and rolecode='TL';

update "28492".rolepermission set priviledgeid = (SELECT id from "28492".reference where code='DENY') where  permissioncode='HRMS_ADD_NEW_POSITION' and rolecode='TL';

update "28492".rolepermission set priviledgeid = (SELECT id from "28492".reference where code='DENY') where  permissioncode='HRMS_COMPANY_GOAL_SUMMARY' and rolecode='TL';
update "28492".rolepermission set priviledgeid = (SELECT id from "28492".reference where code='DENY') where  permissioncode='HRMS_COMPANY_GOAL_SUMMARY' and rolecode='PM';

update "28492".rolepermission set priviledgeid = (SELECT id from "28492".reference where code='DENY') where  permissioncode='HRMS_EDIT_GOAL' and rolecode='PM';
