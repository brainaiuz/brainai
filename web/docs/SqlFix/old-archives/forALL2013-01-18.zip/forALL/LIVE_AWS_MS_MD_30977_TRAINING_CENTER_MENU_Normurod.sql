--Public schema patch's
update permission set context = 'TRAININGCENTER' where code = 'TC_MAIN_MENU';