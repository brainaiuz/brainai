/* public schemaga */

INSERT INTO permission ("code", "context", "name", "sorder", "ismainmenu") values ('SETTINGS_QUICKBOOKS_SETTINGS', 'SETTINGS', 'Quickbooks Integration', null, false);



/* 0 schemaga */

INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_QUICKBOOKS_SETTINGS', 'DR', (SELECT id from "0".reference where code='ALLOW') );
INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_QUICKBOOKS_SETTINGS', 'ADMIN', (SELECT id from "0".reference where code='ALLOW') );
INSERT INTO "0".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_QUICKBOOKS_SETTINGS', 'ACCOUNTANT', (SELECT id from "0".reference where code='ALLOW') );


/* company schemalarga */

INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_QUICKBOOKS_SETTINGS', 'DR', (SELECT id from "anv".reference where code='ALLOW') );
INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_QUICKBOOKS_SETTINGS', 'ADMIN', (SELECT id from "anv".reference where code='ALLOW') );
INSERT INTO "anv".rolepermission ("permissioncode", "rolecode", "priviledgeid") VALUES ('SETTINGS_QUICKBOOKS_SETTINGS', 'ACCOUNTANT', (SELECT id from "anv".reference where code='ALLOW') );





