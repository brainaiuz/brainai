update "0".reference set name='Mass Mailer Temlates', description='Mass Mailer Temlates' where code='CRM_MASS_MAILING_CATEGORY';

update "anv".reference set name='Mass Mailer Temlates', description='Mass Mailer Temlates' where code='CRM_MASS_MAILING_CATEGORY';
