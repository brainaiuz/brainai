--Vacation       --6
--Sick Leave     --1
--Bereavement    --7
--Personal Day   --8
--Excused/Other  --9
--Holiday        --10


--for the companyID = 31733
------------------------------------------------------------------------------------------------------------------------
insert into "31733".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_VACATION', 'Vacation', 'Vacation', true, false, (select id from "31733".reference where code='_LEAVE_REQUEST_TYPE'), 6);

insert into "31733".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_BEREAVEMENT', 'Bereavement', 'Bereavement', true, false, (select id from "31733".reference where code='_LEAVE_REQUEST_TYPE'), 7);

insert into "31733".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_PERSONAL_DAY', 'Personal Day', 'Personal Day', true, false, (select id from "31733".reference where code='_LEAVE_REQUEST_TYPE'), 8);

insert into "31733".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_EXCUSED_OTHER', 'Excused/Other', 'Excused/Other', true, false, (select id from "31733".reference where code='_LEAVE_REQUEST_TYPE'), 9);

insert into "31733".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_HOLIDAY', 'Holiday', 'Holiday', true, false, (select id from "31733".reference where code='_LEAVE_REQUEST_TYPE'), 10);
------------------------------------------------------------------------------------------------------------------------
--for the companyID = 33011
------------------------------------------------------------------------------------------------------------------------
insert into "33011".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_VACATION', 'Vacation', 'Vacation', true, false, (select id from "33011".reference where code='_LEAVE_REQUEST_TYPE'), 6);

insert into "33011".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_BEREAVEMENT', 'Bereavement', 'Bereavement', true, false, (select id from "33011".reference where code='_LEAVE_REQUEST_TYPE'), 7);

insert into "33011".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_PERSONAL_DAY', 'Personal Day', 'Personal Day', true, false, (select id from "33011".reference where code='_LEAVE_REQUEST_TYPE'), 8);

insert into "33011".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_EXCUSED_OTHER', 'Excused/Other', 'Excused/Other', true, false, (select id from "33011".reference where code='_LEAVE_REQUEST_TYPE'), 9);

insert into "33011".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_HOLIDAY', 'Holiday', 'Holiday', true, false, (select id from "33011".reference where code='_LEAVE_REQUEST_TYPE'), 10);
------------------------------------------------------------------------------------------------------------------------

--for the companyID = 33012
------------------------------------------------------------------------------------------------------------------------
insert into "33012".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_VACATION', 'Vacation', 'Vacation', true, false, (select id from "33012".reference where code='_LEAVE_REQUEST_TYPE'), 6);

insert into "33012".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_BEREAVEMENT', 'Bereavement', 'Bereavement', true, false, (select id from "33012".reference where code='_LEAVE_REQUEST_TYPE'), 7);

insert into "33012".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_PERSONAL_DAY', 'Personal Day', 'Personal Day', true, false, (select id from "33012".reference where code='_LEAVE_REQUEST_TYPE'), 8);

insert into "33012".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_EXCUSED_OTHER', 'Excused/Other', 'Excused/Other', true, false, (select id from "33012".reference where code='_LEAVE_REQUEST_TYPE'), 9);

insert into "33012".reference(code, name, description, isSystemReference, isRemovable, parentid, sorder)
  values('LR_TYPE_HOLIDAY', 'Holiday', 'Holiday', true, false, (select id from "33012".reference where code='_LEAVE_REQUEST_TYPE'), 10);