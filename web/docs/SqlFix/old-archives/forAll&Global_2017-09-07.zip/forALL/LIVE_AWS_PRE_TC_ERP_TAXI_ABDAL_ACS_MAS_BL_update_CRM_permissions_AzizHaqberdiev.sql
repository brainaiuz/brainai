--har ehtimol shart oxirida urilsin

update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = 0, isMainMenu = true where code = 'CRM_MAIN_MENU';
	update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_SALES_TAB';
		update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_WELCOME_PAGE';
		update permission set sorder = 2, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_LEADS_LIST';
				update permission set sorder = 1, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_LEADS_LIST';
				update permission set sorder = 2, moduleCode = 'LEAD_MANAGEMENT', name = 'Crm Lead Add', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'ADD_NEW_LEAD';
				update permission set sorder = 3, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_EDIT';
				update permission set sorder = 4, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_DELETE';
				update permission set sorder = 5, name = 'Leads status change', moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_STATUS';
				update permission set sorder = 6, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'ADD_LEAD_SMS';
				update permission set sorder = 7, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_LOOKUP';
				update permission set sorder = 8, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_CONVERT';
				update permission set sorder = 9, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_COPY';
				update permission set sorder = 10, name = 'Leads assignee change', moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CHANGE_LEADS_ASSIGNEE';
				update permission set sorder = 11, name = 'Leads campaign change', moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CHANGE_LEADS_CAMPAIGN';
				update permission set sorder = 12, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEADS_IMPORT';
				update permission set sorder = 13, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEADS_EXPORT';
				update permission set sorder = 14, moduleCode = 'LEAD_MANAGEMENT', parent = (select id from permission where code = 'CRM_LEADS_LIST'), isMainMenu = false where code = 'CRM_LEAD_CONTACT_ASSIGNEE';

		update permission set sorder = 3, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_OPPORTUNITIES_LIST';
        update permission set sorder = 1, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_OPPORTUNITIES_LIST';
        update permission set sorder = 2, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_OPPORTUNITIES';
        update permission set sorder = 3, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_EDIT_OPPORTUNITIES';
        update permission set sorder = 4, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_COPY_OPPORTUNITIES';
        update permission set sorder = 5, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_REMOVE_OPPORTUNITIES';
        update permission set sorder = 6, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_ADD_OPPORTUNITY_NOTE';
        update permission set sorder = 7, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_OPPORTUNITY_CHANGE_STAGE';
        update permission set sorder = 8, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CHANGE_OPPORTUNITIES_CAMPAIGN';
        update permission set sorder = 9, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CONVERT_OPPORTUNITY_TO_SQ';
        update permission set sorder = 10, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CONVERT_OPPORTUNITY_TO_SO';
        update permission set sorder = 11, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CONVERT_OPPORTUNITY_TO_RFQ';
        update permission set sorder = 12, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CONVERT_OPPORTUNITY_TO_PROJECT';
        update permission set sorder = 13, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_OPPORTUNITIES_IMPORT_LIST';
        update permission set sorder = 14, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_OPPORTUNITIES_EXPORT_LIST';
        update permission set sorder = 15, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST';
        update permission set sorder = 16, moduleCode = 'OPPORTUNITY_TRACKING', parent = (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), isMainMenu = false where code = 'CRM_OPPORTUNITIES_RFQ_LIST';

    update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_ACCOUNTS_LIST';
        update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_ACCOUNTS_LIST';
        update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNT_ADD';
        update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_SUPPLIER_ADD';
        update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_CLIENT_ADD';
        update permission set sorder = 5, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_EDIT';
        update permission set sorder = 6, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_COPY';
        update permission set sorder = 7, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_DELETE';
        update permission set sorder = 8, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_CONVERT';
        update permission set sorder = 9, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_ADD_NOTE';
        update permission set sorder = 10, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_DETECT_DUBLICATES';
        update permission set sorder = 11, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_MERGE';
        update permission set sorder = 12, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_IMPORT';
        update permission set sorder = 13, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNTS_EXPORT';
        update permission set sorder = 14, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_ACCOUNTS_LIST'), isMainMenu = false where code = 'CRM_ACCOUNT_NUMBER_EDIT';

		update permission set sorder = 5, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_CONTACTS_LIST';
        update permission set sorder = 1, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_CONTACT_LIST';
        update permission set sorder = 2, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_CONTACT';
        update permission set sorder = 3, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_EDIT_CONTACT';
        update permission set sorder = 4, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_REMOVE_CONTACT';
        update permission set sorder = 5, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'ADD_CONTACT_SMS';
        update permission set sorder = 6, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_CONTACT_LOOK_UP';
        update permission set sorder = 7, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_CONTACTS_DETECT_DUBLICATES';
        update permission set sorder = 8, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_CONTACTS_MERGE';
        update permission set sorder = 9, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_CATEGORY';
        update permission set sorder = 10, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_EDIT_CATEGORY';
        update permission set sorder = 11, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_SHARE_CATEGORY';
        update permission set sorder = 12, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_REMOVE_CATEGORY';
        update permission set sorder = 13, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_COPY_TO_CATEGORY';
        update permission set sorder = 14, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_MOVE_TO_CATEGORY';
        update permission set sorder = 15, moduleCode = 'CONTACT_MANAGEMENT', name='Change Contacts Campaign', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_CHANGE_CAMPAIGN';
        update permission set sorder = 16, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_GOOGLE_CONTACTS';
        update permission set sorder = 17, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_CONTACTS_IMPORT';
        update permission set sorder = 18, moduleCode = 'CONTACT_MANAGEMENT', parent = (select id from permission where code = 'CRM_CONTACTS_LIST'), isMainMenu = false where code = 'CRM_CONTACTS_EXPORT';

		update permission set sorder = 6, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_CAMPAIGNS_LIST';
        update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_CAMPAIGNS_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_CAMPAIGN';
        update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_CAMPAIGNS_LIST'), isMainMenu = false where code = 'CRM_EDIT_CAMPAIGN';
        update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_CAMPAIGNS_LIST'), isMainMenu = false where code = 'CRM_REMOVE_CAMPAIGN';
        update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_CAMPAIGNS_LIST'), isMainMenu = false where code = 'CRM_CAMPAIGNS_EXPORT';

    update permission set sorder = 7, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_TASKS_LIST';
        update permission set sorder = 1, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_TASKS_LIST';
        update permission set sorder = 2, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_ADD';
        update permission set sorder = 3, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_ADD_MULTI';
        update permission set sorder = 4, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_EDIT';
        update permission set sorder = 5, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_REMOVE';
        update permission set sorder = 6, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASK_LIST_MORE_BUTTON';
        update permission set sorder = 7, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_NOTES';
        update permission set sorder = 8, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_TIMER';
        update permission set sorder = 9, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_BUDGET';
        update permission set sorder = 10, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_DOCUMENTS';
        update permission set sorder = 11, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_COMMENTS';
        update permission set sorder = 12, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_ISSUE';
        update permission set sorder = 13, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_TASKS_LIST'), isMainMenu = false where code = 'CRM_TASKS_PDF_EXCEL_EXPORT';

    update permission set sorder = 8, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_ACTIVITIES_LIST';
        update permission set sorder = 1, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_ACTIVITIES_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_ACTIVITIES_LIST';
        update permission set sorder = 2, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_ACTIVITIES_LIST'), isMainMenu = false where code = 'CRM_ACTIVITIES_LOG_CALL_VIEW';
        update permission set sorder = 3, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_ACTIVITIES_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_ACTIVITY_EVENT';
        update permission set sorder = 4, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_ACTIVITIES_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_ACTIVITY_LOG_A_CALL';
        update permission set sorder = 5, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_ACTIVITIES_LIST'), isMainMenu = false where code = 'CRM_EDIT_ACTIVITY';
        update permission set sorder = 6, moduleCode = 'ACTIVITIES', parent = (select id from permission where code = 'CRM_ACTIVITIES_LIST'), isMainMenu = false where code = 'CRM_REMOVE_ACTIVITY';

    update permission set sorder = 9, moduleCode = 'WEB_FORMS', parent = (select id from permission where code = 'CRM_SALES_TAB'), isMainMenu = false where code = 'CRM_WEB_FORMS_LIST';
        update permission set sorder = 1, moduleCode = 'WEB_FORMS', parent = (select id from permission where code = 'CRM_WEB_FORMS_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_WEB_FORMS_LIST';
        update permission set sorder = 2, moduleCode = 'WEB_FORMS', parent = (select id from permission where code = 'CRM_WEB_FORMS_LIST'), isMainMenu = false where code = 'CRM_ADD_NEW_WEB_FORM';
        update permission set sorder = 3, moduleCode = 'WEB_FORMS', parent = (select id from permission where code = 'CRM_WEB_FORMS_LIST'), isMainMenu = false where code = 'CRM_EDIT_WEB_FORM';
        update permission set sorder = 4, moduleCode = 'WEB_FORMS', parent = (select id from permission where code = 'CRM_WEB_FORMS_LIST'), isMainMenu = false where code = 'CRM_REMOVE_WEB_FORM';

	update permission set sorder = 2, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CUSTOMER_SERVICE_TAB';
    update permission set sorder = 1, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CUSTOMER_SERVICE_TAB'), isMainMenu = false where code = 'CRM_CASES_LIST';
        update permission set sorder = 1, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_SEE_ALL_CASES_LIST';
        update permission set sorder = 2, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'ADD_NEW_CASE';
        update permission set sorder = 3, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_COPY_CASE';
        update permission set sorder = 4, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_EDIT_CASE';
        update permission set sorder = 5, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_REMOVE_CASE';
        update permission set sorder = 6, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_CHANGE_STATUS_CASE';
        update permission set sorder = 7, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_CHANGE_PRIORITY_CASE';
        update permission set sorder = 8, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_CHANGE_ASSIGNEE_CASE';
        update permission set sorder = 9, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_CLOSE_CASE';
        update permission set sorder = 10, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_CONVERT_TO_CASE';
        update permission set sorder = 11, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_CASES_LIST'), isMainMenu = false where code = 'CRM_CASES_EXPORT';

	  update permission set sorder = 2, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CUSTOMER_SERVICE_TAB'), isMainMenu = false where code = 'CRM_SOLUTIONS_LIST';
        update permission set sorder = 1, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_SOLUTIONS_LIST'), isMainMenu = false where code = 'ADD_NEW_SOLUTION';
        update permission set sorder = 2, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_SOLUTIONS_LIST'), isMainMenu = false where code = 'CRM_EDIT_SOLUTION';
        update permission set sorder = 3, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_SOLUTIONS_LIST'), isMainMenu = false where code = 'CRM_REMOVE_SOLUTION';
        update permission set sorder = 4, moduleCode = 'CASE_MANAGEMENT', parent = (select id from permission where code = 'CRM_SOLUTIONS_LIST'), isMainMenu = false where code = 'CRM_SOLUTIONS_EXPORT';

  update permission set sorder = 3, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_E_MAIL_MARKETING_TAB';
    update permission set sorder = 1, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_MAILING_LIST';
    update permission set sorder = 2, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_DRAFT_MESSAGES_LIST';
    update permission set sorder = 3, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_SENT_MESSAGES_LIST';
    update permission set sorder = 4, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_QUEUED_MESSAGES_LIST';
    update permission set sorder = 5, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_SEE_ALL_MAILLIST_LIST';
    update permission set sorder = 6, moduleCode = 'EMAIL_MARKETING',name = 'Add new mailing list', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_ADD_NEW_MAILING_LIST';
    update permission set sorder = 7, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_EDIT_MAILING_LIST';
    update permission set sorder = 8, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_REMOVE_MAILING_LIST';
    update permission set sorder = 9, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_MAIL_LIST_MEMBERS';
    update permission set sorder = 10, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_ADD_NEW_MESSAGE';
    update permission set sorder = 11, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_TRACK_MESSAGES_IN_SENT_MESSAGE';
    update permission set sorder = 12, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE';
    update permission set sorder = 13, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_MESSAGE_EDIT';
    update permission set sorder = 14, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_MESSAGE_REMOVE';
    update permission set sorder = 15, moduleCode = 'EMAIL_MARKETING', parent = (select id from permission where code = 'CRM_E_MAIL_MARKETING_TAB'), isMainMenu = false where code = 'CRM_MESSAGES_EXPORT';

	update permission set sorder = 4, moduleCode = 'CRM_CALENDAR', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_Calendar';

	update permission set sorder = 5, moduleCode = 'MESSAGE_CENTER', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_MESSAGE_CENTER';

	update permission set sorder = 6, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_SALES_QUOTE_LIST';
    update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_QUOTE_LIST'), isMainMenu = false where code = 'CRM_SALES_QUOTE_ADD';
    update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_QUOTE_LIST'), isMainMenu = false where code = 'CRM_SALES_QUOTE_EDIT';
    update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_QUOTE_LIST'), isMainMenu = false where code = 'CRM_SALES_QUOTE_DELETE';
    update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_QUOTE_LIST'), isMainMenu = false where code = 'CRM_SALES_QUOTE_SUMMARY';
    update permission set sorder = 5, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_QUOTE_LIST'), isMainMenu = false where code = 'CRM_SALES_QUOTE_PDF';

	update permission set sorder = 7, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_SALES_INVOICE_LIST';
    update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_INVOICE_LIST'), isMainMenu = false where code = 'CRM_SALES_INVOICE_ADD';
    update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_INVOICE_LIST'), isMainMenu = false where code = 'CRM_SALES_INVOICE_EDIT';
    update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_INVOICE_LIST'), isMainMenu = false where code = 'CRM_SALES_INVOICE_DELETE';
    update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_INVOICE_LIST'), isMainMenu = false where code = 'CRM_SALES_INVOICE_SUMMARY';
    update permission set sorder = 5, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_INVOICE_LIST'), isMainMenu = false where code = 'CRM_SALES_INVOICE_PDF';

	update permission set sorder = 8, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_PURCHASE_INVOICE_LIST';
    update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_INVOICE_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_INVOICE_ADD';
    update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_INVOICE_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_INVOICE_EDIT';
    update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_INVOICE_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_INVOICE_DELETE';
    update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_INVOICE_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_INVOICE_SUMMARY';
    update permission set sorder = 5, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_INVOICE_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_INVOICE_PDF';

	update permission set sorder = 9, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_PURCHASE_ORDER_LIST';
    update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_ORDER_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_ORDER_ADD';
    update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_ORDER_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_ORDER_EDIT';
    update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_ORDER_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_ORDER_DELETE';
    update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_ORDER_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_ORDER_SUMMARY';
    update permission set sorder = 5, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_PURCHASE_ORDER_LIST'), isMainMenu = false where code = 'CRM_PURCHASE_ORDER_PDF';

	update permission set sorder = 10, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_MAIN_MENU'), isMainMenu = false where code = 'CRM_SALES_ORDER_LIST';
    update permission set sorder = 1, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_ORDER_LIST'), isMainMenu = false where code = 'CRM_SALES_ORDER_ADD';
    update permission set sorder = 2, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_ORDER_LIST'), isMainMenu = false where code = 'CRM_SALES_ORDER_EDIT';
    update permission set sorder = 3, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_ORDER_LIST'), isMainMenu = false where code = 'CRM_SALES_ORDER_DELETE';
    update permission set sorder = 4, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_ORDER_LIST'), isMainMenu = false where code = 'CRM_SALES_ORDER_SUMMARY';
    update permission set sorder = 5, moduleCode = 'CRM_MODULE', parent = (select id from permission where code = 'CRM_SALES_ORDER_LIST'), isMainMenu = false where code = 'CRM_SALES_ORDER_PDF';

--Delete unused permissions

  DELETE from permission where context = 'CRM' and code not in ('CRM_MAIN_MENU','CRM_SALES_TAB','CRM_WELCOME_PAGE','CRM_LEADS_LIST','CRM_SEE_ALL_LEADS_LIST','ADD_NEW_LEAD',
  'CRM_LEAD_EDIT','CRM_LEAD_DELETE','ADD_LEAD_NOTE','CRM_LEAD_STATUS','ADD_LEAD_SMS','CRM_LEAD_LOOKUP','CRM_LEAD_CONVERT','CRM_LEAD_COPY','CHANGE_LEADS_ASSIGNEE',
  'CHANGE_LEADS_CAMPAIGN','CRM_LEADS_IMPORT','CRM_LEADS_EXPORT','CRM_OPPORTUNITIES_LIST','CRM_SEE_ALL_OPPORTUNITIES_LIST','CRM_ADD_NEW_OPPORTUNITIES','CRM_EDIT_OPPORTUNITIES',
  'CRM_COPY_OPPORTUNITIES','CRM_REMOVE_OPPORTUNITIES','CRM_ADD_OPPORTUNITY_NOTE','CRM_OPPORTUNITY_CHANGE_STAGE','CHANGE_OPPORTUNITIES_CAMPAIGN','CONVERT_OPPORTUNITY_TO_SQ',
  'CONVERT_OPPORTUNITY_TO_SO','CONVERT_OPPORTUNITY_TO_RFQ','CONVERT_OPPORTUNITY_TO_PROJECT','CRM_OPPORTUNITIES_IMPORT_LIST','CRM_OPPORTUNITIES_EXPORT_LIST',
  'CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST','CRM_OPPORTUNITIES_RFQ_LIST','CRM_ACCOUNTS_LIST','CRM_SEE_ALL_ACCOUNTS_LIST','CRM_ACCOUNT_ADD','CRM_SUPPLIER_ADD','CRM_CLIENT_ADD',
  'CRM_ACCOUNTS_EDIT','CRM_ACCOUNTS_COPY','CRM_ACCOUNTS_DELETE','CRM_ACCOUNTS_CONVERT','CRM_ACCOUNTS_ADD_NOTE','CRM_ACCOUNTS_DETECT_DUBLICATES','CRM_ACCOUNTS_MERGE',
  'CRM_ACCOUNTS_IMPORT','CRM_ACCOUNTS_EXPORT','CRM_ACCOUNT_NUMBER_EDIT','CRM_CONTACTS_LIST','CRM_SEE_ALL_CONTACT_LIST','CRM_ADD_NEW_CONTACT','CRM_EDIT_CONTACT','CRM_REMOVE_CONTACT',
  'CRM_NOTE_CONTACT','ADD_CONTACT_SMS','CRM_CONTACT_LOOK_UP','CRM_CONTACTS_DETECT_DUBLICATES','CRM_CONTACTS_MERGE','CRM_ADD_NEW_CATEGORY','CRM_COPY_TO_CATEGORY',
  'CRM_MOVE_TO_CATEGORY','CRM_CHANGE_CAMPAIGN','CRM_GOOGLE_CONTACTS','CRM_CONTACTS_IMPORT','CRM_CONTACTS_EXPORT','CRM_CAMPAIGNS_LIST','CRM_ADD_NEW_CAMPAIGN','CRM_EDIT_CAMPAIGN',
  'CRM_REMOVE_CAMPAIGN','CRM_CAMPAIGNS_EXPORT','CRM_TASKS_LIST','CRM_SEE_ALL_TASKS_LIST','CRM_TASKS_ADD','CRM_TASKS_ADD_MULTI','CRM_TASKS_EDIT','CRM_TASKS_REMOVE',
  'CRM_TASK_LIST_MORE_BUTTON','CRM_TASKS_NOTES','CRM_TASKS_TIMER','CRM_TASKS_BUDGET','CRM_TASKS_DOCUMENTS','CRM_TASKS_COMMENTS','CRM_TASKS_ISSUE','CRM_TASKS_PDF_EXCEL_EXPORT',
  'CRM_ACTIVITIES_LIST','CRM_SEE_ALL_ACTIVITIES_LIST','CRM_ACTIVITIES_LOG_CALL_VIEW','CRM_ADD_NEW_ACTIVITY_EVENT','CRM_ADD_NEW_ACTIVITY_LOG_A_CALL','CRM_EDIT_ACTIVITY',
  'CRM_REMOVE_ACTIVITY','CRM_WEB_FORMS_LIST','CRM_SEE_ALL_WEB_FORMS_LIST','CRM_ADD_NEW_WEB_FORM','CRM_EDIT_WEB_FORM','CRM_REMOVE_WEB_FORM','CUSTOMER_SERVICE_TAB',
  'CRM_CASES_LIST','CRM_SEE_ALL_CASES_LIST','ADD_NEW_CASE','CRM_COPY_CASE','CRM_EDIT_CASE','CRM_REMOVE_CASE','CRM_CHANGE_STATUS_CASE','CRM_CHANGE_PRIORITY_CASE',
  'CRM_CHANGE_ASSIGNEE_CASE','CRM_CLOSE_CASE','CRM_CONVERT_TO_CASE','CRM_CASES_EXPORT','CRM_SOLUTIONS_LIST','ADD_NEW_SOLUTION','CRM_EDIT_SOLUTION','CRM_REMOVE_SOLUTION',
  'CRM_SOLUTIONS_EXPORT','CRM_E_MAIL_MARKETING_TAB','CRM_MAILING_LIST','CRM_DRAFT_MESSAGES_LIST','CRM_SENT_MESSAGES_LIST','CRM_QUEUED_MESSAGES_LIST','CRM_SEE_ALL_MAILLIST_LIST',
  'CRM_ADD_NEW_MAILING_LIST','CRM_EDIT_MAILING_LIST','CRM_REMOVE_MAILING_LIST','CRM_MAIL_LIST_MEMBERS','CRM_ADD_NEW_MESSAGE','CRM_TRACK_MESSAGES_IN_SENT_MESSAGE',
  'CRM_UPDATE_STATISTIC_IN_SENT_MESSAGE','CRM_MESSAGE_EDIT','CRM_MESSAGE_REMOVE','CRM_MESSAGES_EXPORT','CRM_Calendar','CRM_MESSAGE_CENTER','CRM_SALES_QUOTE_LIST',
  'CRM_SALES_QUOTE_ADD','CRM_SALES_QUOTE_EDIT','CRM_SALES_QUOTE_DELETE','CRM_SALES_QUOTE_SUMMARY','CRM_SALES_QUOTE_PDF','CRM_SALES_INVOICE_LIST','CRM_SALES_INVOICE_ADD',
  'CRM_SALES_INVOICE_EDIT','CRM_SALES_INVOICE_DELETE','CRM_SALES_INVOICE_SUMMARY','CRM_SALES_INVOICE_PDF','CRM_PURCHASE_INVOICE_LIST','CRM_PURCHASE_INVOICE_ADD',
  'CRM_PURCHASE_INVOICE_EDIT','CRM_PURCHASE_INVOICE_DELETE','CRM_PURCHASE_INVOICE_SUMMARY','CRM_PURCHASE_INVOICE_PDF','CRM_PURCHASE_ORDER_LIST','CRM_PURCHASE_ORDER_ADD',
  'CRM_PURCHASE_ORDER_EDIT','CRM_PURCHASE_ORDER_DELETE','CRM_PURCHASE_ORDER_SUMMARY','CRM_PURCHASE_ORDER_PDF','CRM_SALES_ORDER_LIST','CRM_SALES_ORDER_ADD','CRM_SALES_ORDER_EDIT',
  'CRM_SALES_ORDER_DELETE','CRM_SALES_ORDER_SUMMARY','CRM_SALES_ORDER_PDF');