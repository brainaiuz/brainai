-----------------
----------------- only for companyId 43880
-----------------
update "43880".quote
		              SET pdftemplate_id = (select c.id from "43880".companypdftemplate c
                                                        left join "43880".pdftemplate pt on c.templateid = pt.id
                                                        left join pdfreference r on pt.typeid = r.id
                                                        where c.deleted = false
                                                        and pt.deleted = false
                                                        and r.code = 'SALES_ORDER'
                                                        order by c.id desc
                                                        limit 1)
                  where id in(
                              select sq.id from "43880".salequote sq
                              left join "43880".quote q on sq.id = q.id
                              where q.deleted = false
                              and sq.issalesorder = true)
                  and deleted = false;