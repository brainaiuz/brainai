

update usageplan set essUsers=0;