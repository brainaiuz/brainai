--for HRMS, schema anv
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'CRM', 'Leads multi assignee change', 11, false, (select id from permission where code='CRM_LEADS_LIST'), false,  'LEAD_MANAGEMENT');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'SALESMAN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_MUlTI_ASSIGNEE', 'SALESMAN', 'ALLOW');
