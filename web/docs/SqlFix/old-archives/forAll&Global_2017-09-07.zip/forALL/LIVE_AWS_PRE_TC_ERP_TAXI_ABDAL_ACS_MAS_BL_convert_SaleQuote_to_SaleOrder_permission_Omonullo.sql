
delete
from "anv".rolepermission
where permissioncode = 'CONVERT_SALE_QUOTE_TO_SALE_ORDER';

delete
from permission  where code = 'CONVERT_SALE_QUOTE_TO_SALE_ORDER';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('CONVERT_SALE_QUOTE_TO_SALE_ORDER',   'ACCOUNTING', false, 'Convert to Sales Order', 10, (select id from permission where code = 'ACCOUNTING_SALES_QUOTE_LIST'), false, 'ACCOUNTING_MODULE');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_SALE_QUOTE_TO_SALE_ORDER', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_SALE_QUOTE_TO_SALE_ORDER', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_SALE_QUOTE_TO_SALE_ORDER', 'ALLOW', 'ACCOUNTANT');