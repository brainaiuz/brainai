

delete from "0".rolepermission where permissioncode='HRMS_ADD_COMPETENCY';
delete from "anv".rolepermission where permissioncode='HRMS_ADD_COMPETENCY';
delete from permission where code='HRMS_ADD_COMPETENCY';
update permission set ismainmenu=true where code='PM_LOCATION_LIST';