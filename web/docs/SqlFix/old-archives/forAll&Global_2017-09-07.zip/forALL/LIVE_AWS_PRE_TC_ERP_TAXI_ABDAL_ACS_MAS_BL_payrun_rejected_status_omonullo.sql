
insert into "0".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid, leavedays, includedayoffs, includeholidays)
values ('PY_REJECTED', false, true, false, true, true, 'Rejected', true, 4, (select id from "0".reference where code = 'PAYRUN_STATUS'), 0.00, false, false);

insert into "anv".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid, leavedays, includedayoffs, includeholidays)
values ('PY_REJECTED', false, true, false, true, true, 'Rejected', true, 4, (select id from "anv".reference where code = 'PAYRUN_STATUS'), 0.00, false, false);