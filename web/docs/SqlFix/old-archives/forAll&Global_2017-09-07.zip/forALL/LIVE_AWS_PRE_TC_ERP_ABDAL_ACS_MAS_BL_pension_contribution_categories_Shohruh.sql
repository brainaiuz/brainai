DELETE FROM "anv".category
WHERE code IN ('EMPLOYEE_PENSION_DEDUCTION', 'EMPLOYER_PENSION_DEDUCTION') AND id NOT IN (SELECT categoryid FROM "anv".paymentdeduction);

INSERT INTO "anv".category (code, forall, name, pensionable, taxable, type)
  SELECT 'EMPLOYEE_PENSION_DEDUCTION', TRUE, 'Employee Pension Contribution', TRUE, TRUE, 'Deduction'
  WHERE NOT exists(SELECT * FROM "anv".category WHERE code = 'EMPLOYEE_PENSION_DEDUCTION');

INSERT INTO "anv".category (code, forall, deductfromemployer, name, pensionable, taxable, type)
  SELECT 'EMPLOYER_PENSION_DEDUCTION', TRUE, TRUE, 'Employer Pension Contribution', TRUE, TRUE, 'Deduction'
  WHERE NOT exists(SELECT * FROM "anv".category WHERE code = 'EMPLOYER_PENSION_DEDUCTION');

UPDATE "anv".category SET debittoaccountid = (SELECT id FROM "anv".account WHERE key = 9995), credittoaccountid = (SELECT id FROM "anv".account WHERE key = 2230)
  WHERE code = 'EMPLOYEE_PENSION_DEDUCTION';

UPDATE "anv".category SET debittoaccountid = (SELECT id FROM "anv".account WHERE key = 7007), credittoaccountid = (SELECT id FROM "anv".account WHERE key = 2230)
  WHERE code = 'EMPLOYER_PENSION_DEDUCTION';