--ATTENTION!!!! Apply patch after Schema Update
update "anv".shippingmethod set currencyid = (select currency_id from "anv".financialsettings) where currencyid is null;