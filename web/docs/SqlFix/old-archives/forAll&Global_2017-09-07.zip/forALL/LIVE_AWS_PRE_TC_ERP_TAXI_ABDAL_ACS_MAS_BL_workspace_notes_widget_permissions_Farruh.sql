
insert into permission (code, context, ismainmenu, name, sorder, parent, modulecode)
      values ('NOTES_WIDGET', 'WORKSPACE', 't', 'Notes widget',
      (select max(sorder)+1 from permission where parent=(select id from permission where code='WORKSPACE_MAIN_MENU')) ,
      (select id from permission where code='WORKSPACE_MAIN_MENU'), 'WORKSPACE');

--------------for "anv". schema----------
insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'ADMIN', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'DR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'TL', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'HR', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'CLIENT', 'ALLOW');

--------------for 0 schema----------
insert into "0".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'ADMIN', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'DR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'TL', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'HR', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access)
values ('NOTES_WIDGET', 'CLIENT', 'ALLOW');
