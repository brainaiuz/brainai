---- for public schema --
delete from permission where code = 'ACCOUNTING_FRANCHISE_LIST';
delete from permission where code = 'ACCOUNTING_FRANCHISE_ADD';
delete from permission where code = 'ACCOUNTING_FRANCHISE_EDIT';
delete from permission where code = 'ACCOUNTING_FRANCHISE_DELETE';

insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('ACCOUNTING_FRANCHISE_LIST','ACCOUNTING','Franchise List',19,'f',(SELECT ID FROM PERMISSION WHERE CODE = 'ACCOUNTING_ACCOUNTING_MENU'),'f','ACCOUNTING_MODULE');

insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('ACCOUNTING_FRANCHISE_ADD','ACCOUNTING','Franchise Add',1,'f',(SELECT ID FROM PERMISSION WHERE CODE = 'ACCOUNTING_FRANCHISE_LIST'),'f','ACCOUNTING_MODULE'),
('ACCOUNTING_FRANCHISE_EDIT','ACCOUNTING','Franchise Edit',2,'f',(SELECT ID FROM PERMISSION WHERE CODE = 'ACCOUNTING_FRANCHISE_LIST'),'f','ACCOUNTING_MODULE'),
('ACCOUNTING_FRANCHISE_DELETE','ACCOUNTING','Franchise Delete',3,'f',(SELECT ID FROM PERMISSION WHERE CODE = 'ACCOUNTING_FRANCHISE_LIST'),'f','ACCOUNTING_MODULE');


--- for private schema --
delete from "anv".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_LIST';
delete from "anv".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_ADD';
delete from "anv".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_EDIT';
delete from "anv".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_DELETE';

insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_LIST','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_LIST','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_LIST','ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_ADD','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_ADD','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_ADD','ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_EDIT','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_EDIT','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_EDIT','ACCOUNTANT','ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_DELETE','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_DELETE','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_DELETE','ACCOUNTANT','ALLOW');

--- for ZERO schema --
delete from "0".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_LIST';
delete from "0".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_ADD';
delete from "0".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_EDIT';
delete from "0".rolepermission where permissioncode = 'ACCOUNTING_FRANCHISE_DELETE';

insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_LIST','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_LIST','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_LIST','ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_ADD','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_ADD','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_ADD','ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_EDIT','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_EDIT','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_EDIT','ACCOUNTANT','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_DELETE','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_DELETE','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_FRANCHISE_DELETE','ACCOUNTANT','ALLOW');