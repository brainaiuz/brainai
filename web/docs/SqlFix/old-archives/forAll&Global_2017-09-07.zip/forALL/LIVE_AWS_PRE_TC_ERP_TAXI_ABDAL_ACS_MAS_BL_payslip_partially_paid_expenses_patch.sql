UPDATE "anv".expensepayments
SET paysliptableitem_id = (SELECT er.paysliptableitemid
                           FROM "anv".expensereport er
                           WHERE er.id = expensereportid)
WHERE deleted IS NULL OR deleted != TRUE;