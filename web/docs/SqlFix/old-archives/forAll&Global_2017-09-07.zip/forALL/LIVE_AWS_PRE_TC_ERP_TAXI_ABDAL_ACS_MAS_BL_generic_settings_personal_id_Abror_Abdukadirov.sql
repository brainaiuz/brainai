
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "anv".genericSettings (key,value) values('EMPLOYEE_FORM_PERSONAL_ID', 'Personal ID');

