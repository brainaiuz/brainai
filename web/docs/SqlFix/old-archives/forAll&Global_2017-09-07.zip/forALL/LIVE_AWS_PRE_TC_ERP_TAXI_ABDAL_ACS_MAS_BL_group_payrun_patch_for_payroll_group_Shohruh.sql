UPDATE "anv".paysliptable
SET payrollbatchid = NULL
WHERE payrollbatchid IS NOT NULL AND
      payrollbatchid NOT IN (SELECT id FROM "anv".payroll_batch);