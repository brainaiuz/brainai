delete
from "anv".rolepermission
where permissioncode = 'CRM_LEAD_DELETE';

delete
from permission  where code = 'CRM_LEAD_DELETE';



insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('CRM_LEAD_DELETE',   'CRM', false, 'Crm Lead Delete', 20, (select id from permission where code = 'CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CRM_LEAD_DELETE', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CRM_LEAD_DELETE', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CRM_LEAD_DELETE', 'ALLOW', 'ACCOUNTANT');