--REQUEST_FOR_QUOTE_CELL_EDITABLE
delete
from "anv".rolepermission
where permissioncode = 'REQUEST_FOR_QUOTE_CELL_EDITABLE';

delete
from permission  where code = 'REQUEST_FOR_QUOTE_CELL_EDITABLE';
-- 805 | ACCOUNTING_REQUEST_FOR_QUOTE_LIST | ACCOUNTING | Request For Quote List |     19 | f          |    477 |             | f      |           | ACCOUNTING_MODULE

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('REQUEST_FOR_QUOTE_CELL_EDITABLE', 'ACCOUNTING',      false, 'RFQ item cost editable',       10, (select id from permission where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_LIST'),  false, 'ACCOUNTING_MODULE');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('REQUEST_FOR_QUOTE_CELL_EDITABLE', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('REQUEST_FOR_QUOTE_CELL_EDITABLE', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('REQUEST_FOR_QUOTE_CELL_EDITABLE', 'ALLOW', 'ACCOUNTANT');