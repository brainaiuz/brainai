
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "58835".genericSettings (key,value) values('PDF_PICK_LIST_DATA', 'YES');
