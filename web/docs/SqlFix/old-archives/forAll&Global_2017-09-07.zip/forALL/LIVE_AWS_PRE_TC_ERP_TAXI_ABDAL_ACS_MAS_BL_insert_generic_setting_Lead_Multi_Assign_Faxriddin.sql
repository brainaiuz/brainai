--Faqat Suralgan Companylarga uriladi. Buni urmanglar!!!
insert into "anv".genericsettings (key,value) values ('SELECT_ALL_ITEMS_FROM_LISTING','YES');