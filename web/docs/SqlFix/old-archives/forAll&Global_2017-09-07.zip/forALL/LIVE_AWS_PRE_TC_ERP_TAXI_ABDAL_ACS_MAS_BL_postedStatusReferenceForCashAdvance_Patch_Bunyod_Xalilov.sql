--- for all schema ---
insert into "anv".reference (code, name, deleted, iscustombutton, isremovable, issystemreference, shared)
            values('POSTED', 'Posted', false, false, false, true, true);