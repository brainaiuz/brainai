DROP FUNCTION IF EXISTS findexpensemultiapprover();
CREATE OR REPLACE FUNCTION findexpensemultiapprover()
  RETURNS text AS
$BODY$
DECLARE
companyId text;
count_ integer;
counts text;
companyname text;
BEGIN
    counts='';
    FOR companyId IN (SELECT id || '' FROM company WHERE active = true)
    LOOP
        IF EXISTS (SELECT nspname FROM pg_namespace WHERE companyId = nspname ORDER BY nspname)
        THEN
            companyname = (SELECT name FROM company WHERE id||'' = companyId);
            EXECUTE REPLACE('select count(id) from "anv".genericSettings where key =''EXPENSE_DOUBLE_APPROVER_ENABLED''', 'anv', companyId) INTO count_;
            IF count_ > 0
            THEN
                counts :=counts || companyId || '|'||companyname || '|';
            END IF;
        END IF;
    END LOOP;
    RETURN counts;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION findexpensemultiapprover()
  OWNER TO postgres;
SELECT findexpensemultiapprover();