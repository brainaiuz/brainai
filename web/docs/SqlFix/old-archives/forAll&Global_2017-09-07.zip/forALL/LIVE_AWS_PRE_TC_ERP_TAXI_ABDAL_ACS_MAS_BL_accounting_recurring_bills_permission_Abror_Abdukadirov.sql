update permission set modulecode = 'ACCOUNTING_MODULE' where code = 'ACCOUNTING_RECURRING_BILL_LIST' and context = 'ACCOUNTING';
update permission set modulecode = 'ACCOUNTING_MODULE' where code = 'ACCOUNTING_RECURRING_BILL_ADD' and context = 'ACCOUNTING';
update permission set modulecode = 'ACCOUNTING_MODULE' where code = 'ACCOUNTING_RECURRING_BILL_EDIT' and context = 'ACCOUNTING';
update permission set modulecode = 'ACCOUNTING_MODULE' where code = 'ACCOUNTING_RECURRING_BILL_SUMMARY' and context = 'ACCOUNTING';
update permission set modulecode = 'ACCOUNTING_MODULE' where code = 'ACCOUNTING_RECURRING_BILL_COPY' and context = 'ACCOUNTING';