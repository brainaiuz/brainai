--SEND_RFQ_QUOTE_NOTE
delete
from "anv".rolepermission
where permissioncode = 'SEND_RFQ_QUOTE_NOTE';

delete
from permission  where code = 'SEND_RFQ_QUOTE_NOTE';
-- 805 | ACCOUNTING_REQUEST_FOR_QUOTE_LIST | ACCOUNTING | Request For Quote List |     19 | f          |    477 |             | f      |           | ACCOUNTING_MODULE

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('SEND_RFQ_QUOTE_NOTE', 'ACCOUNTING',      false, 'RFQ send quote',       10, (select id from permission where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_LIST'),  false, 'ACCOUNTING_MODULE');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('SEND_RFQ_QUOTE_NOTE', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('SEND_RFQ_QUOTE_NOTE', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('SEND_RFQ_QUOTE_NOTE', 'ALLOW', 'ACCOUNTANT');