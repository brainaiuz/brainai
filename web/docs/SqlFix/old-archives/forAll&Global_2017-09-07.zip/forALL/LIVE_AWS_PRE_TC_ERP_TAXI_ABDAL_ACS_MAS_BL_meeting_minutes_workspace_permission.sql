--for HRMS, schema anv
delete from permission where code in ('MEETING_MINUTES_LIST_WORKSPACE', 'SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'ADD_MEETING_MINUTES_WORKSPACE', 'EDIT_MEETING_MINUTES_WORKSPACE', 'REMOVE_MEETING_MINUTES_WORKSPACE', 'CONVERT_MEETING_MINUTES_WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('MEETING_MINUTES_LIST_WORKSPACE', 'WORKSPACE', 'Meeting minutes list', 15, false, (select id from permission where code='WORKSPACE_MAIN_MENU'), false,  'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'WORKSPACE', 'Show all meeting minutes', 1, false, (select id from permission where code='MEETING_MINUTES_LIST_WORKSPACE'), false,  'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ADD_MEETING_MINUTES_WORKSPACE', 'WORKSPACE', 'Add meeting minutes', 2, false, (select id from permission where code='MEETING_MINUTES_LIST_WORKSPACE'), false,  'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('EDIT_MEETING_MINUTES_WORKSPACE', 'WORKSPACE', 'Edit meeting minutes', 3, false, (select id from permission where code='MEETING_MINUTES_LIST_WORKSPACE'), false,  'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'WORKSPACE', 'Remove meeting minutes', 4, false, (select id from permission where code='MEETING_MINUTES_LIST_WORKSPACE'), false,  'WORKSPACE');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'WORKSPACE', 'Convert meeting minutes', 5, false, (select id from permission where code='MEETING_MINUTES_LIST_WORKSPACE'), false,  'WORKSPACE');

delete from "anv".rolepermission where permissioncode in ('MEETING_MINUTES_LIST_WORKSPACE', 'SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'ADD_MEETING_MINUTES_WORKSPACE', 'EDIT_MEETING_MINUTES_WORKSPACE', 'REMOVE_MEETING_MINUTES_WORKSPACE', 'CONVERT_MEETING_MINUTES_WORKSPACE');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');



--For schem 0
delete from "0".rolepermission where permissioncode in ('MEETING_MINUTES_LIST_WORKSPACE', 'SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'ADD_MEETING_MINUTES_WORKSPACE', 'EDIT_MEETING_MINUTES_WORKSPACE', 'REMOVE_MEETING_MINUTES_WORKSPACE', 'CONVERT_MEETING_MINUTES_WORKSPACE');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('MEETING_MINUTES_LIST_WORKSPACE', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('EDIT_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('REMOVE_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CONVERT_MEETING_MINUTES_WORKSPACE', 'HR', 'ALLOW');


