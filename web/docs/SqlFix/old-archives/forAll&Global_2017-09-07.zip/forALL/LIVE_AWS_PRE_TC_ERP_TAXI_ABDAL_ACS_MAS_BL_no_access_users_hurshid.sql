
--Run this after schema update

update usageplan set noAccessUsers=10;