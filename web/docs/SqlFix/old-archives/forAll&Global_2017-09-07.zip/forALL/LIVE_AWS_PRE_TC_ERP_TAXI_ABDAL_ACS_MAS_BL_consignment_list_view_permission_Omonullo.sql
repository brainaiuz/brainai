delete from permission where code = 'ACCOUNTING_CONSIGNMENT_LIST_VIEW';

insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','ACCOUNTING','Consignment List',19,'f',(SELECT ID FROM PERMISSION WHERE CODE = 'ACCOUNTING_ACCOUNTING_MENU'),'f','ACCOUNTING_MODULE');

delete from "anv".rolepermission where permissioncode = 'ACCOUNTING_CONSIGNMENT_LIST_VIEW';

insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','ACCOUNTANT','ALLOW');


delete from "0".rolepermission where permissioncode = 'ACCOUNTING_CONSIGNMENT_LIST_VIEW';

insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_CONSIGNMENT_LIST_VIEW','ACCOUNTANT','ALLOW');