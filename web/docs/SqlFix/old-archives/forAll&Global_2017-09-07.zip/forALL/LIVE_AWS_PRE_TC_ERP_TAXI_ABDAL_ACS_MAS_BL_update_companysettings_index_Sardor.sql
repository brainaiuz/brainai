
--Documents storage size, by default true.
update companysettings set indexeddocumentupload = true;