delete from permission where code = 'PAYROLL_ADDITIONAL_DEDUCTION_ADD';
insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_DEDUCTION_ADD', 'PAYROLL', 'Additional Payment Add', 2, 'PAYROLL', (select id from permission where code='PAYROLL_ADDITIONAL_PAYMENT_LIST'));

delete from "anv".rolepermission where permissioncode = 'PAYROLL_ADDITIONAL_DEDUCTION_ADD';
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_DEDUCTION_ADD', 'ALLOW','ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_DEDUCTION_ADD', 'ALLOW','ADMIN');

delete from "0".rolepermission where permissioncode = 'PAYROLL_ADDITIONAL_DEDUCTION_ADD';
insert into "0".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_DEDUCTION_ADD', 'ALLOW','ADMIN');
insert into "0".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_DEDUCTION_ADD', 'ALLOW','ADMIN');

