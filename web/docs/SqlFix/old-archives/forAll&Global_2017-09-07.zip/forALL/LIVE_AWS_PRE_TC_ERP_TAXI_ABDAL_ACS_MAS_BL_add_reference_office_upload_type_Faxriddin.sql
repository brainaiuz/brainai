
insert into "0".reference (code,name,sorder,parentid,isremovable,issystemreference,deleted,shared,iscustombutton)
values ('OFFICE_365', 'Office_365 type',4,(select id from "0".reference where code='_UPLOAD_TYPE'),false,true,false,true,false);



insert into "anv".reference (code,name,sorder,parentid,isremovable,issystemreference,deleted,shared,iscustombutton)
values ('OFFICE_365', 'Office_365 type',4,(select id from "anv".reference where code='_UPLOAD_TYPE'),false,true,false,true,false);