
--- Accounting CRM Contact List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_CONTACT_LIST', 'ACCOUNTING', 'Contact List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CONTACT_LIST', 'PM', 'ALLOW');


--- Accounting CRM Opportunity  List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_OPPORTUNITY_LIST', 'ACCOUNTING', 'Opportunity List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_OPPORTUNITY_LIST', 'PM', 'ALLOW');

--- Accounting CRM Event List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_EVENT_LIST', 'ACCOUNTING', 'Event List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_EVENT_LIST', 'PM', 'ALLOW');


--- Accounting CRM Case List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_CASE_LIST', 'ACCOUNTING', 'Case List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CASE_LIST', 'PM', 'ALLOW');

--- Accounting Task List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_TASK_LIST', 'ACCOUNTING', 'Task List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TASK_LIST', 'PM', 'ALLOW');

--- Accounting Issue List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_ISSUE_LIST', 'ACCOUNTING', 'Issue List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_ISSUE_LIST', 'PM', 'ALLOW');

--- Accounting Client Note List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_CLIENT_NOTE_LIST', 'ACCOUNTING', 'Client Note List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CLIENT_NOTE_LIST', 'PM', 'ALLOW');


--- Accounting Supplier Note List ----
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'ACCOUNTING', 'Supplier Note List',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'), false, 'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_SUPPLIER_NOTE_LIST', 'PM', 'ALLOW');


