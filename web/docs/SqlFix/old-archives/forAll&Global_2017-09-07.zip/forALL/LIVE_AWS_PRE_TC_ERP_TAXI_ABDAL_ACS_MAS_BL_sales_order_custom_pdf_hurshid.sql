
insert into pdfreference(code,name) values('SALES_ORDER','Sales Order');