
delete FROM permission WHERE code='ACCOUNTING_WELCOME_PAGE';
delete FROM permission WHERE code='ACCOUNTING_HOME_PAGE';

UPDATE  permission set sorder=2 where sorder=1 AND modulecode='ACCOUNTING_MODULE' and parent =(SELECT p.id from permission p WHERE p.code='ACCOUNTING_ACCOUNTING_MENU');

--- Accounting Welcome Page ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('ACCOUNTING_WELCOME_PAGE', 'ACCOUNTING', 'Welcome Page',0, false,
                (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'),
                false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'PM', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_WELCOME_PAGE', 'PM', 'ALLOW');


--- Accounting Home Page ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_HOME_PAGE', 'ACCOUNTING', 'Home Page',1, false,
      (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'),
       false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_HOME_PAGE', 'PM', 'ALLOW');

