-----------------------Cash_Advance_customform2 patch urilgandan kiyin uriladi bu patch
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor, field_ID,       section,       fullwidth,   widget,    form_ID,                       noWrapperFor, labelless) values
                        (12,   false,      false,  false,       '',            false,            '',         'ATTACHMENTS', 'ATTACHMENTS',  true,       'UNKNOWN',  'PAYROLL_CASH_ADVANCE_FORM',  	'',		 			  false);


update modelfield set fieldsetstyle = 'slideDown-content group nobrd', fieldstyle = 'field' where form_id = 'PAYROLL_CASH_ADVANCE_FORM'  and field_id = 'ATTACHMENTS';
update modelfield set nolabelfor = 'addForm,editForm,viewForm', type = 'text', fieldsetstyle = 'slideDown-content group nobrd' where form_id = 'PAYROLL_CASH_ADVANCE_FORM'  and field_id = 'ATTACHMENTS';
update modelfield set rowstyle = 'row hideCustomField', sectionstyle = 'slideDown-box  group expand hideCustomField' where form_id = 'PAYROLL_CASH_ADVANCE_FORM'  and field_id = 'ATTACHMENTS';
