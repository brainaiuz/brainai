----PAYMENT_DEDUCTION_INFORMATION
--PAYMENT_TABLE
--DEDUCTION_TABLE
--LOAN_TABLE

delete from modelfield where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'PAYMENT_TABLE';
delete from modelfield where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'DEDUCTION_TABLE';
delete from modelfield where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'LOAN_TABLE';

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID, section, widget  ,form_ID, noWrapperFor ) values
                      (1001 ,false,   false,  false,    '', false, '',  'PAYMENT_TABLE', 'PAYMENT_DEDUCTION_INFORMATION',  'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM','');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID, section, widget  ,form_ID, noWrapperFor ) values
                      (1002 ,false,   false,  false,    '', false, '',  'DEDUCTION_TABLE', 'PAYMENT_DEDUCTION_INFORMATION',  'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM','');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID, section, widget  ,form_ID, noWrapperFor ) values
                      (1003 ,false,   false,  false,    '', false, '',  'LOAN_TABLE', 'PAYMENT_DEDUCTION_INFORMATION',  'MULTITABLE'  , 'HRMS_EMPLOYEE_FORM','');

DELETE FROM modelfield
WHERE form_ID = 'HRMS_EMPLOYEE_FORM' AND field_ID = 'WPS_NUMBER';

INSERT INTO modelfield (sorder, mandatory, hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID, section, widget, form_ID, noWrapperFor)
VALUES
  ((SELECT sorder+1
    FROM modelfield
    WHERE form_ID = 'HRMS_EMPLOYEE_FORM' and field_id = 'INSURANCE_EXPIRY_DATE'), FALSE, FALSE, FALSE, '', FALSE, '',
                                                                        'WPS_NUMBER', 'PERSONAL_IDENTITY_INFORMATION',
                                                                        'TextBox', 'HRMS_EMPLOYEE_FORM', '');