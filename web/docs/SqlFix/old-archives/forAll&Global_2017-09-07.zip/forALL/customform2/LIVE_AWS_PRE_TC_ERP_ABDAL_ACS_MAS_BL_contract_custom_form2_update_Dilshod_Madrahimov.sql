  delete from  modelfield where form_ID ='CONTRACT_FORM';
  delete from  model where formID ='CONTRACT_FORM';

  insert into model(active, formID, title, viewname) values(true, 'CONTRACT_FORM', 'Add Edit View Contract', 'Contract');
  --Contract details
  insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory,  noLabelFor,                      field_ID,            section,               widget,       form_ID,             noWrapperFor, 				labelless ) values
                        (01,     true ,      false,  false,       '',            true ,            '',                             'NUMBER',            'DETAILS',            'TextBox'  ,  'CONTRACT_FORM',  			'',		 			        false ),
                        (02,     false ,      false,  false,       '',           false,            '',                             'NAME',              'DETAILS',            'TextBox'  ,  'CONTRACT_FORM',				'', 	 			        false ),
                        (03,     false ,      false,  false,       '',           false ,           '',                             'CLIENT',            'DETAILS',            'DatePicker', 'CONTRACT_FORM',				'', 	 			        false ),
                        (04,     false,      false,  false,       '',            false ,           '',                             'PROJECT',           'DETAILS',            'TextArea'  , 'CONTRACT_FORM',				'',    	 			      false ),
                        (05,     false,      false, false,          '',          false,            '',                             'REGISTRATION_DATE', 'DETAILS',             'UNKNOWN',    'CONTRACT_FORM',        '',     false ),
                        (06,     false,      false, false,          '',          false,            'addForm,editForm,viewForm',    'DUE_DATE_REMINDER', 'DETAILS',                   'UNKNOWN', 'CONTRACT_FORM',   'editForm, addForm,viewForm',     false ),
                        (07,     false,      false,  false,        '',           false,            'addForm,editForm,viewForm',    'INVOLVED_EMPLOYEE', 'INVOLVED_EMPLOYEES', 'UNKNOWN',    'CONTRACT_FORM',   'editForm, addForm,viewForm',    false ),
                        (08,     false,      false, false,          '',          false,            'addForm,editForm,viewForm',    'ATTACHMENTS',      'ATTACHMENTS',         'UNKNOWN', 'CONTRACT_FORM',   'editForm, addForm,viewForm',     false ),
                        (09,     false,      false, false,          '',          false,            'addForm,editForm,viewForm',    'contractNote',      'contractNote',       'NoteWidget', 'CONTRACT_FORM',   'editForm, addForm,viewForm',     false ),
                        (10,     false,      false, false,          '',          false,            'addForm,editForm,viewForm',    'ADDITIONAL_INFORMATION', 'ADDITIONAL_INFORMATION',       'NoteWidget', 'CONTRACT_FORM',   'editForm, addForm,viewForm',     false );

update modelfield set split=true where field_ID='NAME' and form_ID='CONTRACT_FORM';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id = 'CONTRACT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id = 'CONTRACT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_id = 'CONTRACT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id = 'CONTRACT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_id = 'CONTRACT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id = 'CONTRACT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id = 'CONTRACT_FORM';