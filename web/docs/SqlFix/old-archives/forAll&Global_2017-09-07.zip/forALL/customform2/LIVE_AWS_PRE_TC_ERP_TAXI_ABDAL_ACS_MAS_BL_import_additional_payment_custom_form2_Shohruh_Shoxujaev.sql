delete from "model"  where formid = 'IMPORT_ADDITIONAL_PAYMENT_FORM';
delete from "modelfield"  where form_id = 'IMPORT_ADDITIONAL_PAYMENT_FORM';

delete from "anv"."model"  where formid = 'IMPORT_ADDITIONAL_PAYMENT_FORM';
delete from "anv"."modelfield"  where form_id = 'IMPORT_ADDITIONAL_PAYMENT_FORM';


insert into model(formID, active, title) values('IMPORT_ADDITIONAL_PAYMENT_FORM', true, 'Import Additional Payment');
insert into modelfield(form_ID,                             field_ID,               sorder,     mandatory,   fullWidth,    isCustomField,     section,                  defaultValue,   widget,        systemmandatory,  split,   noLabelFor) values
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'REFERENCE',            1,          true,        false,        false,             'BASIC_INFORMATION',      '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'MONTH',                2,          true,        false,        false,             'BASIC_INFORMATION',      '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'PAYROLL_BATCH',        3,          true,        false,        false,             'BASIC_INFORMATION',      '',             'DropDown',    false,            true,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'APPROVERS',            4,          true,        false,        false,             'BASIC_INFORMATION',      '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'TYPE',                 5,          false,        false,        false,             'BASIC_INFORMATION',      '',             'DropDown',    false,            false,    ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'SHOW_IN_PAYSLIP',      6,          false,       false,        false,             'BASIC_INFORMATION',      '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'HAS_CSV_HEADER',       7,          false,       false,        false,             'MAIN_PANEL',             '',             'CheckBox',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'EMPLOYEE_NUMBER',      8,          false,       false,        false,             'MAIN_PANEL',             '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'EMPLOYEE_NAME',        9,          false,       false,        false,             'MAIN_PANEL',             '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'AMOUNT',               10,         false,       false,        false,             'MAIN_PANEL',             '',             'DropDown',    false,            false,   ''),
                      ('IMPORT_ADDITIONAL_PAYMENT_FORM',    'CATEGORY',             11,         false,       false,        false,             'MAIN_PANEL',             '',             'DropDown',    false,            false,   '');



UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='IMPORT_ADDITIONAL_PAYMENT_FORM';
