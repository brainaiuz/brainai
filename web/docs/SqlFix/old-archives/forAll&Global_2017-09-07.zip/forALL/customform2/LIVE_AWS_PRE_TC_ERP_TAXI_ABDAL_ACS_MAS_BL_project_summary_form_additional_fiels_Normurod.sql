insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           'viewForm',     'PROJECT_INVOICES',   'PROJECT_INVOICES_DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           'viewForm',     'LOGGED_TIMES',   'LOGGED_TIME_DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           '',     'CLIENT_BALANCE',   'DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   '');
insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           '',     'CLIENT_RETAINER',   'DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   '');


insert into "anv".modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           'viewForm',     'PROJECT_INVOICES',   'PROJECT_INVOICES_DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');
insert into "anv".modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           'viewForm',     'LOGGED_TIMES',   'LOGGED_TIME_DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   'viewForm');
insert into "anv".modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           '',     'CLIENT_BALANCE',   'DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   '');
insert into "anv".modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           '',     'CLIENT_RETAINER',   'DETAILS',    'UNKNOWN',   'PROJECT_SUMMARY_FORM',   '');

update modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';
update modelfield set split=true where field_ID='CREATED_DATE' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'PROJECT_INVOICES';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'LOGGED_TIMES';
UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'ATTACHMENTS';


update "anv".modelfield set split=true where field_ID='DESCRIPTION' and form_ID='PROJECT_SUMMARY_FORM';
update "anv".modelfield set split=true where field_ID='CREATED_DATE' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1 left' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set rowStyle = 'row hideCustomField' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set fieldStyle = 'field' where form_ID='PROJECT_SUMMARY_FORM';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'INVOLVED_EMPLOYEE';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'PROJECT_INVOICES';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'LOGGED_TIMES';
UPDATE "anv".modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'PROJECT_SUMMARY_FORM' AND field_id = 'ATTACHMENTS';