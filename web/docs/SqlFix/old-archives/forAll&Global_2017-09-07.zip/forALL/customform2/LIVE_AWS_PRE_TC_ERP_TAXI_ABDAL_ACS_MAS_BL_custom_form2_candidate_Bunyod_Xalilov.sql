delete from "model"  where formid = 'CANDIDATE_FORM';
delete from "modelfield"  where form_id = 'CANDIDATE_FORM';

delete from "0".reference  where code = '_WORKFLOW_MODULE_CANDIDATE';
insert into "0".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CANDIDATE', 'Candidate', (select max(sorder) from "0".reference where parentid = (select id from "0".reference where code = '_WORKFLOW_MODULE')),
(select id from "0".reference where code = '_WORKFLOW_MODULE'));

insert into model(formID, active, title, viewname) values('CANDIDATE_FORM', true, 'Candidate Form', 'Candidate');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue,  systemmandatory,  field_ID,           section,                 widget         ,form_ID,                noLabelFor,    usableByworkflow,  type,                        source,    split) values
                      (01,     false,      false,       false,          null,           false,      'NUMBER',          'CONTACT_INFORMATION',   'UNKNOWN',      'CANDIDATE_FORM',             '',              false,    'text',                            '',    false),
                      (05,     false,      false,       false,          null,           false,      'OWNER',           'CONTACT_INFORMATION',   'DropDown',     'CANDIDATE_FORM',             '',               true,    'text',           'CRM@LEAD_ASSIGNEE',    false),
                      (10,     false,      false,       false,          null,           true ,      'FIRST_NAME',      'CONTACT_INFORMATION',   'UNKNOWN',      'CANDIDATE_FORM',             '',               true,    'Text',                            '',    false),
                      (15,     false,      false,       false,          null,           false ,      'LAST_NAME',       'CONTACT_INFORMATION',   'TextBox',      'CANDIDATE_FORM',             '',               true,    'Text',                            '',    false),
                      (20,     false,      false,       false,          null,           false,      'BIRTH_DAY',       'CONTACT_INFORMATION',   'UNKNOWN',      'CANDIDATE_FORM',             '',               true,    'Date',                            '',    false),
                      (25,     false,      false,       false,          null,           false,      'CANDIDATE_PROJECT','CONTACT_INFORMATION',   'LookUp',      'CANDIDATE_FORM',             '',               false,    'Text',                            '',    false),
                      (30,     false,      false,       false,          null,           false,      'VACANCIES',       'CONTACT_INFORMATION',   'UNKNOWN',      'CANDIDATE_FORM',             '',              false,    'text',                            '',    true),
                      (35,     false,      false,       false,          null,           false,      'CREATED_DATE',    'CONTACT_INFORMATION',   'DatePicker',   'CANDIDATE_FORM',             '',              false,    'Date',                            '',    false),
                      (40,     false,      false,       false,          null,           false,      'LEAD_SOURCE',     'CONTACT_INFORMATION',   'DropDown',     'CANDIDATE_FORM',             '',               true,    'text',      'REFERENCE@_LEAD_SOURCE',    false),
                      (45,     false,      false,       false,          null,           false,      'WORK_EXPERIENCE', 'CONTACT_INFORMATION',   'UNKNOWN',      'CANDIDATE_FORM',             '',              false,    'text',                            '',    false),
                      (50,     false,      false,       false,          null,           false,      'CURRENT_EMPLOYER','CONTACT_INFORMATION',   'TextBox',      'CANDIDATE_FORM',             '',               true,    'Text',                            '',    false),
                      (55,     false,      false,       false,          null,           false,      'EXPECTED_SALARY', 'CONTACT_INFORMATION',   'TextBox',      'CANDIDATE_FORM',             '',               true,  'Number',                            '',    false),
                      (60,     false,      false,       false,          null,           false,      'STATUS',          'CONTACT_INFORMATION',   'DropDown',     'CANDIDATE_FORM',             '',               true,    'text', 'REFERENCE@_CANDIDATE_STATUS',    false),
                      (65,     false,      false,       false,          null,           false,      'LOCATION',        'CONTACT_INFORMATION',   'DropDown',     'CANDIDATE_FORM',             '',               true,    'text',                 'TC@LOCATION',    false),
                      (70,     false,      false,       false,          null,           false,      'SKILLS',          'CONTACT_INFORMATION',   'TextArea',     'CANDIDATE_FORM',             '',               true,    'Text',                            '',    false),
                      (75,     false,      false,       false,          null,           false,      'PHONE',            'INFORMATION',          'MULTITABLE',   'CANDIDATE_FORM',             '',              false,    'text',                            '',    false),
                      (80,     false,      false,       false,          null,           false,      'EMAIL',            'INFORMATION',          'MULTITABLE',   'CANDIDATE_FORM',             '',               true,    'Text',                            '',    false),
                      (85,     false,      false,       false,          null,           false,      'IM_ADDRESS',       'INFORMATION',          'MULTITABLE',   'CANDIDATE_FORM',             '',              false,    'text',                            '',    false),
                      (90,     false,      false,       false,          null,           false,      'WEB_ADDRESS',      'INFORMATION',          'MULTITABLE',   'CANDIDATE_FORM',             '',              false,    'text',                            '',    false),
                      (91,     false,      false,       false,          null,           false,      'ALLOWANCES',       'ALLOWANCE_INFORMATION','MULTITABLE',   'CANDIDATE_FORM',             '',              false,    'text',                            '',    false),
                      (95,     false,      false,       false,          null,           false,      'CRM_NOTE',         'CRM_NOTE',             'NoteWidget',   'CANDIDATE_FORM',  'addForm,editForm,viewForm',false,    'text',                            '',    false),
                      (100,     false,      false,       false,          null,           false,      'ADDRESS',          'ADDRESS_INFORMATION',  'UNKNOWN',      'CANDIDATE_FORM',  'addForm,editForm,viewForm',false,    'text',                            '',    false),
                      (105,     false,      false,       false,          null,           false,      'LINKS',            'LINKS',                'UNKNOWN',      'CANDIDATE_FORM',  'addForm,editForm,viewForm',false,    'text',                            '',    false),
                      (110,     false,      false,       false,          null,           false,      'ATTACHMENTS',      'ATTACHMENTS',          'UNKNOWN',      'CANDIDATE_FORM',  'addForm,editForm,viewForm',false,    'text',                            '',    false);

UPDATE modelfield set halfSetStyle = 'halfSet-1' WHERE form_id = 'CANDIDATE_FORM' AND field_id = 'ATTACHMENTS';
UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_id='CANDIDATE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_id='CANDIDATE_FORM';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='CANDIDATE_FORM';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_id='CANDIDATE_FORM';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id='CANDIDATE_FORM';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_id='CANDIDATE_FORM';
UPDATE modelfield set fieldStyle = 'field' where form_id='CANDIDATE_FORM';

delete from "anv".reference  where code = '_WORKFLOW_MODULE_CANDIDATE';
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CANDIDATE', 'Candidate', (select max(sorder) from "anv".reference where parentid = (select id from "anv".reference where code = '_WORKFLOW_MODULE')),
(select id from "anv".reference where code = '_WORKFLOW_MODULE'));


