-----((((((( Al fursan )))))))))) ---------

update "200138".modelfield set sorder = 999 where form_id = 'HRMS_EMPLOYEE_FORM' and field_id in ('PUNISHMENT_PROMOTION', 'INTERNAL_EMPLOYMENT', 'PAST_EMPLOYMENT',
                                                                                                       'YEAR_LEAVE_DURATION', 'YEAR_LEAVE_HOUR_DURATION', 'LR_TYPE_SICK_LEAVE',
                                                                                                       'LR_TYPE_STUDY_LEAVE', 'LR_TYPE_ANNUAL_LEAVE', 'LR_TYPE_LATE',
                                                                                                       'LR_TYPE_SPECIAL', 'LR_TYPE_UNAUTHORIZED_LEAVE', 'LR_TYPE_OTHER_LEAVE',
                                                                                                       'APPLY_ALLOUNCE_ALL_EMPLOYEE');