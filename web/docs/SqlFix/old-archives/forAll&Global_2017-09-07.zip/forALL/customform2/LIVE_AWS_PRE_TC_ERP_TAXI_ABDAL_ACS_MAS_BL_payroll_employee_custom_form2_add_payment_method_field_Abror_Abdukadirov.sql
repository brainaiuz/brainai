insert into modelfield(form_ID,                 field_ID,        sorder, mandatory,hide,   isCustomField, section,                    defaultValue, widget,   systemmandatory,nolabelfor, nowrapperfor, fullWidth,  split) values
                      ('PAYROLL_STARTER_FORM', 'PAYMENT_METHOD', 30,     false,    false,  false,         'EMPLOYEE_DETAILS','',           'UNKNOWN',false,          '',         '',           false,      false);


UPDATE modelfield set sectionStyle  = 'slideDown-box  group expand hideCustomField' WHERE form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' WHERE form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' WHERE form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' AND form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';
UPDATE modelfield set rowStyle = 'row hideCustomField' WHERE form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';
UPDATE modelfield set fieldStyle = 'field' WHERE form_id = 'PAYROLL_STARTER_FORM' and field_id = 'PAYMENT_METHOD';