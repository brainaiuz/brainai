delete from "model"  where formid = 'IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
delete from "modelfield"  where form_id = 'IMPORT_MANUAL_TRANSACTION_FORM_TALLY';

delete from "anv"."model"  where formid = 'IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
delete from "anv"."modelfield"  where form_id = 'IMPORT_MANUAL_TRANSACTION_FORM_TALLY';


insert into model(formID, active, title) values('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', true, 'Import Manual Transaction Tally');
insert into modelfield(form_ID,                                field_ID,         sorder, mandatory,   section,                 widget ) values
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'HAS_CSV_HEADER', 1,      false,      'REQUIRED_INFORMATIONS', 'CheckBox'),
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'DATE',           2,      true,       'REQUIRED_INFORMATIONS', 'DropDown'),
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'PARTICULARS',    3,      true,       'REQUIRED_INFORMATIONS', 'DropDown'),
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'EXCHANGE_RATE',  4,      false,      'REQUIRED_INFORMATIONS', 'DropDown'),
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'VOUCHER_NUMBER', 5,      true,       'REQUIRED_INFORMATIONS', 'DropDown'),
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'DEBIT',          6,      true,       'REQUIRED_INFORMATIONS', 'DropDown'),
                      ('IMPORT_MANUAL_TRANSACTION_FORM_TALLY', 'CREDIT',         7,      true,       'REQUIRED_INFORMATIONS', 'DropDown');



UPDATE modelfield set sectionStyle = 'slideDown-box  group expand hideCustomField' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group labelLine' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
UPDATE modelfield set fieldSetStyle = 'slideDown-content group nobrd' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
UPDATE modelfield set halfSetStyle = 'halfSet-1 left' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
UPDATE modelfield set halfSetStyle = '' WHERE noLabelFor is not null AND noLabelFor != '' and form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
UPDATE modelfield set rowStyle = 'row hideCustomField' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
UPDATE modelfield set fieldStyle = 'field' where form_ID ='IMPORT_MANUAL_TRANSACTION_FORM_TALLY';
