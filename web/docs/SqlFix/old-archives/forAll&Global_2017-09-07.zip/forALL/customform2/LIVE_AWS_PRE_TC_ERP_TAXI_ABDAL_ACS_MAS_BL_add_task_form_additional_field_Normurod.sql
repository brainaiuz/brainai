insert into modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           '',     'PROJECT_CLIENTS',   'DETAILS',    'UNKNOWN',   'TASK_MAX_FORM',   '');

insert into "anv".modelfield(sorder, mandatory,  hide, isCustomField, defaultValue, systemmandatory, noLabelFor, field_ID,        section,        widget      ,form_ID,     noWrapperFor) values
                      ((select max(sorder) from modelfield),     false,     true,  false,        '',           false,           '',     'PROJECT_CLIENTS',   'DETAILS',    'UNKNOWN',   'TASK_MAX_FORM',   '');

