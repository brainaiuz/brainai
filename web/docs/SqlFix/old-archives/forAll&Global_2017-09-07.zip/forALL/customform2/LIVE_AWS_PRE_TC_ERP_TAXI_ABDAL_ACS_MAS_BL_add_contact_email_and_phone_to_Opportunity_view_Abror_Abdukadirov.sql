insert into modelfield(field_id,          form_id,            section,                  sorder, widget,  type,  fieldsetstyle,                      fieldstyle, halfsetstyle,    rowstyle,            sectionstyle,                                disableupdate) VALUES
('CRM_OPPORTUNITY_CONTACT_PRIMARY_EMAIL', 'OPPORTUNITY_FORM', 'OPPORTUNITY_INFORMATION',9,     'UNKNOWN','text','slideDown-content group labelLine','field',   'halfSet-1 left','row hideCustomField','slideDown-box  group expand hideCustomField', true ),
('CRM_OPPORTUNITY_CONTACT_PRIMARY_PHONE', 'OPPORTUNITY_FORM', 'OPPORTUNITY_INFORMATION',9,     'UNKNOWN','text','slideDown-content group labelLine','field',   'halfSet-1 left','row hideCustomField','slideDown-box  group expand hideCustomField', true );

insert into "anv".modelfield(field_id,                 form_id,            section,             sorder, widget,  type,  fieldsetstyle,                 fieldstyle, halfsetstyle,    rowstyle,        sectionstyle,                           disableupdate)
	select 'CRM_OPPORTUNITY_CONTACT_PRIMARY_EMAIL', 'OPPORTUNITY_FORM', 'OPPORTUNITY_INFORMATION',9,     'UNKNOWN','text','slideDown-content group labelLine','field',   'halfSet-1 left','row hideCustomField','slideDown-box  group expand hideCustomField', true
where  0 < (select count(id) from "anv".modelfield where form_id='OPPORTUNITY_FORM');

insert into "anv".modelfield(field_id,                 form_id,            section,             sorder, widget,  type,  fieldsetstyle,                 fieldstyle, halfsetstyle,    rowstyle,        sectionstyle,                           disableupdate)
	select 'CRM_OPPORTUNITY_CONTACT_PRIMARY_PHONE', 'OPPORTUNITY_FORM', 'OPPORTUNITY_INFORMATION',9,     'UNKNOWN','text','slideDown-content group labelLine','field',   'halfSet-1 left','row hideCustomField','slideDown-box  group expand hideCustomField', true
where  0 < (select count(id) from "anv".modelfield where form_id='OPPORTUNITY_FORM');
