update "anv".modelfield set systemmandatory = false, mandatory = false where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'LAST_NAME';
update "anv".modelfield set systemmandatory = false, mandatory = false where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'EMAIL';
update modelfield set systemmandatory = false, mandatory = false where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'LAST_NAME';
update modelfield set systemmandatory = false, mandatory = false where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'EMAIL';

update "anv".modelfield set systemmandatory = false, mandatory = false where form_id = 'PM_EMPLOYEE_FORM' and field_id = 'LAST_NAME';
update "anv".modelfield set systemmandatory = false, mandatory = false where form_id = 'PM_EMPLOYEE_FORM' and field_id = 'EMAIL';
update modelfield set systemmandatory = false, mandatory = false where form_id = 'PM_EMPLOYEE_FORM' and field_id = 'LAST_NAME';
update modelfield set systemmandatory = false, mandatory = false where form_id = 'PM_EMPLOYEE_FORM' and field_id = 'EMAIL';