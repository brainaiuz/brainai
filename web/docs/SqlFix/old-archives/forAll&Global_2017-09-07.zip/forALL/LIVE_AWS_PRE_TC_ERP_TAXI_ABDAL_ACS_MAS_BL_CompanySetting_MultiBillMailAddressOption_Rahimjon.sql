---Company Billing address patch
insert into "anv".address (name,address,addressb,city,countryName,zipCode, entityID,entityType,relationType,isprimary,countryid,stateid)
select 'Billing Address', address1,billAddress2,city,cn.name,postCode,c.id,'company',0,true,cn.id,r.id
  from company c
    left join countryZone z on c.countryZoneId = z.id
    left join country cn on z.countryId = cn.id
    left join region r on c.countryRegionId = r.id
 where c.id = anv and 1 > (select count(*) from "anv".address where deleted is not true and entityType = 'company' and relationType = 0 and entityID = c.id  );

 ---Company Mailing address patch
insert into "anv".address (name,address,addressb,city,countryName,zipCode, entityID,entityType,relationType,isprimary,countryid,stateid)
select 'Mailing Address', address2,mailAddress2,mailingCity,cn.name,mailingPostCode,c.id,'company',1,true,cn.id,r.id
  from company c
    left join countryZone z on c.mailingCountryZoneId = z.id
    left join country cn on z.countryId = cn.id
    left join region r on c.mailingCountryRegionId = r.id
 where c.id = anv and 1 > (select count(*) from "anv".address where deleted is not true and entityType = 'company' and relationType = 1 and entityID = c.id  );