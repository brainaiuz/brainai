
ALTER TABLE "0".googlecontacts ALTER COLUMN token TYPE text ;


ALTER TABLE "anv".googlecontacts ALTER COLUMN token TYPE text ;
