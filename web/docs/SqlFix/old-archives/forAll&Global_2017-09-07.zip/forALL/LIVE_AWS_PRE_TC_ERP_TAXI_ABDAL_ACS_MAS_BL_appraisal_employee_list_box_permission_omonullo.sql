--parent: HRMS_SIMPLE_APPRAISALS
--permission: HRMS_APPRAISAL_EMPLOYEE_LIST_BOX

delete from permission where code = 'HRMS_APPRAISAL_EMPLOYEE_LIST_BOX';


insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
values ('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX', 'HRMS', false, 'Employee list box', 10, (select id from permission where code = 'HRMS_SIMPLE_APPRAISALS'), false, 'PERFORMANCE_APPRAISAL');

delete from "anv".rolepermission where permissioncode = 'HRMS_APPRAISAL_EMPLOYEE_LIST_BOX';

insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX','HR','ALLOW');

delete from "0".rolepermission where permissioncode = 'HRMS_APPRAISAL_EMPLOYEE_LIST_BOX';

insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_APPRAISAL_EMPLOYEE_LIST_BOX','HR','ALLOW');