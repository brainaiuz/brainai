update permission set parent = (select id from permission where code = 'HRMS_POSITION') where code ='HRMS_ADD_NEW_POSITION';
update permission set parent = (select id from permission where code = 'HRMS_POSITION') where code ='HRMS_POSITION_EDIT';
update permission set parent = (select id from permission where code = 'HRMS_POSITION') where code ='HRMS_POSITION_SUMMARRY';
update permission set parent = (select id from permission where code = 'HRMS_POSITION') where code ='HRMS_POSITION_REMOVE';