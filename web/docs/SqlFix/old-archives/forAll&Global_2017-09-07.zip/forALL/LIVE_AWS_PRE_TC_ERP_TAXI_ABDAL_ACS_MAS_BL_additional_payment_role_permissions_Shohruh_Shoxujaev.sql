insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_PAYMENT_LIST', 'PAYROLL', 'Additional Payment List', 1, 'PAYROLL', (select id from permission where code='PAYROLL_MAIN_MENU'));
insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_PAYMENT_ADD', 'PAYROLL', 'Additional Payment Add', 2, 'PAYROLL', (select id from permission where code='PAYROLL_ADDITIONAL_PAYMENT_LIST'));
insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_PAYMENT_VIEW', 'PAYROLL', 'Additional Payment View', 3, 'PAYROLL', (select id from permission where code='PAYROLL_ADDITIONAL_PAYMENT_LIST'));
insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_PAYMENT_EDIT', 'PAYROLL', 'Additional Payment Edit', 4, 'PAYROLL', (select id from permission where code='PAYROLL_ADDITIONAL_PAYMENT_LIST'));
insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_PAYMENT_DELETE', 'PAYROLL', 'Additional Payment Delete', 5, 'PAYROLL', (select id from permission where code='PAYROLL_ADDITIONAL_PAYMENT_LIST'));
insert into permission (code,context,name,sorder,modulecode,parent) values ('PAYROLL_ADDITIONAL_PAYMENT_PDF', 'PAYROLL', 'Additional Payment Pdf', 6, 'PAYROLL', (select id from permission where code='PAYROLL_ADDITIONAL_PAYMENT_LIST'));

insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_LIST', 'ALLOW','DR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_ADD', 'ALLOW','DR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_VIEW', 'ALLOW','DR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_EDIT', 'ALLOW','DR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_DELETE', 'ALLOW','DR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_PDF', 'ALLOW','DR');

insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_LIST', 'ALLOW','HR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_ADD', 'ALLOW','HR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_VIEW', 'ALLOW','HR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_EDIT', 'ALLOW','HR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_DELETE', 'ALLOW','HR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_PDF', 'ALLOW','HR');

insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_LIST', 'ALLOW','ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_ADD', 'ALLOW','ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_VIEW', 'ALLOW','ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_EDIT', 'ALLOW','ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_DELETE', 'ALLOW','ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('PAYROLL_ADDITIONAL_PAYMENT_PDF', 'ALLOW','ADMIN');