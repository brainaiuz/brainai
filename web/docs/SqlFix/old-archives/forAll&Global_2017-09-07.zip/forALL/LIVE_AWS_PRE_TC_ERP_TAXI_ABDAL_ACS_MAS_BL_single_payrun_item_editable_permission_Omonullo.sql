delete from permission where code = 'PAYROLL_PAYSLIP_EDITABLE';


insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
values ('PAYROLL_PAYSLIP_EDITABLE', 'PAYROLL', false, 'Payslip items editable', 10, (select id from permission where code = 'PAYROLL_PAYSLIP_LIST'), false, 'PAYROLL');

delete from "anv".rolepermission where permissioncode = 'PAYROLL_PAYSLIP_EDITABLE';

insert into "anv".rolepermission (permissioncode, rolecode,access) values('PAYROLL_PAYSLIP_EDITABLE','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('PAYROLL_PAYSLIP_EDITABLE','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('PAYROLL_PAYSLIP_EDITABLE','ACCOUNTANT','ALLOW');

delete from "0".rolepermission where permissioncode = 'PAYROLL_PAYSLIP_EDITABLE';

insert into "0".rolepermission (permissioncode, rolecode,access) values('PAYROLL_PAYSLIP_EDITABLE','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('PAYROLL_PAYSLIP_EDITABLE','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('PAYROLL_PAYSLIP_EDITABLE','ACCOUNTANT','ALLOW');