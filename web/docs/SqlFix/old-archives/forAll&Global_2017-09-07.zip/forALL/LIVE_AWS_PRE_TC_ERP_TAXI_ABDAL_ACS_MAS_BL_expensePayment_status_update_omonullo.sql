UPDATE "anv".expensepayments
SET status_id = (SELECT id
                 FROM "anv".reference
                 WHERE code = 'PARTIALLY_PAID' AND parentid = (SELECT id
                                                               FROM "anv".reference
                                                               where code = 'EXPENSE_STATUS'))
where status is not null and status like '%Y_PAID%';

UPDATE "anv".expensepayments
SET status_id = (SELECT id
                 FROM "anv".reference
                 WHERE code = 'EXPENSE_PAID' AND parentid = (SELECT id
                                                             FROM "anv".reference
                                                             where code = 'EXPENSE_STATUS'))
where status is not null and status like '%E_PAID%';

ALTER TABLE "anv".expensepayments DROP status;