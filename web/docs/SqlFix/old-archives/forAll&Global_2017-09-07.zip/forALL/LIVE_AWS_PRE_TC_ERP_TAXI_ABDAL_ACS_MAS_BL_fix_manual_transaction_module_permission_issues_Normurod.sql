--THIS PATCH HAS BEEN EXECUDED FOR AWS & LIVE VERSION ALREADY

CREATE OR REPLACE FUNCTION fix_manualjournal_permissions()
  RETURNS VOID AS $$
DECLARE
  company RECORD;
  mtp integer := 0;

BEGIN
  FOR company IN (SELECT c.id, c.name FROM company c INNER JOIN (SELECT nspname AS id FROM pg_namespace WHERE nspname ~ '^[0-9]+$' ORDER BY nspname) sch on sch.id = trim(to_char(c.id, '999999')) WHERE  c.active is true AND c.isdeleted is not true ORDER BY id)
  LOOP
    mtp := 0;
    EXECUTE 'select 1 from "'||company.id||'".mymodule where code =''MANUAL_TRANSLATIONS''' INTO mtp;

    IF mtp > 0 THEN
      mtp := 0;
      EXECUTE 'select 1 from "'||company.id||'".mymodule where code =''MANUAL_TRANSACTIONS''' INTO mtp;

      IF mtp > 0 THEN
        EXECUTE 'delete from "'||company.id||'".mymodule where code = ''MANUAL_TRANSLATIONS''';
      ELSE
        EXECUTE 'update "'||company.id||'".mymodule set code = ''MANUAL_TRANSACTIONS'' where code = ''MANUAL_TRANSLATIONS''';
      END IF;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql VOLATILE;

update permission set modulecode ='MANUAL_TRANSACTIONS' where modulecode = 'MANUAL_TRANSLATIONS';

---SELECT fix_manualjournal_permissions();


------------FOR ZERO SCHEMA----------------
update "0".mymodule set code = 'MANUAL_TRANSACTIONS' where code = 'MANUAL_TRANSLATIONS';

------------URGENT: ****NOT SIGN UPPED COMPANIES ONLY***----------
update "anv".mymodule set code = 'MANUAL_TRANSACTIONS' where code = 'MANUAL_TRANSLATIONS';