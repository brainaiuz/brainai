DROP FUNCTION IF EXISTS "anv".moveEmployeePaymentMethod();
CREATE OR REPLACE FUNCTION "anv".moveEmployeePaymentMethod()
  RETURNS INTEGER AS
  $BODY$
    DECLARE
      emp record;
      payMethodName text;
      BEGIN
          IF EXISTS (SELECT c.id FROM company c
                               LEFT JOIN countryZone cz ON c.countryZoneId = cz.id
                               LEFT JOIN country co ON cz.countryId = co.id
                               WHERE c.id = anv AND (co.code = 'AE' OR co.code = 'SA'
                                                    OR co.code = 'OM' OR co.code = 'QA')
          ) THEN
              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                    WHERE name = 'Bank Transfer'
                                    AND (deleted = false OR deleted IS NULL)
                                    ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'Bank Transfer');
              END IF;

              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                        WHERE name = 'Cheque'
                                        AND (deleted = false or deleted IS NULL)
                                        ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'Cheque');
              END IF;

              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                        WHERE name = 'Cash'
                                        AND (deleted = false OR deleted IS NULL)
                                        ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'Cash');
              END IF;
          ELSE
              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                    WHERE name = 'BACS'
                                    AND (deleted = false OR deleted IS NULL)
                                    ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'BACS');
              END IF;

              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                        WHERE name = 'Transfer'
                                        AND (deleted = false OR deleted IS NULL)
                                        ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'Transfer');
              END IF;

              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                        WHERE name = 'Cheque'
                                        AND (deleted = false or deleted IS NULL)
                                        ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'Cheque');
              END IF;

              IF NOT EXISTS (SELECT id FROM "anv".paymentmethod
                                        WHERE name = 'Cash'
                                        AND (deleted = false OR deleted IS NULL)
                                        ORDER BY id DESC limit 1
              ) THEN
                  INSERT INTO "anv".paymentmethod(deleted, name) VALUES(false, 'Cash');
              END IF;
          END IF;

          FOR emp IN (SELECT * FROM "anv".employee e
                               LEFT JOIN "anv".myuser m ON e.id = m.id
                               WHERE m.deleted = false)
          LOOP
              IF EXISTS (SELECT id FROM "anv".employeePayrollSettings
                                  WHERE employeeid = emp.id
                                  AND key = 'PAY_METHOD'
                                  ORDER BY id DESC limit 1
              ) THEN
                  payMethodName = (SELECT value FROM "anv".employeePayrollSettings
                                              WHERE employeeid = emp.id
                                              AND key = 'PAY_METHOD'
                                              ORDER BY id DESC limit 1);

                  IF EXISTS (SELECT id FROM "anv".paymentmethod
                                      WHERE name = payMethodName
                                      AND (deleted = false OR deleted IS NULL)
                                      ORDER BY id DESC limit 1
                  ) THEN
                      UPDATE "anv".employee SET payMethodId = (SELECT id FROM "anv".paymentmethod
                                                                            WHERE name = payMethodName
                                                                            AND (deleted = false OR deleted IS NULL)
                                                                            ORDER BY id DESC limit 1
                                                                  ) WHERE id = emp.id;
                  END IF;
              END IF;
          END LOOP;
      RETURN NULL;
    END;
  $BODY$
LANGUAGE plpgsql;
ALTER FUNCTION "anv".moveEmployeePaymentMethod() OWNER TO wfmtest;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".moveEmployeePaymentMethod()) IS NOT NULL;