ALTER TABLE "anv".monthly_timesheet ALTER COLUMN worked_hours TYPE double precision;
ALTER TABLE "anv".monthly_timesheet ALTER COLUMN total_days_worked TYPE double precision;
ALTER TABLE "anv".monthly_timesheet ALTER COLUMN overtime TYPE double precision;
ALTER TABLE "anv".monthly_timesheet ALTER COLUMN holiday_overtime TYPE double precision;
ALTER TABLE "anv".monthly_timesheet ALTER COLUMN weekend_overtime TYPE double precision;