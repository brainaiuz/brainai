delete from "anv".reference where code = 'TASK_REMINDER';

insert into "anv".reference (sorder,                             code,  name,                  isremovable, issystemreference, shared, iscustombutton, parentid)
 values                       (1,   'TASK_REMINDER',               'Task Overdue Reminder', false,       true,              false,  false,         (select id from "anv".reference where code = 'ET_TASK_MODULE'));