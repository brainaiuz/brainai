
delete
from "anv".rolepermission
where permissioncode = 'OVERDUE_INVOICE_REMINDER';

delete
from permission  where code = 'OVERDUE_INVOICE_REMINDER';

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('OVERDUE_INVOICE_REMINDER', 'SETTINGS',      false, 'Overdue Invoice Reminder',       10, (select id from permission where code = 'SETTINGS_RECURRENCE_SETTINGS'),  false, 'REMINDERS');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('OVERDUE_INVOICE_REMINDER', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('OVERDUE_INVOICE_REMINDER', 'ALLOW', 'ADMIN');
--TIMESHEET_REMINDER--
delete
from "anv".rolepermission
where permissioncode = 'TIMESHEET_REMINDER';

delete
from permission  where code = 'TIMESHEET_REMINDER';

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('TIMESHEET_REMINDER', 'SETTINGS',      false, 'Timesheet Reminder',       10, (select id from permission where code = 'SETTINGS_RECURRENCE_SETTINGS'),  false, 'REMINDERS');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('TIMESHEET_REMINDER', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('TIMESHEET_REMINDER', 'ALLOW', 'ADMIN');
                          
--DEFAULT_TIMESHEET_REMINDER--
delete
from "anv".rolepermission
where permissioncode = 'DEFAULT_TIMESHEET_REMINDER';

delete
from permission  where code = 'DEFAULT_TIMESHEET_REMINDER';

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('DEFAULT_TIMESHEET_REMINDER', 'SETTINGS',      false, 'Default Timesheet Reminder',       10, (select id from permission where code = 'TIMESHEET_REMINDER'),  false, 'REMINDERS');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('DEFAULT_TIMESHEET_REMINDER', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('DEFAULT_TIMESHEET_REMINDER', 'ALLOW', 'ADMIN');

--SYNC_WITH_GOOGLE_CALENDAR--
delete
from "anv".rolepermission
where permissioncode = 'SYNC_WITH_GOOGLE_CALENDAR';

delete
from permission  where code = 'SYNC_WITH_GOOGLE_CALENDAR';

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('SYNC_WITH_GOOGLE_CALENDAR', 'SETTINGS',      false, 'Synchronize With Google Calendar',       10, (select id from permission where code = 'SETTINGS_RECURRENCE_SETTINGS'),  false, 'REMINDERS');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('SYNC_WITH_GOOGLE_CALENDAR', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('SYNC_WITH_GOOGLE_CALENDAR', 'ALLOW', 'ADMIN');
                          
--HR_REMINDERS--
delete
from "anv".rolepermission
where permissioncode = 'HR_REMINDERS';

delete
from permission  where code = 'HR_REMINDERS';

insert into permission (code,                                   context, ismainmenu,                     name,   sorder,                                                                       parent, iscore,          modulecode)
                values ('HR_REMINDERS', 'SETTINGS',      false, 'Human Resources (HR) Reminders',       10, (select id from permission where code = 'SETTINGS_RECURRENCE_SETTINGS'),  false, 'REMINDERS');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('HR_REMINDERS', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('HR_REMINDERS', 'ALLOW', 'ADMIN');