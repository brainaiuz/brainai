

update usageplan set essUsers=10;

delete from "0".role WHERE code='ESS_USER';
INSERT INTO "0".role (name, description, code, isSystem, isDeleted) VALUES ('Ess User', 'Ess User Role', 'ESS_USER', TRUE, TRUE);

delete from "anv".role WHERE code='ESS_USER';
INSERT INTO "anv".role (name, description, code, isSystem, isDeleted) VALUES ('Ess User', 'Ess User Role', 'ESS_USER', TRUE, TRUE);

delete from "anv".rolepermission WHERE rolecode='ESS_USER';
delete from "0".rolepermission WHERE rolecode='ESS_USER';
insert into "0".rolepermission (permissioncode, rolecode, access) SELECT rp.permissioncode, 'ESS_USER', rp.access FROM (SELECT * FROM "0".rolepermission where rolecode='MEM') AS rp;
--ATTENTION 0-schemadan olinib "anv" ga urilyapti
insert into "anv".rolepermission (permissioncode, rolecode, access) SELECT rp.permissioncode, 'ESS_USER', rp.access FROM (SELECT * FROM "0".rolepermission where rolecode='MEM') AS rp;