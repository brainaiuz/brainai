insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','ACCOUNTING','Purchase Order Receive',13,false,(select id from permission where code = 'ACCOUNTING_PURCHASE_ORDER_LIST'),false,'PURCHASE_ORDERS');


insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','ACCOUNTANT','ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('ACCOUNTING_PURCHASE_ORDER_RECEIVE','ACCOUNTANT','ALLOW');
