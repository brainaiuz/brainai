DROP function if EXISTS "anv".fixApproverNotFound();
CREATE OR replace function "anv".fixApproverNotFound()
  returns INTEGER AS
  $body$
DECLARE
    app record;

    BEGIN
        update "anv".approvers a set exactapprover = (select (CASE WHEN (approver1id IS NULL) THEN managerid ELSE approver1id END) from "anv".sickrequest where id = a.entity_id) where exactapprover is null and entity_id is not null and entitytype='LEAVE_REQUEST';
        FOR app IN (SELECT a.id as appr_id, sr.employeeid as employee_id FROM "anv".approvers a inner join "anv".sickrequest sr on sr.id = a.entity_id where a.entitytype='LEAVE_REQUEST' and a.entity_id is not null and a.exactapprover is null)
        LOOP
            -- do it
            update "anv".approvers set exactapprover = (select t.leaderid from "anv".employee e inner join "anv".teamemployee te on te.id = e.employeeDepartmentId inner join "anv".team t on t.id = te.teamid where te.employeeid = app.employee_id limit 1) where id = app.appr_id;
        END LOOP;

        IF EXISTS (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') AND (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') = 'YES' THEN
          --update on approved action
            update "anv".approvers set onapprovedaction = 5, onrejectedaction=6 where entitytype = 'LEAVE_REQUEST' and approver_order = 2;
        ELSE
            update "anv".approvers set onapprovedaction = 5, onrejectedaction=6 where entitytype = 'LEAVE_REQUEST';
        END IF;

    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".fixApproverNotFound() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".fixApproverNotFound()) IS NOT NULL;
