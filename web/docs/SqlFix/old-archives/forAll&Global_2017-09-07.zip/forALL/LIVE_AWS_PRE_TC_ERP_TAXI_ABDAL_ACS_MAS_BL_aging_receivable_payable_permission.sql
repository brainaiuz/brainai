
delete
from "anv".rolepermission
where permissioncode = 'ACCOUNTING_AGING_SUMMARY';

delete
from permission  where code = 'ACCOUNTING_AGING_SUMMARY';



insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('ACCOUNTING_AGING_SUMMARY_PAYABLE',   'ACCOUNTING', false, 'Aging Summary Payable', 10, (select id from permission where code = 'ACCOUNTING_REPORTS_MENU'), false, 'ACCOUNTING_MODULE');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('ACCOUNTING_AGING_SUMMARY_RECEIVABLE',   'ACCOUNTING', false, 'Aging Summary Receivable', 11, (select id from permission where code = 'ACCOUNTING_REPORTS_MENU'), false, 'ACCOUNTING_MODULE');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('ACCOUNTING_AGING_SUMMARY_PAYABLE', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('ACCOUNTING_AGING_SUMMARY_PAYABLE', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('ACCOUNTING_AGING_SUMMARY_PAYABLE', 'ALLOW', 'ACCOUNTANT');

insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('ACCOUNTING_AGING_SUMMARY_RECEIVABLE', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('ACCOUNTING_AGING_SUMMARY_RECEIVABLE', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('ACCOUNTING_AGING_SUMMARY_RECEIVABLE', 'ALLOW', 'ACCOUNTANT');