

update modelfield set systemmandatory=false where form_id='HRMS_EMPLOYEE_FORM' and field_id='EMAIL';
update modelfield set systemmandatory=false where form_id='PM_EMPLOYEE_FORM' and field_id='EMAIL';

update "anv".modelfield set systemmandatory=false where form_id='HRMS_EMPLOYEE_FORM' and field_id='EMAIL';
update "anv".modelfield set systemmandatory=false where form_id='PM_EMPLOYEE_FORM' and field_id='EMAIL';