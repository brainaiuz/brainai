delete FROM permission WHERE code='HRMS_ONBOARDING_EDIT';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_EDIT', 'HRMS', 'Onboarding Period Edit', 1, false,
                (select id from permission  where code='HRMS_ONBOARDING_LIST'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_EDIT';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_EDIT', 'SALESMAN', 'ALLOW');

delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_EDIT';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_EDIT', 'SALESMAN', 'ALLOW');




delete FROM permission WHERE code='HRMS_ONBOARDING_DELETE';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_DELETE', 'HRMS', 'Onboarding Period Delete', 1, false,
                (select id from permission  where code='HRMS_ONBOARDING_LIST'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_DELETE';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_DELETE', 'SALESMAN', 'ALLOW');

delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_DELETE';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_DELETE', 'SALESMAN', 'ALLOW');




delete FROM permission WHERE code='HRMS_ONBOARDING_STEP_EDIT';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_STEP_EDIT', 'HRMS', 'Onboarding Step Edit', 10, false,
                (select id from permission  where code='HRMS_ONBOARDING_STEP_LIST'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_EDIT';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_EDIT', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_EDIT';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_EDIT', 'SALESMAN', 'ALLOW');



delete FROM permission WHERE code='HRMS_ONBOARDING_STEP_DELETE';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_STEP_DELETE', 'HRMS', 'Onboarding Step Delete', 10, false,
                (select id from permission  where code='HRMS_ONBOARDING_STEP_LIST'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_DELETE';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_DELETE', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_DELETE';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_DELETE', 'SALESMAN', 'ALLOW');