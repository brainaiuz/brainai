UPDATE permission SET sorder = sorder + 1 WHERE parent = (SELECT id FROM permission WHERE code = 'PAYROLL_MAIN_MENU');

DELETE FROM permission WHERE code = 'PAYROLL_MAIN_CONTENT';

INSERT INTO permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) VALUES ('PAYROLL_MAIN_CONTENT', 'PAYROLL', FALSE, 'Payroll Main Content', 1, (SELECT id FROM permission WHERE code = 'PAYROLL_MAIN_MENU'), FALSE, 'PAYROLL');

DELETE FROM "anv".rolepermission WHERE permissioncode = 'PAYROLL_MAIN_CONTENT';
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_MAIN_CONTENT', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_MAIN_CONTENT', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_MAIN_CONTENT', 'HR', 'ALLOW');

DELETE FROM "0".rolepermission WHERE permissioncode = 'PAYROLL_MAIN_CONTENT';
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_MAIN_CONTENT', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_MAIN_CONTENT', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_MAIN_CONTENT', 'HR', 'ALLOW');