
insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('HRMS_GOAL_LINKS','HRMS','Hrms Add Links',6,'f',(SELECT ID FROM PERMISSION WHERE CODE = 'HRMS_GOAL_MANAGEMENT_TAB'),'f','GOAL_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_GOAL_LINKS','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_GOAL_LINKS','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_GOAL_LINKS','HR','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_GOAL_LINKS','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_GOAL_LINKS','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_GOAL_LINKS','HR','ALLOW');