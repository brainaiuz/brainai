--Apply for companies which PROJECT_INLINE_ITEM enabled
DROP FUNCTION IF EXISTS "anv".projectinlineitempatch();
CREATE OR REPLACE FUNCTION "anv".projectinlineitempatch()
  RETURNS VOID
AS
$BODY$
DECLARE inv RECORD;
BEGIN
  FOR inv IN (SELECT * FROM "anv".invoice WHERE relatedproject_id IS NOT NULL ORDER BY id)
  LOOP
    UPDATE "anv".invoiceitem SET project_id=inv.relatedproject_id WHERE invoice_id=inv.id AND project_id IS NULL ;
  END LOOP;
END ;
$BODY$
LANGUAGE plpgsql VOLATILE;