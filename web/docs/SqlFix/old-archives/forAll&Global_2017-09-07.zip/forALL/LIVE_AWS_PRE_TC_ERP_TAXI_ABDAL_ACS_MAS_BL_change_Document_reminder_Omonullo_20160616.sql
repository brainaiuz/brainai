
update "anv".emailtemplate set messagehtml = '${receiverFullName} ,<br />
Company: ${companyname} <br />
Please be advised that you have Document expiration - <b>${remindertype}</b> on ${reminderfieldvalue}.'
where id in (select id from "anv".emailtemplate e where e.id in (select hr.templateid from "anv".employeedocumentremindersettings hr) and e.name = 'Reminder template (for Employee)');

update "anv".emailtemplate set messagehtml = '${receiverFullName} ,<br />
Company: ${companyname}
<br />
Please be advised that the following employees have Document expiration - <b>${remindertype}</b> on ${reminderfieldvalue}.<br />
<br />
${reminderemployees}'
where id in (select id from "anv".emailtemplate e where e.id in (select hr.templateid from "anv".employeedocumentremindersettings hr) and e.name = 'Reminder template (for Managers)');
