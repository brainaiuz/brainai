insert into permission (code,context,name,sorder,iscore,modulecode,parent) values ('CRM_ACCOUNT_NUMBER_EDIT', 'CRM', 'Crm Account Number Edit', 1, true, 'CRM_MODULE', (select id from permission where code='CRM_MAIN_MENU'));

insert into "anv".rolepermission (permissioncode, access, rolecode) values ('CRM_ACCOUNT_NUMBER_EDIT', 'ALLOW','DR');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('CRM_ACCOUNT_NUMBER_EDIT', 'ALLOW','PM');
insert into "anv".rolepermission (permissioncode, access, rolecode) values ('CRM_ACCOUNT_NUMBER_EDIT', 'ALLOW','ADMIN');