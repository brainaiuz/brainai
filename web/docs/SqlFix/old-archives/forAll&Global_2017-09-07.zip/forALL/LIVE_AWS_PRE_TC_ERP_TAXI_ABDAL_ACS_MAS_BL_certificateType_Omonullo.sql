--KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG KG
insert into "31287".certificateType (backimageurl, fieldcount, frontimageurl, name)
                              values('/tc/images/21-2.png', 2, '/tc/iamges/21-1.png', 'OCC first aid awareness');