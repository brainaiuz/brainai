
delete
from "anv".rolepermission
where permissioncode = 'ACCOUNTING_CURRENCY_RATE_EDIT';

delete from "0".rolepermission
where permissioncode = 'ACCOUNTING_CURRENCY_RATE_EDIT';

delete
from permission  where code = 'ACCOUNTING_CURRENCY_RATE_EDIT';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
		values ('ACCOUNTING_CURRENCY_RATE_EDIT',
			'ACCOUNTING',
			'Edit Currency Rate',
			1,
			false,
			(select id from permission where code = 'ACCOUNTING_CURRENCY_RATES_LIST'),
			false,
			'ACCOUNTING_MODULE');


insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATE_EDIT', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_CURRENCY_RATE_EDIT', 'ACCOUNTANT', 'ALLOW');