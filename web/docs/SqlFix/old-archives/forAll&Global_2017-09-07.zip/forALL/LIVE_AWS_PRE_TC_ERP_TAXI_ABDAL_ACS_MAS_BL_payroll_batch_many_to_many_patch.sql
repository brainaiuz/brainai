INSERT INTO "anv".emp_batch (batch_id, emp_id) (SELECT payroll_batch_id, id
                                                   FROM "anv".employee
                                                   WHERE payroll_batch_id IS NOT NULL);