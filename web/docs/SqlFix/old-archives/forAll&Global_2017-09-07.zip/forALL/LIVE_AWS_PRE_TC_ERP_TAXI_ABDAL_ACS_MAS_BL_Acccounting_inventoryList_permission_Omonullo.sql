
delete FROM permission WHERE code='ACCOUNTING_INVENTORY_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('ACCOUNTING_INVENTORY_LIST', 'ACCOUNTING', 'Inventory List', 10, false,
                (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_ACCOUNTING_MENU'),
                false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_INVENTORY_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_INVENTORY_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_INVENTORY_LIST', 'ACCOUNTANT', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_INVENTORY_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_INVENTORY_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_INVENTORY_LIST', 'ACCOUNTANT', 'ALLOW');