DELETE FROM permission WHERE code = 'PAYROLL_BATCH_DELETE';
DELETE FROM "0".rolepermission WHERE permissioncode = 'PAYROLL_BATCH_DELETE';
DELETE FROM "anv".rolepermission WHERE permissioncode = 'PAYROLL_BATCH_DELETE';

INSERT INTO permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) VALUES ('PAYROLL_BATCH_DELETE', 'PAYROLL', FALSE, 'Payroll Batch Delete', 12, (SELECT id FROM permission WHERE code = 'PAYROLL_BATCH_LIST'), FALSE, 'PAYROLL');

INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'ADMIN', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'DR', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'ACCOUNTANT', 'ALLOW');
INSERT INTO "0".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'HR', 'ALLOW');

INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'ADMIN', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'DR', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'ACCOUNTANT', 'ALLOW');
INSERT INTO "anv".rolepermission (permissioncode, rolecode, access) VALUES ('PAYROLL_BATCH_DELETE', 'HR', 'ALLOW');