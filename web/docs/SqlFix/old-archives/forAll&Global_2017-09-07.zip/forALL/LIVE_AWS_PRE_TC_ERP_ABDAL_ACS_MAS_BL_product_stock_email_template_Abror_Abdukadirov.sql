DO $$
    BEGIN
        IF NOT EXISTS (
            select id from "anv".emailtemplate where categoryid = (select id from "anv".reference where code = 'PRODUCT_STOCK_CATEGORY' order by id desc limit 1)
        ) THEN
            insert into "anv".emailtemplate(deleted, fromuserid, fromusername, iscompanyemailtemplate, isdefault, messagehtml, name, subject, categoryid, module_id, locale)
                  VALUES (false, -1, 'Current User', 'COMPANY_EMAIL_TEMPLATE', true, 'Dear $username,<br />
Please be advised that stock amount of following item(s) is below Reorder Point:<br />
<br />
$items<br />
<br />
Click here to view the Inventory item listing page<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser:<br />
$url',
                  'Product Stock Notification', 'Product Stock', (select id from "anv".reference where code='PRODUCT_STOCK_CATEGORY'), (select id from "anv".reference where code='ET_PRODUCT_MODULE'), 'en');
          ELSE
            update "anv".emailtemplate set isCompanyEmailTemplate = 'COMPANY_EMAIL_TEMPLATE', messagehtml = 'Dear $username,<br />
Please be advised that stock amount of following item(s) is below Reorder Point:<br />
<br />
$items<br />
<br />
Click here to view the Inventory item listing page<br />
* If you are not able to click on the link, you can instead copy and paste the following address in to your web browser:<br />
$url',
                                              categoryid = (select id from "anv".reference where code='PRODUCT_STOCK_CATEGORY'),
                                              isDefault = true, module_id = (select id from "anv".reference where code='ET_PRODUCT_MODULE')
                                                  where categoryid = (select id from "anv".reference where code='PRODUCT_STOCK_CATEGORY');
        END IF;
END$$;