

ALTER TABLE "0".googledocumentssettings  ALTER COLUMN documentlink TYPE text ;
ALTER TABLE "0".googledocumentssettings  ALTER COLUMN downloadlink TYPE text ;

ALTER TABLE "0".googledocuments  ALTER COLUMN token TYPE text ;
ALTER TABLE "0".googledocuments  ALTER COLUMN officeToken TYPE text;


ALTER TABLE "anv".googledocumentssettings  ALTER COLUMN documentlink TYPE text;
ALTER TABLE "anv".googledocumentssettings  ALTER COLUMN downloadlink TYPE text;

ALTER TABLE "anv".googledocuments  ALTER COLUMN token TYPE text ;
ALTER TABLE "anv".googledocuments  ALTER COLUMN officeToken TYPE text ;
