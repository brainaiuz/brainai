
--=====================================================================

-------------------- FAQAT FREE DB GA URILSIN

--=====================================================================


insert into "0".reference(code, name, sorder, parentid) values('BENEFIT_CASH', 'Cash', 3, (select id from "0".reference where code = '_BENEFIT_TYPE'));