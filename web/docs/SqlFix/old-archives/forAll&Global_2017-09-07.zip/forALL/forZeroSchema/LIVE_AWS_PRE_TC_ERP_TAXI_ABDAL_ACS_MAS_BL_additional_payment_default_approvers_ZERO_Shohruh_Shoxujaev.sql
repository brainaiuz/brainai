insert into "0".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
values('_WORKFLOW_MODULE_ADDITIONAL_PAYMENT', false, true, 'Additional Payment', true, 10, (select id from "0".reference where code='_WORKFLOW_MODULE'), true);

DROP function if EXISTS "0".createAdditionalPaymentDefaultApprovers();
CREATE OR replace function "0".createAdditionalPaymentDefaultApprovers()
  returns INTEGER AS
  $body$
DECLARE
    approverID INTEGER;
    approved1WorkflowID INTEGER;
    rejected1WorkflowID INTEGER;
    ca record;
    BEGIN
            --one level approval here
            --create approver item in "0".approvers table
            insert into "0".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'ADDITIONAL_PAYMENT', true, 1, 3) RETURNING id INTO approverID;
            --create approvers_role rows.!!!!!!!!!
            insert into "0".approver_roles(approver_id, role_id) (select approverID, r.id from "0".role r where code in ('ADMIN','DR','HR'));
            --create workflows for approval1
            insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_ADDITIONAL_PAYMENT', false) RETURNING id into approved1WorkflowID;
            insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_ADDITIONAL_PAYMENT', false) RETURNING id INTO rejected1WorkflowID;
            --set workflowids to the approver
            update "0".approvers set workflow=approved1WorkflowID, rejected_workflow=rejected1WorkflowID where id=approverID;
            --create workflow alert on actions
            INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Declined your Additional Payment', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${creator},</p><br /> <p>Please be advised that ${current_approver} has declined your Additional Payment on ${decline_date}. You can review ${current_approver} ''s comments, and make the appropriate changes and resubmit the payment.</p> <p>Click <a href="${link}" title="Edit  Additional Payment" target="_blank">here </a> to view and edit the  Additional Payment.</p> <p>${rejection_note}</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
            INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Approved your  Additional Payment', '', '', null,approved1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${creator},</p><br /><p>Please be advised that ${current_approver} has approved your Additional Payment, ${payment_reference} for ${date}.</p> <p>The PDF version of the Additional Payment is attached for your attention.</p> <p>Click <a href="${link}" title="Edit Additional Payment" target="_blank">here </a> to view the Additional Payment.</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "0".createAdditionalPaymentDefaultApprovers() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "0".createAdditionalPaymentDefaultApprovers()) IS NOT NULL;