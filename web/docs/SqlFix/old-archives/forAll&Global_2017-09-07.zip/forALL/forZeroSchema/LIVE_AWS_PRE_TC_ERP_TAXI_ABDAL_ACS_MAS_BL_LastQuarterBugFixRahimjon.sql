CREATE OR REPLACE FUNCTION currentquarterlastday()
  RETURNS date AS
$BODY$
  SELECT (date_trunc('QUARTER', current_date) + INTERVAL '3 MONTH - 1 DAY')::date;
$BODY$
  LANGUAGE sql IMMUTABLE STRICT
  COST 100;
ALTER FUNCTION currentquarterlastday()
  OWNER TO postgres;