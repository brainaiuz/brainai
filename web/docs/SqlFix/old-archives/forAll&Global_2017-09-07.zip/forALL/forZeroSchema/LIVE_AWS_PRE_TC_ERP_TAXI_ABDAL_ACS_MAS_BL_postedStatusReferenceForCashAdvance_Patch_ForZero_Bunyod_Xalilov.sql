--- for ZERO schema ---
insert into "0".reference (code, name, deleted, iscustombutton, isremovable, issystemreference, shared)
            values('POSTED', 'Posted', false, false, false, true, true);