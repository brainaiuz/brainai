delete from "0".approver_roles where approver_id in(select id from "0".approvers where entityType = 'CASH_ADVANCE');
delete from "0".approvers where entityType = 'CASH_ADVANCE';
delete from "0".workflowrule where module = '_WORKFLOW_MODULE_CASH_ADVANCE' and executioncriteria = '_WORKFLOW_ACTION_APPROVING';

DROP function if EXISTS "0".createDefaultApproversForCashAdvance();
CREATE OR replace function "0".createDefaultApproversForCashAdvance()
  returns INTEGER AS
  $body$
DECLARE
    approverID INTEGER;
    approvedWorkflowID INTEGER;
    rejectedWorkflowID INTEGER;
    cashAdvance_approver_id INTEGER;
    ca record;

    BEGIN
            --create approver item in "0".approvers table
            insert into "0".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'CASH_ADVANCE', true, 1, 3) RETURNING id INTO approverID;
            --create approvers_role rows.!!!!!!!!!
            insert into "0".approver_roles(approver_id, role_id) (select approverID, r.id from "0".role r where code in ('ADMIN','DR','HR'));
            --create workflows for approval1
            insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_CASH_ADVANCE', false) RETURNING id into approvedWorkflowID;
            insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_CASH_ADVANCE', false) RETURNING id INTO rejectedWorkflowID;
            --set workflowids to the approver
            update "0".approvers set workflow=approvedWorkflowID, rejected_workflow=rejectedWorkflowID where id=approverID;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "0".createDefaultApproversForCashAdvance() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "0".createDefaultApproversForCashAdvance()) IS NOT NULL;