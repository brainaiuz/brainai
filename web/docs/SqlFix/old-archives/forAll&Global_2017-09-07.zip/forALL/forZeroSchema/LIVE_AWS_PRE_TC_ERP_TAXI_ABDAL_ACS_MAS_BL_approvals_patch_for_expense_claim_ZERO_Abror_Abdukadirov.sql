DROP function if EXISTS "0".createExpenseClaimDefaultApprovers();
CREATE OR replace function "0".createExpenseClaimDefaultApprovers()
  returns INTEGER AS
  $body$
DECLARE
    approverID INTEGER;
    approved1WorkflowID INTEGER;
    rejected1WorkflowID INTEGER;
    ca record;
    BEGIN
            --one level approval here
            --create approver item in "0".approvers table
            insert into "0".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'EXPENSE_CLAIM', true, 1, 3) RETURNING id INTO approverID;
            --create approvers_role rows.!!!!!!!!!
            insert into "0".approver_roles(approver_id, role_id) (select approverID, r.id from "0".role r where code in ('ADMIN','DR','HR'));
            --create workflows for approval1
            insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id into approved1WorkflowID;
            insert into "0".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id INTO rejected1WorkflowID;
            --set workflowids to the approver
            update "0".approvers set workflow=approved1WorkflowID, rejected_workflow=rejected1WorkflowID where id=approverID;
            --create workflow alert on actions
            INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Declined your Expense Claim', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /> <p>Please be advised that ${current_approver} has declined your Expense Claims on ${decline_date}. You can review ${current_approver} ''s comments, and make the appropriate changes and resubmit the report.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view and edit the Expense Claims.</p> <p>${rejection_note}</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
            INSERT INTO "0".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Approved your Expense Claim', '', '', null,approved1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /><p>Please be advised that ${current_approver} has approved your Expense Claims, ${report_title} on ${date}.</p> <p>The PDF version of the Expense Claims is attached for your attention.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view the Expense Claims.</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "0".createExpenseClaimDefaultApprovers() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "0".createExpenseClaimDefaultApprovers()) IS NOT NULL;