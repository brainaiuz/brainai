update permission set modulecode = 'SALES_QUOTES' where code = 'CONVERT_OPPORTUNITY_TO_SQ';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_LIST';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_ADD';
update permission set modulecode = 'SALES_ORDERS' where code = 'CONVERT_SALE_QUOTE_TO_SALE_ORDER';