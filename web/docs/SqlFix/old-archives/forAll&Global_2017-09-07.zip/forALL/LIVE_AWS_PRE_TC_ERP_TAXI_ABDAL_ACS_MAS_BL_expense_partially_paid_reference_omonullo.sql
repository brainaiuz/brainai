
insert into "0".reference (code,name,sorder,parentid,isremovable,issystemreference,deleted,shared,iscustombutton)
values ('PARTIALLY_PAID', 'Partially paid',4,(select id from "0".reference where code='EXPENSE_STATUS'),false,true,false,true,false);

insert into "anv".reference (code,name,sorder,parentid,isremovable,issystemreference,deleted,shared,iscustombutton)
values ('PARTIALLY_PAID', 'Partially paid',4,(select id from "anv".reference where code='EXPENSE_STATUS'),false,true,false,true,false);