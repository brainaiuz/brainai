delete from permission where code = 'HRMS_LEAVE_REQUEST_SEND_NOTIFICATION';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
values ('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION', 'HRMS', false, 'Send Notification Panel', 30, (select id from permission where code = 'HRMS_ATTENDANCE_TRACKING_TAB'), false, 'HRMS_MODULE');

delete from "anv".rolepermission where permissioncode = 'HRMS_LEAVE_REQUEST_SEND_NOTIFICATION';

insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION','HR','ALLOW');

delete from "0".rolepermission where permissioncode = 'HRMS_LEAVE_REQUEST_SEND_NOTIFICATION';

insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_LEAVE_REQUEST_SEND_NOTIFICATION','HR','ALLOW');