--For schema 0
DELETE FROM "0".emailtemplate WHERE module_id=(SELECT id FROM "0".reference WHERE code = 'ET_MEETING_MINUTES_MODULE') and iscompanyemailtemplate='DEFAULT_EMAIL_TEMPLATE';
INSERT INTO "0".emailtemplate (fromuserid, iscompanyemailtemplate, isdefault, locale, messagehtml, name, subject, categoryid, module_id, showinmessagecenter)
VALUES (-1, 'DEFAULT_EMAIL_TEMPLATE', TRUE, 'en',
'<p>Dear ${recipientname},</p>
<p>${calledBy} has held a meeting on ${title} and wants you to review the meeting minutes. Here are the details of the meeting:</p>

Location: ${location}<br/>
Purpose: ${purpose}<br/>
Start Date: ${startdate}<br/>
End Date: ${enddate}
<br/>
<p>You can view the details of the meeting by clicking on this link: ${link}</p>',

'Meeting Minutes Default Template',
'Meeting Minutes on ${title}',
(SELECT id FROM "0".reference WHERE code = 'MEETING_MINUTES_NOTIFICATION'),
(SELECT id FROM "0".reference WHERE code = 'ET_MEETING_MINUTES_MODULE'),
FALSE);



--For schema anv
DELETE FROM "anv".emailtemplate WHERE module_id=(SELECT id FROM "anv".reference WHERE code = 'ET_MEETING_MINUTES_MODULE') and iscompanyemailtemplate='DEFAULT_EMAIL_TEMPLATE';
INSERT INTO "anv".emailtemplate (fromuserid, iscompanyemailtemplate, isdefault, locale, messagehtml, name, subject, categoryid, module_id, showinmessagecenter)
VALUES (-1, 'DEFAULT_EMAIL_TEMPLATE', TRUE, 'en',
'<p>Dear ${recipientname},</p>
<p>${calledBy} has held a meeting on ${title} and wants you to review the meeting minutes. Here are the details of the meeting:</p>

Location: ${location}<br/>
Purpose: ${purpose}<br/>
Start Date: ${startdate}<br/>
End Date: ${enddate}
<br/>
<p>You can view the details of the meeting by clicking on this link: ${link}</p>',

'Meeting Minutes Default Template',
'Meeting Minutes on ${title}',
(SELECT id FROM "anv".reference WHERE code = 'MEETING_MINUTES_NOTIFICATION'),
(SELECT id FROM "anv".reference WHERE code = 'ET_MEETING_MINUTES_MODULE'),
FALSE);

