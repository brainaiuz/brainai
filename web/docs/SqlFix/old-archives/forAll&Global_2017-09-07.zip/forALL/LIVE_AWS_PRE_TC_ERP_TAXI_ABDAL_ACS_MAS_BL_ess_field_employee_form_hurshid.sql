
update modelfield set sorder=sorder+1 where form_ID='HRMS_EMPLOYEE_FORM' and sorder>(select sorder from modelfield where form_ID='HRMS_EMPLOYEE_FORM' and field_ID='NO_ACCESS');

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID,                         section,                 widget      ,form_ID,     noWrapperFor ) values
                      ((select sorder+1 from modelfield where form_ID='HRMS_EMPLOYEE_FORM' and field_ID='NO_ACCESS'),     false,      false,  false,          '',           false,            '',     'ESS_USER',             'ACCOUNT_INFORMATION',   'CheckBox'  , 'HRMS_EMPLOYEE_FORM','');
