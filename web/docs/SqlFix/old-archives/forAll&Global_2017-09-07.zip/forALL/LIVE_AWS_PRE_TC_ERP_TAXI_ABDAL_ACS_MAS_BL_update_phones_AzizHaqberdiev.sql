update "anv".crmcontactitemparams set value = replace(value, '||', '-') where paramid = 1 and value not like '||%';
update "anv".crmcontactitemparams set value = replace(value, '|', '-') where paramid = 1 and value not like '||%';
update "anv".crmcontactitemparams set value = replace(value, '|', '') where paramid = 1 and value like '||%';
update "anv".crmContact set primaryPhone = replace(primaryPhone, '||', '-') where deleted is not true and primaryPhone not like '||%';
update "anv".crmContact set primaryPhone = replace(primaryPhone, '|', '-') where deleted is not true and primaryPhone not like '||%';
update "anv".crmContact set primaryPhone = replace(primaryPhone, '|', '') where deleted is not true and primaryPhone like '||%';
