 DELETE from "0".genericsettings where key='CREATE_OBJECT_FOLDER_TO_OFFICE_365_DRIVE';
 insert into "0".genericsettings(key,value) select 'CREATE_OBJECT_FOLDER_TO_OFFICE_365_DRIVE','YES';

 DELETE from "anv".genericsettings where key='CREATE_OBJECT_FOLDER_TO_OFFICE_365_DRIVE';
 INSERT INTO "anv".genericsettings(key,value) VALUES('CREATE_OBJECT_FOLDER_TO_OFFICE_365_DRIVE','YES');