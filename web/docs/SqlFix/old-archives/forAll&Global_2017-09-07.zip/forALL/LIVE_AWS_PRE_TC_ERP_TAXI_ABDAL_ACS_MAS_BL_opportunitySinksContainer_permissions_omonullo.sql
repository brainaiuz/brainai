--CRM_OPPORTUNITIES_MESSAGE_LIST
--CRM_OPPORTUNITIES_RFQ_LIST
--CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST

delete FROM permission WHERE code='CRM_OPPORTUNITIES_MESSAGE_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'CRM', 'Opportunity Messages', 9, false,
                (select id from permission  where code='CRM_OPPORTUNITIES_LIST'),
                false, 'OPPORTUNITY_TRACKING');

delete from "0".rolepermission where permissioncode='CRM_OPPORTUNITIES_MESSAGE_LIST';
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='CRM_OPPORTUNITIES_MESSAGE_LIST';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_MESSAGE_LIST', 'SALESMAN', 'ALLOW');



delete FROM permission WHERE code='CRM_OPPORTUNITIES_RFQ_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('CRM_OPPORTUNITIES_RFQ_LIST', 'CRM', 'Opportunity RFQ List', 10, false,
                (select id from permission  where code='CRM_OPPORTUNITIES_LIST'),
                false, 'OPPORTUNITY_TRACKING');

delete from "0".rolepermission where permissioncode='CRM_OPPORTUNITIES_RFQ_LIST';
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_RFQ_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_RFQ_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_RFQ_LIST', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='CRM_OPPORTUNITIES_RFQ_LIST';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_RFQ_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_RFQ_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_RFQ_LIST', 'SALESMAN', 'ALLOW');



delete FROM permission WHERE code='CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'CRM', 'Opportunities Expense Claim', 11, false,
                (select id from permission  where code='CRM_OPPORTUNITIES_LIST'),
                false, 'OPPORTUNITY_TRACKING');

delete from "0".rolepermission where permissioncode='CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST';
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST', 'SALESMAN', 'ALLOW');