insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_CAMPAIGNS_EXPORT', 'CRM', false, 'Campaigns Export', 4, (select id from permission where code ='CRM_CAMPAIGNS_LIST'), false, 'CRM_MODULE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CAMPAIGNS_EXPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CAMPAIGNS_EXPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CAMPAIGNS_EXPORT', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CAMPAIGNS_EXPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CAMPAIGNS_EXPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CAMPAIGNS_EXPORT', 'SALESMAN','ALLOW');
