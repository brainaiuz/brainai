--for updating employeetasks
update "45990".employeetask e1 set percent = (select sum(cast(ts.timespent as double precision))*100
from "45990".timesheet ts
JOIN "45990".reference r ON r.id = ts.statusid 
where r.code='_APPROVE' and ts.employeetaskid = e1.id)/(select  sum(cast(et.estimatedtime as double precision))
		from "45990".employeetask et  
		left join "45990".projectemployee pe on pe.id = et.projectemployeeid  
		left join "45990".teamEmployee te on te.id = pe.employeeDepartmentId  
		left join "45990".employee e on e.id = te.employeeId  
		where et.deleted = false 
		and pe.isdeleted is not true and et.estimatedtime != 0)
where e1.estimatedtime != 0 and e1.deleted is not true;

--for updating tasks
update "45990".task t1 set percent = (select sum(cast(ts.timespent as double precision))*100
from "45990".timesheet ts
JOIN "45990".reference r ON r.id = ts.statusid 
where r.code='_APPROVE' and ts.taskid =t1.id)/(select  sum(cast(et.estimatedtime as double precision))
		from "45990".employeetask et  
		left join "45990".projectemployee pe on pe.id = et.projectemployeeid  
		left join "45990".teamEmployee te on te.id = pe.employeeDepartmentId  
		left join "45990".employee e on e.id = te.employeeId  
		left join "45990".task t on et.taskid = t.id  
		where t.id = t1.id and et.deleted = false 
		and pe.isdeleted is not true and t.deleted = false and et.estimatedtime != 0);

--for updating projects
update "45990".project p1 set percent = ((select sum(cast(ts.timespent as double precision))*100
from "45990".timesheet ts
JOIN "45990".reference r ON r.id = ts.statusid 
where r.code='_APPROVE' and ts.projectid = p1.id)/(select  sum(cast(et.estimatedtime as double precision))
		from "45990".employeetask et  
		left join "45990".projectemployee pe on pe.id = et.projectemployeeid  
		left join "45990".teamEmployee te on te.id = pe.employeeDepartmentId  
		left join "45990".employee e on e.id = te.employeeId  
		left join "45990".task t on et.taskid = t.id  
		left join "45990".project p on t.projectid = p.id  
		where p.id = p1.id and p.isdeleted = false and et.deleted = false 
		and pe.isdeleted is not true and t.deleted = false and et.estimatedtime != 0 ));