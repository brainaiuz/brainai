insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('PM_CONTRACT_REMINDER', 'PM', 'Contract Reminder Receivers', 30, false, (select id from permission where code='PM_MAIN_MENU'), false,  'PM');

insert into "0".rolepermission   (permissioncode, rolecode, access) values ('PM_CONTRACT_REMINDER', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values ('PM_CONTRACT_REMINDER', 'PM', 'ALLOW');
