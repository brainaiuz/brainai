

delete from "200443".mymodule where code='STOREFRONT';
insert into "200443".mymodule (code) values('STOREFRONT');