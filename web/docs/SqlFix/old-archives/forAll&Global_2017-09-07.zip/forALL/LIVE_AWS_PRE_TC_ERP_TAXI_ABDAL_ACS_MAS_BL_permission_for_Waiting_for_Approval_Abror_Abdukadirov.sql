insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('SHOW_ALL_WAITING_FOR_APPROVAL', 'HRMS', false, 'Show all waiting for approval LR', 2, (select id from permission where code ='HRMS_ATTENDANCE_HOME'), false, 'CORE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_WAITING_FOR_APPROVAL', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_WAITING_FOR_APPROVAL', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('SHOW_ALL_WAITING_FOR_APPROVAL', 'HR','ALLOW');