
--For only Alfursan
update "200138".employeeprofile set intnumber=NULLIF(employeecode, '')::int;