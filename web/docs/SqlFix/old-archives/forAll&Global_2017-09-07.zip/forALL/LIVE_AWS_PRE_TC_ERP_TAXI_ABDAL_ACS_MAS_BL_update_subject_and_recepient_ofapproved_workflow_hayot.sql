DROP function if EXISTS "anv".fixLeaveRequestEmailSubjects();
CREATE OR replace function "anv".fixLeaveRequestEmailSubjects()
  returns INTEGER AS
  $body$
DECLARE
    app record;

    BEGIN
        IF EXISTS (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') AND (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') = 'YES' THEN
          --update on approved action
        ELSE
            update "anv".workflow_alerts wa set recepient = '${registered_by_email}', subject = 'Leave request approved' where wa.workflow in (select a.workflow from "anv".approvers a where a.entitytype = 'LEAVE_REQUEST' and a.is_default = true) and recepient='${current_approver_email}';
            update "anv".workflow_alerts wa set recepient = '${registered_by_email}', subject = 'Leave request rejected' where wa.workflow in (select a.rejected_workflow from "anv".approvers a where a.entitytype = 'LEAVE_REQUEST' and a.is_default = true) and recepient='${current_approver_email}';
        END IF;

    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".fixLeaveRequestEmailSubjects() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".fixLeaveRequestEmailSubjects()) IS NOT NULL;
