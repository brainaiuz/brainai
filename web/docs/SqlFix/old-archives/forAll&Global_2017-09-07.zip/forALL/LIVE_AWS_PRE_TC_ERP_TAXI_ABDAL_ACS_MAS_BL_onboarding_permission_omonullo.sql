--parentid: select id from permission where code = 'HRMS_ONBOARDING_MANAGEMENT'
--HRMS_ONBOARDING_LIST
  --HRMS_ONBOARDING_ADD
--HRMS_ONBOARDING_STEP_LIST
  --HRMS_ONBOARDING_STEP_ADD

delete FROM permission WHERE code='HRMS_ONBOARDING_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_LIST', 'HRMS', 'Onboarding Period List', 9, false,
                (select id from permission  where code='HRMS_ONBOARDING_MANAGEMENT'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_LIST';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_LIST', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_LIST';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_LIST', 'SALESMAN', 'ALLOW');


delete FROM permission WHERE code='HRMS_ONBOARDING_ADD';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_ADD', 'HRMS', 'Onboarding Period Add', 1, false,
                (select id from permission  where code='HRMS_ONBOARDING_LIST'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_ADD';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_ADD', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_ADD';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_ADD', 'SALESMAN', 'ALLOW');



delete FROM permission WHERE code='HRMS_ONBOARDING_STEP_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_STEP_LIST', 'HRMS', 'Onboarding Step List', 10, false,
                (select id from permission  where code='HRMS_ONBOARDING_MANAGEMENT'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_LIST';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_LIST', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_LIST';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_LIST', 'SALESMAN', 'ALLOW');



delete FROM permission WHERE code='HRMS_ONBOARDING_STEP_ADD';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('HRMS_ONBOARDING_STEP_ADD', 'HRMS', 'Onboarding Step List', 10, false,
                (select id from permission  where code='HRMS_ONBOARDING_STEP_LIST'),
                false, 'ONBOARDING');

delete from "0".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_ADD';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_ADD', 'SALESMAN', 'ALLOW');


delete from "anv".rolepermission where permissioncode='HRMS_ONBOARDING_STEP_ADD';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_ONBOARDING_STEP_ADD', 'SALESMAN', 'ALLOW');