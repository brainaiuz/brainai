
//Hammaga emas Faqat suralgan companylarga uriladi!!!

INSERT INTO "anv".genericSettings (key, value) VALUES ('ENABLE_LEAVE_REQUEST_PDF', 'YES');