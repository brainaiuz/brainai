insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_ACCOUNTS_COPY', 'CRM', false, 'Copy Crm Account', 6, (select id from permission where code ='CRM_ACCOUNTS_LIST'), false, 'CRM_MODULE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_COPY', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_COPY', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_COPY', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_COPY', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_COPY', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ACCOUNTS_COPY', 'SALESMAN','ALLOW');