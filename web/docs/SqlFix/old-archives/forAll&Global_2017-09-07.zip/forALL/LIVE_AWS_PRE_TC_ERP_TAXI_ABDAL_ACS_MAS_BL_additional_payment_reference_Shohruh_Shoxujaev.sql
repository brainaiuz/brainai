--Zero Schema
insert into "0".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder)
values ('PAYMENT_STATUS', false, true, false, true, true, 'Payment Status', true, 0);

insert into "0".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_DRAFT', false, true, false, true, true, 'Draft', true, 1, (select id from "0".reference where code = 'PAYMENT_STATUS'));
insert into "0".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_SUBMITTED', false, true, false, true, true, 'Submitted', true, 2, (select id from "0".reference where code = 'PAYMENT_STATUS'));
insert into "0".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_APPROVED', false, true, false, true, true, 'Approved', true, 3, (select id from "0".reference where code = 'PAYMENT_STATUS'));
insert into "0".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_REJECTED', false, true, false, true, true, 'Rejected', true, 4, (select id from "0".reference where code = 'PAYMENT_STATUS'));

--For All
insert into "anv".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder)
values ('PAYMENT_STATUS', false, true, false, true, true, 'Payment Status', true, 0);

insert into "anv".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_DRAFT', false, true, false, true, true, 'Draft', true, 1, (select id from "anv".reference where code = 'PAYMENT_STATUS'));
insert into "anv".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_SUBMITTED', false, true, false, true, true, 'Submitted', true, 2, (select id from "anv".reference where code = 'PAYMENT_STATUS'));
insert into "anv".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_APPROVED', false, true, false, true, true, 'Approved', true, 3, (select id from "anv".reference where code = 'PAYMENT_STATUS'));
insert into "anv".reference (code, deleted, isactive, iscustombutton, isremovable, issystemreference, name, shared, sorder, parentid)
values ('PAYMENT_REJECTED', false, true, false, true, true, 'Rejected', true, 4, (select id from "anv".reference where code = 'PAYMENT_STATUS'));