delete from permission where modulecode='LOGISTICS_MODULE' or code like 'LOGISTICS_%';
insert into permission (code, context, name, sorder, parent, modulecode, isMainMenu) values('LOGISTICS_MAIN_MENU', 'LOGISTICS', 'Logistics', 5.5, 0, 'LOGISTICS_MODULE', true);


--Supplier List
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_LIST', 'LOGISTICS', 'Supplier List', 5, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_ADD', 'LOGISTICS', 'Supplier Add', 1, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_EDIT', 'LOGISTICS', 'Supplier Edit', 2, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_DELETE', 'LOGISTICS', 'Supplier Delete', 3, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_SUMMARY', 'LOGISTICS', 'Supplier Summary View', 4, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'LOGISTICS', 'Supplier List Full Access', 5, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_IMPORT', 'LOGISTICS', 'Supplier Import', 6, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_EXPORT', 'LOGISTICS', 'Supplier Export', 7, (SELECT id from permission where code='LOGISTICS_SUPPLIER_LIST'), 'LOGISTICS_MODULE');

insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'LOGISTICS', 'Supplier Credit List', 6, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'LOGISTICS', 'Add Supplier Credit', 1, (SELECT id from permission where code='LOGISTICS_SUPPLIER_CREDIT_LIST'), 'LOGISTICS_MODULE');

insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_SALES_QUOTE_ADD', 'LOGISTICS', 'Add Sales Quote', 7, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');

--Purchase Order List
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_LIST', 'LOGISTICS', 'Purchase Order List', 10, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_ADD', 'LOGISTICS', 'Purchase Order Add', 1, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'LOGISTICS', 'Purchase Order Edit', 2, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'LOGISTICS', 'Purchase Order Delete', 3, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'LOGISTICS', 'Purchase Order Summary', 4, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_COPY', 'LOGISTICS', 'Purchase Order Copy', 5, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'LOGISTICS', 'Purchase Order Approve and Send Button', 6, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'LOGISTICS', 'Purchase Order Save and Approve Button', 7, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'LOGISTICS', 'Mark As Open', 8, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'LOGISTICS', 'Purchase Order Full List Access', 9, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'LOGISTICS', 'Purchase Order Full Edit Access', 10, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'LOGISTICS', 'Purchase Order Receive', 11, (SELECT id from permission where code='LOGISTICS_PURCHASE_ORDER_LIST'), 'LOGISTICS_MODULE');


--Purchase Invoice List
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'LOGISTICS', 'Purchase Invoice List', 15, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'LOGISTICS', 'Purchase Invoice Add', 1, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'LOGISTICS', 'Purchase Invoice Edit', 2, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'LOGISTICS', 'Purchase Credit Note Edit', 3, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'LOGISTICS', 'Purchase Invoice Full Edit Access', 4, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'LOGISTICS', 'Purchase Credit Note Full Edit Access', 5, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'LOGISTICS', 'Purchase Invoice Delete', 6, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'LOGISTICS', 'Purchase Invoice Void', 7, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'LOGISTICS', 'Purchase Invoice Summary', 8, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'LOGISTICS', 'Credit Note Add', 9, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'LOGISTICS', 'Purchase Invoice Copy', 10, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PAY_BILL', 'LOGISTICS', 'Pay Bill', 11, (SELECT id from permission where code='LOGISTICS_PURCHASE_INVOICE_LIST'), 'LOGISTICS_MODULE');

--recurring bill
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_BILL_LIST', 'LOGISTICS', 'Recurring Bill List', 20, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_BILL_ADD', 'LOGISTICS', 'Add Recurring Bill', 1, (SELECT id from permission where code='LOGISTICS_RECURRING_BILL_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_BILL_EDIT', 'LOGISTICS', 'Edit Recurring Bill', 2, (SELECT id from permission where code='LOGISTICS_RECURRING_BILL_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_BILL_DELETE', 'LOGISTICS', 'Delete Recurring Bill', 3, (SELECT id from permission where code='LOGISTICS_RECURRING_BILL_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'LOGISTICS', 'Recurring Bill Summary', 4, (SELECT id from permission where code='LOGISTICS_RECURRING_BILL_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_BILL_COPY', 'LOGISTICS', 'Copy Recurring Bill', 5, (SELECT id from permission where code='LOGISTICS_RECURRING_BILL_LIST'), 'LOGISTICS_MODULE');

--Product list
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PRODUCT_LIST', 'LOGISTICS', 'Product List', 25, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PRODUCT_ADD', 'LOGISTICS', 'Add Product', 1, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PRODUCT_EDIT', 'LOGISTICS', 'Edit Product', 2, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PRODUCT_DELETE', 'LOGISTICS', 'Delete Product', 3, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PRODUCT_SUMMARY', 'LOGISTICS', 'Product Summary', 4, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_VARIATION_ADD', 'LOGISTICS', 'Variation Add', 5, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_VARIATION_DELETE', 'LOGISTICS', 'Variation Delete', 6, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_BUILD_ASSEMBLY', 'LOGISTICS', 'Build Assembly', 7, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_PRODUCT_COST', 'LOGISTICS', 'Product Cost', 8, (SELECT id from permission where code='LOGISTICS_PRODUCT_LIST'), 'LOGISTICS_MODULE');

insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_INVENTORY_LIST', 'LOGISTICS', 'Inventory List', 30, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
--Warehouse
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_WAREHOUSE_LIST', 'LOGISTICS', 'Warehouse List', 35, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'MULTIPLE_WAREHOUSE');

--STOCK TRANSFER LIST
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_TRANSFER_LIST', 'LOGISTICS', 'Stock Transfer List', 40, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'MULTIPLE_WAREHOUSE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_TRANSFER_ADD', 'LOGISTICS', 'Add Stock Transfer', 1, (SELECT id from permission where code='LOGISTICS_STOCK_TRANSFER_LIST'), 'MULTIPLE_WAREHOUSE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'LOGISTICS', 'Edit Stock Transfer', 2, (SELECT id from permission where code='LOGISTICS_STOCK_TRANSFER_LIST'), 'MULTIPLE_WAREHOUSE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'LOGISTICS', 'Delete Stock Transfer', 3, (SELECT id from permission where code='LOGISTICS_STOCK_TRANSFER_LIST'), 'MULTIPLE_WAREHOUSE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'LOGISTICS', 'Stock Transfer Summary', 4, (SELECT id from permission where code='LOGISTICS_STOCK_TRANSFER_LIST'), 'MULTIPLE_WAREHOUSE');


--STOCK ADJUSTMENT
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'LOGISTICS', 'Stock Adjustment List', 45, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'LOGISTICS', 'Add Stock Adjustment', 1, (SELECT id from permission where code='LOGISTICS_STOCK_ADJUSTMENT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'LOGISTICS', 'Edit Stock Adjustment', 2, (SELECT id from permission where code='LOGISTICS_STOCK_ADJUSTMENT_LIST'), 'LOGISTICS_MODULE');
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'LOGISTICS', 'Delete Stock Adjustment', 3, (SELECT id from permission where code='LOGISTICS_STOCK_ADJUSTMENT_LIST'), 'LOGISTICS_MODULE');

--STOCK VALUATION
insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_STOCK_VALUATION', 'LOGISTICS', 'Stock Valuation', 50, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');

insert into permission (code, context, name, sorder, parent, modulecode) values('LOGISTICS_RECURRING_INVOICE_ADD', 'LOGISTICS', 'Add Recurring Invoice', 55, (SELECT id from permission where code='LOGISTICS_MAIN_MENU'), 'LOGISTICS_MODULE');




--LOGISTICS_MAIN_MENU
delete from "0".rolepermission WHERE permissioncode like 'LOGISTICS_%';
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'HR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'ADMIN_LOCATION','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'SALESMAN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'TL','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'PM','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'SALESPERSON','ALLOW');

--LOGISTICS_SUPPLIER_LIST
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'PM','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'PM','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'PM','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'PM','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'PM','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_IMPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_IMPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_IMPORT', 'ACCOUNTANT','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EXPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EXPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EXPORT', 'ACCOUNTANT','ALLOW');


--PURCHASE ORDER
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'SUPPLIER', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'TL', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'ACCOUNTANT', 'ALLOW');

--PURCHASE INVOICE
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'SUPPLIER', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'PM', 'ALLOW');

--RECURRING_BILL
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_COPY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_COPY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_COPY', 'ACCOUNTANT', 'ALLOW');

--PRODUCT
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_INVENTORY_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_INVENTORY_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_INVENTORY_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_BUILD_ASSEMBLY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_BUILD_ASSEMBLY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_BUILD_ASSEMBLY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'TL', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'HR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'SALESPERSON', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'ESS_USER', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'MEM', 'ALLOW');

--WAREHOUSE
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_WAREHOUSE_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_WAREHOUSE_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_WAREHOUSE_LIST', 'ACCOUNTANT', 'ALLOW');

--STOCK TRANSFER_
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'SALESMAN', 'ALLOW');


--STOCK ADJUSTMENT
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'ACCOUNTANT', 'ALLOW');

--STOCK VALUATION
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_VALUATION', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_VALUATION', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_VALUATION', 'ACCOUNTANT', 'ALLOW');


insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'PM', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'SALESMAN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'SALESPERSON', 'ALLOW');


















--LOGISTICS_MAIN_MENU
delete from "anv".rolepermission WHERE permissioncode like 'LOGISTICS_%';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'HR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'ADMIN_LOCATION','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'SALESMAN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'TL','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'PM','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_MAIN_MENU', 'SALESPERSON','ALLOW');

--LOGISTICS_SUPPLIER_LIST
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_LIST', 'PM','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_ADD', 'PM','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EDIT', 'PM','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_DELETE', 'PM','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_SUMMARY', 'PM','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_FULL_LIST_ACCESS', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_IMPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_IMPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_IMPORT', 'ACCOUNTANT','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EXPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EXPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_EXPORT', 'ACCOUNTANT','ALLOW');


--PURCHASE ORDER
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'SUPPLIER', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_LIST', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_ADD', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_EDIT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_DELETE', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_SUMMARY', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_COPY', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_APPROVE_AND_SEND_BUTTON', 'TL', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_SAVE_AND_APPROVE_BUTTON', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_LIST_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_ORDER_RECEIVE', 'ACCOUNTANT', 'ALLOW');

--PURCHASE INVOICE
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'SUPPLIER', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_LIST', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_ADD', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_EDIT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_FULL_EDIT_ACCESS', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_DELETE', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_VOID', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_SUMMARY', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_CREDIT_NOTE_ADD', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PURCHASE_INVOICE_COPY', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PAY_BILL', 'PM', 'ALLOW');

--RECURRING_BILL
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_COPY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_COPY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_BILL_COPY', 'ACCOUNTANT', 'ALLOW');

--PRODUCT
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_INVENTORY_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_INVENTORY_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_INVENTORY_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_VARIATION_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_BUILD_ASSEMBLY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_BUILD_ASSEMBLY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_BUILD_ASSEMBLY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'TL', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'HR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'SALESPERSON', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'ESS_USER', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_PRODUCT_COST', 'MEM', 'ALLOW');

--WAREHOUSE
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_WAREHOUSE_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_WAREHOUSE_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_WAREHOUSE_LIST', 'ACCOUNTANT', 'ALLOW');

--STOCK TRANSFER_
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_LIST', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_EDIT', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_DELETE', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_TRANSFER_SUMMARY', 'SALESMAN', 'ALLOW');


--STOCK ADJUSTMENT
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_ADJUSTMENT_DELETE', 'ACCOUNTANT', 'ALLOW');

--STOCK VALUATION
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_VALUATION', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_VALUATION', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_STOCK_VALUATION', 'ACCOUNTANT', 'ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_RECURRING_INVOICE_ADD', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SUPPLIER_CREDIT_ADD', 'ACCOUNTANT', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'SALESMAN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('LOGISTICS_SALES_QUOTE_ADD', 'SALESPERSON', 'ALLOW');

