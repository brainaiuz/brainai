
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "59386".genericSettings (key,value) values('PDF_GROUP_BY_PRODUCT_CATEGORY', 'YES');
