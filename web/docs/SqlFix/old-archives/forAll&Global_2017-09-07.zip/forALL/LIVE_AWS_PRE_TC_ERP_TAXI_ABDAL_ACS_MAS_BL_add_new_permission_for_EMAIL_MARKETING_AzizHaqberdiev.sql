insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_SEE_ALL_MAILLIST_LIST', 'CRM', false, 'See all mailing lists', 5, (select id from permission where code ='CRM_MAILING_LIST'), false, 'EMAIL_MARKETING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SEE_ALL_MAILLIST_LIST', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SEE_ALL_MAILLIST_LIST', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SEE_ALL_MAILLIST_LIST', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SEE_ALL_MAILLIST_LIST', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SEE_ALL_MAILLIST_LIST', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SEE_ALL_MAILLIST_LIST', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_MAIL_LIST_MEMBERS', 'CRM', false, 'Mailing list members list', 9, (select id from permission where code ='CRM_MAILING_LIST'), false, 'EMAIL_MARKETING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_MAIL_LIST_MEMBERS', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_MAIL_LIST_MEMBERS', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_MAIL_LIST_MEMBERS', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_MAIL_LIST_MEMBERS', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_MAIL_LIST_MEMBERS', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_MAIL_LIST_MEMBERS', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_MESSAGES_EXPORT', 'CRM', false, 'Export Messages', 15, (select id from permission where code ='CRM_MAILING_LIST'), false, 'EMAIL_MARKETING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_MESSAGES_EXPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_MESSAGES_EXPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_MESSAGES_EXPORT', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_MESSAGES_EXPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_MESSAGES_EXPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_MESSAGES_EXPORT', 'SALESMAN','ALLOW');
