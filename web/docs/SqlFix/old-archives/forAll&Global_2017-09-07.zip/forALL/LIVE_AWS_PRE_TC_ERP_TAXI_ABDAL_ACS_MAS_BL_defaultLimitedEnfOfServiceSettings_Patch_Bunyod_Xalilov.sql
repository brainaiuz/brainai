
-- after schema update


UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select setval('"anv".eos_rules_id_seq',(select max(id) from "anv".eos_rules))) IS NOT NULL;

insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode, ruletype) values(0, 'EMPLOYEE_RESIGNATION', 'Less than 1 year', (select id from "anv".eos_settings where countrycode='AE' limit 1), '0<x<1', 1);
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode, ruletype) values(21, 'EMPLOYEE_RESIGNATION', '1 to 5 years', (select id from "anv".eos_settings where countrycode='AE' limit 1), '1<=x<5', 1);
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode, ruletype) values(30, 'EMPLOYEE_RESIGNATION', 'More than 5 years', (select id from "anv".eos_settings where countrycode='AE' limit 1), 'x>5', 1);
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode, ruletype) values(0, 'CONTRACT_TERMINATION', 'Less than 1 year', (select id from "anv".eos_settings where countrycode='AE' limit 1), '0<x<1', 1);
insert into "anv".eos_rules(days, reasoncode, rule, settings_id, rulecode, ruletype) values(30, 'CONTRACT_TERMINATION', 'More than 1 years', (select id from "anv".eos_settings where countrycode='AE' limit 1), 'x>1', 1);