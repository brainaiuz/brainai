INSERT INTO "anv".paymentdeductionscategories (paymentdeductionid, categoryid)
  (SELECT paymentdeduction_id, id FROM "anv".category
   WHERE paymentdeduction_id IS NOT NULL);