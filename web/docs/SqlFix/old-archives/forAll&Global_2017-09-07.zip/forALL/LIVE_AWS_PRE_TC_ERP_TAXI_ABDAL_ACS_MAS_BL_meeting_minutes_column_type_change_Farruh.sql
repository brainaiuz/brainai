alter table "anv".meetingminutes alter column nonCompanyAttendees TYPE text;
