insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('CRM_WELCOME_PAGE','CRM','CRM Welcome',2,false,(SELECT ID FROM PERMISSION WHERE CODE = 'CRM_SALES_TAB'),false,'CRM_MODULE');


insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_WELCOME_PAGE','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_WELCOME_PAGE','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_WELCOME_PAGE','SALESPERSON','ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_WELCOME_PAGE','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_WELCOME_PAGE','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_WELCOME_PAGE','SALESPERSON','ALLOW');
