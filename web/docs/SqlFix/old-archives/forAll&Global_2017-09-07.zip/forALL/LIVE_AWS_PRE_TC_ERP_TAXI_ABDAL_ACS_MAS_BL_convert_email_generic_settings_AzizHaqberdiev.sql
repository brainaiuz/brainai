insert into "0".genericSettings (key,value) values ('CONVERT_EACH_EMAIL_TO_CASE', 'NO');
insert into "anv".genericSettings (key,value) values ('CONVERT_EACH_EMAIL_TO_CASE', 'NO');

--MCTC enable
update "51346".genericSettings set value = 'YES' where key = 'CONVERT_EACH_EMAIL_TO_CASE';