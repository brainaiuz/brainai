insert into permission (code,     context,ismainmenu, name, sorder,            parent,                                                        iscore,   modulecode)
                select 'CRM_SALES_ORDER_ADD','CRM',  false, 'Sales Order Add', 1,(select id from permission where code = 'CRM_SALES_ORDER_LIST'), false, 'CRM_MODULE'
		            where 1 <> (select count(id) from permission where code = 'CRM_SALES_ORDER_ADD');
