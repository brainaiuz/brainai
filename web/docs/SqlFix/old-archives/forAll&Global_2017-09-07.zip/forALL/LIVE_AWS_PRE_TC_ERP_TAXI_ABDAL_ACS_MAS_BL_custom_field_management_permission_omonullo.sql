delete from permission where code = 'CUSTOM_FIELD_SETTINGS';
insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
                values ('CUSTOM_FIELD_SETTINGS', 'SETTINGS', false, 'Custom Field Settings', 10, (select id from permission where code = 'SETTINGS_MAIN_MENU'), false, 'CORE');


delete from "anv".rolepermission where permissioncode = 'CUSTOM_FIELD_SETTINGS';
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CUSTOM_FIELD_SETTINGS', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CUSTOM_FIELD_SETTINGS', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CUSTOM_FIELD_SETTINGS', 'ALLOW', 'ACCOUNTANT');

delete from "0".rolepermission where permissioncode = 'CUSTOM_FIELD_SETTINGS';
insert into "0".rolepermission (permissioncode, access, rolecode)
                          values ('CUSTOM_FIELD_SETTINGS', 'ALLOW', 'DR');
insert into "0".rolepermission (permissioncode, access, rolecode)
                          values ('CUSTOM_FIELD_SETTINGS', 'ALLOW', 'ADMIN');
insert into "0".rolepermission (permissioncode, access, rolecode)
                          values ('CUSTOM_FIELD_SETTINGS', 'ALLOW', 'ACCOUNTANT');