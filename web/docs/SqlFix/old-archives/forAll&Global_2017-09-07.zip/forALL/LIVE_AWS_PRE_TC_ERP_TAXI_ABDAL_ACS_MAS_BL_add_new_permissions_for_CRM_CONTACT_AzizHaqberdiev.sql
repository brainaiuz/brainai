insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('ADD_CONTACT_SMS', 'CRM', false, 'Contact send SMS', 6, (select id from permission where code ='CRM_CONTACTS_LIST'), false, 'CONTACT_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_CONTACT_SMS', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_CONTACT_SMS', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_CONTACT_SMS', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_CONTACT_SMS', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_CONTACT_SMS', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_CONTACT_SMS', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_CONTACTS_DETECT_DUBLICATES', 'CRM', false, 'Contact detect duplicates', 8, (select id from permission where code ='CRM_CONTACTS_LIST'), false, 'CONTACT_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_DETECT_DUBLICATES', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_DETECT_DUBLICATES', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_DETECT_DUBLICATES', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_DETECT_DUBLICATES', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_DETECT_DUBLICATES', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_DETECT_DUBLICATES', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_CONTACTS_MERGE', 'CRM', false, 'Contacts merge', 9, (select id from permission where code ='CRM_CONTACTS_LIST'), false, 'CONTACT_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_MERGE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_MERGE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_MERGE', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_MERGE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_MERGE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CONTACTS_MERGE', 'SALESMAN','ALLOW');