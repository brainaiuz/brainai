
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "59386".genericSettings (key,value) values('ENABLE_PRODUCT_PROFIT_AMOUNT_FOR_INVOICE_PDF', 'YES');
