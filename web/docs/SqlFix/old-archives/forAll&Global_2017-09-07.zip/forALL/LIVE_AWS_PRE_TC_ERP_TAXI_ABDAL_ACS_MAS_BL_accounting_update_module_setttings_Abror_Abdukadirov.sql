update permission set modulecode = 'SALES_INVOICING' where code = 'CRM_SALES_INVOICE_ADD';
update permission set modulecode = 'SALES_INVOICING' where code = 'CRM_SALES_INVOICE_LIST';

update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_LIST';
update permission set modulecode = 'SALES_ORDERS' where code = 'CONVERT_OPPORTUNITY_TO_SO';

update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'CONVERT_OPPORTUNITY_TO_RFQ';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'CRM_OPPORTUNITIES_RFQ_LIST';

update permission set modulecode = 'EXPENSE_REPORTING' where code = 'CRM_OPPORTUNITIES_EXPENSE_CLAIM_LIST';

