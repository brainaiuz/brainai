---for all---
insert into "anv".category(code, name, type, forall, pensionable) values('REMAINING_PREV_MONTH_PAYMENT', 'Remaining prev month payment', 'Payment', true,true);

---for ZERO---
insert into "0".category(code, name, type, forall, pensionable) values('REMAINING_PREV_MONTH_PAYMENT', 'Remaining prev month payment', 'Payment', true,true);