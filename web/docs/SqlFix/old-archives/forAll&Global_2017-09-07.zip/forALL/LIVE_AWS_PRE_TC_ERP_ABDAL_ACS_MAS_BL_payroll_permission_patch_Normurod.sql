---- For PUBLIC schema ----
update permission set sorder = 1 where code = 'PAYROLL_MAIN_CONTENT';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 0 where code = 'PAYROLL_WELCOME';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 1 where code = 'PAYROLL_PAYSLIP_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 2 where code = 'PAYROLL_EMPLOYEES_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 3 where code = 'PAYROLL_GROUP_PAYRUN_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 4 where code = 'END_OF_SERVICE_GRATUITY_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 5 where code = 'PAYROLL_CASH_ADVANCE_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_MAIN_CONTENT'), modulecode = 'PAYROLL', sorder = 6 where code = 'PAYROLL_ADDITIONAL_PAYMENT_LIST';

insert into permission(code, context, name, modulecode, ismainmenu, iscore, sorder, parent) values('PAYROLL_REPORTS', 'PAYROLL', 'Reports', 'PAYROLL', false, false, 2, (select id from permission where code = 'PAYROLL_MAIN_MENU'));
update permission set parent = (select id from permission where code = 'PAYROLL_REPORTS'), modulecode = 'PAYROLL', sorder = 1 where code = 'PAYROLL_WPS_REPORT';
update permission set parent = (select id from permission where code = 'PAYROLL_REPORTS'), modulecode = 'PAYROLL', sorder = 2 where code = 'PAYROLL_END_OF_SERVICE_REPORT';
update permission set parent = (select id from permission where code = 'PAYROLL_REPORTS'), modulecode = 'PAYROLL', sorder = 3 where code = 'PAYROLL_PENSION_CONTRIBUTION_REPORT';


update permission set sorder = 3 where code = 'PAYROLL_SETTINGS';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 1 where code = 'PAYROLL_SETTINGS_EMPLOYER_SETTINGS';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 2 where code = 'PAYROLL_BATCH_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 3 where code = 'PAYROLL_PAYMENT_DEDUCATION_LIST';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 4 where code = 'PAYROLL_SETTINGS_PENSION_PROVIDERS';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 5 where code = 'PAYROLL_SETTINGS_PENSION_SCHEMES';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 6 where code = 'PAYROLL_SETTINGS_PAYMENT_CATEGORIES';
update permission set parent = (select id from permission where code = 'PAYROLL_SETTINGS'), modulecode = 'PAYROLL', sorder = 7 where code = 'PAYROLL_SETTINGS_DEDUCATION_CATEGORIES';



---- For ZERO schema ----
insert into "0".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'ADMIN', 'ALLOW');
insert into "0".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'DR', 'ALLOW');
insert into "0".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'HR', 'ALLOW');
insert into "0".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'ACCOUNTANT', 'ALLOW');


---- For ALL schema ----
insert into "anv".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'DR', 'ALLOW');
insert into "anv".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'HR', 'ALLOW');
insert into "anv".rolepermission(permissioncode, rolecode, access) values('PAYROLL_REPORTS', 'ACCOUNTANT', 'ALLOW');