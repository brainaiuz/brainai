insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CHANGE_LEADS_ASSIGNEE', 'CRM', false, 'Leads Assignee Change', 1, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_ASSIGNEE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_ASSIGNEE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_ASSIGNEE', 'SALESMAN','ALLOW');