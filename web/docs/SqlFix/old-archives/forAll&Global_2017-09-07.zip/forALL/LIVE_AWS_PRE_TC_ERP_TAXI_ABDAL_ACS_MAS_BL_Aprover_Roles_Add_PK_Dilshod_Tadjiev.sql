-- For zero schema
ALTER TABLE "0".approver_roles DROP CONSTRAINT approver_roles_pkey;
ALTER TABLE "0".approver_roles ADD COLUMN id SERIAL PRIMARY KEY;
-- For all schema
ALTER TABLE "anv".approver_roles DROP CONSTRAINT approver_roles_pkey;
ALTER TABLE "anv".approver_roles ADD COLUMN id SERIAL PRIMARY KEY;