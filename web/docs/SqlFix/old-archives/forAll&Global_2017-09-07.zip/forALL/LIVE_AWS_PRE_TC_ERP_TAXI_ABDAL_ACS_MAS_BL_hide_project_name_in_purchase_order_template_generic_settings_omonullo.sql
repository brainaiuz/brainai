
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "50474".genericSettings (key,value) values('HIDE_PROJECT_IN_PURCHASE_ORDER_TEMPLATE', 'YES');
