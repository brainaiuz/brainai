insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_LEAD_CONTACT_ASSIGNEE', 'CRM', false, 'Assignee/Owner for Lead/Contact', 15, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'SALESMAN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'SALESPERSON','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'SALESMAN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_CONTACT_ASSIGNEE', 'SALESPERSON','ALLOW');
