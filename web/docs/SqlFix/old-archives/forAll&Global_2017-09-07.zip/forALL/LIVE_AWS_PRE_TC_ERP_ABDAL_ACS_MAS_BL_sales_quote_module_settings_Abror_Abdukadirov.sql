delete from "anv".mymodule where code = 'SALES_QUOTES';
delete from "anv".mymodule where code = 'SALES_ORDERS';
delete from "anv".mymodule where code = 'REQUEST_FOR_QUOTES';
delete from "anv".mymodule where code = 'RECURRING_BILLS';
delete from "anv".mymodule where code = 'SUPPLIER_CENTER';
delete from "anv".mymodule where code = 'BANK_ACCOUNTS';
delete from "anv".mymodule where code = 'ACCOUNTING_CHART_OF_ACCOUNTS';
delete from "anv".mymodule where code = 'FRANCHISE_MANAGEMENT';
delete from "anv".mymodule where code = 'RESERVATIONS';
delete from "anv".mymodule where code = 'CONSIGNMENTS';

insert into "anv".mymodule(code) values('SALES_QUOTES');
insert into "anv".mymodule(code) values('SALES_ORDERS');
insert into "anv".mymodule(code) values('REQUEST_FOR_QUOTES');
insert into "anv".mymodule(code) values('RECURRING_BILLS');
insert into "anv".mymodule(code) values('SUPPLIER_CENTER');
insert into "anv".mymodule(code) values('BANK_ACCOUNTS');
insert into "anv".mymodule(code) values('ACCOUNTING_CHART_OF_ACCOUNTS');
insert into "anv".mymodule(code) values('FRANCHISE_MANAGEMENT');
insert into "anv".mymodule(code) values('RESERVATIONS');
insert into "anv".mymodule(code) values('CONSIGNMENTS');

delete from "0".mymodule where code = 'SALES_QUOTES';
delete from "0".mymodule where code = 'SALES_ORDERS';
delete from "0".mymodule where code = 'REQUEST_FOR_QUOTES';
delete from "0".mymodule where code = 'RECURRING_BILLS';
delete from "0".mymodule where code = 'SUPPLIER_CENTER';
delete from "0".mymodule where code = 'BANK_ACCOUNTS';
delete from "0".mymodule where code = 'ACCOUNTING_CHART_OF_ACCOUNTS';
delete from "0".mymodule where code = 'FRANCHISE_MANAGEMENT';
delete from "0".mymodule where code = 'RESERVATIONS';
delete from "0".mymodule where code = 'CONSIGNMENTS';

insert into "0".mymodule(code) values('SALES_QUOTES');
insert into "0".mymodule(code) values('SALES_ORDERS');
insert into "0".mymodule(code) values('REQUEST_FOR_QUOTES');
insert into "0".mymodule(code) values('RECURRING_BILLS');
insert into "0".mymodule(code) values('SUPPLIER_CENTER');
insert into "0".mymodule(code) values('BANK_ACCOUNTS');
insert into "0".mymodule(code) values('ACCOUNTING_CHART_OF_ACCOUNTS');
insert into "0".mymodule(code) values('FRANCHISE_MANAGEMENT');
insert into "0".mymodule(code) values('RESERVATIONS');
insert into "0".mymodule(code) values('CONSIGNMENTS');

----------------Sales Quote Module--------------------------
update permission set modulecode = 'SALES_QUOTES' where code = 'PM_PROJECT_SALES_QUOTE';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_LIST';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_ADD';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_EDIT';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_DELETE';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_SUMMARY';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SALES_QUOTE_PDF';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_LIST';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_ADD';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_EDIT';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_DELETE';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_SUMMARY';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_COPY';
update permission set modulecode = 'SALES_QUOTES' where code = 'ACCOUNTING_SALES_QUOTE_PDF';
update permission set modulecode = 'SALES_QUOTES' where code = 'CRM_SEND_SALES_QUOTE';
update permission set modulecode = 'SALES_QUOTES' where code = 'WORKSPACE_SALES_QUOTE_ADD';

----------------Sales Order Module--------------------------
update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_LIST';
update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_ADD';
update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_EDIT';
update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_DELETE';
update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_SUMMARY';
update permission set modulecode = 'SALES_ORDERS' where code = 'CRM_SALES_ORDER_PDF';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_LIST';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_ADD';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_DELETE';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_SUMMARY';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_PICKLIST';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_COPYTOPO';
update permission set modulecode = 'SALES_ORDERS' where code = 'ACCOUNTING_SALES_ORDER_PDF';


----------------Request For Quote Module--------------------------
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_LIST';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_ADD';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_EDIT';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_DELETE';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_SUMMARY';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_COPY';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'ACCOUNTING_REQUEST_FOR_QUOTE_CONVERT';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'REQUEST_FOR_QUOTE_CELL_EDITABLE';
update permission set modulecode = 'REQUEST_FOR_QUOTES' where code = 'SEND_RFQ_QUOTE_NOTE';


----------------Recurring Bills Module--------------------------
update permission set modulecode = 'RECURRING_BILLS' where code = 'ACCOUNTING_RECURRING_BILL_LIST';
update permission set modulecode = 'RECURRING_BILLS' where code = 'ACCOUNTING_RECURRING_BILL_ADD';
update permission set modulecode = 'RECURRING_BILLS' where code = 'ACCOUNTING_RECURRING_BILL_EDIT';
update permission set modulecode = 'RECURRING_BILLS' where code = 'ACCOUNTING_RECURRING_BILL_DELETE';
update permission set modulecode = 'RECURRING_BILLS' where code = 'ACCOUNTING_RECURRING_BILL_SUMMARY';
update permission set modulecode = 'RECURRING_BILLS' where code = 'ACCOUNTING_RECURRING_BILL_COPY';

----------------Supplier Center Module--------------------------
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_LIST';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_ADD';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_EDIT';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_DELETE';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_SUMMARY';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_FULL_LIST_ACCESS';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'CRM_SUPPLIER_ADD';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_IMPORT';
update permission set modulecode = 'SUPPLIER_CENTER' where code = 'ACCOUNTING_SUPPLIER_EXPORT';

----------------Bank Account Module--------------------------
update permission set modulecode = 'BANK_ACCOUNTS' where code = 'ACCOUNTING_BANK_ACCOUNT_LIST';
update permission set modulecode = 'BANK_ACCOUNTS' where code = 'ACCOUNTING_BANK_ACCOUNT_ADD';
update permission set modulecode = 'BANK_ACCOUNTS' where code = 'ACCOUNTING_BANK_ACCOUNT_EDIT';
update permission set modulecode = 'BANK_ACCOUNTS' where code = 'ACCOUNTING_BANK_ACCOUNT_DELETE';

----------------Chart Of Accounts Module--------------------------
update permission set modulecode = 'ACCOUNTING_CHART_OF_ACCOUNTS' where code = 'ACCOUNTING_ACCOUNT_LIST';
update permission set modulecode = 'ACCOUNTING_CHART_OF_ACCOUNTS' where code = 'ACCOUNTING_ACCOUNT_ADD';
update permission set modulecode = 'ACCOUNTING_CHART_OF_ACCOUNTS' where code = 'ACCOUNTING_ACCOUNT_EDIT';
update permission set modulecode = 'ACCOUNTING_CHART_OF_ACCOUNTS' where code = 'ACCOUNTING_ACCOUNT_DELETE';
update permission set modulecode = 'ACCOUNTING_CHART_OF_ACCOUNTS' where code = 'ACCOUNTING_ACCOUNT_SUMMARY';

----------------Franchise Management Module--------------------------
update permission set modulecode = 'FRANCHISE_MANAGEMENT' where code = 'ACCOUNTING_FRANCHISE_LIST';
update permission set modulecode = 'FRANCHISE_MANAGEMENT' where code = 'ACCOUNTING_FRANCHISE_ADD';
update permission set modulecode = 'FRANCHISE_MANAGEMENT' where code = 'ACCOUNTING_FRANCHISE_EDIT';
update permission set modulecode = 'FRANCHISE_MANAGEMENT' where code = 'ACCOUNTING_FRANCHISE_DELETE';

----------------Reservations Module--------------------------
update permission set modulecode = 'RESERVATIONS' where code = 'ACCOUNTING_RESERVATION_LIST';
update permission set modulecode = 'RESERVATIONS' where code = 'ACCOUNTING_RESERVATION_ADD';
update permission set modulecode = 'RESERVATIONS' where code = 'ACCOUNTING_RESERVATION_EDIT';

----------------Consignment Module--------------------------
update permission set modulecode = 'CONSIGNMENTS' where code = 'ACCOUNTING_CONSIGNMENT_LIST_VIEW';

