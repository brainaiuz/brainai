insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('CRM_LEAD_CONVERT','CRM','Lead Convert',4,false,(select id from permission where code = 'CRM_LEADS_LIST'),false,'LEAD_MANAGEMENT');


insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','SALESMAN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','SALESPERSON','ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','SALESMAN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_CONVERT','SALESPERSON','ALLOW');

insert into permission(code,context,name,sorder,ismainmenu,parent,iscore,modulecode)
values('CRM_LEAD_STATUS','CRM','Edit Lead Status',4,false,(select id from permission where code = 'CRM_LEADS_LIST'),false,'LEAD_MANAGEMENT');


insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','SALESMAN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','SALESPERSON','ALLOW');


insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','SALESMAN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('CRM_LEAD_STATUS','SALESPERSON','ALLOW');