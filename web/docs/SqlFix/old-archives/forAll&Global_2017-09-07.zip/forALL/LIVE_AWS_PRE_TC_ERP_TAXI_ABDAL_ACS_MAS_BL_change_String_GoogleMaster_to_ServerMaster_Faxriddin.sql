//schema update dan kiyin urilsin!!!

update "anv".useremailsettings set contactSyncType='SERVERMASTER' where contactSyncType='GOOGLEMASTER';

update "anv".useremailsettings set officeContactSyncType='SERVERMASTER' where officeContactSyncType='GOOGLEMASTER';