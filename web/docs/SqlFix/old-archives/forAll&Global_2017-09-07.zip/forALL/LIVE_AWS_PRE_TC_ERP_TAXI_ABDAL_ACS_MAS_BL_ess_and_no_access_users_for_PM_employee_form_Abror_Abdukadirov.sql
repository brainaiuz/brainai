
update modelfield set split = true where form_ID='PM_EMPLOYEE_FORM' and field_ID='ACCOUNT_STATUS';

insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID, section, widget  ,form_ID, noWrapperFor ) values
                      ((select sorder+1 from modelfield where form_ID='PM_EMPLOYEE_FORM' and field_ID='ACCOUNT_STATUS'),false,   false,  false,    '', false, '',  'NO_ACCESS', 'ACCOUNT_INFORMATION',  'CheckBox'  , 'PM_EMPLOYEE_FORM','');


insert into modelfield(sorder, mandatory,  hide,   isCustomField,  defaultValue, systemmandatory, noLabelFor, field_ID, section, widget  ,form_ID, noWrapperFor ) values
                      ((select sorder+1 from modelfield where form_ID='PM_EMPLOYEE_FORM' and field_ID='NO_ACCESS'),     false,   false,  false,    '', false, '', 'ESS_USER', 'ACCOUNT_INFORMATION',   'CheckBox'  , 'PM_EMPLOYEE_FORM','');
