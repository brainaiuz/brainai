insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('PAYROLL_POST_TRANSACTION', 'PAYROLL', false, 'Cash Advance Post', 6, (select id from permission where code ='PAYROLL_CASH_ADVANCE_LIST'), false, 'CORE');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_POST_TRANSACTION', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_POST_TRANSACTION', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_POST_TRANSACTION', 'ACCOUNTANT','ALLOW');