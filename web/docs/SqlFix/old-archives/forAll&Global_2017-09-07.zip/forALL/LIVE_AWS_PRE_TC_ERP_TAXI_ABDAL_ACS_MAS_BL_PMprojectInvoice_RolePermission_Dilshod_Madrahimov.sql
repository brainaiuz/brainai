update permission set modulecode='PM' where code='PM_PROJECT_INVOICE';
update permission set modulecode='PM' where code='PM_TASKS_BUDGET';

UPDATE "anv".rolepermission  set access='DENY' where permissioncode='PM_PROJECT_INVOICE' and rolecode in('PMOFPR','DLOFPR','BMOFPR','CREATOR');
UPDATE "anv".rolepermission  set access='DENY' where permissioncode='PM_TASKS_BUDGET' and rolecode in('PMOFPR','DLOFPR','BMOFPR','CREATOR');