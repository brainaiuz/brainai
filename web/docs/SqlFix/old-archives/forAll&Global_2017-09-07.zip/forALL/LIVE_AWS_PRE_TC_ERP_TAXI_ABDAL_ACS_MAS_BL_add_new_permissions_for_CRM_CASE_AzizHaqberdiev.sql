insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_COPY_CASE', 'CRM', false, 'CRM Copy Case', 3, (select id from permission where code ='CRM_CASES_LIST'), false, 'CASE_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_CASE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_CASE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_CASE', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_CASE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_CASE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_CASE', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_CASES_EXPORT', 'CRM', false, 'Export Cases', 11, (select id from permission where code ='CRM_CASES_LIST'), false, 'CASE_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CASES_EXPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CASES_EXPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_CASES_EXPORT', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CASES_EXPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CASES_EXPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_CASES_EXPORT', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_SOLUTIONS_EXPORT', 'CRM', false, 'Export Solutions', 4, (select id from permission where code ='CRM_SOLUTIONS_LIST'), false, 'CASE_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SOLUTIONS_EXPORT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SOLUTIONS_EXPORT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_SOLUTIONS_EXPORT', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SOLUTIONS_EXPORT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SOLUTIONS_EXPORT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_SOLUTIONS_EXPORT', 'SALESMAN','ALLOW');
