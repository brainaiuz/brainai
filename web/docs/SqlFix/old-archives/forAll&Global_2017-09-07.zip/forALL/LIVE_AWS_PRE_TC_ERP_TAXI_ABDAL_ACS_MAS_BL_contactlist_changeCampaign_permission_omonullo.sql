delete from "anv".rolepermission where permissioncode = 'CRM_CHANGE_CAMPAIGN';
delete from "0".rolepermission where permissioncode = 'CRM_CHANGE_CAMPAIGN';

delete from permission where code = 'CRM_CHANGE_CAMPAIGN';

INSERT INTO permission (code, context, name, sorder, parent, iscore, modulecode)
VALUES ('CRM_CHANGE_CAMPAIGN', 'CRM', 'Edit Campaign', 5, (SELECT id
                                                           FROM permission
                                                           WHERE code = 'CRM_CONTACTS_LIST'), FALSE,
        'CONTACT_MANAGEMENT');


insert into "anv".rolepermission (permissioncode, access, rolecode)
values ('CRM_CHANGE_CAMPAIGN', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
values ('CRM_CHANGE_CAMPAIGN', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
values ('CRM_CHANGE_CAMPAIGN', 'ALLOW', 'ACCOUNTANT');

insert into "0".rolepermission (permissioncode, access, rolecode)
values ('CRM_CHANGE_CAMPAIGN', 'ALLOW', 'DR');
insert into "0".rolepermission (permissioncode, access, rolecode)
values ('CRM_CHANGE_CAMPAIGN', 'ALLOW', 'ADMIN');
insert into "0".rolepermission (permissioncode, access, rolecode)
values ('CRM_CHANGE_CAMPAIGN', 'ALLOW', 'ACCOUNTANT');