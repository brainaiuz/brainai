DROP function if EXISTS "anv".fixActionsOfApprovers();
CREATE OR replace function "anv".fixActionsOfApprovers()
  returns INTEGER AS
  $body$
DECLARE
    app record;

    BEGIN
        IF EXISTS (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') AND (select "value" from "anv".genericSettings where "key" ='LEAVE_REQUEST_DOUBLE_APPROVE_ENABLED') = 'YES' THEN
          --update on approved action
            update "anv".approvers set onapprovedaction = 5, onrejectedaction=6 where entitytype = 'LEAVE_REQUEST' and approver_order = 2;
        ELSE
            update "anv".approvers set onapprovedaction = 5, onrejectedaction=6 where entitytype = 'LEAVE_REQUEST';
        END IF;

    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".fixActionsOfApprovers() owner TO wfmtest;

UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".fixActionsOfApprovers()) IS NOT NULL;
