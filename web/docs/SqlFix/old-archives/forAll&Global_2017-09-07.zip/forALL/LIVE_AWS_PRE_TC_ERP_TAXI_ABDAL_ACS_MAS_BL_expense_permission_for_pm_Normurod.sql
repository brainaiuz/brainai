DELETE FROM permission where code = 'PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF';
DELETE FROM permission where code = 'PM_PROJECT_EXPENSE_REPORT_EDIT';
DELETE FROM permission where code = 'PM_PROJECT_EXPENSE_REPORT_DELETE';
DELETE FROM permission where code = 'PM_PROJECT_EXPENSE_REPORT_VOID';

DELETE FROM "0".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF';
DELETE FROM "0".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_EDIT';
DELETE FROM "0".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_DELETE';
DELETE FROM "0".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_VOID';

DELETE FROM "anv".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF';
DELETE FROM "anv".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_EDIT';
DELETE FROM "anv".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_DELETE';
DELETE FROM "anv".rolepermission where permissioncode = 'PM_PROJECT_EXPENSE_REPORT_VOID';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'PM', 'Expense Claim add to the staff', 1, false, (select id from permission where code='PM_PROJECT_EXPENSE_CLAIMS'), false, 'EXPENSE_REPORTING');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'PM', 'Expense Claims Edit', 2, false, (select id from permission where code='PM_PROJECT_EXPENSE_CLAIMS'), false, 'EXPENSE_REPORTING');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'PM', 'Expense Claims Delete', 3, false, (select id from permission where code='PM_PROJECT_EXPENSE_CLAIMS'), false, 'EXPENSE_REPORTING');
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'PM', 'Expense Claims Void', 4, false, (select id from permission where code='PM_PROJECT_EXPENSE_CLAIMS'), false, 'EXPENSE_REPORTING');

insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'MEM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_ADD_TO_STAFF', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_EDIT', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_DELETE', 'MEM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PM_PROJECT_EXPENSE_REPORT_VOID', 'PM', 'ALLOW');
