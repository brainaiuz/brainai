insert into myupdatetype (code, description, parentid) values ('BANK_TRANSFER_DELETE',     'Records when user deletes bank transfer',     (select id from myupdatetype where code='BANK_TRANSFER'));
--BATCH_PAYMENT
--BATCH_PAYMENT_ADD
--BATCH_PAYMENT_EDIT
--BATCH_PAYMENT_DELETE
insert into myupdatetype (code, description) values ('BATCH_PAYMENT',     'Records when batch payment is updated or created');
insert into myupdatetype (code, description, parentid) values ('BATCH_PAYMENT_ADD',     'Records when user adds batch payment',     (select id from myupdatetype where code='BATCH_PAYMENT'));
insert into myupdatetype (code, description, parentid) values ('BATCH_PAYMENT_EDIT',     'Records when user edits batch payment',     (select id from myupdatetype where code='BATCH_PAYMENT'));
insert into myupdatetype (code, description, parentid) values ('BATCH_PAYMENT_DELETE',     'Records when user deletes batch payment',     (select id from myupdatetype where code='BATCH_PAYMENT'));
insert into myupdatetype (code, description, parentid) values ('BATCH_PAYMENT_VOID',     'Records when user void batch payment',     (select id from myupdatetype where code='BATCH_PAYMENT'));
