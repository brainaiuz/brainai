-- FAQAT AWS UCHUN
-- ONLY ON AWS
-- ТОЛьКО НА AWS
insert into "200182".genericSettings (key,value) values('PDF_HORIZONTAL_PAGE', 'YES');