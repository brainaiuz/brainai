ALTER TABLE "0".googlecalendar ALTER COLUMN googleid TYPE text;
ALTER TABLE "0".googlecalendar ALTER COLUMN token TYPE text;
ALTER TABLE "0".googlecalendar ALTER COLUMN refreshtoken TYPE text;
ALTER TABLE "0".googlecalendar ALTER COLUMN calendarid TYPE text;
ALTER TABLE "0".googlecalendar ALTER COLUMN task_calendar_id TYPE text;
ALTER TABLE "0".googlecalendar ALTER COLUMN officeUserId TYPE text;


---  private schema


ALTER TABLE "anv".googlecalendar ALTER COLUMN googleid TYPE text;
ALTER TABLE "anv".googlecalendar ALTER COLUMN token TYPE text;
ALTER TABLE "anv".googlecalendar ALTER COLUMN refreshtoken TYPE text;
ALTER TABLE "anv".googlecalendar ALTER COLUMN calendarid TYPE text;
ALTER TABLE "anv".googlecalendar ALTER COLUMN task_calendar_id TYPE text;
ALTER TABLE "anv".googlecalendar ALTER COLUMN officeUserId TYPE text;