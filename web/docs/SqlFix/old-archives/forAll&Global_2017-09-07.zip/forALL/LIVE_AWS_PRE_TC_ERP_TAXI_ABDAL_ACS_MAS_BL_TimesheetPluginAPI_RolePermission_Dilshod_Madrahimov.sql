
delete FROM permission WHERE code='TIMESHEET_PLUGIN_API';
delete FROM permission WHERE code='TIMESHEET_PLUGIN';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('TIMESHEET_PLUGIN', 'PM', 'Timesheet Plugin', 1+(select sorder from permission p where code='PM_MAIN_MENU'), false,
                (select id from permission  where modulecode='PM' and code='PM_MAIN_MENU'),
                false, 'PM');

delete from "0".rolepermission where permissioncode='TIMESHEET_PLUGIN_API';
delete from "0".rolepermission where permissioncode='TIMESHEET_PLUGIN';

insert into "0".rolepermission (permissioncode, rolecode, access) values('TIMESHEET_PLUGIN', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('TIMESHEET_PLUGIN', 'DR', 'ALLOW');

delete from "anv".rolepermission where permissioncode='TIMESHEET_PLUGIN_API';
delete from "anv".rolepermission where permissioncode='TIMESHEET_PLUGIN';

insert into "anv".rolepermission (permissioncode, rolecode, access) values('TIMESHEET_PLUGIN', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('TIMESHEET_PLUGIN', 'DR', 'ALLOW');
