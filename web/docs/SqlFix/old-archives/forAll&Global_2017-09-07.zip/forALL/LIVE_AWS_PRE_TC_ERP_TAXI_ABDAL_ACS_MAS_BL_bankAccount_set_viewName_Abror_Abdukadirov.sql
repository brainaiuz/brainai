update "0".model SET viewname = 'BankAccounts' where formid = 'BANK_ACCOUNT_FORM';
update model SET viewname = 'BankAccounts' where formid = 'BANK_ACCOUNT_FORM';

update "anv".model SET viewname = 'BankAccounts' where formid = 'BANK_ACCOUNT_FORM';
