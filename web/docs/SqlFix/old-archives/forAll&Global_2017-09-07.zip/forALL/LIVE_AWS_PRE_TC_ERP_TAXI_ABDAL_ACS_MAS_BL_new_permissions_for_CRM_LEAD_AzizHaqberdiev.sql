insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_ASSIGNEE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_ASSIGNEE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_ASSIGNEE', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_LEAD_EDIT', 'CRM', false, 'Crm Lead Edit', 3, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_EDIT', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_EDIT', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_EDIT', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_EDIT', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_EDIT', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_EDIT', 'SALESMAN','ALLOW');


insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('ADD_LEAD_NOTE', 'CRM', false, 'Lead write a note', 5, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_NOTE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_NOTE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_NOTE', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_NOTE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_NOTE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_NOTE', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('ADD_LEAD_SMS', 'CRM', false, 'Lead send SMS', 7, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_SMS', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_SMS', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_SMS', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_SMS', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_SMS', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ADD_LEAD_SMS', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_LEAD_LOOKUP', 'CRM', false, 'Lead Lookup actions', 8, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_LOOKUP', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_LOOKUP', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_LOOKUP', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_LOOKUP', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_LOOKUP', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_LOOKUP', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_LEAD_COPY', 'CRM', false, 'Copy Lead', 10, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_COPY', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_COPY', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_COPY', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_COPY', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_COPY', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_LEAD_COPY', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CHANGE_LEADS_CAMPAIGN', 'CRM', false, 'Leads campaign change', 12, (select id from permission where code ='CRM_LEADS_LIST'), false, 'LEAD_MANAGEMENT');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_CAMPAIGN', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_CAMPAIGN', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_CAMPAIGN', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_CAMPAIGN', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_CAMPAIGN', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_LEADS_CAMPAIGN', 'SALESMAN','ALLOW');