insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_COPY_OPPORTUNITIES', 'CRM', false, 'Copy Opportunity', 4, (select id from permission where code ='CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_OPPORTUNITIES', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_OPPORTUNITIES', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_OPPORTUNITIES', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_OPPORTUNITIES', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_OPPORTUNITIES', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_COPY_OPPORTUNITIES', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_ADD_OPPORTUNITY_NOTE', 'CRM', false, 'Add Note for Opportunity', 6, (select id from permission where code ='CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ADD_OPPORTUNITY_NOTE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ADD_OPPORTUNITY_NOTE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_ADD_OPPORTUNITY_NOTE', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ADD_OPPORTUNITY_NOTE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ADD_OPPORTUNITY_NOTE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_ADD_OPPORTUNITY_NOTE', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'CRM', false, 'Change Opportunity Stage', 7, (select id from permission where code ='CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CRM_OPPORTUNITY_CHANGE_STAGE', 'SALESMAN','ALLOW');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'CRM', false, 'Change Opportunities Campaign', 8, (select id from permission where code ='CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'SALESMAN','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('CHANGE_OPPORTUNITIES_CAMPAIGN', 'SALESMAN','ALLOW');