delete FROM permission WHERE code='PAYROLL_WELCOME';

UPDATE  permission set sorder=2 where sorder=1 AND modulecode='PAYROLL' and parent =(SELECT p.id from permission p WHERE p.code='PAYROLL_MAIN_MENU');

--- Payroll Welcome Page ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('PAYROLL_WELCOME', 'PAYROLL', 'Payroll Welcome',0, false,
                (select id from permission  where modulecode='PAYROLL' and code='PAYROLL_MAIN_MENU'),
                false, 'PAYROLL');



delete from "0".rolepermission where permissioncode='PAYROLL_WELCOME';

insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'PM', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'HR', 'ALLOW');


delete from "anv".rolepermission where permissioncode='PAYROLL_WELCOME';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'PM', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_WELCOME', 'HR', 'ALLOW');