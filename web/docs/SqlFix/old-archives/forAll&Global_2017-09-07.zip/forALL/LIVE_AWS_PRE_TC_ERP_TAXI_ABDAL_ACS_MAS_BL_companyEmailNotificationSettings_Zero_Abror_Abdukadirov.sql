

--for ADMINISTRATORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), true);
--for DIRECTORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), true);
--for PROJECT_MANAGERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'PROJECT_MANAGERS' AND entrytype = 2), true);
--for DEPARTMENT_LEADERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DEPARTMENT_LEADERS' AND entrytype = 2), true);
--for HRS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'HRS' AND entrytype = 2), true);
--for MEMBERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'MEMBERS' AND entrytype = 2), true);
--for ACCOUNTANTS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ACCOUNTANTS' AND entrytype = 2), true);
--for SALESMEN
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), true);
--for CUSTOMER_SERVICE_REPRESENTATIVES
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), true);
--for ONE_OFFS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ONE_OFFS' AND entrytype = 2), true);
--for SALESPERSONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL',(SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), true);
--for ADMIN_LOCATIONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), true);
--for CALENDAR_EDITORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Quote Email','SALES_QUOTE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CALENDAR_EDITORS' AND entrytype = 2), true);


--for ADMINISTRATORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), true);
--for DIRECTORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), true);
--for PROJECT_MANAGERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'PROJECT_MANAGERS' AND entrytype = 2), true);
--for DEPARTMENT_LEADERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DEPARTMENT_LEADERS' AND entrytype = 2), true);
--for HRS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'HRS' AND entrytype = 2), true);
--for MEMBERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'MEMBERS' AND entrytype = 2), true);
--for ACCOUNTANTS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ACCOUNTANTS' AND entrytype = 2), true);
--for SALESMEN
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), true);
--for CUSTOMER_SERVICE_REPRESENTATIVES
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), true);
--for ONE_OFFS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ONE_OFFS' AND entrytype = 2), true);
--for SALESPERSONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL',(SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), true);
--for ADMIN_LOCATIONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), true);
--for CALENDAR_EDITORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Order Email','SALES_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CALENDAR_EDITORS' AND entrytype = 2), true);


--for ADMINISTRATORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), true);
--for DIRECTORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), true);
--for PROJECT_MANAGERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'PROJECT_MANAGERS' AND entrytype = 2), true);
--for DEPARTMENT_LEADERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DEPARTMENT_LEADERS' AND entrytype = 2), true);
--for HRS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'HRS' AND entrytype = 2), true);
--for MEMBERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'MEMBERS' AND entrytype = 2), true);
--for ACCOUNTANTS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ACCOUNTANTS' AND entrytype = 2), true);
--for SALESMEN
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), true);
--for CUSTOMER_SERVICE_REPRESENTATIVES
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), true);
--for ONE_OFFS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ONE_OFFS' AND entrytype = 2), true);
--for SALESPERSONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL',(SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), true);
--for ADMIN_LOCATIONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), true);
--for CALENDAR_EDITORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Sales Invoice Email','SALES_INVOICE_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CALENDAR_EDITORS' AND entrytype = 2), true);


--for ADMINISTRATORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMINISTRATORS' AND entrytype = 2), true);
--for DIRECTORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DIRECTORS' AND entrytype = 2), true);
--for PROJECT_MANAGERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'PROJECT_MANAGERS' AND entrytype = 2), true);
--for DEPARTMENT_LEADERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'DEPARTMENT_LEADERS' AND entrytype = 2), true);
--for HRS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'HRS' AND entrytype = 2), true);
--for MEMBERS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'MEMBERS' AND entrytype = 2), true);
--for ACCOUNTANTS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ACCOUNTANTS' AND entrytype = 2), true);
--for SALESMEN
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESMEN' AND entrytype = 2), true);
--for CUSTOMER_SERVICE_REPRESENTATIVES
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CUSTOMER_SERVICE_REPRESENTATIVES' AND entrytype = 2), true);
--for ONE_OFFS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ONE_OFFS' AND entrytype = 2), true);
--for SALESPERSONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL',(SELECT id FROM "0".trusteegroup WHERE constantname = 'SALESPERSONS' AND entrytype = 2), true);
--for ADMIN_LOCATIONS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'ADMIN_LOCATIONS' AND entrytype = 2), true);
--for CALENDAR_EDITORS
insert into "0".companyEmailNotificationSettings(category, description, notificationname, rolegroupid, isenabled) values ('CATEGORY_ACCOUNTING','Purchase Order Email','PURCHASE_ORDER_EMAIL', (SELECT id FROM "0".trusteegroup WHERE constantname = 'CALENDAR_EDITORS' AND entrytype = 2), true);