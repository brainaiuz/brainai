
delete from permission where code='HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS';
insert into permission (code, context, name, sorder, parent, modulecode) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'HRMS', 'Add Leave Request For Others', 5, (SELECT id from permission where code='HRMS_LIVE_REQUEST'), 'LEAVE_MANAGEMENT');

delete from "0".rolepermission WHERE permissioncode='HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS';
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'HR','ALLOW');


delete from "anv".rolepermission WHERE permissioncode='HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_LEAVE_REQUESTS_ADD_FOR_OTHERS', 'HR','ALLOW');