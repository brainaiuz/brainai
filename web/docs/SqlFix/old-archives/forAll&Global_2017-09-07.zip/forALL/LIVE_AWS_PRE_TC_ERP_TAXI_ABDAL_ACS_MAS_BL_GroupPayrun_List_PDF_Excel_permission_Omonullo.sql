--PAYROLL_GROUP_PAYRUN_LIST_EXCEL
--PAYROLL_GROUP_PAYRUN_LIST_PDF

delete FROM permission WHERE code='PAYROLL_GROUP_PAYRUN_LIST_EXCEL';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
                values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'PAYROLL', 'List Excel version', 9, false,
                (select id from permission  where code='PAYROLL_GROUP_PAYRUN_LIST'),
                false, 'PAYROLL');

delete from "0".rolepermission where permissioncode='PAYROLL_GROUP_PAYRUN_LIST_EXCEL';
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'ACCOUNTANT', 'ALLOW');


delete from "anv".rolepermission where permissioncode='PAYROLL_GROUP_PAYRUN_LIST_EXCEL';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('PAYROLL_GROUP_PAYRUN_LIST_EXCEL', 'ACCOUNTANT', 'ALLOW');