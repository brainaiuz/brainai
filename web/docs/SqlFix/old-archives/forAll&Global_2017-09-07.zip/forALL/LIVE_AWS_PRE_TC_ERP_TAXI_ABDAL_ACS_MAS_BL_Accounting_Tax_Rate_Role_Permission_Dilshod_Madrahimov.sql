
delete FROM permission WHERE code='ACCOUNTING_TAX_RATES_LIST';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_TAX_RATES_LIST', 'ACCOUNTING', 'Tax Rates',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_SETTINGS_MENU'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_SETTINGS_MENU'),
  false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATES_LIST', 'PM', 'ALLOW');


--- Accounting Tax Rate Add ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_TAX_RATE_ADD', 'ACCOUNTING', 'Tax Rate Add',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'),
  false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_ADD', 'PM', 'ALLOW');


--- Accounting Tax Rate Edit ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_TAX_RATE_EDIT', 'ACCOUNTING', 'Tax Rate Edit',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'),
  false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_EDIT', 'PM', 'ALLOW');


--- Accounting Tax Rate Delete ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_TAX_RATE_DELETE', 'ACCOUNTING', 'Tax Rate Delete',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'),
  false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_DELETE', 'PM', 'ALLOW');



--- Accounting Tax Rate Summary ---
insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode)
values('ACCOUNTING_TAX_RATE_SUMMARY', 'ACCOUNTING', 'Tax Rate Summary',
(select max(sorder)+1 from permission where parent=(select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'))
, false,
  (select id from permission  where modulecode='ACCOUNTING_MODULE' and code='ACCOUNTING_TAX_RATES_LIST'),
  false, 'ACCOUNTING_MODULE');

insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'PM', 'ALLOW');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_TAX_RATE_SUMMARY', 'PM', 'ALLOW');





