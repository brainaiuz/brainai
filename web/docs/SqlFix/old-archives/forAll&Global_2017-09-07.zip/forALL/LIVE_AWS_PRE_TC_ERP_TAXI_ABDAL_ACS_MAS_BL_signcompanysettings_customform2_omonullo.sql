DELETE FROM "model"  WHERE formid = 'SIGNUP_COMPANY_SETTINGS_FORM';
DELETE FROM "modelfield"  WHERE form_id = 'SIGNUP_COMPANY_SETTINGS_FORM';

insert into model(active, formID, title, viewname) values(true, 'SIGNUP_COMPANY_SETTINGS_FORM', 'Signup Company Settings Form', 'signUpCompanySettings');
insert into modelfield(form_ID,     field_ID,                                   sorder, mandatory,  hide,   isCustomField,         section,                     defaultValue, widget, systemmandatory,             nolabelfor,                   nowrapperfor,            fullWidth, split) values
  ('SIGNUP_COMPANY_SETTINGS_FORM', 'CS_COMPANY_NAME',                        1,      false,   false,       false,   'CS_COMPANY_DETAILS',                  '',    'TextBox',    false,                     '',                            '',                   false,   false),
  ('SIGNUP_COMPANY_SETTINGS_FORM', 'LANGUAGE',                      2,      false,   false,       false,   'CS_COMPANY_DETAILS',                  '',    'DropDown',      false,                     '',                            '',                   false,   false),
('SIGNUP_COMPANY_SETTINGS_FORM', 'MESSAGE_CONTENT',                      3,      false,   false,       false,   'CS_COMPANY_DETAILS',                  '',    'TextBox',      false,                     '',                            '',                   false,   false);
