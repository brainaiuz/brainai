update "anv".modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_PROBABILITY';
update "anv".modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_STAGE';
update "anv".modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_EXPECTED_REVENUE';
update "anv".modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_AMOUNT';

update modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_PROBABILITY';
update modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_STAGE';
update modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_EXPECTED_REVENUE';
update modelfield SET disableupdate = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_AMOUNT';