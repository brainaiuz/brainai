delete FROM modelfield where form_id = 'LEAVE_REQUEST_FORM' and field_id = 'TAKE_LIVE_TYPE';
delete FROM modelfield where form_id = 'LEAVE_REQUEST_FORM' and field_id = 'CONFIRM_DATE';