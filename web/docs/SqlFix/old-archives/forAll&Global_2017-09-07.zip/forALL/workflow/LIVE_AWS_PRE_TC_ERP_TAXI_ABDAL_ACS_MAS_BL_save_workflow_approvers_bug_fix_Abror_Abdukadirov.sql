-----------------------------------------------------------------------------------------------------------
--|                                                                                                     |--
--|                                                                                                     |--
--|           Bu query faqat so'ralgan companyga execute qilinadi                                       |--
--|            va execute qilingandan kiyin schemaUpdate qilinishi shart                                |--
--|                                                                                                     |--
----------------------------------------------------------------------------------------------------------


---------------------------------------Bu function bir marta execute qilinadi-----------------------------
CREATE OR REPLACE FUNCTION first_element_state(anyarray, anyelement)
  RETURNS anyarray AS
$$
    SELECT CASE WHEN array_upper($1,1) IS NULL THEN array_append($1,$2) ELSE $1 END;
$$
  LANGUAGE 'sql' IMMUTABLE;

CREATE OR REPLACE FUNCTION first_element(anyarray)
  RETURNS anyelement AS
$$
    SELECT ($1)[1] ;
$$
  LANGUAGE 'sql' IMMUTABLE;

CREATE OR REPLACE FUNCTION last_element(anyelement, anyelement)
  RETURNS anyelement AS
$$
    SELECT $2;
$$
  LANGUAGE 'sql' IMMUTABLE;

CREATE AGGREGATE first(anyelement) (
  SFUNC=first_element_state,
  STYPE=anyarray,
  FINALFUNC=first_element
  )
;

CREATE AGGREGATE last(anyelement) (
  SFUNC=last_element,
  STYPE=anyelement
);
---------------------------------------Bu function bir marta execute qilinadi-----------------------------



---==========================Approver roles=============================

CREATE TABLE "20068".approver_roles_new AS
SELECT id, last(approver_id order by id) approver_id, last(role_id order by id) role_id, last(approveforall) approveforall FROM "20068".approver_roles WHERE id is not null GROUP BY id;

DROP TABLE  "20068".approver_roles;

CREATE TABLE "20068".approver_roles AS
SELECT * FROM "20068".approver_roles_new;

DROP TABLE "20068".approver_roles_new;

ALTER TABLE "20068".approver_roles ALTER COLUMN id SET NOT NULL, ADD CONSTRAINT approver_roles_pkey PRIMARY KEY (id);

DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1
                FROM   pg_class c
                JOIN   pg_namespace n ON n.oid = c.relnamespace
                WHERE  c.relname = 'approver_roles_id_seq'
                AND    n.nspname = '20068'
        ) THEN
            CREATE SEQUENCE "20068".approver_roles_id_seq;
    END IF;
END$$;

DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1
                FROM information_schema.columns
                WHERE table_schema='20068'
                and table_name='approver_roles'
                and column_name='id'
        ) THEN
		      ALTER TABLE "20068".approver_roles ADD COLUMN id integer NOT NULL DEFAULT nextval('"20068".approver_roles_id_seq'::regclass);
        ELSE
          ALTER TABLE "20068".approver_roles ALTER COLUMN id SET DEFAULT nextval('"20068".approver_roles_id_seq'::regclass);
	      END IF;
END$$;

SELECT setval('"20068".approver_roles_id_seq', (select max(id) from "20068".approver_roles));


---==========================Approver employees=============================


CREATE TABLE "20068".approver_employees_new AS
SELECT id, last(approver_id order by id) approver_id, last(employee_id order by id) employee_id, last(approveforall) approveforall FROM "20068".approver_employees WHERE id is not null GROUP BY id;

DROP TABLE  "20068".approver_employees;

CREATE TABLE "20068".approver_employees AS
SELECT * FROM "20068".approver_employees_new;

DROP TABLE "20068".approver_employees_new;

ALTER TABLE "20068".approver_employees ALTER COLUMN id SET NOT NULL, ADD CONSTRAINT approver_employees_pkey PRIMARY KEY (id);

DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1
                FROM   pg_class c
                JOIN   pg_namespace n ON n.oid = c.relnamespace
                WHERE  c.relname = 'approver_employees_id_seq'
                AND    n.nspname = '20068'
        ) THEN
            CREATE SEQUENCE "20068".approver_employees_id_seq;
    END IF;
END$$;

DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1
                FROM information_schema.columns
                WHERE table_schema='20068'
                and table_name='approver_employees'
                and column_name='id'
        ) THEN
		      ALTER TABLE "20068".approver_employees ADD COLUMN id integer NOT NULL DEFAULT nextval('"20068".approver_employees_id_seq'::regclass);
        ELSE
          ALTER TABLE "20068".approver_employees ALTER COLUMN id SET DEFAULT nextval('"20068".approver_employees_id_seq'::regclass);
	      END IF;
END$$;

SELECT setval('"20068".approver_employees_id_seq', (select max(id) from "20068".approver_employees));