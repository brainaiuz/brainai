insert into "0".modelfield(form_ID, field_ID, sorder, widget, source, usableByWorkflow, type, disableUpdate, section) values
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_SICK_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_STUDY_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_ANNUAL_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_LATE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_SPECIAL', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_UNAUTHORIZED_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_OTHER_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION');

insert into modelfield(form_ID, field_ID, sorder, widget, source, usableByWorkflow, type, disableUpdate, section) values
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_SICK_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_STUDY_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_ANNUAL_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_LATE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_SPECIAL', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_UNAUTHORIZED_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION'),
('HRMS_EMPLOYEE_FORM', 'LR_TYPE_OTHER_LEAVE', 1000, 'TextBox', null, true,	'Number', false, 'EMPLOYMENT_INFORMATION');