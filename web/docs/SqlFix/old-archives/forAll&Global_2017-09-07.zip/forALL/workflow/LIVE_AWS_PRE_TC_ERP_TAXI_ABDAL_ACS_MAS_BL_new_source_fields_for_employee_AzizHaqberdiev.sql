update modelfield set widget = 'DropDown', usableByWorkflow = true, source = 'HRMS@POSITION' where field_id = 'POSITION' and form_id = 'HRMS_EMPLOYEE_FORM';
update modelfield set widget = 'DropDown', usableByWorkflow = true, source = 'HRMS@LOCATION' where field_id = 'LOCATION' and form_id = 'HRMS_EMPLOYEE_FORM';

update "0".modelfield set widget = 'DropDown', usableByWorkflow = true, source = 'HRMS@POSITION' where field_id = 'POSITION' and form_id = 'HRMS_EMPLOYEE_FORM';
update "0".modelfield set widget = 'DropDown', usableByWorkflow = true, source = 'HRMS@LOCATION' where field_id = 'LOCATION' and form_id = 'HRMS_EMPLOYEE_FORM';

update "anv".modelfield set widget = 'DropDown', usableByWorkflow = true, source = 'HRMS@POSITION' where field_id = 'POSITION' and form_id = 'HRMS_EMPLOYEE_FORM';
update "anv".modelfield set widget = 'DropDown', usableByWorkflow = true, source = 'HRMS@LOCATION' where field_id = 'LOCATION' and form_id = 'HRMS_EMPLOYEE_FORM';