delete from model  where formid = 'CASH_ADVANCE_FORM';
delete from modelfield where form_ID = 'CASH_ADVANCE_FORM';

insert into model(active,formID, title,viewname) values(true,'CASH_ADVANCE_FORM', 'Cash Advance Form','Cash Advance');

insert into modelfield(form_ID,             field_ID,                 sorder, widget,     source,                              usableByWorkflow, type,     disableUpdate, isWorkflowAttribute) values
                      ('CASH_ADVANCE_FORM', 'DATE',                   1,   'DatePicker', null,                                 true,	            'text', true,           false),
                      ('CASH_ADVANCE_FORM', 'DESCRIPTION',            2,   'TextBox',    null,                                 true,	            'text', true,           false),
                      ('CASH_ADVANCE_FORM', 'STATUS',                 3,   'TextBox',   null,                                   true,	            'text', true,           true),
                      ('CASH_ADVANCE_FORM', 'CATEGORY',               4,   'DropDown', 'PAYROLL@CASH_ADVANCE_CATEGORY',        true,	            'text', true,           false),
                      ('CASH_ADVANCE_FORM', 'REQUESTED_AMOUNT',       5,   'TextBox',  null,                                   true,	            'text', true,           false),
                      ('CASH_ADVANCE_FORM', 'REQUESTER',              6,   'DropDown',  'PAYROLL@CASH_ADVANCE_REQUESTER',      true,	            'text', true,           false),
                      ('CASH_ADVANCE_FORM', 'PAYMENT_METHOD',         7,   'TextBox',  null,                                    true,	            'text', true,           false),
                      ('CASH_ADVANCE_FORM', 'PREV_APPROVER',          8,    null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'PREV_APPROVER_EMAIL',    9,    null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'PREV_APPROVER_STATUS',   10,   null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'CURRENT_APPROVER',       11,   null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'CURRENT_APPROVER_EMAIL', 12,   null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'CURRENT_APPROVER_STATUS',13,   null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'NEXT_APPROVER',          14,   null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'NEXT_APPROVER_EMAIL',    15,   null,       null,                                   true,	            null,   true,           true),
                      ('CASH_ADVANCE_FORM', 'NEXT_APPROVER_STATUS',   16,   null,       null,                                   true,	            null,   true,           true);
