update modelfield set usablebyworkflow = true where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';
update modelfield set widget = 'DatePicker' where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';
update modelfield set type = 'Date' where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';

update "anv".modelfield set usablebyworkflow = true where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';
update "anv".modelfield set widget = 'DatePicker' where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';
update "anv".modelfield set type = 'Date' where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';

update "0".modelfield set usablebyworkflow = true where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';
update "0".modelfield set widget = 'DatePicker' where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';
update "0".modelfield set type = 'Date' where form_id = 'HRMS_EMPLOYEE_FORM' and field_id = 'BIRTH_DAY';