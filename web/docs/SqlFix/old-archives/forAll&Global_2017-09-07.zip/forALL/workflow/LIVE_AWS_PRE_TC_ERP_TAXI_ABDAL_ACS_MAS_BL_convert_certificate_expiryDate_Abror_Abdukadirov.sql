update "31287".certificatetype SET expirydatesorder = 1 where name = 'NORMA';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'NORMS';
update "31287".certificatetype SET expirydatesorder = 10 where name = 'PLANT OPERATOR PERMIT';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'RIGGER AND BANKSMAN';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'BREATHING APPARATUS AUTHORISED USER';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'AUTHORISED GAS TESTER';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'H2S AND SO2 ENTRY PERMIT';
update "31287".certificatetype SET expirydatesorder = 12 where name = 'HSE TRAINING CARD';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'SUPERVISOR LIFTING OPERATIONS';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'SCAFFOLD INSPECTOR';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'LIFTING_EQUIPMENT';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'SAFETY LEADERSHIP FOR SUPERVISORS';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'FIRST AIDER';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'DEFENSIVE DRIVING';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'FIRE WARDEN';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'AUTHORISED GAS TESTER AUTHORISATION';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'H2S AND SO2 AWARENESS AND ESCAPE';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'Rusayl Lifting and handling';
update "31287".certificatetype SET expirydatesorder = 1 where name = 'OCC first aid awareness';

DROP FUNCTION IF EXISTS "31287".update_certificate_table();
CREATE OR REPLACE FUNCTION "31287".update_certificate_table()
  RETURNS INTEGER AS
  $BODY$
    DECLARE
      crt record;
      BEGIN
          FOR crt IN (SELECT * FROM "31287".certificate)
          LOOP
            BEGIN
            UPDATE "31287".certificate SET expirydate = (
                      SELECT to_date((SELECT i.values FROM "31287".certificateitem i
                                                      LEFT JOIN "31287".certificate c ON i.certificate_id = c.id
                                                      LEFT JOIN "31287".certificateType t ON c.certificatetypeid = t.id
                                                      WHERE t.expirydatesorder = i.sorder
                                                      AND t.fieldcount = (
                                                                          SELECT COUNT(i.id) FROM "31287".certificateitem i
                                                                          LEFT JOIN "31287".certificate c ON i.certificate_id = c.id
                                                                          LEFT JOIN "31287".certificateType t ON c.certificatetypeid = t.id
                                                                          WHERE i.certificate_id = crt.id
                                                                          )
                                                      AND i.certificate_id = crt.id),
                      'DD/MM/YY')
            ) WHERE id = crt.id;

            EXCEPTION WHEN OTHERS THEN

            END;
      END LOOP;
      RETURN NULL;
    END;
  $BODY$
LANGUAGE plpgsql;
ALTER FUNCTION "31287".update_certificate_table() OWNER TO wfmtest;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "31287".update_certificate_table()) IS NOT NULL;