DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT 1
                FROM   "anv".approvers a                
                WHERE  a.entityType = 'CASH_ADVANCE'
        ) THEN
              DROP function if EXISTS "anv".createDefaultApproversForCashAdvance();
              CREATE OR replace function "anv".createDefaultApproversForCashAdvance()
                returns INTEGER AS
                $body$
              DECLARE
                  approverID INTEGER;
                  approvedWorkflowID INTEGER;
                  rejectedWorkflowID INTEGER;
                  cashAdvance_approver_id INTEGER;
                  ca record;

                  BEGIN
                    --create approver item in "anv".approvers table
                    insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'CASH_ADVANCE', true, 5, 3) RETURNING id INTO approverID;
                    --create approvers_role rows.!!!!!!!!!
                    insert into "anv".approver_roles(approver_id, role_id) (select approverID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
                    --create workflows for approval1
                    insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_CASH_ADVANCE', false) RETURNING id into approvedWorkflowID;
                    insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_CASH_ADVANCE', false) RETURNING id INTO rejectedWorkflowID;
                    --set workflowids to the approver
                    update "anv".approvers set workflow=approvedWorkflowID, rejected_workflow=rejectedWorkflowID where id=approverID;
                  return NULL;
                  END;
              $body$
              LANGUAGE plpgsql;
              ALTER function "anv".createDefaultApproversForCashAdvance() owner TO wfmtest;
              UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".createDefaultApproversForCashAdvance()) IS NOT NULL;
    END IF;
END$$;