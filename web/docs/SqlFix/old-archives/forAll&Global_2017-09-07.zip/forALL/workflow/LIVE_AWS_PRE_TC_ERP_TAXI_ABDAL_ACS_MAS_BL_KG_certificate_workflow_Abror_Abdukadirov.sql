insert into "0".reference (code, name, sorder, parentid) values
('_WORKFLOW_MODULE_CERTIFICATE', 'Certificate', (select max(sorder) from "0".reference where parentid = (select id from "0".reference where code = '_WORKFLOW_MODULE')),
(select id from "0".reference where code = '_WORKFLOW_MODULE'));

insert into "anv".reference (code, name, sorder, parentid) values
('_WORKFLOW_MODULE_CERTIFICATE', 'Certificate', (select max(sorder) from "anv".reference where parentid = (select id from "anv".reference where code = '_WORKFLOW_MODULE')),
(select id from "anv".reference where code = '_WORKFLOW_MODULE'));


insert into model(active,formID, title,viewname) values(true,'CERTIFICATE_FORM', 'Certificate Form', 'Certificate');
insert into modelfield(form_ID,             field_ID,       sorder,  isCustomField,   widget,       source,    type,   usableByWorkflow, disableupdate) values
                      ('CERTIFICATE_FORM',  'EXPIRY_DATE',  4,       false,           'DatePicker', null,      'Date', true,             true);

