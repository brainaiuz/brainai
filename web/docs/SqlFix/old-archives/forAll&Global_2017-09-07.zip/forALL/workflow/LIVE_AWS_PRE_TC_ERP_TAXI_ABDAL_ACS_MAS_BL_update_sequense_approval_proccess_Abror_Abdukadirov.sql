DO $$
    BEGIN
        IF NOT EXISTS (
            SELECT id FROM company WHERE id = anv
        ) THEN
            PERFORM setval('"anv".approvers_id_seq', (select max(id) from "anv".approvers));
        END IF;
END$$;