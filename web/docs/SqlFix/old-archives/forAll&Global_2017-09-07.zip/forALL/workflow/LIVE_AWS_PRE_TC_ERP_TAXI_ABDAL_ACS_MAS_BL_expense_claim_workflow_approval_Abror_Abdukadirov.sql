
insert into "anv".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_EXPENSE_CLAIM', false, true, 'Expense Claim', true, 6, (select id from "anv".reference where code='_WORKFLOW_MODULE'), true);

insert into "0".reference(code, deleted, isremovable, name, shared, sorder, parentid, isactive)
							values('_WORKFLOW_MODULE_EXPENSE_CLAIM', false, true, 'Expense Claim', true, 6, (select id from "0".reference where code='_WORKFLOW_MODULE'), true);


insert into model(active, formid, title, viewname) values(true, 'EXPENSE_CLAIM_FORM', 'Expense Claim Form', 'Expense Claim');

insert into modelfield(form_ID, 				      field_ID, 	 						sorder, widget , 				source, 													    usableByWorkflow, 	  type, 		disableUpdate, isWorkflowAttribute) values
											('EXPENSE_CLAIM_FORM', 'DATE',        					 1,			'DatePicker', 	null,  														    true,								  'Date',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'STATUS',								 2, 		'DropDown', 		'ACCOUNTING@EXPENSE_CLAIM_STATUS',    true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'REPORTER',							 2, 		'DropDown', 		'ACCOUNTING@EXPENSE_CLAIM_REPORTER'   ,true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'REPORT_TITLE',					 2,     'TextBox', 		  null,                                 true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'FIXED_ASSET',						 2,     'DropDown', 		'ACCOUNTING@EXPENSE_CLAIM_FIXED_ASSET',true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'DESCRIPTION',						 2,     'TextBox', 		  null,                                 true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'NUMBER',						     2,     'TextBox', 		  null,                                 true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'PROJECT',						     2,     'DropDown', 		'ACCOUNTING@EXPENSE_CLAIM_PROJECT',   true, 							  'Text',	  true,          false),
											('EXPENSE_CLAIM_FORM', 'PREV_APPROVER',					 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'PREV_APPROVER_EMAIL',		 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'PREV_APPROVER_STATUS',	 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'CURRENT_APPROVER',			 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'CURRENT_APPROVER_EMAIL', 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'CURRENT_APPROVER_STATUS',2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'NEXT_APPROVER',					 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'NEXT_APPROVER_EMAIL',		 2, 		 null, 	        null,                                 true, 								null,	    true,          true),
											('EXPENSE_CLAIM_FORM', 'NEXT_APPROVER_STATUS',	 2, 		 null, 	        null,                                 true, 								null,	    true,          true);


---
--================================Approval Process========================================
---
DROP function if EXISTS "anv".createExpenseClaimDefaultApprovers();
CREATE OR replace function "anv".createExpenseClaimDefaultApprovers()
  returns INTEGER AS
  $body$
DECLARE
    approverID INTEGER;
    approver2ID INTEGER;
    approved1WorkflowID INTEGER;
    rejected1WorkflowID INTEGER;
    approved2WorkflowID INTEGER;
    rejected2WorkflowID INTEGER;
    expense_approver_id1 INTEGER;
    expense_approver_id2 INTEGER;
    result1 INTEGER;
    result2 INTEGER;
    resultStatusid INTEGER;
    resultStatus2id INTEGER;
    er record;

    BEGIN
        IF EXISTS (select "value" from "anv".genericSettings where "key" ='EXPENSE_DOUBLE_APPROVER_ENABLED') AND (select "value" from "anv".genericSettings where "key" ='EXPENSE_DOUBLE_APPROVER_ENABLED') = 'YES'
        THEN
          --two level approval here
          --create approver item in "anv".approvers table
          insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'EXPENSE_CLAIM', true, 1, 3) RETURNING id INTO approverID;
          insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (2, 'EXPENSE_CLAIM', true, 1, 3) RETURNING id INTO approver2ID;
          --create approvers_role rows.!!!!!!!!!
          insert into "anv".approver_roles(approver_id, role_id) (select approverID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
          insert into "anv".approver_roles(approver_id, role_id) (select approver2ID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
          --create workflows for approval1
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id into approved1WorkflowID;
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id INTO rejected1WorkflowID;
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id into approved2WorkflowID;
          insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id INTO rejected2WorkflowID;
          --set workflowids to the approver
          update "anv".approvers set workflow=approved1WorkflowID, rejected_workflow=rejected1WorkflowID where id=approverID;
          update "anv".approvers set workflow=approved2WorkflowID, rejected_workflow=rejected2WorkflowID where id=approver2ID;
          --create workflow alert on actions
          INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Declined your Expense Claim', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /> <p>Please be advised that ${current_approver} has declined your Expense Claims on ${decline_date}. You can review ${current_approver} ''s comments, and make the appropriate changes and resubmit the report.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view and edit the Expense Claims.</p> <p>${rejection_note}</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
          INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Declined your Expense Claim', '', '', null,rejected2WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /> <p>Please be advised that ${current_approver} has declined your Expense Claims on ${decline_date}. You can review ${current_approver} ''s comments, and make the appropriate changes and resubmit the report.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view and edit the Expense Claims.</p> <p>${rejection_note}</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
          INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Approved your Expense Claim', '', '', null,approved2WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /><p>Please be advised that ${current_approver} has approved your Expense Claims, ${report_title} on ${date}.</p> <p>The PDF version of the Expense Claims is attached for your attention.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view the Expense Claims.</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
          --create approvers for every "anv".expenseReport
          FOR er IN (SELECT * FROM "anv".expenseReport)
          LOOP
              result1 = er.approverID;
              result2 = er.approver2id;
              resultStatusid = er.statusId;
              resultStatus2id = er.status2Id;

              IF er.approver2id IS NULL THEN
                result2 = er.approverID;
                resultStatus2id = er.statusId;
              END IF;

              --create new item in approvers
                INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
                values (1, 'EXPENSE_CLAIM', er.id, false, 1, 2,approved1WorkflowID, rejected1WorkflowID,result1,resultStatusid) RETURNING id INTO expense_approver_id1;
                --create new item in approvers
                INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
                values (2, 'EXPENSE_CLAIM', er.id, false, 1, 2,approved2WorkflowID, rejected2WorkflowID,result2,resultStatus2id) RETURNING id INTO expense_approver_id2;
                -- update current expenseReport with new approver item.
                update "anv".expenseReport a set currentapprover=expense_approver_id2, prevapprover=expense_approver_id1, overallstatus=a.statusid where id = er.id;

          END LOOP;
        ELSE
            --one level approval here
            --create approver item in "anv".approvers table
            insert into "anv".approvers(approver_order, entitytype, is_default, onapprovedaction, onrejectedaction) values (1, 'EXPENSE_CLAIM', true, 1, 3) RETURNING id INTO approverID;
            --create approvers_role rows.!!!!!!!!!
            insert into "anv".approver_roles(approver_id, role_id) (select approverID, r.id from "anv".role r where code in ('ADMIN','DR','HR'));
            --create workflows for approval1
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id into approved1WorkflowID;
            insert into "anv".workflowrule(executioncriteria, module,showinlist) values('_WORKFLOW_ACTION_APPROVING', '_WORKFLOW_MODULE_EXPENSE_CLAIM', false) RETURNING id INTO rejected1WorkflowID;
            --set workflowids to the approver
            update "anv".approvers set workflow=approved1WorkflowID, rejected_workflow=approved2WorkflowID where id=approverID;
            --create workflow alert on actions
            INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Declined your Expense Claim', '', '', null,rejected1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /> <p>Please be advised that ${current_approver} has declined your Expense Claims on ${decline_date}. You can review ${current_approver} ''s comments, and make the appropriate changes and resubmit the report.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view and edit the Expense Claims.</p> <p>${rejection_note}</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
            INSERT INTO "anv".workflow_alerts (deleted, extrakeyvalues, recepient, replyto, subject, tobcc, ccemails, emailtemplateid, workflow, workflowactionstarttimeunit, workflowactionstarttime, workflowactionstarttimegranularity, isworkflowactiontimebased, fromuserid, fromusername, content) VALUES (false, null, '${current_approver_email}', null, 'Approved your Expense Claim', '', '', null,approved1WorkflowID, 0, 'TRIGGER_TIME', 'MINUTES', false, -1, null, '<p>Dear ${reporter},</p><br /><p>Please be advised that ${current_approver} has approved your Expense Claims, ${report_title} on ${date}.</p> <p>The PDF version of the Expense Claims is attached for your attention.</p> <p>Click <a href="${link}" title="Edit Expense Claims" target="_blank">here </a> to view the Expense Claims.</p> <p><font color=''red''>* </font>If you are not able to click on the link, you can copy and paste the following address into your web browser:<br /> ${link}</p> <p></p>');
            --create approvers for every "anv".expenseReport
            FOR er IN (SELECT * FROM "anv".expenseReport)
            LOOP
                INSERT INTO "anv".approvers(approver_order, entitytype, entity_id, is_default, onapprovedaction, onrejectedaction,workflow, rejected_workflow,exactapprover,status)
                values (1, 'EXPENSE_CLAIM', er.id, false, 1, 2,approved1WorkflowID, rejected1WorkflowID,er.approverID,er.statusId) RETURNING id INTO expense_approver_id1;
                -- update current expenseReport with new approver item.
                update "anv".expenseReport a set currentapprover=expense_approver_id1, prevapprover=expense_approver_id1, overallstatus=a.statusid where id = er.id;
            END LOOP;
        END IF;
    return NULL;
    END;
$body$
LANGUAGE plpgsql;
ALTER function "anv".createExpenseClaimDefaultApprovers() owner TO wfmtest;
UPDATE company SET isdeleted = FALSE WHERE isdeleted IS NULL AND (select "anv".createExpenseClaimDefaultApprovers()) IS NOT NULL;

