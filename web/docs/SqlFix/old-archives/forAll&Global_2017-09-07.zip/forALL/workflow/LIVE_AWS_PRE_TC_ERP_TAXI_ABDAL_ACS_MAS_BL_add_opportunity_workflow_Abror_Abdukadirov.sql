insert into "anv".reference(code,                    deleted, isremovable, name,        shared, sorder, parentid,                                                       isactive)
							values('_WORKFLOW_MODULE_OPPORTUNITY', false,   true,       'Opportunity', true,  3,      (select id from "anv".reference where code='_WORKFLOW_MODULE'), true);

insert into "0".reference(code,                      deleted, isremovable, name,          shared, sorder, parentid,                                                     isactive)
							values('_WORKFLOW_MODULE_OPPORTUNITY', false,   true,        'Opportunity', true,   3,      (select id from "0".reference where code='_WORKFLOW_MODULE'), true);

update modelfield set source = 'CRM@OPPORTUNITY_ASSIGNEE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_ASSIGNEE';
update modelfield set source = 'CRM@OPPORTUNITY_BACKUP_ASSIGNEE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_BACKUP_ASSIGNEE';
update modelfield set source = 'CRM@ACCOUNT', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_ACCOUNT_NAME';
update modelfield set source = 'CRM@CONTACT', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_CONTACT_NAME';
update modelfield set source = 'CRM@OPPORTUNITY_TYPE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_TYPE';
update modelfield set source = 'CRM@OPPORTUNITY_STAGE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_STAGE';
update modelfield set source = 'CRM@CAMPAIGN', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_CAMPAIGN_SOURCE';
update modelfield set source = 'CRM@OPPORTUNITY_LEAD_SOURCE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_LEAD_SOURCE';


update "anv".modelfield set source = 'CRM@OPPORTUNITY_ASSIGNEE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_ASSIGNEE';
update "anv".modelfield set source = 'CRM@OPPORTUNITY_BACKUP_ASSIGNEE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_BACKUP_ASSIGNEE';
update "anv".modelfield set source = 'CRM@ACCOUNT', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_ACCOUNT_NAME';
update "anv".modelfield set source = 'CRM@CONTACT', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_CONTACT_NAME';
update "anv".modelfield set source = 'CRM@OPPORTUNITY_TYPE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_TYPE';
update "anv".modelfield set source = 'CRM@OPPORTUNITY_STAGE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_STAGE';
update "anv".modelfield set source = 'CRM@CAMPAIGN', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_CAMPAIGN_SOURCE';
update "anv".modelfield set source = 'CRM@OPPORTUNITY_LEAD_SOURCE', usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_LEAD_SOURCE';


update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_NUMBER';
update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_NAME';
update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_NEXT_STEP';
update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_AMOUNT';
update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_CLOSING_DATE';
update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_PROBABILITY';
update modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_EXPECTED_REVENUE';

update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_NUMBER';
update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_NAME';
update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_NEXT_STEP';
update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_AMOUNT';
update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_CLOSING_DATE';
update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_PROBABILITY';
update "anv".modelfield set usableByWorkflow = true where form_id = 'OPPORTUNITY_FORM' and field_id = 'CRM_OPPORTUNITY_EXPECTED_REVENUE';