update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'BANK_NAME';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_NUMBER';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_NAME';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'BANK_ADDRESS';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SWIFT_CODE';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SORT_CODE';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'IBAN_CODE';
update modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'AGENT_ID';

update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'BANK_NAME';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_NUMBER';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_NAME';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'BANK_ADDRESS';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SWIFT_CODE';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SORT_CODE';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'IBAN_CODE';
update "0".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'AGENT_ID';

update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'BANK_NAME';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_NUMBER';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'ACCOUNT_NAME';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'BANK_ADDRESS';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SWIFT_CODE';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'SORT_CODE';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'IBAN_CODE';
update "anv".modelfield set usableByWorkflow = true,type='Text' where form_id = 'HRMS_EMPLOYEE_FORM' AND field_id = 'AGENT_ID';