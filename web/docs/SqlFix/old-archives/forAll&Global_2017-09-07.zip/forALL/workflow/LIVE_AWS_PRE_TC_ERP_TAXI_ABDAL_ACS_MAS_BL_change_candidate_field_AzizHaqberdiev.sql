update modelfield set usableByworkflow = true, widget = 'FileUploadWidget' where field_id = 'ATTACHMENTS' and form_id = 'CANDIDATE_FORM';
update "0".modelfield set usableByworkflow = true, widget = 'FileUploadWidget' where field_id = 'ATTACHMENTS' and form_id = 'CANDIDATE_FORM';

update modelfield set usableByworkflow = true where widget in ('FileUploadWidget', 'FileUploadItem');
update "0".modelfield set usableByworkflow = true where widget in ('FileUploadWidget', 'FileUploadItem');

update "anv".modelfield set usableByworkflow = true, widget = 'FileUploadWidget' where field_id = 'ATTACHMENTS' and form_id = 'CANDIDATE_FORM';
update "anv".modelfield set usableByworkflow = true where widget in ('FileUploadWidget', 'FileUploadItem');
