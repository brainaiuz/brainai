--for public schema
insert into model(active,formID, title,viewname) values(true,'PAYROLL_CASH_ADVANCE_FORM', 'Cash Advance Form','Cash Advance');

insert into modelfield(form_ID,     field_ID, usableByWorkflow, source, widget) values
('PAYROLL_CASH_ADVANCE_FORM', 'STATUS',  true, 'REFERENCE@CASH_ADVANCE_STATUS', 'LOOKUP');

--for zero schema
insert into "0".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CASH_ADVANCE', 'CashAdvance', 9, (select id from "0".reference where code = '_WORKFLOW_MODULE'));


--for all
insert into "anv".reference (code, name, sorder, parentid)
values ('_WORKFLOW_MODULE_CASH_ADVANCE', 'CashAdvance', 9, (select id from "anv".reference where code = '_WORKFLOW_MODULE'));

