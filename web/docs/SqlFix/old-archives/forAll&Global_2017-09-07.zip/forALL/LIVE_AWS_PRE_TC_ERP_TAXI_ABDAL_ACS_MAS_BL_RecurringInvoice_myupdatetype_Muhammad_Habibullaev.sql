insert into myupdatetype (code, description) values ('RECURRING_INVOICE','All recurrings invoice related updates');

insert into myupdatetype (code, description, parentid) values
	('RECURRING_INVOICE_ADD','Records when user has add recurring invoice', (select id  from myupdatetype where code = 'RECURRING_INVOICE')),
	('RECURRING_INVOICE_EDIT','Records when user has edited recurring invoice', (select id  from myupdatetype where code = 'RECURRING_INVOICE')),
	('RECURRING_INVOICE_DELETE','Records when user has deleted recurring invoice', (select id  from myupdatetype where code = 'RECURRING_INVOICE'));
