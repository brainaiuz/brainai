
insert into "0".reference (code,name,sorder,parentid,isremovable,issystemreference,deleted,shared,iscustombutton)
values ('OFFICE_365_SHARE_POINT', 'Office_365 share point type',5,(select id from "0".reference where code='_UPLOAD_TYPE'),false,true,false,true,false);



insert into "anv".reference (code,name,sorder,parentid,isremovable,issystemreference,deleted,shared,iscustombutton)
values ('OFFICE_365_SHARE_POINT', 'Office_365 share point type',5,(select id from "anv".reference where code='_UPLOAD_TYPE'),false,true,false,true,false);