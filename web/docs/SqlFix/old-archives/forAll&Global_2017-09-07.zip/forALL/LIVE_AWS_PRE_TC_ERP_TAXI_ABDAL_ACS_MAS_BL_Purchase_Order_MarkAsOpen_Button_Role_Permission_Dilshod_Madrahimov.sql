delete from permission where code = 'ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON';

insert into permission (code, context, name, sorder, ismainmenu, parent, iscore, modulecode) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ACCOUNTING', 'Purchase Order Mark As Open Button', '8', 'false', (select id from permission where code='ACCOUNTING_PURCHASE_ORDER_LIST'), 'false', 'ACCOUNTING_MODULE');

--- for private scheme ---
delete from "anv".rolepermission where permissioncode = 'ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON';
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ADMIN', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'DR', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'CLIENT', 'ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'SALESMAN', 'ALLOW');


--- for ZERO schema --
delete from "0".rolepermission where permissioncode = 'ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON';
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ADMIN', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'DR', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'ACCOUNTANT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'CLIENT', 'ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('ACCOUNTING_PURCHASE_ORDER_MARK_AS_OPEN_BUTTON', 'SALESMAN', 'ALLOW');


