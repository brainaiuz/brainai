alter table "anv".adjustment_item alter column currentQty type numeric(19,2);
alter table "anv".adjustment_item alter column newQty type numeric(19,2);
alter table "anv".adjustment_item alter column qty type numeric(19,2);