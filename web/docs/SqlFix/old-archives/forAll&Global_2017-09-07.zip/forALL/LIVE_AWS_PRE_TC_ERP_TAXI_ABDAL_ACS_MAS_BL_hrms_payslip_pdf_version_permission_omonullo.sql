



delete from permission where code = 'HRMS_PAYSLIP_PDF';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
values ('HRMS_PAYSLIP_PDF', 'HRMS', false, 'Payslip PDF Version', 40, (select id from permission where code = 'HRMS_CURENT_EMPLOYEE_PROFILE_TAB'), false, 'HRMS_MODULE');

delete from "anv".rolepermission where permissioncode = 'HRMS_PAYSLIP_PDF';

insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_PAYSLIP_PDF','DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_PAYSLIP_PDF','ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode,access) values('HRMS_PAYSLIP_PDF','HR','ALLOW');

delete from "0".rolepermission where permissioncode = 'HRMS_PAYSLIP_PDF';

insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_PAYSLIP_PDF','DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_PAYSLIP_PDF','ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode,access) values('HRMS_PAYSLIP_PDF','HR','ALLOW');