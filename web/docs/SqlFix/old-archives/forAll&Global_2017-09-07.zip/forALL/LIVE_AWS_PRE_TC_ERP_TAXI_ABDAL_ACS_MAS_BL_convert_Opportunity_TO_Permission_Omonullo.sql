delete
from "anv".rolepermission
where permissioncode = 'CONVERT_OPPORTUNITY_TO_SQ';

delete
from permission  where code = 'CONVERT_OPPORTUNITY_TO_SQ';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('CONVERT_OPPORTUNITY_TO_SQ',   'CRM', false, 'Convert Opportunity to SQ', 10, (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_SQ', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_SQ', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_SQ', 'ALLOW', 'SALESMAN');


delete
from "anv".rolepermission
where permissioncode = 'CONVERT_OPPORTUNITY_TO_SO';

delete
from permission  where code = 'CONVERT_OPPORTUNITY_TO_SO';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('CONVERT_OPPORTUNITY_TO_SO',   'CRM', false, 'Convert Opportunity to SO', 10, (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_SO', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_SO', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_SO', 'ALLOW', 'SALESMAN');

delete
from "anv".rolepermission
where permissioncode = 'CONVERT_OPPORTUNITY_TO_PROJECT';

delete
from permission  where code = 'CONVERT_OPPORTUNITY_TO_PROJECT';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('CONVERT_OPPORTUNITY_TO_PROJECT',   'CRM', false, 'Convert Opportunity to Project', 10, (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_PROJECT', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_PROJECT', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_PROJECT', 'ALLOW', 'SALESMAN');

delete
from "anv".rolepermission
where permissioncode = 'CONVERT_OPPORTUNITY_TO_RFQ';

delete
from permission  where code = 'CONVERT_OPPORTUNITY_TO_RFQ';

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode)
		values ('CONVERT_OPPORTUNITY_TO_RFQ',   'CRM', false, 'Convert Opportunity to RFQ', 10, (select id from permission where code = 'CRM_OPPORTUNITIES_LIST'), false, 'OPPORTUNITY_TRACKING');


insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_RFQ', 'ALLOW', 'DR');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_RFQ', 'ALLOW', 'ADMIN');
insert into "anv".rolepermission (permissioncode, access, rolecode)
                          values ('CONVERT_OPPORTUNITY_TO_RFQ', 'ALLOW', 'SALESMAN');