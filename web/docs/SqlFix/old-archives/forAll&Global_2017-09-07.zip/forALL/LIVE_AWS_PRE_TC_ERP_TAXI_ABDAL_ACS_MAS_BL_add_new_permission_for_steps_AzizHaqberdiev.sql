update permission set sorder = 1 where code = 'HRMS_ONBOARDING_STEP_LIST' and parent = (select id from permission where code ='HRMS_ONBOARDING_MANAGEMENT');
update permission set sorder = 2 where code = 'HRMS_ONBOARDING_LIST' and parent = (select id from permission where code ='HRMS_ONBOARDING_MANAGEMENT');

insert into permission (code, context, ismainmenu, name, sorder, parent, iscore, modulecode) values('HRMS_EMPLOYEE_STEPS', 'HRMS', false, 'HRMS Employee Steps', 3, (select id from permission where code ='HRMS_ONBOARDING_MANAGEMENT'), false, 'ONBOARDING');

insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_STEPS', 'ADMIN','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_STEPS', 'DR','ALLOW');
insert into "anv".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_STEPS', 'HR','ALLOW');

insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_STEPS', 'ADMIN','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_STEPS', 'DR','ALLOW');
insert into "0".rolepermission (permissioncode, rolecode, access) values('HRMS_EMPLOYEE_STEPS', 'HR','ALLOW');