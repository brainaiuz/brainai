



delete from permission where code = 'PM_TASKS_MEMBERS_INVOLVED';

delete from "anv".rolepermission where permissioncode = 'PM_TASKS_MEMBERS_INVOLVED';

delete from "0".rolepermission where permissioncode = 'PM_TASKS_MEMBERS_INVOLVED';

