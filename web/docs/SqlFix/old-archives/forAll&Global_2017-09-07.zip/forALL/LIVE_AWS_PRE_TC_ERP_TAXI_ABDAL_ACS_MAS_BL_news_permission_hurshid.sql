
update permission set name='Show all news'  where code='HRMS_COMPANY_NEWS_LIST';