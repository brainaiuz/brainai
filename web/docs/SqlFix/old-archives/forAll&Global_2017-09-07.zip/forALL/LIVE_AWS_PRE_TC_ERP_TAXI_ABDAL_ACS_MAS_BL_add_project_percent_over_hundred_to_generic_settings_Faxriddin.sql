
//Hammaga emas Faqat suralgan companylarga uriladi!!!

insert into "anv".genericSettings (key,value) values('PROJECT_PERCENT_OVER_HUNDRED', 'YES');
