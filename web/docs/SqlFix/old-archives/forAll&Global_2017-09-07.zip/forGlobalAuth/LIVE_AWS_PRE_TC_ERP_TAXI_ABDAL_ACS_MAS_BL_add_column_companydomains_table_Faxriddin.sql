ALTER TABLE companydomains ADD COLUMN dynamicStatus boolean;
ALTER TABLE companydomains ALTER COLUMN dynamicStatus SET DEFAULT false;