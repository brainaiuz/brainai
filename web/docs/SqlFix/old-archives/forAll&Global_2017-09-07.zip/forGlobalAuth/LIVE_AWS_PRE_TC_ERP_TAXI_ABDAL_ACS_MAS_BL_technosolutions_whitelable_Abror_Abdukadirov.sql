INSERT INTO hostbasedsetting(
emlfiledirectory, facebookapikey, facebookappid,
facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
googleconsumerkey,
googlesignaturekey, hostname, isliveenv, linkedinapikey,

linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
productname, logoimage, helphost, email,
skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
productcompanyname, issslsupported, defaultlocale, massmailparamsfilename,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
wikiurl, recaptcha_pubkey, recaptcha_privkey)
VALUES (
'/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
null, null, null,
'app.passionerp.com',
null, 'app.passionerp.com', TRUE, null,

null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
'passionerp', '/customisation/passionerp/images/logo.png', 'passionerp.com', 'support@passionerp.com',
'passionerp', '0096265833183' , 'P.O.Box: 114056 Amman – 11814 Jordan Mecca Street, Mecca Mall Entrance, Hijawi Building, Office# 204', '/customisation/passionerp/images/logo.png', 'passionerp.com', 'passionerpmail.properties',
'Passion for websites management', false, 'en','passionerpmassmailler.properties',
'khalid.alkurdi@gmail.com', null, 14, 'workforce', null,
null, null, null
);

INSERT INTO hostbasedsetting(
emlfiledirectory, facebookapikey, facebookappid,
facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
googleconsumerkey,
googlesignaturekey, hostname, isliveenv, linkedinapikey,

linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
productname, logoimage, helphost, email,
skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
productcompanyname, issslsupported, defaultlocale, massmailparamsfilename,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
wikiurl, recaptcha_pubkey, recaptcha_privkey)
VALUES (
'/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
null, null, null,
'aws.passionerp.com',
null, 'aws.passionerp.com', TRUE, null,

null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
'passionerp', '/customisation/passionerp/images/logo.png', 'passionerp.com', 'support@passionerp.com',
'passionerp', '0096265833183' , 'P.O.Box: 114056 Amman – 11814 Jordan Mecca Street, Mecca Mall Entrance, Hijawi Building, Office# 204', '/customisation/passionerp/images/logo.png', 'passionerp.com', 'passionerpmail.properties',
'Passion for websites management', false, 'en','passionerpmassmailler.properties',
'khalid.alkurdi@gmail.com', null, 14, 'workforce', null,
null, null, null
);