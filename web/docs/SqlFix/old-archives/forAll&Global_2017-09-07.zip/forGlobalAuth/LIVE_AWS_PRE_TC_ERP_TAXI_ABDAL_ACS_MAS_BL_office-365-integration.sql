-- Office Auth Token

CREATE TABLE office365authtoken
(
  id           SERIAL                      NOT NULL,
  userId       INTEGER                     NOT NULL,
  companyId    INTEGER                     NOT NULL,

  objectId     CHARACTER VARYING(255)      NOT NULL,
  expiresOn    TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  accessToken  text                        NOT NULL,
  refreshToken text                        NOT NULL,

  CONSTRAINT office365authtoken_pkey PRIMARY KEY (id),
  CONSTRAINT office365authtoken_fk FOREIGN KEY (userId)
  REFERENCES userauth (id) MATCH SIMPLE
  ON UPDATE NO ACTION ON DELETE CASCADE
) WITH (
OIDS = FALSE
);

ALTER TABLE office365authtoken OWNER TO wftauth;

-- Office Secret Code

CREATE TABLE office365secretcode
(
  id          SERIAL                 NOT NULL,
  authTokenId INTEGER                NOT NULL,
  email       CHARACTER VARYING(255) NOT NULL,
  secretCode  CHARACTER VARYING(255) NOT NULL,

  CONSTRAINT office365secretcode_pkey PRIMARY KEY (id),
  CONSTRAINT office365secretcode_fk FOREIGN KEY (authTokenId)
  REFERENCES office365authtoken (id) MATCH SIMPLE
  ON UPDATE NO ACTION ON DELETE CASCADE
) WITH (
OIDS = FALSE
);

ALTER TABLE office365secretcode OWNER TO wftauth;

-- Office User

CREATE TABLE office365user
(
  id        SERIAL  NOT NULL,
  userId    INTEGER NOT NULL,
  companyId INTEGER NOT NULL,
  objectId  VARCHAR NOT NULL,

  CONSTRAINT office365user_pkey PRIMARY KEY (id),
  CONSTRAINT office365user_fk FOREIGN KEY (userId)
  REFERENCES userauth (id) MATCH SIMPLE
  ON UPDATE NO ACTION ON DELETE CASCADE
) WITH (
OIDS = FALSE
);

ALTER TABLE office365user OWNER TO wftauth;