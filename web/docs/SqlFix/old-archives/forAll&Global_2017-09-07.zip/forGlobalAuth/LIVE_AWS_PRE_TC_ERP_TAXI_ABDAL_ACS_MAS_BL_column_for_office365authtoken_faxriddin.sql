--office-365-integration.sql dan kiyin urilsin

ALTER TABLE office365authtoken ADD COLUMN issharepoint boolean;
ALTER TABLE office365authtoken ALTER COLUMN issharepoint SET DEFAULT false;

ALTER TABLE office365authtoken ADD COLUMN siteurl character varying(255);