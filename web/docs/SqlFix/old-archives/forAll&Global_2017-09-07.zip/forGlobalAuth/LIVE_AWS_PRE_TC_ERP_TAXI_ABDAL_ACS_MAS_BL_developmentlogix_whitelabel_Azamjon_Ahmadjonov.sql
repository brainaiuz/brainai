INSERT INTO hostbasedsetting(
emlfiledirectory, facebookapikey, facebookappid,
facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
googleconsumerkey,
googlesignaturekey, hostname, isliveenv, linkedinapikey,

linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
productname, logoimage, helphost, email,
skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
productcompanyname, issslsupported, defaultlocale, massmailparamsfilename,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
wikiurl, recaptcha_pubkey, recaptcha_privkey)
VALUES (
'/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
null, null, null,
'app.kpi.developmentlogix.com',
null, 'app.kpi.developmentlogix.com', TRUE, null,

null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
'developmentlogix', '/customisation/developmentlogix/images/logo.png', 'developmentlogix.com', 'rasibkhan@developmentlogix.com',
'azeem_zaheer', '+92 321 7177 410' , 'Development Logix 473/0 - New Iqbal Park Lahore Cantt Pakistan', '/customisation/developmentlogix/images/logo.png', 'developmentlogix.com', 'developmentlogixmail.properties',
'Developmentlogix for websites management', false, 'en','developmentlogixmassmailler.properties',
null, null, 14, 'workforce', null,
null, null, null
);

INSERT INTO hostbasedsetting(
emlfiledirectory, facebookapikey, facebookappid,
facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
googleconsumerkey,
googlesignaturekey, hostname, isliveenv, linkedinapikey,

linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
productname, logoimage, helphost, email,
skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
productcompanyname, issslsupported, defaultlocale, massmailparamsfilename,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
wikiurl, recaptcha_pubkey, recaptcha_privkey)
VALUES (
'/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
null, null, null,
'aws.kpi.developmentlogix.com',
null, 'aws.kpi.developmentlogix.com', TRUE, null,

null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
'developmentlogix', '/customisation/developmentlogix/images/logo.png', 'developmentlogix.com', 'rasibkhan@developmentlogix.com',
'azeem_zaheer', '+92 321 7177 410' , 'Development Logix 473/0 - New Iqbal Park Lahore Cantt Pakistan', '/customisation/developmentlogix/images/logo.png', 'developmentlogix.com', 'developmentlogixmail.properties',
'Developmentlogix for websites management', false, 'en','developmentlogixmassmailler.properties',
null, null, 14, 'workforce', null,
null, null, null
);