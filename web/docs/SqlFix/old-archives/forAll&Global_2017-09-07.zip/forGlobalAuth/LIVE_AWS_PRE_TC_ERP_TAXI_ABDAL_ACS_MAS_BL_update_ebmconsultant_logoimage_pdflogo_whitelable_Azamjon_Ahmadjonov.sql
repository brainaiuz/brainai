UPDATE hostbasedsetting
SET logoimage = '/customisation/ebmc/images/logo.png', pdflogo = '/customisation/ebmc/images/logo.png' WHERE hostname = 'aws.ebmconsultant.com';

UPDATE hostbasedsetting
SET logoimage = '/customisation/ebmc/images/logo.png', pdflogo = '/customisation/ebmc/images/logo.png' WHERE hostname = 'app.ebmconsultant.com';