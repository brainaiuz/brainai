INSERT INTO hostbasedsetting(
emlfiledirectory, facebookapikey, facebookappid,
facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
googleconsumerkey,
googlesignaturekey, hostname, isliveenv, linkedinapikey,

linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
productname, logoimage, helphost, email,
skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
productcompanyname, issslsupported, defaultlocale, massmailparamsfilename,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
wikiurl, recaptcha_pubkey, recaptcha_privkey, oauth2consumerkey, oauth2consumersecret)
VALUES (
'/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
null, null, null,
'app.ebmconsultant.com',
null, 'app.ebmconsultant.com', TRUE, null,

null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
'EBMC', '/customisation/ebmc/images/logo.png', 'ebmconsultant.com', 'ebmcit@gmail.com',
'uddhap', '009714-2087777 009714-2087800' , 'Emirates Business and Management Consultant 1st Floor, Nasser Lootha Building, Above Ashrafi Restaurant & ,
Karachi Darbar Restaurant Building, Near crossing of Dubai Cargo Village, Next to Aramex , Dubai Airport Road Al Garhoud, Deira, Dubai, UAE',
 '/customisation/ebmc/images/logo.png', 'ebmconsultant.com', 'embcmail.properties',
'EBMC for websites management', false, 'en','embcmassmailler.properties',
'ebmconlineservice@gmail.com', null, 14, 'workforce', null,
null, null, null, '1008254142323-2gtdg57k2g4antb0oblk2umr1k27amcl.apps.googleusercontent.com',
'VdYLM4ZTGuECOFsxQ7gxi9qt'
);

INSERT INTO hostbasedsetting(
emlfiledirectory, facebookapikey, facebookappid,
facebooksecret, googleappsconsumerkey, googleappsconsumersecret,
googleconsumerkey,
googlesignaturekey, hostname, isliveenv, linkedinapikey,

linkedinsecret, liveidappid, liveidsecret, projectrootpath, solrurl,
productname, logoimage, helphost, email,
skype, phone, address, pdflogo, defaultfromname, mailparamsfilename,
productcompanyname, issslsupported, defaultlocale, massmailparamsfilename,
paypalaccount, vat, freetrialdays, defaulttheme, currencycode,
wikiurl, recaptcha_pubkey, recaptcha_privkey, oauth2consumerkey, oauth2consumersecret)
VALUES (
'/mnt/webapps/projects/app.workforcetrack.com/ROOT', null, null,
null, null, null,
'aws.ebmconsultant.com',
null, 'aws.ebmconsultant.com', TRUE, null,

null, null, null,'/mnt/webapps/projects/app.workforcetrack.com/ROOT', 'http://solr2.workforcetrack.com:8080/solr/',
'EBMC', '/customisation/ebmc/images/logo.png', 'ebmconsultant.com', 'ebmcit@gmail.com',
'uddhap', '009714-2087777 009714-2087800' , 'Emirates Business and Management Consultant 1st Floor, Nasser Lootha Building, Above Ashrafi Restaurant & ,
Karachi Darbar Restaurant Building, Near crossing of Dubai Cargo Village, Next to Aramex , Dubai Airport Road Al Garhoud, Deira, Dubai, UAE',
 '/customisation/ebmc/images/logo.png', 'ebmconsultant.com', 'embcmail.properties',
'EBMC for websites management', false, 'en','embcmassmailler.properties',
'ebmconlineservice@gmail.com', null, 14, 'workforce', null,
null, null, null, '1008254142323-2gtdg57k2g4antb0oblk2umr1k27amcl.apps.googleusercontent.com',
'VdYLM4ZTGuECOFsxQ7gxi9qt'
);
