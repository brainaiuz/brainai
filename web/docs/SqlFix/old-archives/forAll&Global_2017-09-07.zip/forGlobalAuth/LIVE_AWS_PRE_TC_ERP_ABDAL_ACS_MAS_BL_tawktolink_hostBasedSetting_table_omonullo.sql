-- GLOBAL SCHEMA --GLOBAL SCHEMA --GLOBAL SCHEMA --GLOBAL SCHEMA --GL
ALTER TABLE public.hostbasedsetting ADD tawktolink VARCHAR(255) NULL;

update hostbasedsetting set tawktolink = '589b32efda22730aacba2e54' where hostname = 'aws.kpi.com';